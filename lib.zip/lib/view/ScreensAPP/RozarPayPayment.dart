import 'package:flutter/material.dart';
import 'package:nin2byo2i/Common/ThemeColor.dart';
import 'package:nin2byo2i/Common/colo_extension.dart';
import 'package:nin2byo2i/Controller/user_profile_controller.dart';
import 'package:nin2byo2i/Language/localization/Language/languages.dart';
import 'package:nin2byo2i/custom%20widgets/sized_box.dart';
import 'package:nin2byo2i/view/ScreensAPP/CartForOrder.dart';
import 'package:nin2byo2i/view/ScreensAPP/OrderHistory.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

//payment page and sddress filling page
class PaymentPage extends StatefulWidget {
  final Map<String, dynamic> paymentData;

  PaymentPage({required this.paymentData});

  @override
  _PaymentPageState createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  late Razorpay _razorpay;
  TextEditingController _amountController = TextEditingController();
  final UserProfileController _controller = UserProfileController();
  late String address, phoneNumnber;
  late String pinCode, postOffice, state, city;
  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    _razorpay.clear();
    _amountController.dispose();
    super.dispose();
  }

  Future<void> _handlePaymentSuccess(PaymentSuccessResponse response) async {
    Map<String, dynamic> paymentData = {
      "paymentId": "${response.paymentId}",
      "amount": int.parse(widget.paymentData['razorPay']['applicationFee']),
    };
    try {
      final data = await _controller.ValidatePayment(paymentData);

      // Handle successful response or further processing if needed
      SharedPreferences prefs = await SharedPreferences.getInstance();

      // Delete the 'cartItems' key
      prefs.remove('cartItems');
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => OrderHistoryPage()),
      );
      // Navigator.push(
      //   context,
      //   MaterialPageRoute(
      //     builder: (context) => OrderHistoryPage(),
      //   ),
      // );
    } catch (error) {
      // Handle the exception and show an alert box
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: ThemeManager.themelightColor,
            title: Text(
              Languages.of(context)!.error,
              style: TextStyle(color: ThemeManager.themeText),
            ),
            content: Text(
              "${Languages.of(context)!.errorOccurred}$error",
              style: TextStyle(color: ThemeManager.themeText),
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text(
                  Languages.of(context)!.ok,
                  style: TextStyle(color: ThemeManager.themeText),
                ),
              ),
            ],
          );
        },
      );
    }

    // if (mounted) {
    //   // OredrIdRozarPay = data;

    //   print("order id is  fbfgjhfgjgfjfjg ");
    // }
    // Handle payment success
    print("Payment Success: ${response.paymentId}");
    // You can navigate to a success page or perform other actions
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    // Handle payment failure
    print("Payment Error: ${response.message}");
    // You can show an error message or perform other actions
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    // Handle external wallet payments
    print("External Wallet: ${response.walletName}");
    // You can perform actions for external wallet payments
  }

  void _startPayment() {
    var options = {
      'key': widget.paymentData['razorPay']['secretKey'],
      'amount': int.parse(widget.paymentData['razorPay']['applicationFee']),
      'name': widget.paymentData['razorPay']['merchantName'],
      'description': widget.paymentData['razorPay']['purchaseDescription'],
      'prefill': {
        'contact': '',
        'email': widget.paymentData['razorPay']['customerEmail'],
      },
      'external': {
        'wallets': ['paytm'],
      },
      'notes': {
        'razorpayOrderId': widget.paymentData['razorPay']['razorpayOrderId'],
        'OrderIdNIN': widget.paymentData['razorPay']['notes'],
        'userEmail': widget.paymentData['razorPay']['customerEmail'],
        'address':
            "$address ,City : $city ,State : $state,Post Office: $postOffice ,PinCode: $pinCode",
        'Contact': phoneNumnber
      },
    };

    try {
      print(
          "amount is ${int.parse(widget.paymentData['razorPay']['applicationFee'])}");
      _razorpay.open(options);
    } catch (e) {
      print("Error in starting Razorpay payment: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    String amount = widget.paymentData['razorPay']['applicationFee'].substring(
        0, widget.paymentData['razorPay']['applicationFee'].length - 2);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: ThemeManager.themeColor,
        centerTitle: true,
        elevation: 0,
        leading: InkWell(
          onTap: () {
            Navigator.pop(context);
          },
          child: Container(
            margin: EdgeInsets.all(MediaQuery.of(context).size.width * 0.02),
            height: MediaQuery.of(context).size.width * 0.1,
            width: MediaQuery.of(context).size.width * 0.1,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: ThemeManager.themelightColor,
              borderRadius: BorderRadius.circular(
                  MediaQuery.of(context).size.width * 0.025),
            ),
            child: Image.asset(
              "assets/img/black_btn.png",
              color: ThemeManager.themeText,
              width: MediaQuery.of(context).size.width * 0.0375,
              height: MediaQuery.of(context).size.width * 0.0375,
              fit: BoxFit.contain,
            ),
          ),
        ),
        title: Text(
          " Check and Pay",
          style: TextStyle(
              color: ThemeManager.themeText,
              fontSize: MediaQuery.of(context).size.width * 0.04,
              fontWeight: FontWeight.w700),
        ),
      ),
      backgroundColor: ThemeManager.themeColor,
      body: Padding(
        padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.04),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width * 0.5,
                  height: MediaQuery.of(context).size.height * 0.02,
                  child: Text(
                    'Add a new address',
                    style: TextStyle(
                      color: ThemeManager.themeText,
                      fontSize: MediaQuery.of(context).size.width * 0.04,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w700,
                      height: 0,
                    ),
                  ),
                ),
                Spacer(),
                Container(
                  width: MediaQuery.of(context).size.width * 0.05,
                  height: MediaQuery.of(context).size.width * 0.05,
                  decoration: ShapeDecoration(
                    color: Color(0xAA15B8FF),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                          MediaQuery.of(context).size.width * 0.115),
                    ),
                  ),
                  child: Icon(
                    Icons.star,
                    color: ThemeManager.themeText,
                  ),
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.0075,
                )
              ],
            ),
            SizedBox(height: MediaQuery.of(context).size.width * 0.05),
            Container(
              width: MediaQuery.of(context).size.width * 0.9,
              height: MediaQuery.of(context).size.height * 0.0443,
              decoration: ShapeDecoration(
                color: ThemeManager.themelightColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(
                      MediaQuery.of(context).size.width * 0.012),
                ),
              ),
              child: TextField(
                onChanged: (value) {
                  setState(() {
                    address = value;
                  });
                },
                decoration: InputDecoration(
                  labelText: 'Full Address',
                  filled: true,
                  labelStyle: TextStyle(
                    color: ThemeManager.themeText,
                  ),
                  hintStyle: TextStyle(
                    color: ThemeManager.themeText,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: ThemeManager.themeText,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: ThemeManager.themeText,
                    ),
                  ),
                ),
                style: TextStyle(
                  color: ThemeManager.themeText,
                ),
              ),
            ),
            SizedBox(height: MediaQuery.of(context).size.width * 0.025),
            Container(
              width: MediaQuery.of(context).size.width * 0.9,
              height: MediaQuery.of(context).size.height * 0.0443,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * 0.437,
                    height: MediaQuery.of(context).size.height * 0.0443,
                    decoration: ShapeDecoration(
                      color: ThemeManager.themelightColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                            MediaQuery.of(context).size.width * 0.012),
                      ),
                    ),
                    child: TextField(
                      onChanged: (value) {
                        setState(() {
                          pinCode = value;
                        });
                      },
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: 'PIN Code',
                        filled: true,
                        labelStyle: TextStyle(
                          color: ThemeManager.themeText,
                        ),
                        hintStyle: TextStyle(
                          color: ThemeManager.themeText,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: ThemeManager.themeText,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: ThemeManager.themeText,
                          ),
                        ),
                      ),
                      style: TextStyle(
                        color: ThemeManager.themeText,
                      ),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.437,
                    height: MediaQuery.of(context).size.height * 0.0443,
                    decoration: ShapeDecoration(
                      color: ThemeManager.themelightColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                            MediaQuery.of(context).size.width * 0.012),
                      ),
                    ),
                    child: TextField(
                      onChanged: (value) {
                        setState(() {
                          postOffice = value;
                        });
                      },
                      decoration: InputDecoration(
                        labelText: 'Post Office',
                        filled: true,
                        labelStyle: TextStyle(
                          color: ThemeManager.themeText,
                        ),
                        hintStyle: TextStyle(
                          color: ThemeManager.themeText,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: ThemeManager.themeText,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: ThemeManager.themeText,
                          ),
                        ),
                      ),
                      style: TextStyle(
                        color: ThemeManager.themeText,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: MediaQuery.of(context).size.width * 0.025),
            Container(
              width: MediaQuery.of(context).size.width * 0.9,
              height: MediaQuery.of(context).size.height * 0.0443,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * 0.437,
                    height: MediaQuery.of(context).size.height * 0.0443,
                    decoration: ShapeDecoration(
                      color: ThemeManager.themelightColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                            MediaQuery.of(context).size.width * 0.012),
                      ),
                    ),
                    child: TextField(
                      onChanged: (value) {
                        setState(() {
                          city = value;
                        });
                      },
                      // keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: 'City',
                        filled: true,
                        labelStyle: TextStyle(
                          color: ThemeManager.themeText,
                        ),
                        hintStyle: TextStyle(
                          color: ThemeManager.themeText,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: ThemeManager.themeText,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: ThemeManager.themeText,
                          ),
                        ),
                      ),
                      style: TextStyle(
                        color: ThemeManager.themeText,
                      ),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.437,
                    height: MediaQuery.of(context).size.height * 0.0443,
                    decoration: ShapeDecoration(
                      color: ThemeManager.themelightColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                            MediaQuery.of(context).size.width * 0.012),
                      ),
                    ),
                    child: TextField(
                      onChanged: (value) {
                        setState(() {
                          state = value;
                        });
                      },
                      decoration: InputDecoration(
                        labelText: 'State',
                        filled: true,
                        labelStyle: TextStyle(
                          color: ThemeManager.themeText,
                        ),
                        hintStyle: TextStyle(
                          color: ThemeManager.themeText,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: ThemeManager.themeText,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: ThemeManager.themeText,
                          ),
                        ),
                      ),
                      style: TextStyle(
                        color: ThemeManager.themeText,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: MediaQuery.of(context).size.width * 0.025),
            Container(
              width: MediaQuery.of(context).size.width * 0.9,
              height: MediaQuery.of(context).size.height * 0.0443,
              decoration: ShapeDecoration(
                color: ThemeManager.themelightColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(
                      MediaQuery.of(context).size.width * 0.012),
                ),
              ),
              child: TextField(
                onChanged: (value) {
                  setState(() {
                    phoneNumnber = value;
                  });
                },
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                  labelText: 'Phone Number',
                  filled: true,
                  labelStyle: TextStyle(
                    color: ThemeManager.themeText,
                  ),
                  hintStyle: TextStyle(
                    color: ThemeManager.themeText,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: ThemeManager.themeText,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: ThemeManager.themeText,
                    ),
                  ),
                ),
                style: TextStyle(
                  color: ThemeManager.themeText,
                ),
              ),
            ),
            Spacer(),
            SizedBox(height: MediaQuery.of(context).size.width * 0.05),
            InkWell(
              onTap: _startPayment,
              child: Center(
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.9,
                  height: MediaQuery.of(context).size.height * 0.0544,
                  decoration: ShapeDecoration(
                    color: TColor.secondaryColor1,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                            MediaQuery.of(context).size.width * 0.012)),
                  ),
                  child: Center(
                      child: Text(
                    'Make Payment',
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  )),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
