import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:nin2byo2i/Repository/auth_repo.dart';
import 'package:nin2byo2i/models/user.dart';

class AuthProviderNin with ChangeNotifier {
  bool _isLoading = false;
  String _errorMessage = '';

  late String _verificationId;
  late User user;
  late MyUser myUser;
  final AuthRepo _authRepo = AuthRepo();
  final FirebaseAuth _auth = FirebaseAuth.instance;

  bool get isLoading => _isLoading;

  late String _email, _userName, _password;
  late String _phoneNumer;
  late String _firstName, _lastName, _gender;
  late DateTime _dateOfBirth;
  late String _weight, _heightInFeet, _heightInInch, workLevel;
  late String Latitude, Longitude;
  late String googlelink, facebooklink, linkdinlink, twitterlink;
  late String wakeupTime;

  String get phoneNumber => _phoneNumer;

  void setLatitude(String val) {
    Latitude = val;
  }

  void setworkLevel(String val) {
    workLevel = val;
  }

  void setwakeupTime(String val) {
    wakeupTime = val;
  }

  void setLongitude(String val) {
    Longitude = val;
  }

  void setGoogleLink(String val) {
    googlelink = val;
  }

  void setFacebookLink(String val) {
    facebooklink = val;
  }

  void setLinkedInLink(String val) {
    linkdinlink = val;
  }

  void setTwitterLink(String val) {
    twitterlink = val;
  }

  void setEmail(val) {
    _email = val;
  }

  void setUserName(val) {
    _userName = val;
  }

  void setPassword(val) {
    _password = val;
  }

  void setPhoneNumber(val) {
    _phoneNumer = val;
  }

  void setFirstName(val) {
    _firstName = val;
  }

  void setLastName(val) {
    _lastName = val;
  }

  void setGender(val) {
    _gender = val;
  }

  void setDateOfBirth(val) {
    _dateOfBirth = val;
  }

  void setWeight(val) {
    _weight = val;
  }

  void setHeightInFeet(val) {
    _heightInFeet = val;
  }

  void setHeightInInch(val) {
    _heightInInch = val;
  }

  void setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void setVerificationId(val) {
    _verificationId = val;
  }

  Future<void> signInWithGoogle() async {
    try {
      setLoading(true);
      final res = await _authRepo.signInWithGoogle();
      if (res != null) {
        user = res;
        print("User signed in with Google: $res");
      }
    } catch (e) {
      rethrow;
    } finally {
      setLoading(false);
    }
  }

  Future<void> verifyPhoneNumber(String number) async {
    setPhoneNumber(number);

    void verificationCompleted(AuthCredential credential) async {
      await signInWithCredential(credential);
    }

    void verificationFailed(FirebaseAuthException authException) {
      print('Verification failed: ${authException.message}');
      switch (authException.code) {
        case 'invalid-phone-number':
          _errorMessage = 'The provided phone number is not valid';
          break;
        case 'invalid-verification-code':
          _errorMessage = 'The verification code is invalid.';
          break;
        case 'session-expired':
          _errorMessage =
              'The SMS code has expired. Please resend the verification code to try again';
          break;
        case 'too-many-requests':
          _errorMessage =
              'We have blocked all requests from this device due to unusual activity. Try again later.';
          break;
        default:
          _errorMessage = 'An error occurred. Please try again later.';
      }
      setLoading(false);
    }

    void codeSent(String verificationId, [int? forceResendingToken]) {
      setVerificationId(verificationId);
      setLoading(false);
    }

    void codeAutoRetrievalTimeout(String verificationId) {
      _verificationId = verificationId;
    }

    await _auth.verifyPhoneNumber(
      phoneNumber: '+91$number',
      verificationCompleted: verificationCompleted,
      verificationFailed: verificationFailed,
      codeSent: codeSent,
      codeAutoRetrievalTimeout: codeAutoRetrievalTimeout,
      timeout: const Duration(seconds: 30),
    );
  }

  Future<void> signInWithCredential(AuthCredential credential) async {
    try {
      final UserCredential userCredential =
          await _auth.signInWithCredential(credential);
      final User? res = userCredential.user;
      if (res != null) {
        user = res;
        print('Phone number sign-in successful. User UID: ${user.uid}');
      } else {
        print('Phone number sign-in failed.');
      }
    } catch (e) {
      rethrow;
    }
  }

  Future<void> register() async {
    try {
      final res = await _authRepo.register(
          _userName, _phoneNumer, _email, _password, Longitude, Latitude);
    } catch (e) {
      rethrow;
    }
  }

  Future<void> login() async {
    try {
      final res = await _authRepo.login(_email, _password);
      myUser = MyUser.fromJson(res);
      AuthRepo.storeToken(myUser.token);
      AuthRepo.storeRefreshToken(myUser.Refreshtoken);
      print('Token is here: ${myUser.token}');
      print(res.toString());
    } catch (e) {
      print("Error during login: $e");
      rethrow;
    }
  }

  Future<void> updateProfile() async {
    try {
      print("Updating profile...");
      final res = await _authRepo.updateProfile(
          myUser.userId,
          myUser.token,
          _firstName,
          _lastName,
          _gender,
          _dateOfBirth.toString(),
          _weight,
          _heightInFeet,
          _heightInInch,
          googlelink,
          facebooklink,
          linkdinlink,
          twitterlink,
          workLevel,
          wakeupTime);
      print(res);
    } catch (e) {
      print("Error during profile update: $e");
      rethrow;
    }
  }
}

// import 'dart:io';

// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:nin2byo2i/Repository/auth_repo.dart';
// import 'package:nin2byo2i/models/user.dart';

// class AuthProviderNin with ChangeNotifier {
//   bool _isLoading = false;
//   String _errorMessage = '';

//   late String _verificationId;
//   late User user;
//   late MyUser myUser;
//   final AuthRepo _authRepo = AuthRepo();
//   final FirebaseAuth _auth = FirebaseAuth.instance;
//   bool get isLoading => _isLoading;

//   late String _email,
//       _userName,
//       _password,
//       _phoneNumer,
//       _firstName,
//       _lastName,
//       _gender;
//   late DateTime _dateOfBirth;
//   late String _weight, _heightInFeet, _heightInInch, workLevel;
//   late String Latitude, Longitude;
//   late String googlelink, facebooklink, linkdinlink, twitterlink;
//   late String wakeupTime;
//   String get phoneNumber => _phoneNumer;
//   void setLatitude(String val) {
//     Latitude = val;
//   }

//   void setworkLevel(String val) {
//     workLevel = val;
//   }

//   void setwakeupTime(String val) {
//     wakeupTime = val;
//   }

//   void setLongitude(String val) {
//     Longitude = val;
//   }

//   void setGoogleLink(String val) {
//     googlelink = val;
//   }

//   void setFacebookLink(String val) {
//     facebooklink = val;
//   }

//   void setLinkedInLink(String val) {
//     linkdinlink = val;
//   }

//   void setTwitterLink(String val) {
//     twitterlink = val;
//   }

//   void setEmail(val) {
//     _email = val;
//   }

//   void setUserName(val) {
//     _userName = val;
//   }

//   void setPassword(val) {
//     _password = val;
//   }

//   void setPhoneNumber(val) {
//     _phoneNumer = val;
//   }

//   void setFirstName(val) {
//     _firstName = val;
//   }

//   void setLastName(val) {
//     _lastName = val;
//   }

//   void setGender(val) {
//     _gender = val;
//   }

//   void setDateOfBirth(val) {
//     _dateOfBirth = val;
//   }

//   void setWeight(val) {
//     _weight = val;
//   }

//   void setHeightInFeet(val) {
//     _heightInFeet = val;
//   }

//   void setHeightInInch(val) {
//     _heightInInch = val;
//   }

//   void setLoading(bool value) {
//     _isLoading = value;
//     notifyListeners();
//   }

//   void setVerificationId(val) {
//     _verificationId = val;
//   }

//   Future<void> signInWithGoogle() async {
//     try {
//       print("googlelog 2");
//       setLoading(true);
//       final res = await _authRepo.signInWithGoogle();
//       if (res != null) {
//         user = res;

//         print("gfhfhfhfjfj here $res ");
//         // print("gfhfhfhfjfj here ${res.email} ${res.uid}");
//       }
//     } catch (e) {
//       // print(e.toString() + ' from auth');
//       // _errorMessage = 'Error occurred using Google Sign-In. Try again.';
//       // signOut();
//       rethrow;
//     } finally {
//       setLoading(false);
//     }
//   }

//   Future<void> verifyPhoneNumber(String number) async {
//     // setLoading(true);
//     setPhoneNumber(number);
//     // notifyListeners();
//     verificationCompleted(AuthCredential credential) {
//       // signInWithCredential(credential).then((value) async {
//       //   // await dataBase.registerUser(number);
//       // });
//     }

//     verificationFailed(FirebaseAuthException authException) {
//       print('Verification failed: ${authException.message}');
//       // _errorMessage = authException.code;
//       print(authException.code);
//       switch (authException.code) {
//         case 'invalid-phone-number':
//           _errorMessage = 'The provided phone number is not valid';
//           break;
//         case 'invalid-verification-code':
//           _errorMessage = 'The verification code is invalid.';
//           break;
//         case 'session-expired':
//           _errorMessage =
//               'The SMS code has expired. Please resend the verification code to try again';
//           break;
//         case 'too-many-requests':
//           _errorMessage =
//               'We have blocked all requests from this device due to unusual activity. Try again later.';
//           break;
//         default:
//           _errorMessage = 'An error occoured, Please try again later.';
//       }

//       setLoading(false);
//     }

//     codeSent(String verificationId, [int? forceResendingToken]) {
//       setVerificationId(verificationId);
//       setLoading(false);
//     }

//     codeAutoRetrievalTimeout(String verificationId) {
//       // setState(() {
//       _verificationId = verificationId;
//       // });
//     }

//     await _auth.verifyPhoneNumber(
//       phoneNumber: '+91$number',
//       verificationCompleted: verificationCompleted,
//       verificationFailed: verificationFailed,
//       codeSent: codeSent,
//       codeAutoRetrievalTimeout: codeAutoRetrievalTimeout,
//       timeout: const Duration(seconds: 30),
//     );
//   }

//   Future<void> signInWithCredential(AuthCredential credential) async {
//     try {
//       final UserCredential userCredential =
//           await _auth.signInWithCredential(credential);
//       final User? res = userCredential.user;
//       if (res != null) {
//         // User is signed in
//         user = res;

//         print('Phone number sign in successful. User UID: ${user.uid}');
//       } else {
//         // Sign in failed
//         print('Phone number sign in failed.');
//       }
//     } catch (e) {
//       rethrow;
//     }
//   }

//   Future<void> signUpWithEmailPassword() async {
//     try {
//       final credential =
//           await FirebaseAuth.instance.createUserWithEmailAndPassword(
//         email: _email,
//         password: _password,
//       );
//     } on FirebaseAuthException catch (e) {
//       if (e.code == 'weak-password') {
//         print('The password provided is too weak.');
//       } else if (e.code == 'email-already-in-use') {
//         print('The account already exists for that email.');
//       }
//     } catch (e) {
//       print(e);
//     }
//   }

//   Future<void> signInwithEmailPassword() async {
//     try {
//       setLoading(true);
//       // final credential = await FirebaseAuth.instance
//       //     .signInWithEmailAndPassword(email: _email, password: _password);
//       await login();
//     } on FirebaseAuthException catch (e) {
//       if (e.code == 'INVALID_LOGIN_CREDENTIALS') {
//         throw 'INVALID LOGIN CREDENTIALS';
//       }
//       if (e.code == 'user-not-found') {
//         print('No user found for that email.');
//         throw 'No user found for that email.';
//       } else if (e.code == 'wrong-password') {
//         print('Wrong password provided for that user.');
//         throw 'Wrong password provided for that user.';
//       }

//       throw 'An Error Occoured, Tay again';
//     } catch (e) {
//       print("Successful login respfrtgrronse: ${e}");
//       rethrow;
//     } finally {
//       setLoading(false);
//     }
//   }

//   Future<void> signInWithSmsCode(String code) async {
//     try {
//       setLoading(true);

//       // Ensure _verificationId is not null and _phoneNumber is set
//       if (_phoneNumer == null) {
//         throw FirebaseAuthException(
//           code: "verification-id-missing",
//           message:
//               "Verification ID or phone number is missing. Please restart the process.",
//         );
//       }

//       final AuthCredential credential = PhoneAuthProvider.credential(
//         verificationId: _verificationId,
//         smsCode: code,
//       );
//       await signInWithCredential(credential);

//       // myUser = await dataBase.signUpWithPhoneNumber(_phoneNumber!);
//       await signUpWithEmailPassword();
//       // await register();
//       await login();

//       await AuthRepo.saveNewUser();

//       // Successful sign-in
//     } on FirebaseAuthException catch (e) {
//       print("FirebaseAuthException - Code: ${e.code}, Message: ${e.message}");

//       if (e.code == 'invalid-verification-code') {
//         throw 'The verification code is invalid.';
//       } else if (e.code == 'user-disabled') {
//         throw "This user account has been disabled.";
//       } else if (e.code == 'session-expired') {
//         throw 'The SMS code has expired. Please resend the verification code to try again.';
//       } else {
//         throw 'An error occured. Please try again.';
//       }
//     } catch (e) {
//       print(e.toString());
//       rethrow;
//       // print("Error occurred: ${e.toString()}");
//     } finally {
//       setLoading(false);
//     }
//   }

//   Future<void> register() async {
//     try {
//       final res = await _authRepo.register(
//           _userName, _phoneNumer, _email, _password, Longitude, Latitude);
//     } catch (e) {
//       rethrow;
//     }
//   }

//   Future<void> login() async {
//     try {
//       final res = await _authRepo.login(_email, _password);
//       myUser = MyUser.fromJson(res);
//       AuthRepo.storeToken(myUser.token);
//       AuthRepo.storeRefreshToken(myUser.Refreshtoken);
//       print('token is here------${myUser.token}');
//       print(res.toString());
//     } catch (e) {
//       print("FDgbfhngjkhngmlnkghmngh $e");
//       rethrow;
//     }
//   }

//   Future<void> updateProfile() async {
//     try {
//       print("error cout here update call");
//       final res = await _authRepo.updateProfile(
//           myUser.userId,
//           myUser.token,
//           _firstName,
//           _lastName,
//           _gender,
//           _dateOfBirth.toString(),
//           _weight,
//           _heightInFeet,
//           _heightInInch,
//           googlelink,
//           facebooklink,
//           linkdinlink,
//           twitterlink,
//           workLevel,
//           wakeupTime);
//       print(res);
//     } catch (e) {
//       print(e.toString());
//       rethrow;
//     }
//   }
// }
