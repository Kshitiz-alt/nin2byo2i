import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:nin2byo2i/Common/appfontsize.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(GeocodeWidget());
}

class GeocodeWidget extends StatefulWidget {
  // location
  @override
  _GeocodeWidgetState createState() => _GeocodeWidgetState();
}

class _GeocodeWidgetState extends State<GeocodeWidget> {
  var locationMessage = '';
  late String latitude;
  late String longitude;

  // function for getting the current location
  // but before that you need to add this permission!
  void getCurrentLocation() async {
    var position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    var lat = position.latitude;
    var long = position.longitude;

    // passing this to latitude and longitude strings
    latitude = "$lat";
    longitude = "$long";
    print("Latitude: $lat and Longitude: $long");
    setState(() {
      locationMessage = "Latitude: $lat and Longitude: $long";
    });
  }

  // function for opening it in google maps

  void googleMap() async {
    String googleUrl =
        "https://www.google.com/maps/search/?api=1&query=$latitude,$longitude";

    if (await canLaunch(googleUrl)) {
      await launch(googleUrl);
    } else
      throw ("Couldn't open google maps");
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'User location application',
      theme: ThemeData(
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(
                Icons.location_on,
                size: 45.0,
                color: Colors.white,
              ),
              SizedBox(
                height: 20.0,
              ),
              Text(
                "Get User Location",
                style: TextStyle(
                  fontSize: AppFontSizes.extraLargeDefault,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(
                height: 30.0,
              ),
              Text(
                locationMessage,
                style: TextStyle(
                  color: Colors.white,
                ),
              ),
              SizedBox(
                height: 05.0,
              ),

              // button for taking the location
              ElevatedButton(
                  onPressed: () {
                    getCurrentLocation();
                  },
                  child: Text("get")),
              // FlatButton(
              //   color: Colors.white,
              //   onPressed: () {
              //     getCurrentLocation();
              //   },
              //   child: Text("Get User Location"),
              // ),
              ElevatedButton(
                onPressed: () {
                  googleMap();
                },
                child: Text("Open GoogleMap"),
              ),
              Text(
                "location is ${locationMessage}",
                style: TextStyle(color: Colors.amber),
              )
              // FlatButton(
              //   color: Colors.white,
              //   onPressed: () {
              //     googleMap();
              //   },
              //   child: Text("Open GoogleMap"),
              // ),
            ],
          ),
        ),
      ),
    );
  }
}
