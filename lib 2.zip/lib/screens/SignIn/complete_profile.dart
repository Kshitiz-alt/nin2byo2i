import 'package:flutter/cupertino.dart';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:nin2byo2i/Common/ThemeColor.dart';
import 'package:nin2byo2i/Common/colo_extension.dart';
import 'package:nin2byo2i/Controller/user_profile_controller.dart';
import 'package:nin2byo2i/Language/localization/Language/languages.dart';
import 'package:nin2byo2i/constants/assets.dart';
import 'package:nin2byo2i/custom%20widgets/button.dart';
import 'package:nin2byo2i/custom%20widgets/custom_textfield.dart';
import 'package:nin2byo2i/screens/SignIn/InstructionScreen.dart';
import 'package:nin2byo2i/screens/SignIn/login.dart';
import 'package:nin2byo2i/view/home/home_view.dart';
import 'package:provider/provider.dart';
import 'package:location/location.dart';
import '../../Providers/auth_provider.dart';
import 'package:nin2byo2i/Common/appfontsize.dart';

//complete profile page
class CompleteProfile extends StatefulWidget {
  static const routeName = '/completeProfile';
  const CompleteProfile({super.key});

  @override
  State<CompleteProfile> createState() => _CompleteProfileState();
}

class _CompleteProfileState extends State<CompleteProfile> {
  late String _email,
      _userName,
      _password,
      _phoneNumer,
      _firstName,
      _lastName,
      googlelink = '',
      facebooklink = '',
      linkdinlink = '',
      twitterlink = '',
      _gender = 'Male';
  String _activityLevel = '';
  Map<String, String> _activityDescriptions = {
    'Sedentary':
        'This category includes occupations with little to no physical movement throughout the day. People in these jobs spend most of their time sitting or lying down. Examples include office workers, teachers, and those in administrative roles.',
    'Moderate':
        'Individuals in this category engage in some level of physical activity, such as walking or light jogging, for around 30 minutes to an hour daily. Occupations like manual laborers, artisans, and some types of skilled workers fall into this category.',
    'Heavy':
        'This category comprises occupations involving regular and intense physical activity, such as running, cycling, or heavy lifting, for more than an hour each day. Examples include blacksmiths, miners, and construction workers.'
  };

  late DateTime _dateOfBirth;
  late String _weight, _heightInFeet, _heightInInch;
  final _formKey = GlobalKey<FormState>();
  final _controller = TextEditingController();
  late LocationData _currentLocation = LocationData.fromMap({
    "latitude": 0.0,
    "longitude": 0.0,
    // Add any other necessary properties here
  });
  int selectedGenderIndex = 0;
  final Map<int, String> genderOptions = {
    0: 'Male',
    1: 'Female',
  };
  TimeOfDay _selectedTime = TimeOfDay.now();
  late TimeOfDay selectedTime;
  String formattedTime = '';
  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: selectedTime,
    );
    if (picked != null && picked != selectedTime) {
      setState(() {
        selectedTime = picked;
        formattedTime = _formatTime(picked);
      });
    }
  }

  String _formatTime(TimeOfDay time) {
    final int hour = time.hour;
    final int minute = time.minute;
    final String formattedHour = hour.toString().padLeft(2, '0');
    final String formattedMinute = minute.toString().padLeft(2, '0');
    return '$formattedHour:$formattedMinute';
  }

  String convert12to24(String time12hr) {
    // Extract hours, minutes, and period (AM/PM)
    int hours = int.parse(time12hr.substring(0, 2));
    int minutes = int.parse(time12hr.substring(3, 5));
    String period = time12hr
        .substring(6, 8)
        .toUpperCase(); // Convert to uppercase for consistency

    // Handle special cases for 12 AM and 12 PM
    if (hours == 12) {
      hours = (period == "AM") ? 0 : 12;
    } else {
      hours = (period == "AM") ? hours : hours + 12;
    }

    // Format hours and minutes to 24-hour format
    String hours24 = hours.toString().padLeft(2, '0');
    String minutes24 = minutes.toString().padLeft(2, '0');

    // Return the formatted time
    return '$hours24:$minutes24';
  }

  final UserProfileController _controller1 = UserProfileController();

  @override
  void initState() {
    super.initState();
    _getLocation();
    selectedTime = TimeOfDay.now();
    formattedTime = _formatTime(selectedTime);
  }

  Future<void> _getLocation() async {
    try {
      var location = Location();
      var currentLocation = await location.getLocation();
      setState(() {
        _currentLocation = currentLocation;
      });
    } catch (e) {
      print("Error getting location: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // Returning false prevents the user from navigating back
        return false;
      },
      child: Scaffold(
        backgroundColor: ThemeManager.themeColor,
        body: SafeArea(
          child: SingleChildScrollView(
            child:
                Consumer<AuthProviderNin>(builder: (context, authProvider, _) {
              return Stack(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SvgPicture.asset(
                        Assets.complete,
                        fit: BoxFit.cover,
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      Text(
                        'Let’s complete your profile',
                        style: TextStyle(
                          color: ThemeManager.themeText,
                          fontSize: AppFontSizes.mediumDefault,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        'It will help us to know more about you!',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: ThemeManager.themeText,
                          fontSize: AppFontSizes.smallDefault,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      const SizedBox(
                        height: 6,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 24, vertical: 24),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            children: [
                              CustomTextField(
                                label: "First Name",
                                icon: Icons.person_2_outlined,
                                keyboardType: TextInputType.name,
                                onProgress: (String value) {
                                  _firstName = value;
                                },
                                validator: (value) {
                                  if (value != null && value.isEmpty) {
                                    return 'First Name is Required';
                                  }
                                  return null;
                                },
                              ),
                              const SizedBox(
                                height: 12,
                              ),
                              CustomTextField(
                                label: 'Last Name',
                                icon: Icons.person_2_outlined,
                                keyboardType: TextInputType.name,
                                onProgress: (String value) {
                                  _lastName = value;
                                },
                                validator: (value) {
                                  if (value != null && value.isEmpty) {
                                    return 'Last Name is Required';
                                  }
                                  return null;
                                },
                              ),
                              const SizedBox(
                                height: 12,
                              ),
                              SizedBox(
                                width:
                                    350, // Set the width to your desired value
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(
                                      20.0), // Adjust the radius value as needed
                                  child: CupertinoSlidingSegmentedControl(
                                    groupValue: selectedGenderIndex,
                                    thumbColor: TColor
                                        .primaryColor1, // Set the selected color to blue
                                    children:
                                        genderOptions.map((index, gender) {
                                      return MapEntry(
                                        index,
                                        Padding(
                                          padding: const EdgeInsets.all(12.0),
                                          child: Text(gender),
                                        ),
                                      );
                                    }),
                                    onValueChanged: (value) {
                                      setState(() {
                                        selectedGenderIndex = value!;
                                        _gender =
                                            genderOptions[selectedGenderIndex]!;
                                      });
                                    },
                                  ),
                                ),
                              ),
                              const SizedBox(
                                height: 12,
                              ),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(20),
                                child: TextFormField(
                                  controller: _controller,
                                  validator: (value) => value!.isEmpty
                                      ? 'Date of Birth is Required'
                                      : null,
                                  readOnly: true,
                                  onChanged: (value) {
                                    _dateOfBirth = DateTime.parse(value);
                                  },
                                  style: TextStyle(
                                    color: ThemeManager.themeText,
                                    fontSize: AppFontSizes.mediumDefault,
                                  ),
                                  decoration: InputDecoration(
                                      filled: true,
                                      fillColor: ThemeManager.themelightColor,
                                      labelText: 'Date of Birth',
                                      labelStyle: TextStyle(
                                        color: ThemeManager.themeText,
                                        fontSize: AppFontSizes.smallDefault,
                                        fontWeight: FontWeight.w400,
                                      ),
                                      prefixIcon: Icon(
                                        Icons.calendar_month,
                                        color: ThemeManager.themeText,
                                      ),
                                      border: InputBorder.none),
                                  onTap: () async {
                                    var date = await showDatePicker(
                                      context: context,
                                      initialDate: DateTime.now(),
                                      firstDate: DateTime(1900),
                                      lastDate: DateTime.now(),
                                      builder: (BuildContext context,
                                          Widget? child) {
                                        return Theme(
                                          data: ThemeData.dark().copyWith(
                                            primaryColor: ThemeManager
                                                .themelightColor, // Background color of the header

                                            colorScheme: ColorScheme.dark(
                                              primary: TColor
                                                  .primaryColor1, // Background color of the calendar
                                              onPrimary: Colors
                                                  .white, // Text color of the calendar
                                              surface: TColor
                                                  .primaryColor1, // Background color of the modal
                                              onSurface: Colors
                                                  .white, // Text color of the modal
                                            ),
                                            dialogBackgroundColor: Color.fromARGB(
                                                255,
                                                91,
                                                92,
                                                92), // Background color of the modal
                                            textButtonTheme:
                                                TextButtonThemeData(
                                              style: TextButton.styleFrom(
                                                primary: TColor
                                                    .primaryColor1, // Color of the "OK" button
                                              ),
                                            ),
                                          ),
                                          child: child!,
                                        );
                                      },
                                    );

                                    if (date != null) {
                                      // Calculate age based on selected date
                                      int age = DateTime.now()
                                              .difference(date)
                                              .inDays ~/
                                          365;

                                      // Check if age is within the valid range
                                      if (age >= 2 && age <= 100) {
                                        setState(() {
                                          _dateOfBirth = date;
                                          _controller.text =
                                              DateFormat('dd/MM/yyyy')
                                                  .format(date);
                                        });
                                      } else {
                                        // Show an error message for invalid age
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                              backgroundColor: Colors.white,
                                              duration: Duration(seconds: 2),
                                              content: Text(
                                                Languages.of(context)!
                                                    .ageMustBeBetween2And100Years,
                                                style: TextStyle(
                                                    color: Colors.red),
                                              )),
                                        );
                                      }
                                    }
                                  },
                                ),
                              ),
                              const SizedBox(
                                height: 12,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    flex: 5,
                                    child: CustomTextField(
                                      label: 'Your Weight in Kg',
                                      icon: Icons.speed,
                                      keyboardType: TextInputType.number,
                                      onProgress: (String value) {
                                        _weight = value;
                                      },
                                      validator: (value) {
                                        if (value != null && value.isEmpty) {
                                          return 'Weight is Required';
                                        }
                                        if (!RegExp(r'^\d*\.?\d*$')
                                            .hasMatch(value!)) {
                                          return 'Invalid input. \nPlease enter a\n valid number.';
                                        }
                                        int? weightcheck = int.tryParse(value);
                                        if (weightcheck != null &&
                                            weightcheck > 300) {
                                          return 'Weight cannot \nbe greater than\n 300 Kg.';
                                        }
                                        return null;
                                      },
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 20,
                                  ),
                                  Expanded(
                                    child: Container(
                                      width: 48,
                                      height: 48,
                                      decoration: ShapeDecoration(
                                        gradient: LinearGradient(
                                          begin: Alignment(-1.00, 0.08),
                                          end: Alignment(1, -0.08),
                                          colors: [
                                            TColor.primaryColor1,
                                            TColor.primaryColor2,
                                          ],
                                        ),
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(14),
                                        ),
                                      ),
                                      child: const Center(
                                          child: Text(
                                        'Kg',
                                        style: TextStyle(color: Colors.white),
                                      )),
                                    ),
                                  )
                                ],
                              ),
                              const SizedBox(
                                height: 12,
                              ),
                              Container(
                                padding: EdgeInsets.all(
                                    8.0), // Adjust padding for small size
                                margin: EdgeInsets.symmetric(
                                    vertical: 8.0), // Adjust margin if needed
                                // constraints: BoxConstraints(
                                //   maxWidth:
                                //       300.0, // Set a max width to control size
                                // ),
                                color: ThemeManager.themelightColor.withOpacity(
                                    0.4), // Set background color to grey
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment
                                      .start, // Align text to the start
                                  children: [
                                    Text(
                                      "Enter your height in feet and inches (e.g. 5 feet 9 inch)",
                                      style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600),
                                    ),
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: CustomTextField(
                                            label: 'Height(Ft.)',
                                            icon: Icons.height,
                                            keyboardType: TextInputType.number,
                                            onProgress: (String value) {
                                              _heightInFeet = value;
                                            },
                                            validator: (value) {
                                              if (value != null &&
                                                  value.isEmpty) {
                                                return 'Height in Feet Required';
                                              }
                                              if (!RegExp(r'^\d+$')
                                                  .hasMatch(value!)) {
                                                return 'Invalid input.\n Please enter digits \nonly without a period.';
                                              }
                                              int? heightInFeet =
                                                  int.tryParse(value);
                                              if (heightInFeet != null &&
                                                  heightInFeet > 10) {
                                                return 'Height cannot \nbe greater than\n 10 feet.';
                                              }
                                              return null;
                                            },
                                          ),
                                        ),
                                        const SizedBox(
                                          width: 20,
                                        ),
                                        Expanded(
                                          child: CustomTextField(
                                            label: 'Height(Inch)',
                                            icon: Icons.height,
                                            keyboardType: TextInputType.number,
                                            onProgress: (String value) {
                                              _heightInInch = value;
                                            },
                                            validator: (value) {
                                              if (value != null &&
                                                  value.isEmpty) {
                                                return 'Height in Inch Required';
                                              }
                                              if (!RegExp(r'^\d*\.?\d+$')
                                                  .hasMatch(value!)) {
                                                return 'Only numbers allowed';
                                              }
                                              // if (!RegExp(r'^\d+$')
                                              //     .hasMatch(value!)) {
                                              //   return 'Invalid input. Please enter digits only without a period.';
                                              // }
                                              // int? heightInInches =
                                              //     int.tryParse(value);
                                              // if (heightInInches != null &&
                                              //     heightInInches > 12) {
                                              //   return 'Height cannot be greater than 12 inches.';
                                              // }
                                              int? heightInInches =
                                                  int.tryParse(value);
                                              if (double.parse(value) > 12) {
                                                return 'Height cannot \nbe greater than\n 12 inches.';
                                              }
                                              return null;
                                            },
                                          ),
                                        ),
                                      ],
                                    ),

                                    // SizedBox(
                                    //     height: 8.0), // Add space between texts
                                    // Text(
                                    //   'Inches: Enter the number of inches (e.g., 9 for 9 inches). Make sure the number of inches is between 0 and 11.',
                                    //   style: TextStyle(fontSize: 10),
                                    // ),
                                  ],
                                ),
                              ),
                              const SizedBox(
                                height: 12,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Text(
                                    'Wake Up Time: $formattedTime',
                                    style: TextStyle(
                                        fontSize: AppFontSizes.largeDefault),
                                  ),
                                  ElevatedButton(
                                    onPressed: () {
                                      _selectTime(context);
                                    },
                                    child: Text(
                                      "Change",
                                      style: TextStyle(color: Colors.black),
                                    ),
                                    style: ElevatedButton.styleFrom(
                                      primary: TColor
                                          .primaryColor1, // Background color

                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(
                                            8), // Adjust the border radius to your preference
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              const SizedBox(
                                height: 12,
                              ),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(20.0),
                                child: Container(
                                  padding: EdgeInsets.all(8.0),
                                  color: ThemeManager.themelightColor,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 8.0, right: 8, top: 8),
                                        child: Text(
                                          '${Languages.of(context)!.ninTextHowActiveAreYou}?',
                                          style: TextStyle(
                                            fontSize:
                                                AppFontSizes.mediumDefault,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 20.0),
                                      RadioListTile(
                                        title: Text('Sedentary'),
                                        activeColor: TColor.primaryColor1,
                                        subtitle: Text(_activityDescriptions[
                                            'Sedentary']!),
                                        value: 'Sedentary',
                                        groupValue: _activityLevel,
                                        onChanged: (value) {
                                          setState(() {
                                            _activityLevel = value!;
                                          });
                                        },
                                      ),
                                      RadioListTile(
                                        title: Text('Moderate'),
                                        activeColor: TColor.primaryColor1,
                                        subtitle: Text(
                                            _activityDescriptions['Moderate']!),
                                        value: 'Moderate',
                                        groupValue: _activityLevel,
                                        onChanged: (value) {
                                          setState(() {
                                            _activityLevel = value!;
                                          });
                                        },
                                      ),
                                      RadioListTile(
                                        title: Text('Heavy'),
                                        activeColor: TColor.primaryColor1,
                                        subtitle: Text(
                                            _activityDescriptions['Heavy']!),
                                        value: 'Heavy',
                                        groupValue: _activityLevel,
                                        onChanged: (value) {
                                          setState(() {
                                            _activityLevel = value!;
                                          });
                                        },
                                      ),
                                      // SizedBox(height: 20.0),
                                      // Text(
                                      //   'Selected Activity Level: $_activityLevel',
                                      //   style: TextStyle(
                                      //     fontSize: AppFontSizes.mediumDefault.0,
                                      //   ),
                                      // ),
                                    ],
                                  ),
                                ),
                              ),
                              // const SizedBox(
                              //   height: 12,
                              // ),
                              // Padding(
                              //   padding: const EdgeInsets.all(8.0),
                              //   child: Text(
                              //     "Optional",
                              //     style: TextStyle(
                              //         fontSize: AppFontSizes.mediumDefault,
                              //         color: ThemeManager.themeText),
                              //   ),
                              // ),
                              // CustomTextField(
                              //   label: 'Facebook Link',
                              //   icon: Icons.link,
                              //   keyboardType: TextInputType.name,
                              //   onProgress: (String value) {
                              //     facebooklink = value;
                              //   },
                              //   // validator: (value) {
                              //   //   if (value != null && value.isEmpty) {
                              //   //     return 'Last Name is Required';
                              //   //   }
                              //   //   return null;
                              //   // },
                              // ),
                              // const SizedBox(
                              //   height: 12,
                              // ),
                              // CustomTextField(
                              //   label: 'Linkdin Link',
                              //   icon: Icons.link,
                              //   keyboardType: TextInputType.name,
                              //   onProgress: (String value) {
                              //     linkdinlink = value;
                              //   },
                              // ),
                              // const SizedBox(
                              //   height: 12,
                              // ),
                              // CustomTextField(
                              //   label: 'Twitter Link',
                              //   icon: Icons.link,
                              //   keyboardType: TextInputType.name,
                              //   onProgress: (String value) {
                              //     twitterlink = value;
                              //   },
                              // ),
                              // const SizedBox(
                              //   height: 12,
                              // ),
                              // CustomTextField(
                              //   label: 'Google Link',
                              //   icon: Icons.person_2_outlined,
                              //   keyboardType: TextInputType.name,
                              //   onProgress: (String value) {
                              //     googlelink = value;
                              //   },
                              // ),
                              const SizedBox(
                                height: 30,
                              ),
                              InkWell(
                                onTap: () async {
                                  try {
                                    final formKeyState = _formKey.currentState!;
                                    print(
                                        "Error getting location: Latitude: ${_currentLocation.latitude} Longitude: ${_currentLocation.longitude}");
                                    bool isValid =
                                        _formKey.currentState!.validate();
                                    if (!isValid) {
                                      showDialog(
                                        context: context,
                                        builder: (context) {
                                          return AlertDialog(
                                            title: Text('Error'),
                                            content: Text(
                                                'Please fill in all mandatory fields and provide correct information.'),
                                            actions: <Widget>[
                                              TextButton(
                                                onPressed: () {
                                                  Navigator.of(context).pop();
                                                },
                                                child: Text('OK'),
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    }
                                    if (formKeyState.validate()) {
                                      final authProvider =
                                          Provider.of<AuthProviderNin>(context,
                                              listen: false);
                                      authProvider.setFirstName(_firstName);
                                      authProvider.setLastName(_lastName);
                                      authProvider.setGender(_gender);
                                      authProvider.setDateOfBirth(_dateOfBirth);
                                      authProvider.setWeight(_weight);
                                      authProvider
                                          .setHeightInFeet(_heightInFeet);
                                      authProvider
                                          .setHeightInInch(_heightInInch);
                                      authProvider.setLinkedInLink(linkdinlink);
                                      authProvider
                                          .setFacebookLink(facebooklink);
                                      authProvider.setTwitterLink(twitterlink);
                                      authProvider.setGoogleLink(googlelink);
                                      authProvider.setworkLevel(_activityLevel);
                                      authProvider.setwakeupTime(formattedTime);
                                      // authProvider.setLongitude(
                                      //     _currentLocation.longitude.toString());
                                      // authProvider
                                      //     .setLatitude(_currentLocation.latitude.toString());

                                      await Provider.of<AuthProviderNin>(
                                              context,
                                              listen: false)
                                          .updateProfile();
                                      print("error cout here");
                                      // Future.delayed(Duration(seconds: 3));

                                      if (!mounted) return;
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                InstructionScreen()),
                                      );
                                      // Navigator.pushNamed(context, '/root');
                                    }
                                  } catch (e) {
                                    // debugPrint(e.toString());
                                    print("efdvgghfhgjghhgg");
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                            backgroundColor: Colors.black,
                                            duration: Duration(seconds: 2),
                                            content: Text(e.toString())));
                                  }
                                },
                                child: const CustomButton(
                                  text: 'Next >',
                                  isColored: true,
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  if (authProvider.isLoading)
                    Positioned.fill(
                      child: Container(
                        color: ThemeManager.themeText,
                        child: const Center(
                          child: CircularProgressIndicator(),
                        ),
                      ),
                    ),
                ],
              );
            }),
          ),
        ),
      ),
    );
  }
}
