import 'languages.dart';

class LanguageEn extends Languages {
  @override
  String get appName => "NIN2.0";

  @override
  String get labelWelcome => "Welcome";

  @override
  String get labelSelectLanguage => "Select language";

  @override
  String get labelInfo => "This is multi-languages demo application";

  @override
  // TODO: implement labelChangeLanguage
  String get labelChangeLanguage => "Change language";
  @override
  String get labelWelcomeBack => "Welcome back,";

  @override
  String get labelUnderweight => "You are underweight";

  @override
  String get labelNormalWeight => "You are normal weight";

  @override
  String get labelOverweight => "You are overweight";

  @override
  String get labelObese => "You are obese";

  @override
  String get labelViewMore => "View more";

  @override
  String get labelTodaySteps => "Today's steps";

  @override
  String get labelCheck => "Check";

  @override
  String get labelHealthData =>
      "Record my Blood Pressure / Blood glucose / SPO2";

  @override
  String get labelActivityStatus => "Activity status";

  @override
  String get labelHeartRate => "Heart rate";

  @override
  String get labelHeartRateValue => "78 BPM";

  @override
  String get labelMinutesAgo => "mins ago";

  @override
  String get labelWaterIntake => "My water intake ";

  @override
  String get labelLiters => "Liters";

  @override
  String get labelZeroLiters => "0 Liters";

  @override
  String get labelRealTimeGoal => "Real time, goal";

  @override
  String get labelCalories => "Calories burnt";

  @override
  String get labelCaloriesEarned => "Calories earned";

  @override
  String get labelFoodPlan => "Food plan";

  @override
  String get labelWorkoutProgress => "Workout progress";

  @override
  String get labelWeekly => "Weekly";

  @override
  String get labelMonthly => "Monthly";

  @override
  String get labelLatestWorkout => "Latest workout";

  @override
  String get labelSeeMore => "See more";
  String get labelBreakfast => "Breakfast";
  String get labelLunch => "Lunch";
  String get labelDinner => "Dinner";
  String get labelSnacks => "Snacks";
  String get labelTaken => "Taken";
  String get labelTarget => "Target";

  //profile

  String get labelProfile => "Profile";
  String get labelEdit => "Edit";
  String get labelUser => "User";
  String get labelProgram => "Lose a fat program";
  String get labelHeight => "Height";
  String get labelWeight => "Weight";
  String get labelAge => "Age";
  String get labelAccount => "Account";
  String get labelPersonalData => "Personal data";
  String get labelAchievement => "Achievement";
  String get labelActivityHistory => "Activity history";
//String get labelWorkoutProgress => "Workout Progress";
  String get labelNotification => "Notification";
  String get labelPopupNotification => "Pop-up notification";
  String get labelMensurationCycle => "Menstruation cycle";
  String get labelOther => "Other";
  String get labelContactUs => "Contact us";
  String get labelPrivacyPolicy => "Privacy policy";
  String get labelSetting => "Setting";
  String get labelFeedback => "Feedback";
  String get labelConfirmLogout => "Confirm logout";
  String get labelConfirmLogoutMessage => "Are you sure you want to log out?";
  String get labelLogout => "Logout";
  //select tab
  String get labelOptions => "Options";
  String get labelFoodTable => "Add food";
  String get labelTop10Food => "Top 10 foods";
  String get labelActivityTrack => "Activity tracker";
  String get labelsteptracker => "Step tracker";

  String get labelTodayTarget => "Water target";
  String get labelJoggingTrack => "Jogging track";
  String get labelMensurationTrack => "Menstruation track";
//String get labelFoodTable => "Food Table";
  String get labelPassword => "Change password";
  String get labelDarkMode => "Try dark mode ";
  String get labelconectWatch => "Connect watch";
  @override
  String get labelSleep => "Sleep ";
  @override
  String get labelBookStore => " Book store";
  @override
  String get labelSearchBooks => "Search books";
  @override
  String get labelPrice => "Price";
  @override
  String get labelAddToCart => "Add to cart";
  @override
  String get labelAuthor => "Author";
  @override
  String get labelYear => "Year";
  @override
  String get labelQuantityAvailable => "Quantity available";
  @override
  String get labelCart => "Add to cart";
  @override
  String get labelMyOrders => "My orders";
  @override
  String get labelAllOrders => "All orders";
  @override
  String get labelOrderDetail => "Order detail";
  @override
  String get labelOrderId => "Order Id";
  @override
  String get labelOrdersInMyOrders => "Orders in my orders";
  @override
  String get labelItemsInMyOrders => "Items in my orders";
  @override
  String get labelTotal => "Total";
  @override
  String get labelTotalPrice => "Total price";
  @override
  String get labelCheckout => "Checkout";

  // Meal List
  @override
  String get labelMealList => "My diet";
  @override
  String get labelAnalyze => "Analyse";
  @override
  String get labelAddDish => "Add dish";
  @override
  String get labelTop10Foods => "Top 10 foods";
  @override
  String get labelRecentMeal => "Recent meal";
  @override
  String get labelAnalyzeIngredientsTaken => "Analyse food intake";

  // Nutrition Summary
  @override
  String get labelCarbs => "Carbohydrate";
  // @override
  // String get labelCalories => "Calories";
  @override
  String get labelFibers => "Total fibre";
  @override
  String get labelFats => "Fat";
  @override
  String get labelProteins => "Protein";
  @override
  String get labelCalcium => "Calcium";

  @override
  String get labelNiacinB3 => "Niacin (B3)";

  @override
  String get labelThiamineB1 => "Thiamine (B1)";

  @override
  String get labelIron => "Iron";

  @override
  String get labelZinc => "Zinc";

  @override
  String get labelFolatesB9 => "Folate (B9)";

  @override
  String get labelRiboflavinB2 => "Riboflavin (B2)";

  @override
  String get labelRetinolVitA => "Retinol (Vitamin A)";

  @override
  String get labelMagnesium => "Magnesium";

  @override
  String get labelTodaysNutritionSummary => "Today's nutrition summary";
  @override
  String get labelChangeGoal => "Change goal";
  @override
  String get labelIngredientsTaken => "Ingredients taken";
  @override
  String get labelIngredientsLeft => "Ingredients left";

  // Food Table
  // @override
  // String get labelFoodTable => "Food Table";
  // @override
  // String get labelBreakfast => "Breakfast";
  // @override
  // String get labelLunch => "Lunch";
  // @override
  // String get labelDinner => "Dinner";
  // @override
  // String get labelSnacks => "Snacks";
  @override
  String get labelTop10FoodsSleep => "Top 10 foods";
  @override
  String get labelFavouriteDishes => "Favourite dishes";

  // User Profile
  @override
  String get labelHelp => "Help";
  // @override
  // String get labelLogout => "Logout";
  // @override
  // String get labelWeight => "Weight";
  @override
  String get labelEmail => "Email";
  // @override
  // String get labelHeight => "Height";
  @override
  String get labelLinkedInProfileLink => "LinkedIn profile link";
  @override
  String get labelGoogleProfileLink => "Google profile link";
  @override
  String get labelFacebookProfileLink => "Facebook profile link";
  @override
  String get labelTwitterProfileLink => "Twitter profile link";
  @override
  String get labelName => "Name";
  @override
  String get labelPhoneNumber => "Phone No.";
  @override
  String get labelDateOfBirth => "D.O.B";
  @override
  String get labelBMI => "BMI";
  // @override
  // String get labelAge => "Age";

  // Contact Us
  @override
  String get labelMessage => "Message";
  @override
  String get labelSubmit => "Submit";
  @override
  String get labelCompanyContacts => "Company contacts";
  @override
  String get labelAddress => "Address";
  @override
  String get labelDirectorsEmail => "Director's email";
  @override
  String get labelFax => "FAX";

  // Settings
  @override
  String get labelResetPassword => "Reset password";
  // @override
  // String get labelFeedback => "Feedback";
  @override
  String get labelPleaseProvideFeedback => "Please provide your feedback";
  @override
  String get labelEnterYourFeedbackHere => "Enter your feedback here";
  @override
  String get labelSubmitFeedback => "Submit feedback";

  // Credits
  // @override
  // String get labelContactUs => "Contact Us";
  @override
  String get labelDevelopmentTeam => "Development team";
  @override
  String get labelAcknowledgments => "Acknowledgments";
  @override
  String get labelPartnerships => "Partnerships";

  // Mobile
  @override
  String get labelSearchComponents => "Search components";
  @override
  String get labelSearchComponentsHere => "Search components here";
  @override
  String get lablelDishName => 'Dish name';
  @override
  String get labelCredits => 'Credits';
  @override
  String get labelShareAppButton => "Share";
  @override
  String get labelShareApp =>
      "Scan the QR Code with a barcode scanner app and download App";
  // New translations
  @override
  String get labelConnectedWatch => "Connected watch is";
  @override
  String get labelDisconnect => "Disconnect";
  @override
  String get labelFitbit => "Fitbit";
  @override
  String get labelGoogleFit => "Google Fit";
  @override
  String get labelAppleWatch => "Apple watch";
  @override
  String get labelSamsungSmartWatch => "Samsung smart watch";
  @override
  String get labelBookDetails => "Book details";
  @override
  String get labelDeliveryDate => "Delivery date";
  @override
  String get labelOrderDate => "Order date";
  @override
  String get labelAnalyseIngredientsTaken => "Analyse food intake";
  @override
  String get labelAddDishIngredients => "Add dish ingredients";
  @override
  String get labelIngredientName => "Ingredient name";
  @override
  String get labelEnterIngredientName => "Enter an ingredient name";
  @override
  String get labelIngredientQuantity => "Ingredient quantity";
  @override
  String get labelEnterIngredientQuantity => "Enter ingredient quantity";
  @override
  String get labelAdd => "Add";
  @override
  String get labelSave => "Save";
  @override
  String get labelwatch => "watch";

  //
  @override
  String get labelBloodOxygenHeart =>
      'Measure vital signs and track overall health.';
  @override
  String get labelTop10FoodS =>
      'Discover recommended foods to maintain a healthy lifestyle.';
  @override
  String get labelWaterTrack =>
      'Set and achieve daily fitness hydration goals.';
  @override
  String get labelPersonalDetails =>
      'Manage and update personal information securely.';
  @override
  String get labelFeedbackS => 'Share your thoughts and suggestions with us.';
  @override
  String get labelContactUsS =>
      'Reach customer support and get in touch with us.';
  @override
  String get labelBMICalculator =>
      'Calculate your Body Mass Index for health insights.';
  @override
  String get labelBMRCalculator =>
      'Calculate your Basal Metabolic Rate for fitness planning.';
  @override
  String get labelRunningJoggingSteps =>
      'Track your running and jogging steps for a healthy lifestyle.';
  @override
  String get labelHealthyDietChart =>
      'Access a comprehensive chart for a healthy diet overview.';
  @override
  String get labelHealthyRecommendation =>
      'Receive personalized health recommendations.';
  @override
  String get labelSleepTracker =>
      'Track your sleep patterns and improve sleep quality.';
  @override
  String get labelSetReminder =>
      'Set reminders for health and fitness activities.';
  // @override
  // String get labelMenstruationCycle =>
  //     'Track and manage your menstrual cycle for better insights.';
  @override
  String get labelCSVDownload =>
      'Download your data in CSV format for easy analysis.';

  // New Headings
  @override
  String get headingBloodOxygenHeart => 'Blood | Oxygen';
  @override
  String get headingTop10Food => 'Top 10 foods';
  @override
  String get headingWaterTrack => 'Water tracker';
  @override
  String get headingPersonalDetails => 'Personal details';
  @override
  String get headingFeedback => 'Feedback';
  @override
  String get headingContactUs => 'Contact us';
  @override
  String get headingBMICalculator => 'BMI calculator';
  @override
  String get headingBMRCalculator => 'BMR calculator';
  @override
  String get headingRunningJoggingSteps => 'Running / Jogging / Steps';
  @override
  String get headingHealthyDietChart => 'Healthy diet chart';
  @override
  String get headingHealthyRecommendation => 'Healthy recommendation';
  @override
  String get headingSleepTracker => 'Sleep tracker';
  @override
  String get headingSetReminder => 'Set reminder';
  // @override
  // String get headingMenstruationCycle => 'Menstruation Cycle';
  @override
  String get headingCSVDownload => 'CSV download';

  // Water-related phrases
  @override
  String get labelWaterTarget => "Water target";
  // @override
  // String get labelTodayTarget => "Today Target";
  @override
  String get labelWaterGoal => "Water goal";
  // @override
  // String get labelWaterIntake => "Water Intake";
  @override
  String get labelWaterProgress => "Water progress";
  // @override
  // String get labelWeekly => "Weekly";
  @override
  String get labelDateWise => "Date wise";
  @override
  String get labelSun => "Sun";
  @override
  String get labelMon => "Mon";
  @override
  String get labelTue => "Tue";
  @override
  String get labelWed => "Wed";
  @override
  String get labelThu => "Thu";
  @override
  String get labelFri => "Fri";

  // BMI Calculator
  // @override
  // String get labelBMI => "BMI";
  @override
  String get labelEnterHeight => "Enter height (cm)";
  @override
  String get labelEnterWeight => "Enter weight (kg)";
  @override
  String get labelCalculateBMI => "Calculate BMI";

  // BMR Calculator
  @override
  String get labelMale => "Male";
  @override
  String get labelFemale => "Female";
  @override
  String get labelEnterAge => "Enter age";
  @override
  String get labelCalculateBMR => "Calculate BMR";
  @override
  String get labelBMR => "BMR";
  @override
  String get labelCaloriesPerDay => "calories / day";

  // Step Tracker
  @override
  String get labelStepsTracker => "Step tracker";
  @override
  String get labelRunningTracker => "Running tracker";
  @override
  String get labelAddStep => "Add step";
  @override
  String get labelSelectDate => "Select date";
  @override
  String get labelJoggingTracker => "Jogging tracker";
  @override
  String get labelCaloriesBurn => "Calories burnt";

  // Sleep Tracker
  @override
  String get labelSleepTarget => "Sleep target";
  @override
  String get labelTodaySleep => "Today sleep";
  @override
  String get labelSleepProgress => "Sleep progress";
  @override
  String get labelTotalSleep => "Total sleep";
  @override
  String get labelSleepGoal => "Sleep goal";
  @override
  String get labelSetNotification => "Set notification";
  @override
  String get labelStartTime => "Start time";
  @override
  String get labelEndTime => "End time";
  @override
  String get labelSelect => "Select";
  @override
  String get labelSat => "Sat";
  // @override
  // String get labelSave => "Save";
  @override
  String get labelStart => "Start";
  @override
  String get labelEnd => "End";
  @override
  String get labelType => "Type";
  @override
  String get labelIsConnected => "is connected";

  // @override
  // String get labelMensurationCycle => "Mensuration Cycle";

  @override
  String get labelTrackAndManage =>
      "Track and manage your menstruation cycle for better insights";

  @override
  String get labelMensurationStatus => "Menstruation status";

  @override
  String get labelDaysLength => "Days length";

  @override
  String get labelDay => "Day";

  @override
  String get labelNextDate => "Next date";

  @override
  String get labelLastPeriodStartDate => "Last period start date";

  @override
  String get labelAverageCycleLength => "Average cycle length";

  @override
  String get labelChange => "Change";

  // Common Messages
  @override
  String get messageSent => "Message sent";

  @override
  String get thankYouForContactingUs => "Thank you for contacting us!";

  @override
  String get alert => "Alert";

  @override
  String get fillInAllFields => "Please fill in all fields.";

  @override
  String get thankYouFeedbackSubmitted => "Your feedback has been submitted.";

  @override
  String get resetPassword => "Reset password";

  @override
  String get dishAdded => "Dish added!";

  @override
  String get dishAndIngredientsAddedSuccessfully =>
      "Successfully added dish and ingredients.";

  @override
  String get failed => "Failed";

  @override
  String get error => "Error";

  @override
  String get enterBloodGlucoseLevel => "Enter Blood glucose level in mg / dL";

  @override
  String get enterBloodPressureLevel => "Enter Blood pressure level in mmHg";

  @override
  String get enterHeartLevel =>
      "कृपया हृदय गति को बीट्स प्रति मिनट (बीपीएम) में दर्ज करें।";

  @override
  String get cancel => "Cancel";

  @override
  String get submit => "Submit";

  @override
  String get valueCannotBeGreaterThan100 => "Value cannot be greater than 100.";

  @override
  String get bloodStatusSubmittedSuccessfully =>
      "Blood status submitted successfully.";

  @override
  String get failedToSubmitBlood => "Failed to submit Blood.";

  @override
  String get enterHeartLevel1to100 =>
      "Please enter heart rate in beats per minute (BPM).";

  @override
  String get heartLevelSubmittedSuccessfully =>
      "Heart level submitted successfully.";

  @override
  String get enterOxygenSaturationLevel1to100 =>
      "Enter oxygen saturation level 1%-100%";

  @override
  String get oxygenLevelSubmittedSuccessfully =>
      "Oxygen level submitted successfully.";

  @override
  String get updateData => "Update data";

  @override
  String get selectLastPeriodStartDate => "Select last period start date";

  @override
  String get update => "Update";

  @override
  String get failedToFetchBooks => "Failed to fetch books. Please try again.";

  @override
  String get errorOccurred => "An error occurred:";

  @override
  String get invalidEndTime => "Invalid end time";

  @override
  String get chooseTimeWithin1Hour =>
      "Please choose a time within 1 hour of the start time.";

  @override
  String get notificationSaved => "Notification saved";

  @override
  String get notificationSetSuccessfully => "Notification set successfully.";

  @override
  String get thereIsSomeError => "There is some error.";

  @override
  String get watchDisconnected => "Watch disconnected";

  @override
  String get watchDisconnectedSuccessfully =>
      "The watch has been disconnected successfully.";

  @override
  String get addCup => "Add cup";

  @override
  String get numberOfCups => "Number of cups";

  @override
  String get addCupCapacityInMl => "Add cup capacity in ml";

  @override
  String get cupCapacitySubmittedSuccessfully =>
      "Cup capacity submitted successfully.";

  @override
  String get pleaseEnterValidValuesForAllFields =>
      "Please enter valid values for all fields.";

  @override
  String get enterWater => "Enter water";

  @override
  String get waterGoalLiters => "Water goal (Liters)";

  @override
  String get waterSubmittedSuccessfully => "Water goal submitted successfully.";

  @override
  String get addActivityData => "Add activity data";

  @override
  String get enterValue => "Enter value";

  @override
  String get addStepsData => "Add steps data";

  @override
  String get numberOfSteps => "Number of steps";

  @override
  String get stepsDataSubmittedSuccessfully =>
      "Steps data submitted successfully.";

  @override
  String get enterSleepTarget => "Enter sleep target";

  @override
  String get sleepTargetInHours => "Sleep target in hours";

  @override
  String get addYourSleepDuration => "Add your sleep duration";

  @override
  String get enterDurationInMinutes => "Enter duration in minutes:";

  @override
  String get add => "Add";

  @override
  String get ok => "ok";

  @override
  String get csvFileSavedTo => "CSV file saved to";

  @override
  String get ageMustBeBetween2And100Years =>
      "Age must be between 2 and 100 years";

  @override
  String get next => "Next";

  @override
  String get register => "Register";

  @override
  String get oopsSomethingWentWrong => "Oops! Something went wrong";

  @override
  String get errorFetchingMeals => "An error occurred while fetching meals:";

  @override
  String get reviewAddedSuccessfully => "Review added successfully!";

  @override
  String get failedToAddReview => "Failed to add review:";

  @override
  String get alreadyInCart => "Already in Cart";

  @override
  String get addedToCart => "Added to Cart";

  @override
  String get quantityNotBetween1And2 =>
      "Quantity is not more than 2 and less than 1";

  String get createcustomdish => "Create custom dish";
  String get quantityingram => "Quantity (gram)";
  String get labelCaloriestaken => 'Energy';
  String get mainlabelEarlyMorning => "Early morning";
  String get mainlabelMidMorning => "Mid morning";
  String get mainlabelEvening => "Evening";
  String get mainlabelBedtime => "Bedtime";
  String get mainlabelTimeSpentOn => "Time spent in different activities";
  String get mainlabelHealthCalculator => "Health calculator";
  String get mainlabelStepProgress => "Step progress";
  String get mainlabelRealTimeIntakes => "Real time intakes";
  String get mainlabelCaloriesBurnProgress => "Calories burnt progress";
  String get mainlabelCaloriesBurnBreakdown => "Calories burnt breakdown on";
  String get mainlabelHeartReportsTrends => "Heart report trends";
  String get mainlabelOxygenStatus => "Oxygen status";
  String get mainlabelNoRecord => "no record";
  String get mainlabelSystolicBloodPressure => "Systolic blood pressure";
  String get mainlabelMeasuredon => "measured on";
  String get mainlabelEnterBloodPressure => "Enter blood pressure";
  String get mainlabelBloodPressure => "Blood pressure";
  String get mainlabelDiastolicBloodPressure => "Diastolic blood pressure";
  String get mainlabelBloodGlucose => "Blood glucose";
  String get mainlabelHeartStatus => "Heart status";
  String get mainlabelAllExercise => "All exercise";
  String get mainlabelCleaningOrMopping => "cleaning or mopping";
  String get mainlabelGardening => "Gardening";
  String get mainlabelWatchingTV => "Watching tv";
  String get mainlabelCycling => "Cycling";
  String get mainlabelRunning => "Running";
  String get mainlabelWalking => "Walking";
  String get mainlabelShuttle => "Shuttle";
  String get mainlabelTableTennis => "Table tennis";
  String get mainlabelTennis => "Tennis";
  String get mainlabelVolleyBall => "Volley ball";
  String get mainlabelDancing => "Dancing";
  String get mainlabelFishing => "Fishing";
  String get mainlabelShopping => "Shopping";
  String get mainlabelTyping => "Typing";
  String get mainlabelSleeping => "Sleeping";
  String get mainlabelStanding => "Standing";
  String get mainlabelSitting => "Sitting";
  String get mainlabelClickToStartActivity => "click to start activity";
  String get mainlabelBMICalculator => "BMI calculator";
  String get mainlabelBMRCalculator => "BMR calculator";
  String get mainlabelDownloadActivityReportInCsv =>
      "download activity report in csv";
  String get mainlabelSelectStartDate => "Select start date";
  String get mainlabelSelectEndDate => "Select end date";
  String get mainlabelDownloadFile => "Download file";
  String get mainlabelDate => "Date";
  String get mainlabelValue => "Value";
  String get mainlabelLink => "link";
  String get mainlabelNoNotificationFound => "No notification found";
  String get mainlabelTotalNutritionTaken => "=Total nutrition taken";
  String get mainlabelSearchFood => "Search recipes";
  String get mainlabelSelectFromPersonalFood => "Select from personal recipes";
  String get mainlabelRecipeName => "Recipe name";
  String get mainlabelSelectDate => "select date";
  String get mainlabelNutrientOfAllIngredientsRaw =>
      "Nutrients in all ingredients (raw)";
  String get mainlabelNutrientsCompostionOfCookedWeight =>
      "Nutrient composition of cooked recipe ";
  String get mainlabelWantToEditThisRecipyFollowThe =>
      "Fixed recipe standardised by NIN. If you want to edit this recipe, follow the";
  String get mainlabelAddIngredientFrom => "Add ingredient from";
  String get mainlabelAddFromNutrientSpecifcFood =>
      "Add from nutrient specific food";
  String get mainlabelAddFromAllFoods => "Add from all foods";
  String get mainlabelNumberOfServing => "Number of servings";
  String get mainlabelWeightInG => "Weight (g)";
  String get mainlabelEditIngredientsWeight => "Edit ingredients weight";
  String get mainlabelIngredient => "Ingredient";
  String get mainlabelNewWeightInG => "New weight (g)";
  String get mainlabelCancel => "cancel";
  String get mainlabelUpdate => "update";
  String get mainlabelCookedWeightInG => "Cooked weight (g)";
  String get mainlabelEnterWeight => "Enter weight";
  String get mainlabelEditRecipy => "Edit recipe";
  String get mainlabelAlert => "alert";
  String get mainlabelToSeeNutritionCompositionPleaseEnterNoOfServing =>
      "To see the nutrient composition, please enter number of servings";
  String get mainlabelNutrirntsIn100CookedWeight =>
      "nutrients in 100 (cooked) weight";
  String get mainlabelSetNutritionTargetInG => "set nutrition target in grams";
  String get mainlabelFoodAnalyse => "Explore";
  String get mainlabelExploreTop10Foods => "Explore top 10 foods";
  String get mainlabelSearchCookedFood => "Search nutrients in recipes";
  String get mainlabelNutritionBasedOnEAR =>
      "Nutrient Requirement based on EAR";
  String get mainlabelDietDiary => "diet diary";
  String get mainlabelRecipes => "Recipes";
  String get mainlabelSearchByFoodName => "Search by food name";
  String get mainlabelAllRecipeOf100G => "all recipe of 100 grams";
  String get mainlabelNutritionRequirement => "nutrition requirement";
  String get mainlabelGender => "Gender";
  String get mainlabelParticulars => "particulars";
  String get mainlabelBodyWeight => "bodyweight";
  String get mainlabelDietaryDiaryReports => "Nutrient intake";
  String get mainlabelTotalNutritionTakenOn => "total nutrition taken on";
  String get mainlabelAttachImage => "Attach image";
  String get mainlabelFixedRecipy => "Fixed Recipe";
  String get mainlabelFoodInDetail => "Food in detail";
  String get TextAppNutrientsInMyFood => "Search nutrients in foods";
  String get TextAppMyActivity => "My Activity";
  String get TextAppToday => "today";
  String get TextAppMyNutrientRequirements => "My nutrient requirements";
  String get TextAppTotalNutrition => "Total nutrition";
  String get TextAppTaken => "Taken";
  String get TextAppRatings => "Ratings";
  String get TextAppSearchComponents => "Search components";
  String get TextAppTotalNutrientTaken => "My nutrient intake today";
  String get TextAppShareApp => "Share App";
  String get TextAppNoNotificationsFound => "No notifications found";
  String get TextAppConnectWatch => "Connect Watch";
  String get TextAppYourBMIIs => "Your BMI is";
  String get TextAppBMI => "BMI";
  String get TextAppBMICategories => "BMI Categories";
  String get TextAppUnderweight => "Underweight";
  String get TextAppNormal => "Normal";
  String get TextAppOverweight => "Overweight";
  String get TextAppObesity => "Obesity";
  String get TextAppSelectDate => "Select Date";
  String get TextAppOxygen => "Oxygen";
  String get TextAppBlood => "Blood";
  String get TextAppNoRecord => "No Record";
  String get TextAppAllExercise => "All Exercise";
  String get TextAppCleaningOrMopping => "Cleaning or Mopping";
  String get TextAppGardening => "Gardening";
  String get TextAppWatchingTV => "Watching TV";
  String get TextAppCycling => "Cycling";
  String get TextAppRunning => "Running";
  String get TextAppWalking => "Walking";
  String get TextAppShuttle => "Shuttle";
  String get TextAppTableTennis => "Table Tennis";
  String get TextAppTennis => "Tennis";
  String get TextAppVolleyBall => "Volley Ball";
  String get TextAppDancing => "Dancing";
  String get TextAppFishing => "Fishing";
  String get TextAppShopping => "Shopping";
  String get TextAppTyping => "Typing";
  String get TextAppSleeping => "Sleeping";
  String get TextAppStanding => "Standing";
  String get TextAppSitting => "Sitting";
  String get TextAppClickStartToStartActivity =>
      "Click start to start activity";
  String get TextAppCaloriesBurn => "Calories burnt";
  String get TextAppAddDurationManually => "Add duration manually";
  String get TextAppStartOrMopping => "Start or Mopping";
  String get TextAppMale => "Male";
  String get TextAppFemale => "Female";
  String get TextAppWeightManager => "Track my body weight";
  String get TextAppUpdateWeight => "Update weight";
  String get TextAppSetWeightGoal => "Set weight goal";
  String get TextAppCurrentWeight => "Current weight";
  String get TextAppWeightProgress => "Weight Progress";
  String get TextAppPrevious30Days => "Previous 30 days";
  String get TextAppYourWeightGoalIsSet => "Your goal is to";
  String get TextAppMaintain => "Maintain";
  String get TextAppInitialWeightOf => "Initial weight";
  String get TextAppFinalWeightOf => "Latest weight";
  String get TextAppWeight => "Weight";
  String get TextAppYouAreNotYetAchievingYourWeightGoalKeepGoing =>
      "You are not yet achieving your weight goal. Keep going!";
  String get TextAppYouAreAchievedYourWeightGoalKeepGoing =>
      "You are achieved your weight goal. Keep going!";
  String get TextAppAndYourWeightChangeIsSet => "and your weight change is set";
  String get TextApp1NutrientsInMyFood => "Nutrients In My Food";
  String get TextAppSearchNutrientsInRawFoods =>
      "Search nutrients in raw foods";
  String get TextAppRawIngredients => "Raw ingredients";
  String get TextAppSearchRawFoodByName => "Search raw food by name";
  String get TextApp1MyActivity => "My activity report";
  String get TextAppCheckOthersDates => "Check other dates";
  String get TextAppYour24HoursChart => "Your 24 hours chart";
  String get TextAppActivity => "Activity";
  String get TextAppOthers => "Others";
  String get TextAppExerciseDetails => "Exercise details";
  String get TextAppActivityType => "Activity type";
  String get TextAppDuration => "Duration";
  String get TextAppMyActivityOfCustomDates => "My activity on Custom dates";
  String get TextAppOurCustomerFeedback => "Our customer feedback";
  String get TextAppOverallRatings => "Overall ratings";
  String get TextAppEnterCookedWeight => "Enter cooked weight";
  String get TextAppCookedWeightGram => "Cooked weight (gram)";
  String get TextAppNutrientIn100gCooked => "Nutrient in 100g (Cooked)";
  String get TextAppEnterServingSize => "Enter serving size";
  String get TextAppSearchByRecipeName => "Search by recipe name";
  String get TextAppMyPersonalRecipe => "My personal recipe";
  String get TextAppFixedRecipe => "Fixed recipe";
  String get TextApp2NutrientsInMyFood => "Nutrients in my food";
  String get TextAppMyDietDiary => "My diet diary";
  String get TextApp2MyActivity => "My activity";
  String get TextAppDownloadFile => "Download file";
  String get TextAppStartMyNewDietDiary => "Start my new diet diary";
  String get TextAppGoogle => "Google";
  String get TextAppFacebook => "Facebook";
  String get TextAppLinkedin => "Linkedin";
  String get TextAppTwitter => "Twitter";
  String get TextAppContactUs => "Contact us";
  String get TextAppReportBug => "Report bug";
  String get TextAppAttachImage => "Attach image";
  String get TextAppResetPassword => "Reset password";
  String get TextAppNINAppCreditsPage => "NIN app credits page";
  String get NINTextOopsSomethingWentWrong => "Oops! something went wrong";
  String get NINTextPleaseEnterAllFields => "Please enter all fields";
  String get NINTextSubmittedSuccessfully1 => "Submitted successfully";
  String get NINTextSubmittedSuccessfully2 => "Submitted successfully";
  String get NINTextFitbitAuthentication => "Fitbit authentication";
  String get NINTextHours => "hours";
  String get NINTextMinutes => "minutes";
  String get NINTextEnterDurationFor => "Enter duration for";
  String get NINTextTimerRunning => "Timer running";
  String get NINTextPleaseStopTheTimerBeforeSubmitting =>
      "Please stop the timer before submitting";
  String get NINTextTotalDuration => "Total duration";
  String get NINTextSec => "sec";
  String get NINTextStartYourActivity => "Start your activity!";
  String get NINTextPause => "Pause";
  String get NINTextReset => "Reset";
  String get NINTextError => "Error";
  String get NINTextPleaseEnterCookedWeightAndServingSize =>
      "Please enter cooked weight and Serving Size";
  String get NINTextEditIngredient => "Edit Ingredient";
  String get NINTextAlert => "Alert";
  String get NINTextEnterWeightFor => "Enter weight for";
  String get NINTextNewWeightGram => "New weight (g)";
  String get NINTextEditRecipeName => "Edit recipe name";
  String get NINTextNewRecipeName => "New recipy name";
  String get NINTextSubmitted => "submitted";
  String get NINTextSuccess => "Success";
  String get NINTextDietaryDiaryReportSavedTo =>
      "Dietary diary report saved to";
  String get NINTextErrorSavingFile => "Error saving file";
  String get NINTextClose => "close";
  String get NINTextIWantTo => "I want to";
  String get NINTextGain => "Gain";
  String get NINTextMaintain => "Maintain";
  String get NINTextLose => "Lose";
  String get NINTextWeightChangeKg => "Weight change (kg)";
  String get NINTextAddNewWeight => "Add new weight";
  String get NINTextEnterWeight => "Enter weight";
  String get NINTextOf100Gram => "of 100 gram";
  String get NINTextProximateComposition => "Proximate composition";
  String get NINTextVitamins => "Vitamins";
  String get NINTextMinerals => "Minerals";
  String get NINTextTotalSaturatedFattyAcids => "Total saturated fatty acids";
  String get NINTextAllRecipeOf100Grams => "All recipe of 100 grams";
  String get NINTextOurCustomerFeedback => "Our customer feedback";
  String get NINTextOverallRatings => "Overall ratings";
  String get NINTextRateUs => "Rate us";
  String get NINTextBookDetails => "Book details";
  String get NINTextOne => "One";
  String get NINTextWeightOf => "wt. of";
  String get NINTextSelectStartDate => "Select start date";
  String get NINTextSelectEndDate => "Select end date";
  String get NINTextNoData => "No data";
  String get NINTextWorkLevel => "Work level";
  String get NINTextOldPassword => "Old password";
  String get NINTextNewPassword => "New password";
  String get NINTextUpdateProfile => "Update profile";
  String get NINTextChangeImage => "Change image";
  String get NINTextNoFavouriteFoodFound => "No favourite food found";
  String get NINTextCookedQuantity => "Cooked quantity";
  String get NINTextServingQuantity => "Serving quantity";
  String get NINTextNutrientInformation => "Nutrient information";
  String get NINTextIngredient => "Ingredient";
  String get NINTextMealsTakenOn => "Meals taken on";
  String get NINTextPercentage => "Percentage";
  String get NINTextEAR => "EAR";
  String get NINTextValue => "Value";
  String get NINTextNutrient => "Nutrient";
  String get NINTextEnergyKcal => "Energy (Kcal)";
  String get NINTextProteinG => "Protein (g)";
  String get NINTextFatG => "Fat (g)";
  String get NINTextCarbohydratesG => "Carbohydrate (g)";
  String get NINTextCalciumMg => "Calcium (mg)";
  String get NINTextFiberG => "Fibre (g)";
  String get NINTextIronMg => "Iron (mg)";
  String get NINTextZincMg => "Zinc (mg)";
  String get NINTextMagnesiumMg => "Magnesium (mg)";
  String get NINTextThiamineB1Mg => "Thiamine (B1) (mg)";
  String get NINTextRiboflavinB2Mg => "Riboflavin (B2) (mg)";
  String get NINTextNiacinB3Mg => "Niacin (B3) (mg)";
  String get NINTextFolatesB9Mcg => "Folate (B9) (µg)";
  String get NINTextRetinolVitAMcg => "Vit A (µg)";
  String get VitaminCmg => "Vitamin C (mg)";
  String get Iodinemcg => "Iodine (mcg)";
  String get serving => "serving";
  String get Mynutritionstatus => "My nutrition status";

  String get ninTextMyHealthStatus => 'My Nutritional Status';
  String get ninTextNutrientsInRawFoods => 'Nutrients in raw foods';
  String get ninTextNutrientsInRecipes => 'Nutrients in recipes';
  String get ninTextIcmrNinMyPlateForTheDay => 'ICMR-NIN My plate for the day';
  String get ninTextToday => 'today';
  String get ninTextTrackMyActivity => 'Track my activity';
  String get ninTextMyHeartRate => 'My heart rate';
  String get ninTextMyWaterIntake => 'My water intake';
  String get ninTextSleepTracker => 'Sleep tracker';
  String get ninTextLit => 'Lit';
  String get ninTextRecordMyBloodPressure =>
      'Record my blood pressure / blood glucose / SPO2';
  String get ninTextNutritionEducationContent => 'Nutrition Education Content';
  String get ninTextMyNutrientIntake => 'My nutrient intake';
  String get ninTextOn => 'on';
  String get ninTextWithReferenceToEAR => 'with reference to EAR';
  String get ninTextAchieveYourHealthGoals => 'Achieve Your Health Goals';
  String get ninTextPercentage => 'Percentage';
  String get ninTextMyPreviousDietDiaries => 'My previous diet diaries';
  String get ninTextRecordReviewSleep => 'Record / review sleep';
  String get ninTextHours => 'hrs';
  String get ninTextIngredient => 'Ingredient';
  String get ninTextOthersSpecify => 'Others specify';
  String get ninTextAddNewIngredient => 'Add new ingredient';
  String get ninTextFoodName => 'Food name';
  String get ninTextSource => 'Source';
  String get ninTextEnterBrandAndProductName =>
      'Enter the brand and product name';
  String get ninTextEnterAuthorDetails =>
      'Enter author name, year, journal, page';
  String get ninTextEnterFctName => 'Enter the name of FCT';
  String get ninTextName => 'Name';
  String get ninTextProductName => 'Product name';
  String get ninTextSelectStartDate => 'Select start date';
  String get ninTextSelectEndDate => 'Select end date';
  String get ninTextNoExercise => 'No exercise';
  String get ninTextDevelopedWithExpertiseAndInputs =>
      'Developed with Expertise and Inputs from NIN by Centre for Development and Advanced Computing (C-DAC), Hyderabad Language Link';
  String get ninTextMyNutrientIntakeToday => 'My nutrient intake today';
  String get ninTextIcmrNationalInstituteOfNutritionAddress =>
      'ICMR - National Institute of Nutrition Beside Tarnaka Metro Station, Jamai-Osmania PO, Hyderabad-500 007, India.';

  String get ninTextKcal => 'Kcal';
  String get ninTextKcalPerDay => 'Kcal/day';
  String get ninTextDelete => 'Delete';
  String get ninTextDeleteNotification => 'Delete notification';
  String get ninTextConfirmDeleteNotification =>
      'Are you sure you want to delete this notification?';
  String get ninTextTimeFor => 'Hey, It\'s time for';
  String get ninTextFitbitWatch => 'Fitbit watch';
  String get ninTextGoogleFitApp => 'Google Fit app';
  String get ninTextUnderweight => 'Underweight';
  String get ninTextNormal => 'Normal';
  String get ninTextOverweight => 'Overweight';
  String get ninTextObesity => 'Obesity';
  String get ninTextMale => 'Male';
  String get ninTextFemale => 'Female';
  String get ninTextAgeInYears => 'Age in years';
  String get ninTextChangeInWeight => 'Change in weight';
  String get ninTextSteps => 'Steps';
  String get ninTextFor => 'for';
  String get ninTextMinutes => 'minutes';
  String get ninTextPause => 'Pause';
  String get ninTextReset => 'Reset';
  String get ninTextStartActivity => 'Start your activity';
  String get ninTextCartIsEmpty => 'Your cart is empty';
  String get ninTextMyPersonalRecipe => 'My personal recipe';
  String get ninTextSearchByRecipeName => 'Search by recipe name';
  String get ninTextHelpCenter => 'Help center';
  String get ninTextCommonProblems => 'Common problems';
  String get ninTextFAQs => 'FAQs';
  String get ninTextHowActiveAreYou => 'How active are you';
  String get ninTextVitaminC => 'Vitamin C (mg)';
  String get ninTextVitaminA => 'Vitamin A (IU)';
  String get ninTextSodium => 'Sodium (mg)';
  String get ninTextJournal => 'Journal';
  String get ninTextPage => 'Page';
  String get ninTextAdequateIntakeCarbs =>
      '*Adequate Intake (AI) recommended for Carbohydrates: 130 g for adult men and women.';
  String get ninTextAdequateIntakeFiber =>
      '**AI recommended for fibre: 25 g for women and 38 g for men.';
  String get your => 'your';
  String get question1 => 'Can I edit my personal details?';
  String get answer1 =>
      'Yes. Your personal data can be edited in your profile.';
  String get linkText1 => 'Click here to edit your personal details';

  String get question2 => 'Can I change my contact details?';
  String get answer2 =>
      'Yes. Your contact details can be changed by going to the ‘personal data’ option in your profile.';
  String get linkText2 => 'Click here to edit your contact details';

  String get question3 => 'Can I change my user password?';
  String get answer3 =>
      'Yes. Your password can be changed by going to the ‘setting’ option in your profile.';
  String get linkText3 => 'Click here to change your password';

  String get question4 => 'How can I check my BMI?';
  String get answer4 =>
      'You can check your BMI by entering your height and body weight in the ‘BMI calculator’ provided in the ‘health calculator’ option displayed in the home page.';
  String get linkText4 => 'Click here to use the BMI calculator';

  String get question5 => 'Can I track my weight for the past month?';
  String get answer5 =>
      'Yes. You can view the details of changes in your body weight for the past month/year in the ‘weight manager’ option provided in the home page.';
  String get linkText5 => 'Click here to track your weight';

  String get question6 =>
      'How can I check my overall physical activity on a particular day?';
  String get answer6 =>
      'You can track your physical activity from the ‘my activity’ option in the home page.';
  String get linkText6 => 'Click here to view your activity';

  String get question7 => 'How can I set a reminder for water intake?';
  String get answer7 =>
      'You can set a time for water intake reminder in the ‘set notification’ option provided in the home page.';
  String get linkText7 => 'Click here to set a water intake reminder';

  String get question8 => 'How can I integrate the app with my smart watch?';
  String get answer8 =>
      'You can integrate your smart watch with the app by going to the ‘connect watch’ option provided in the home page.';
  String get linkText8 => 'Click here to connect your smart watch';

  String get question9 =>
      'How many wearables can I integrate with the app at a time?';
  String get answer9 =>
      'You can integrate Fitbit watch and Google Fit with the app.';
  String get linkText9 => '';

  String get question10 => 'Which smart watches are compatible with the app?';
  String get answer10 => 'Fitbit watch and Google Fit.';
  String get linkText10 => '';

  String get question11 =>
      'Can I track my activity if I don’t have a smart watch?';
  String get answer11 =>
      'Yes, you can track your activity. For that, you need to download the Google Fit app, sign in with a Google account, and with the same Google account, you need to log into our watch section.';
  String get linkText11 => '';

  String get question12 => 'How can I track my sleep?';
  String get answer12 =>
      'You can track your sleep on a weekly/monthly basis by going to the sleep tracker option provided in the home page.';
  String get linkText12 => 'Click here to track your sleep';

  String get question13 =>
      'How can I purchase any NIN publication through the app?';
  String get answer13 =>
      'You can purchase NIN publications from the ‘book store’ option provided in the home page.';
  String get linkText13 => 'Click here to visit the book store';

  String get question14 => 'How can I create my personal diet diary?';
  String get answer14 =>
      'You can enter the details of the food consumed the entire day by going to the ‘my diet diary option’.';
  String get linkText14 => 'Click here to create your diet diary';

  String get question15 =>
      'How can I search for a recipe which is rich in a particular nutrient?';
  String get answer15 =>
      'You can first select the ‘search nutrients in recipes’ option given in the ‘nutrients in my food’ tab in the home page. Then select the required nutrient from the drop-down list on the top right corner.';
  String get linkText15 => 'Click here to search for recipes';

  String get question16 =>
      'How can I check my nutrient intake for a day which was saved the previous month?';
  String get answer16 =>
      'You can view your nutrient intake on a specific day by selecting a date from the ‘calendar icon’ in ‘meal list’ page.';
  String get linkText16 => 'Click here to check your nutrient intake';

  String get question17 =>
      'How can I find out the nutrients in the raw ingredients used in my recipes?';
  String get answer17 =>
      'You can know the nutrients in a specific ingredient by selecting the ‘search nutrients in raw foods’ option given in the ‘nutrients in my food’ tab in the home page.';
  String get linkText17 => 'Click here to search nutrients in raw foods';

  String get question18 =>
      'How can I know the nutrient composition of a recipe?';
  String get answer18 =>
      'You can know the nutrients in a specific ingredient by selecting the ‘search nutrients in recipes’ option given in the ‘nutrients in my food’ tab in the home page.';
  String get linkText18 => 'Click here to know nutrient composition';

  String get question19 =>
      'Can I include a new recipe which is not available in the app?';
  String get answer19 =>
      'Yes. You can either modify an existing recipe using the link provided in the bottom of the specific fixed recipe or create an entirely new recipe by clicking on the ‘create custom dish’ option provided for each meal in the diet diary page.';
  String get linkText19 => 'Click here to create a custom recipe';

  String get question20 =>
      'Can I get dietary recommendations for a specific health condition?';
  String get answer20 =>
      'Yes. You can get health recommendations or diet chart guidelines from the ‘search component’ option in the home page.';
  String get linkText20 => 'Click here to get dietary recommendations';

  String get question21 =>
      'Can I use the app in a language other than English?';
  String get answer21 =>
      'Yes. You can select the desired language from the ‘setting’ option provided in your profile.';
  String get linkText21 => 'Click here to change language';

  String get ninTextBmiHwading => 'Body Mass Index (BMI) :';
  String get ninTextBmiDiscription =>
      'BMI is defined as a person’s weight in kilograms divided by the square of the person’s height in meters (kg/m²). The BMI ranges are based on the effect excessive body fat has on disease and death and are reasonably well related to adiposity. BMI was developed as a risk indicator of disease; as BMI increases, so does the risk for some diseases. Some common conditions related to overweight and obesity include: premature death, cardiovascular diseases, high blood pressure, osteoarthritis, some cancers, and diabetes (WHO).';
  String get ninTextbminutritionsta => 'BMI nutritional status';
  String get ninTextNutritionstat => 'Nutritional status';
  String get ninTextBelow => 'Below';
  String get ninTextPreobesity => 'Pre-obesity';

  String get ninTextbesity => 'Obesity class I';
  String get ninTextbesity2 => 'Obesity class II';
  String get ninTextbesity3 => 'Obesity class III';
  String get ninTextBMRfull => 'Basal Metabolic Rate (BMR)';
  String get ninTextBMRDiscription =>
      'BMR is the rate at which a person expends energy while at rest';
  String get ninTextPreviousdays => 'Previous 30 days';
  String get ninTextason => 'as on';
  String get ninTextYearly => 'Yearly';
  String get ninTextabove => 'Above';
  String get ninTextAchieveyourhealthgoal => 'Achieve your health goal';
  String get heavyDescription =>
      'This category comprises occupations involving regular and intense physical activity, such as running, cycling, or heavy lifting, for more than an hour each day. Examples include blacksmiths, miners, and construction workers.';
  String get moderateDescription =>
      'Individuals in this category engage in some level of physical activity, such as walking or light jogging, for around 30 minutes to an hour daily. Occupations like manual laborers, artisans, and some types of skilled workers fall into this category.';
  String get sedentaryDescription =>
      'This category includes occupations with little to no physical movement throughout the day. People in these jobs spend most of their time sitting or lying down. Examples include office workers, teachers, and those in administrative roles.';
  String get Foodprotein => "Protein";
  String get Foodfat => "Fat";
  String get Foodenergy => "Energy";
  String get FoodtotalB2 => "Total B2";
  String get Foodvitamins => "Vitamins";
  String get FoodtotalFat => "Total fat";
  String get FoodproximateComposition => "Proximate composition";
  String get FoodnutrientsIn100g => "Nutrients in 100 g";
  String get FoodtotalCarotenoids => "Total carotenoids";
  String get FoodtotalAscorbicAcid => "Total ascorbic acid";
  String get FoodtotalB9 => "Total B9";
  String get FoodtotalB6 => "Total B6";
  String get Foodcalcium => "Calcium";
  String get Foodsodium => "Sodium";
  String get Foodpotassium => "Potassium";
  String get Foodzinc => "Zinc";
  String get Foodiron => "Iron";
  String get Foodminerals => "Minerals";
  String get FoodtotalSaturatedFattyAcids => "Total Saturated Fatty Acids";
  String get FoodfattyAcids => "Fatty acids";
  String get FoodtotalDietaryFiber => "Total Dietary Fibre";
  String get Foodmanganese => "Manganese";
  String get Foodcopper => "Copper";
  String get Foodselenium => "Selenium";
  String get Foodmagnesium => "Magnesium";
  String get Foodphosphorus => "Phosphorus";
  String get Foodcholesterol => "Cholesterol";
  String get Foodcarbohydrate => "Carbohydrate";
  String get FoodvitaminB6 => "Vitamin B6 (mg)";
//last
  String get Punjabi => "Punjabi";
  String get Gujarati => "Gujarati";
  String get Odia => "Odia";
  String get Kannada => "Kannada";
  String get Marathi => "Marathi";
  String get Tamil => "Tamil";
  String get Bengali => "Bengali";
  String get Telugu => "Telugu";
  String get English => "English";
  String get Hindi => "Hindi";
  String get firstname => "First name";
  String get lastname => "Last name";
  String get labelSodium => "Sodium";
  String get labelVitaminC => "Vitamin  C";
  String get FinanameEnergy => "Energy";
  String get FinanameCarbohydrate => "Carbohydrate";
  String get FinanameFat => "Fat";
  String get FinanameSodium => "Sodium";
  String get FinanameDietaryFibre => "Dietary fibre";
  String get FinanameCalcium => "Calcium";
  String get FinanameIron => "Iron";
  String get FinanameMagnesium => "Magnesium";
  String get FinanameZinc => "Zinc";
  String get FinanameProtein => "Protein";
  String get FinanameThiamine => "Thiamine";
  String get FinanameRiboflavin => "Riboflavin";
  String get FinanameNiacin => "Niacin";
  String get FinanameVitaminB => "Vitamin B";
  String get FinanameFolate => "Folate";
  String get FinanameVitaminC => "Vitamin C";
  String get FinanameVitaminA => "Vitamin A";
  String get FinanameVitaminb6 => "Vitamin B6";
  String get confirmDeleteAllNotifications =>
      "Are you sure you want to delete all notifications?";
  String get fillAllFields => "Please fill in all fields";
  String get successfullyAddedIngredient => "Successfully added ingredient";
  String get confirmDeletion => "Confirm Deletion";
  String get confirmDeleteIngredient =>
      "Are you sure you want to delete this ingredient?";
  String get fileDownloaded =>
      "File downloaded successfully and location of file";
  String get confirmDeleteFood => "Are you sure you want to delete food?";
  String get estimatedAverageRequirement =>
      'Estimated Average Requirement (EAR): Average daily level of intake estimated to meet the requirements of 50% of healthy individuals';
  String get editQuantity => "Edit Quantity";
  String get confirmDelete => "Are you sure you want to delete?";
  String get exerciseDeleted => "Exercise deleted successfully.";
  String get confirmDeleteExercise =>
      "Are you sure you want to delete this exercise?";
  String get EssentialNutritionalGuidelines =>
      "Essential nutritional guidelines tailored for the dietary needs of Indians.";
  String get NutrientRequirementsRDA2020 =>
      "Nutrient Requirements and Recommended Dietary Allowances (RDA 2020) for Indians.";
  String get RecommendationsBalancedDiets =>
      "Recommendations promoting balanced diets and healthy eating habits in India.";
  String get DietaryGuidelinesForIndians => "Dietary guidelines for Indians.";
  String get Nutritionstat =>
      "Nutrition statistics"; // Replace with actual translation if needed
  String get referenceMen65kg => "Reference men (65 kg)";
  String get referenceWomen55kg => "Reference women (55 kg)";
  String get valueForMen => "1506";
  String get valueForWomen => "1184";
  String get referenceMenWomenDescription =>
      "Reference men and women as healthy adults who are 19–39 years old, have a normal BMI, and are moderately active (ICMR-NIN). Refer to";
  String get personalizedDietDiaryDescription =>
      "Personalized diet diary tracks your nutrient intake from present to past month";
  String get totalEnergyConsumption => "Total Energy Intake";
  String get totalEnergyExpenditure => "Total Energy Expenditure";
  String get energybalance => "Energy Balance";
  String get indicatorhealth =>
      "('+' indicates energy excess; '-' indicates energy deficit)";
  String get inputActivityDataPrompt =>
      "Energy Balance will be displayed after entering 24 hours dietry intake and activity data.";
  String get myEnergyBalanceYesterday => "My Energy Balance (Yesterday)";
  String get caloriesBurnFromWatch => "Calories burnt (from watch";
  String get activities => "Activities";
  String get searchActivityHere => "Search activity here";
  String get orSelectActivityFromBelow => "Or Select activity from below";
  String get tryLater => "Try later";
  String get recordMyDiet => "Record my diet";
  String get moisture => "Moisture";
  String get indianFoodCompositionTitle =>
      "Indian Food Composition Tables (2017)";

  String get indianFoodCompositionDescription =>
      "Indian Food Composition Tables (2017): Comprehensive nutritional data for Indian foods.";
}
