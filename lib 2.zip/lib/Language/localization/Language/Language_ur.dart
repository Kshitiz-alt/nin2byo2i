// LanguageUr.dart
import 'languages.dart';

class LanguageUr extends Languages {
  @override
  String get appName => "NIN2.0";

  @override
  String get labelWelcome => "خوش آمدید";
  String get activities => "سرگرمیاں";
  String get searchActivityHere => "یہاں سرگرمی تلاش کریں";
  String get orSelectActivityFromBelow => "یا نیچے سے سرگرمی منتخب کریں";
  String get tryLater => "بعد میں کوشش کریں";
  @override
  String get labelSelectLanguage => "زبان منتخب کریں۔";
  String get inputActivityDataPrompt =>
      "اپنی توانائی کے اخراجات اور توازن کو دیکھنے کے لیے، براہ کرم 24 گھنٹے کی سرگرمی کا ڈیٹا درج کریں۔";
  String get myEnergyBalanceYesterday => "میرا توانائی توازن (کل)";
  String get caloriesBurnFromWatch => "گھڑی سے جلی ہوئی کیلوریز";
  String get recordMyDiet => "میری خوراک ریکارڈ کریں";

  @override
  String get labelInfo => "یہ کثیر زبانوں کی ڈیمو ایپلی کیشن ہے۔";
  String get totalEnergyConsumption => "کل توانائی استعمال";
  String get totalEnergyExpenditure => "کل توانائی خرچ";
  String get energybalance => "توازن توانائی";
  String get indicatorhealth =>
      "('+' توانائی کی زائدت کو ظاہر کرتا ہے؛ '-' توانائی کی کمی کو ظاہر کرتا ہے)";

  @override
  // TODO: implement labelChangeLanguage
  String get labelChangeLanguage => "زبان تبدیل کریں";
  @override
  String get labelWelcomeBack => "خوش آمدید،";

  @override
  String get labelUnderweight => "آپ کا وزن کم ہے۔";

  @override
  String get labelNormalWeight => "آپ کا وزن نارمل ہے۔";

  @override
  String get labelOverweight => "آپ کا وزن زیادہ ہے۔";

  @override
  String get labelObese => "آپ موٹے ہیں۔";

  @override
  String get labelViewMore => "مزید دیکھیں";

  @override
  String get labelTodaySteps => "آج کے اقدامات";

  @override
  String get labelCheck => "چیک کریں۔";

  @override
  String get labelHealthData =>
      "میرا بلڈ پریشر / بلڈ گلوکوز / ایس پی او 2 ریکارڈ کریں۔";

  @override
  String get labelActivityStatus => "سرگرمی کی حیثیت";

  @override
  String get labelHeartRate => "دل کی شرح";

  @override
  String get labelHeartRateValue => "78 بی پی ایم";

  @override
  String get labelMinutesAgo => "منٹ پہلے";

  @override
  String get labelWaterIntake => "میرا پانی کی مقدار";

  @override
  String get labelLiters => "لیٹر";

  @override
  String get labelZeroLiters => "0 لیٹر";

  @override
  String get labelRealTimeGoal => "اصل وقت، مقصد";

  @override
  String get labelCalories => "کیلوری جل گئی۔";

  @override
  String get labelCaloriesEarned => "کیلوریز کمائی";

  @override
  String get labelFoodPlan => "کھانے کا منصوبہ";

  @override
  String get labelWorkoutProgress => "ورزش کی پیشرفت";

  @override
  String get labelWeekly => "ہفتہ وار";

  @override
  String get labelMonthly => "ماہانہ";

  @override
  String get labelLatestWorkout => "تازہ ترین ورزش";

  @override
  String get labelSeeMore => "دیکھیں مزید";
  String get labelBreakfast => "ناشتہ";
  String get labelLunch => "دوپہر کا کھانا";
  String get labelDinner => "رات کا کھانا";
  String get labelSnacks => "نمکین";
  String get labelTaken => "لیا";
  String get labelTarget => "ہدف";

  //profile

  String get labelProfile => "پروفائل";
  String get labelEdit => "ترمیم";
  String get labelUser => "صارف";
  String get labelProgram => "ایک موٹا پروگرام کھو دیں";
  String get labelHeight => "اونچائی";
  String get labelWeight => "وزن";
  String get labelAge => "عمر";
  String get labelAccount => "کھاتہ";
  String get labelPersonalData => "ذاتی مواد";
  String get labelAchievement => "کامیابی";
  String get labelActivityHistory => "سرگرمی کی تاریخ";
//String get labelWorkoutProgress => "ورزش کی پیشرفت";
  String get labelNotification => "اطلاع";
  String get labelPopupNotification => "پاپ اپ اطلاع";
  String get labelMensurationCycle => "سائیکل کی پیمائش";
  String get labelOther => "دیگر";
  String get labelContactUs => "ہم سے رابطہ کریں۔";
  String get labelPrivacyPolicy => "رازداری کی پالیسی";
  String get labelSetting => "ترتیب";
  String get labelFeedback => "تاثرات";
  String get labelConfirmLogout => "لاگ آؤٹ کی تصدیق کریں۔";
  String get labelConfirmLogoutMessage =>
      "کیا آپ واقعی لاگ آؤٹ کرنا چاہتے ہیں؟";
  String get labelLogout => "لاگ آوٹ";
  //select tab
  String get labelOptions => "اختیارات";
  String get labelFoodTable => "کھانا شامل کریں۔";
  String get labelTop10Food => "ٹاپ 10 کھانے";
  String get labelActivityTrack => "ایکٹیویٹی ٹریکر";
  String get labelsteptracker => "سٹیپ ٹریکر";

  String get labelTodayTarget => "پانی کا ہدف";
  String get labelJoggingTrack => "جاگنگ ٹریک";
  String get labelMensurationTrack => "مینسوریشن ٹریک";
//String get labelFoodTable => "کھانے کی میز";
  String get labelPassword => "پاس ورڈ تبدیل کریں";
  String get labelDarkMode => "ڈارک موڈ آزمائیں۔";
  String get labelconectWatch => "گھڑی کو جوڑیں۔";
  @override
  String get labelSleep => "سونا";
  @override
  String get labelBookStore => "کتابوں کی دکان";
  @override
  String get labelSearchBooks => "کتابیں تلاش کریں۔";
  @override
  String get labelPrice => "قیمت";
  @override
  String get labelAddToCart => "ٹوکری میں شامل کریں";
  @override
  String get labelAuthor => "مصنف";
  @override
  String get labelYear => "سال";
  @override
  String get labelQuantityAvailable => "دستیاب مقدار";
  @override
  String get labelCart => "ٹوکری میں شامل کریں";
  @override
  String get labelMyOrders => "میرے احکام";
  @override
  String get labelAllOrders => "تمام احکامات";
  @override
  String get labelOrderDetail => "آرڈر کی تفصیل";
  @override
  String get labelOrderId => "آرڈر کی شناخت";
  @override
  String get labelOrdersInMyOrders => "میرے حکم میں حکم";
  @override
  String get labelItemsInMyOrders => "میرے آرڈر میں اشیاء";
  @override
  String get labelTotal => "کل";
  @override
  String get labelTotalPrice => "کل قیمت";
  @override
  String get labelCheckout => "اس کو دیکھو";

  // Meal List
  @override
  String get labelMealList => "میری خوراک";
  @override
  String get labelAnalyze => "تجزیہ کریں۔";
  @override
  String get labelAddDish => "ڈش شامل کریں۔";
  @override
  String get labelTop10Foods => "ٹاپ 10 فوڈز";
  @override
  String get labelRecentMeal => "حالیہ کھانا";
  @override
  String get labelAnalyzeIngredientsTaken => "کھانے کی مقدار کا تجزیہ کریں۔";

  // Nutrition Summary
  @override
  String get labelCarbs => "کاربوہائیڈریٹ";
  // @override
  // String get labelCalories => "کیلوریز";
  @override
  String get labelFibers => "کل فائبر";
  @override
  String get labelFats => "موٹا";
  @override
  String get labelProteins => "پروٹین";
  @override
  String get labelCalcium => "کیلشیم";

  @override
  String get labelNiacinB3 => "نیاسین (B3)";

  @override
  String get labelThiamineB1 => "تھامین (B1)";

  @override
  String get labelIron => "لوہا";

  @override
  String get labelZinc => "زنک";

  @override
  String get labelFolatesB9 => "فولیٹ (B9)";

  @override
  String get labelRiboflavinB2 => "Riboflavin (B2)";

  @override
  String get labelRetinolVitA => "ریٹینول (وٹامن اے)";

  @override
  String get labelMagnesium => "میگنیشیم";

  @override
  String get labelTodaysNutritionSummary => "آج کی غذائیت کا خلاصہ";
  @override
  String get labelChangeGoal => "مقصد تبدیل کریں۔";
  @override
  String get labelIngredientsTaken => "لی گئی اجزاء";
  @override
  String get labelIngredientsLeft => "اجزاء رہ گئے۔";

  // Food Table
  // @override
  // String get labelFoodTable => "کھانے کی میز";
  // @override
  // String get labelBreakfast => "ناشتہ";
  // @override
  // String get labelLunch => "دوپہر کا کھانا";
  // @override
  // String get labelDinner => "رات کا کھانا";
  // @override
  // String get labelSnacks => "نمکین";
  @override
  String get labelTop10FoodsSleep => "ٹاپ 10 فوڈز";
  @override
  String get labelFavouriteDishes => "پسندیدہ پکوان";

  // User Profile
  @override
  String get labelHelp => "مدد";
  // @override
  // String get labelLogout => "لاگ آوٹ";
  // @override
  // String get labelWeight => "وزن";
  @override
  String get labelEmail => "ای میل";
  // @override
  // String get labelHeight => "اونچائی";
  @override
  String get labelLinkedInProfileLink => "لنکڈ ان پروفائل لنک";
  @override
  String get labelGoogleProfileLink => "گوگل پروفائل لنک";
  @override
  String get labelFacebookProfileLink => "فیس بک پروفائل لنک";
  @override
  String get labelTwitterProfileLink => "ٹویٹر پروفائل لنک";
  @override
  String get labelName => "نام";
  @override
  String get labelPhoneNumber => "فون نمبر.";
  @override
  String get labelDateOfBirth => "D.O.B";
  @override
  String get labelBMI => "BMI";
  // @override
  // String get labelAge => "عمر";

  // Contact Us
  @override
  String get labelMessage => "پیغام";
  @override
  String get labelSubmit => "جمع کرائیں";
  @override
  String get labelCompanyContacts => "کمپنی کے رابطے";
  @override
  String get labelAddress => "پتہ";
  @override
  String get labelDirectorsEmail => "ڈائریکٹر کا ای میل";
  @override
  String get labelFax => "فیکس";

  // Settings
  @override
  String get labelResetPassword => "پاس ورڈ ری سیٹ";
  // @override
  // String get labelFeedback => "تاثرات";
  @override
  String get labelPleaseProvideFeedback => "براہ کرم اپنی رائے دیں۔";
  @override
  String get labelEnterYourFeedbackHere => "اپنی رائے یہاں درج کریں۔";
  @override
  String get labelSubmitFeedback => "رائے جمع کروائیں۔";

  // Credits
  // @override
  // String get labelContactUs => "ہم سے رابطہ کریں۔";
  @override
  String get labelDevelopmentTeam => "ترقیاتی ٹیم";
  @override
  String get labelAcknowledgments => "اعترافات";
  @override
  String get labelPartnerships => "شراکت داریاں";

  // Mobile
  @override
  String get labelSearchComponents => "اجزاء تلاش کریں۔";
  @override
  String get labelSearchComponentsHere => "یہاں اجزاء تلاش کریں۔";
  @override
  String get lablelDishName => 'ڈش کا نام';
  @override
  String get labelCredits => 'کریڈٹس';
  @override
  String get labelShareAppButton => "بانٹیں";
  @override
  String get labelShareApp =>
      "بار کوڈ اسکینر ایپ سے QR کوڈ اسکین کریں اور ایپ ڈاؤن لوڈ کریں۔";
  // New translations
  @override
  String get labelConnectedWatch => "منسلک گھڑی ہے۔";
  @override
  String get labelDisconnect => "منقطع کرنا";
  @override
  String get labelFitbit => "فٹ بٹ";
  @override
  String get labelGoogleFit => "گوگل فٹ";
  @override
  String get labelAppleWatch => "ایپل گھڑی";
  @override
  String get labelSamsungSmartWatch => "سام سنگ سمارٹ واچ";
  @override
  String get labelBookDetails => "کتاب کی تفصیلات";
  @override
  String get labelDeliveryDate => "ادئیگی کی تاریخ";
  @override
  String get labelOrderDate => "آرڈر کی تاریخ";
  @override
  String get labelAnalyseIngredientsTaken => "کھانے کی مقدار کا تجزیہ کریں۔";
  @override
  String get labelAddDishIngredients => "ڈش کے اجزاء شامل کریں۔";
  @override
  String get labelIngredientName => "اجزاء کا نام";
  @override
  String get labelEnterIngredientName => "اجزاء کا نام درج کریں۔";
  @override
  String get labelIngredientQuantity => "اجزاء کی مقدار";
  @override
  String get labelEnterIngredientQuantity => "اجزاء کی مقدار درج کریں۔";
  @override
  String get labelAdd => "شامل کریں۔";
  @override
  String get labelSave => "محفوظ کریں۔";
  @override
  String get labelwatch => "گھڑی";

  //
  @override
  String get labelBloodOxygenHeart =>
      'اہم علامات کی پیمائش کریں اور مجموعی صحت کو ٹریک کریں۔';
  @override
  String get labelTop10FoodS =>
      'صحت مند طرز زندگی کو برقرار رکھنے کے لیے تجویز کردہ غذائیں دریافت کریں۔';
  @override
  String get labelWaterTrack =>
      'روزانہ فٹنس ہائیڈریشن کے اہداف مقرر کریں اور حاصل کریں۔';
  @override
  String get labelPersonalDetails =>
      'محفوظ طریقے سے ذاتی معلومات کا نظم اور اپ ڈیٹ کریں۔';
  @override
  String get labelFeedbackS => 'اپنے خیالات اور تجاویز ہمارے ساتھ شیئر کریں۔';
  @override
  String get labelContactUsS => 'کسٹمر سپورٹ تک پہنچیں اور ہم سے رابطہ کریں۔';
  @override
  String get labelBMICalculator =>
      'صحت کی بصیرت کے لیے اپنے باڈی ماس انڈیکس کا حساب لگائیں۔';
  @override
  String get labelBMRCalculator =>
      'فٹنس پلاننگ کے لیے اپنے بیسل میٹابولک ریٹ کا حساب لگائیں۔';
  @override
  String get labelRunningJoggingSteps =>
      'صحت مند طرز زندگی کے لیے اپنے دوڑ اور جاگنگ کے اقدامات کو ٹریک کریں۔';
  @override
  String get labelHealthyDietChart =>
      'صحت مند غذا کے جائزہ کے لیے ایک جامع چارٹ تک رسائی حاصل کریں۔';
  @override
  String get labelHealthyRecommendation =>
      'ذاتی نوعیت کی صحت کی سفارشات حاصل کریں۔';
  @override
  String get labelSleepTracker =>
      'اپنی نیند کے نمونوں کو ٹریک کریں اور نیند کے معیار کو بہتر بنائیں۔';
  @override
  String get labelSetReminder =>
      'صحت اور تندرستی کی سرگرمیوں کے لیے یاد دہانیاں مرتب کریں۔';
  // @override
  // String get labelMenstruationCycle =>
  //     'بہتر بصیرت کے لیے اپنے ماہواری کو ٹریک کریں اور ان کا نظم کریں۔';
  @override
  String get labelCSVDownload =>
      'آسان تجزیہ کے لیے اپنا ڈیٹا CSV فارمیٹ میں ڈاؤن لوڈ کریں۔';

  // New Headings
  @override
  String get headingBloodOxygenHeart => 'خون | آکسیجن';
  @override
  String get headingTop10Food => 'ٹاپ 10 کھانے';
  @override
  String get headingWaterTrack => 'واٹر ٹریکر';
  @override
  String get headingPersonalDetails => 'ذاتی معلومات';
  @override
  String get headingFeedback => 'تاثرات';
  @override
  String get headingContactUs => 'ہم سے رابطہ کریں۔';
  @override
  String get headingBMICalculator => 'BMI کیلکولیٹر';
  @override
  String get headingBMRCalculator => 'BMR کیلکولیٹر';
  @override
  String get headingRunningJoggingSteps => 'دوڑنا / ٹہلنا / قدم';
  @override
  String get headingHealthyDietChart => 'صحت مند غذا کا چارٹ';
  @override
  String get headingHealthyRecommendation => 'صحت مند تجویز';
  @override
  String get headingSleepTracker => 'سلیپ ٹریکر';
  @override
  String get headingSetReminder => 'یاد دہانی سیٹ کریں۔';
  // @override
  // String get headingMenstruationCycle => 'ماہواری کا چکر';
  @override
  String get headingCSVDownload => 'CSV ڈاؤن لوڈ';

  // Water-related phrases
  @override
  String get labelWaterTarget => "پانی کا ہدف";
  // @override
  // String get labelTodayTarget => "آج کا ہدف";
  @override
  String get labelWaterGoal => "پانی کا مقصد";
  // @override
  // String get labelWaterIntake => "پانی کی مقدار";
  @override
  String get labelWaterProgress => "پانی کی ترقی";
  // @override
  // String get labelWeekly => "ہفتہ وار";
  @override
  String get labelDateWise => "تاریخ کے لحاظ سے";
  @override
  String get labelSun => "سورج";
  @override
  String get labelMon => "پیر";
  @override
  String get labelTue => "منگل";
  @override
  String get labelWed => "بدھ";
  @override
  String get labelThu => "جمعرات";
  @override
  String get labelFri => "جمعہ";

  // BMI Calculator
  // @override
  // String get labelBMI => "BMI";
  @override
  String get labelEnterHeight => "اونچائی درج کریں (سینٹی میٹر)";
  @override
  String get labelEnterWeight => "وزن درج کریں (کلوگرام)";
  @override
  String get labelCalculateBMI => "BMI کا حساب لگائیں۔";

  // BMR Calculator
  @override
  String get labelMale => "مرد";
  @override
  String get labelFemale => "عورت";
  @override
  String get labelEnterAge => "عمر درج کریں۔";
  @override
  String get labelCalculateBMR => "BMR کا حساب لگائیں۔";
  @override
  String get labelBMR => "بی ایم آر";
  @override
  String get labelCaloriesPerDay => "کیلوری / دن";

  // Step Tracker
  @override
  String get labelStepsTracker => "سٹیپ ٹریکر";
  @override
  String get labelRunningTracker => "رننگ ٹریکر";
  @override
  String get labelAddStep => "قدم شامل کریں۔";
  @override
  String get labelSelectDate => "تاریخ منتخب کریں۔";
  @override
  String get labelJoggingTracker => "جاگنگ ٹریکر";
  @override
  String get labelCaloriesBurn => "کیلوری جل گئی۔";

  // Sleep Tracker
  @override
  String get labelSleepTarget => "نیند کا ہدف";
  @override
  String get labelTodaySleep => "آج سو جاؤ";
  @override
  String get labelSleepProgress => "نیند کی ترقی";
  @override
  String get labelTotalSleep => "مکمل نیند";
  @override
  String get labelSleepGoal => "نیند کا مقصد";
  @override
  String get labelSetNotification => "نوٹیفکیشن سیٹ کریں۔";
  @override
  String get labelStartTime => "وقت آغاز";
  @override
  String get labelEndTime => "آخر وقت";
  @override
  String get labelSelect => "منتخب کریں۔";
  @override
  String get labelSat => "سات";
  // @override
  // String get labelSave => "محفوظ کریں۔";
  @override
  String get labelStart => "شروع کریں۔";
  @override
  String get labelEnd => "ختم";
  @override
  String get labelType => "قسم";
  @override
  String get labelIsConnected => "منسلک ہے";

  // @override
  // String get labelMensurationCycle => "سائیکل کی پیمائش";

  @override
  String get labelTrackAndManage =>
      "بہتر بصیرت کے لیے اپنے حیض کے چکر کو ٹریک کریں اور ان کا نظم کریں۔";

  @override
  String get labelMensurationStatus => "پیمائش کی حیثیت";

  @override
  String get labelDaysLength => "دنوں کی لمبائی";

  @override
  String get labelDay => "دن";

  @override
  String get labelNextDate => "اگلی تاریخ";

  @override
  String get labelLastPeriodStartDate => "آخری مدت شروع ہونے کی تاریخ";

  @override
  String get labelAverageCycleLength => "سائیکل کی اوسط لمبائی";

  @override
  String get labelChange => "تبدیلی";

  // Common Messages
  @override
  String get messageSent => "پیغام چلا گیا";

  @override
  String get thankYouForContactingUs => "ہم سے رابطہ کرنے کا شکریہ!";

  @override
  String get alert => "الرٹ";

  @override
  String get fillInAllFields => "براہ کرم تمام فیلڈز کو پُر کریں۔";

  @override
  String get thankYouFeedbackSubmitted => "آپ کی رائے جمع کرائی گئی ہے۔";

  @override
  String get resetPassword => "پاس ورڈ ری سیٹ";

  @override
  String get dishAdded => "ڈش شامل!";

  @override
  String get dishAndIngredientsAddedSuccessfully =>
      "ڈش اور اجزاء کو کامیابی کے ساتھ شامل کیا گیا۔";

  @override
  String get failed => "ناکام";

  @override
  String get error => "خرابی";

  @override
  String get enterBloodGlucoseLevel =>
      "ایم جی / ڈی ایل میں خون میں گلوکوز کی سطح درج کریں۔";

  @override
  String get enterBloodPressureLevel => "mmHg میں بلڈ پریشر کی سطح درج کریں۔";

  @override
  String get enterHeartLevel =>
      "براہ کرم دل کی دھڑکن فی منٹ (BPM) میں درج کریں۔";

  @override
  String get cancel => "منسوخ کریں۔";

  @override
  String get submit => "جمع کرائیں";

  @override
  String get valueCannotBeGreaterThan100 => "قدر 100 سے زیادہ نہیں ہو سکتی۔";

  @override
  String get bloodStatusSubmittedSuccessfully =>
      "خون کی صورتحال کامیابی کے ساتھ جمع کرائی گئی۔";

  @override
  String get failedToSubmitBlood => "خون جمع کرانے میں ناکام۔";

  @override
  String get enterHeartLevel1to100 =>
      "براہ کرم دل کی دھڑکن فی منٹ (BPM) میں درج کریں۔";

  @override
  String get heartLevelSubmittedSuccessfully =>
      "دل کی سطح کامیابی کے ساتھ جمع کرائی گئی۔";

  @override
  String get enterOxygenSaturationLevel1to100 =>
      "آکسیجن سنترپتی لیول 1%-100% درج کریں";

  @override
  String get oxygenLevelSubmittedSuccessfully =>
      "آکسیجن کی سطح کامیابی کے ساتھ جمع کرائی گئی۔";

  @override
  String get updateData => "ڈیٹا کو اپ ڈیٹ کریں۔";

  @override
  String get selectLastPeriodStartDate =>
      "آخری مدت شروع ہونے کی تاریخ منتخب کریں۔";

  @override
  String get update => "اپ ڈیٹ";

  @override
  String get failedToFetchBooks => "کتابیں لانے میں ناکام۔ دوبارہ کوشش کریں.";

  @override
  String get errorOccurred => "ایک خرابی آگئی:";

  @override
  String get invalidEndTime => "غلط اختتامی وقت";

  @override
  String get chooseTimeWithin1Hour =>
      "براہ کرم آغاز کے وقت کے 1 گھنٹے کے اندر وقت کا انتخاب کریں۔";

  @override
  String get notificationSaved => "اطلاع محفوظ ہو گئی۔";

  @override
  String get notificationSetSuccessfully => "اطلاع کامیابی سے سیٹ ہو گئی۔";

  @override
  String get thereIsSomeError => "کچھ خرابی ہے۔";

  @override
  String get watchDisconnected => "گھڑی منقطع ہو گئی۔";

  @override
  String get watchDisconnectedSuccessfully =>
      "گھڑی کامیابی سے منقطع ہو گئی ہے۔";

  @override
  String get addCup => "کپ شامل کریں۔";

  @override
  String get numberOfCups => "کپ کی تعداد";

  @override
  String get addCupCapacityInMl => "ملی لیٹر میں کپ کی گنجائش شامل کریں۔";

  @override
  String get cupCapacitySubmittedSuccessfully =>
      "کپ کی گنجائش کامیابی سے جمع کرادی گئی۔";

  @override
  String get pleaseEnterValidValuesForAllFields =>
      "براہ کرم تمام فیلڈز کے لیے درست قدریں درج کریں۔";

  @override
  String get enterWater => "پانی داخل کریں۔";

  @override
  String get waterGoalLiters => "پانی کا مقصد (لیٹر)";

  @override
  String get waterSubmittedSuccessfully =>
      "پانی کا ہدف کامیابی کے ساتھ جمع ہو گیا۔";

  @override
  String get addActivityData => "سرگرمی کا ڈیٹا شامل کریں۔";

  @override
  String get enterValue => "قدر درج کریں۔";

  @override
  String get addStepsData => "اقدامات کا ڈیٹا شامل کریں۔";

  @override
  String get numberOfSteps => "قدموں کی تعداد";

  @override
  String get stepsDataSubmittedSuccessfully =>
      "مراحل کا ڈیٹا کامیابی کے ساتھ جمع کرایا گیا۔";

  @override
  String get enterSleepTarget => "نیند کا ہدف درج کریں۔";

  @override
  String get sleepTargetInHours => "گھنٹوں میں نیند کا ہدف";

  @override
  String get addYourSleepDuration => "اپنی نیند کا دورانیہ شامل کریں۔";

  @override
  String get enterDurationInMinutes => "منٹ میں دورانیہ درج کریں:";

  @override
  String get add => "شامل کریں۔";

  @override
  String get ok => "ٹھیک ہے";

  @override
  String get csvFileSavedTo => "CSV فائل محفوظ ہو گئی۔";

  @override
  String get ageMustBeBetween2And100Years =>
      "عمر 2 سے 100 سال کے درمیان ہونی چاہیے۔";

  @override
  String get next => "اگلے";

  @override
  String get register => "رجسٹر کریں۔";

  @override
  String get oopsSomethingWentWrong => "افوہ! کچھ غلط ہو گیا";

  @override
  String get errorFetchingMeals => "کھانا لانے کے دوران ایک خرابی پیش آگئی:";

  @override
  String get reviewAddedSuccessfully => "جائزہ کامیابی کے ساتھ شامل کیا گیا!";

  @override
  String get failedToAddReview => "جائزہ شامل کرنے میں ناکام:";

  @override
  String get alreadyInCart => "پہلے ہی کارٹ میں ہے۔";

  @override
  String get addedToCart => "کارٹ میں شامل کر دیا گیا۔";

  @override
  String get quantityNotBetween1And2 => "مقدار 2 سے زیادہ اور 1 سے کم نہیں ہے۔";

  String get createcustomdish => "اپنی مرضی کے مطابق ڈش بنائیں";
  String get quantityingram => "مقدار (گرام)";
  String get labelCaloriestaken => 'توانائی';
  String get mainlabelEarlyMorning => "صبح سویرے";
  String get mainlabelMidMorning => "وسط صبح";
  String get mainlabelEvening => "شام";
  String get mainlabelBedtime => "سونے کا وقت";
  String get mainlabelTimeSpentOn => "مختلف کاموں میں وقت گزارا۔";
  String get mainlabelHealthCalculator => "صحت کیلکولیٹر";
  String get mainlabelStepProgress => "مرحلہ وار ترقی";
  String get mainlabelRealTimeIntakes => "حقیقی وقت کی مقدار";
  String get mainlabelCaloriesBurnProgress => "کیلوری جلانے کی پیشرفت";
  String get mainlabelCaloriesBurnBreakdown => "کیلوریز جلنے والی خرابی پر";
  String get mainlabelHeartReportsTrends => "دل رجحانات کی اطلاع دیتا ہے۔";
  String get mainlabelOxygenStatus => "آکسیجن کی حیثیت";
  String get mainlabelNoRecord => "مجھے یاد نہیں";
  String get mainlabelSystolicBloodPressure => "انقباضی بلڈ پریشر";
  String get mainlabelMeasuredon => "پر ماپا";
  String get mainlabelEnterBloodPressure => "بلڈ پریشر درج کریں۔";
  String get mainlabelBloodPressure => "بلڈ پریشر";
  String get mainlabelDiastolicBloodPressure => "diastolic بلڈ پریشر";
  String get mainlabelBloodGlucose => "خون میں گلوکوز";
  String get mainlabelHeartStatus => "دل کی کیفیت";
  String get mainlabelAllExercise => "تمام ورزش";
  String get mainlabelCleaningOrMopping => "صفائی یا موپنگ";
  String get mainlabelGardening => "باغبانی";
  String get mainlabelWatchingTV => "ٹی وی دیکھ رہے ہیں۔";
  String get mainlabelCycling => "سائیکلنگ";
  String get mainlabelRunning => "چل رہا ہے۔";
  String get mainlabelWalking => "چلنا";
  String get mainlabelShuttle => "شٹل";
  String get mainlabelTableTennis => "ٹیبل ٹینس";
  String get mainlabelTennis => "ٹینس";
  String get mainlabelVolleyBall => "والی بال";
  String get mainlabelDancing => "رقص";
  String get mainlabelFishing => "ماہی گیری";
  String get mainlabelShopping => "خریداری";
  String get mainlabelTyping => "ٹائپنگ";
  String get mainlabelSleeping => "سو رہا ہے۔";
  String get mainlabelStanding => "کھڑا ہے۔";
  String get mainlabelSitting => "بیٹھے";
  String get mainlabelClickToStartActivity =>
      "سرگرمی شروع کرنے کے لیے کلک کریں۔";
  String get mainlabelBMICalculator => "BMI کیلکولیٹر";
  String get mainlabelBMRCalculator => "BMR کیلکولیٹر";
  String get mainlabelDownloadActivityReportInCsv =>
      "csv میں سرگرمی کی رپورٹ ڈاؤن لوڈ کریں۔";
  String get mainlabelSelectStartDate => "آغاز کی تاریخ منتخب کریں۔";
  String get mainlabelSelectEndDate => "اختتامی تاریخ منتخب کریں۔";
  String get mainlabelDownloadFile => "فائل ڈاؤن لوڈ کریں";
  String get mainlabelDate => "تاریخ";
  String get mainlabelValue => "قدر";
  String get mainlabelLink => "لنک";
  String get mainlabelNoNotificationFound => "کوئی اطلاع نہیں ملی";
  String get mainlabelTotalNutritionTaken => "= مکمل غذائیت لی گئی۔";
  String get mainlabelSearchFood => "ترکیبیں تلاش کریں۔";
  String get mainlabelSelectFromPersonalFood =>
      "ذاتی ترکیبوں میں سے انتخاب کریں۔";
  String get mainlabelRecipeName => "نسخہ کا نام";
  String get mainlabelSelectDate => "تاریخ منتخب کریں";
  String get mainlabelNutrientOfAllIngredientsRaw =>
      "تمام اجزاء کی غذائیت (خام)";
  String get mainlabelNutrientsCompostionOfCookedWeight =>
      "کے لیے پکے ہوئے وزن کی غذائی اجزاء";
  String get mainlabelWantToEditThisRecipyFollowThe =>
      "اس ترکیب میں ترمیم کرنا چاہتے ہیں؟ پیروی کریں یا پیچھے چلیں";
  String get mainlabelAddIngredientFrom => "سے اجزاء شامل کریں۔";
  String get mainlabelAddFromNutrientSpecifcFood =>
      "غذائیت سے متعلق مخصوص کھانے میں شامل کریں۔";
  String get mainlabelAddFromAllFoods => "تمام کھانوں میں شامل کریں۔";
  String get mainlabelNumberOfServing => "سرونگ کی تعداد";
  String get mainlabelWeightInG => "وزن (جی)";
  String get mainlabelEditIngredientsWeight => "اجزاء کے وزن میں ترمیم کریں۔";
  String get mainlabelIngredient => "اجزاء";
  String get mainlabelNewWeightInG => "نیا وزن (جی)";
  String get mainlabelCancel => "منسوخ کریں";
  String get mainlabelUpdate => "اپ ڈیٹ";
  String get mainlabelCookedWeightInG => "پکا ہوا وزن (جی)";
  String get mainlabelEnterWeight => "وزن درج کریں۔";
  String get mainlabelEditRecipy => "نسخہ میں ترمیم کریں۔";
  String get mainlabelAlert => "الرٹ";
  String get mainlabelToSeeNutritionCompositionPleaseEnterNoOfServing =>
      "غذائیت کی ترکیب دیکھنے کے لیے، براہ کرم سرونگ کی تعداد درج کریں۔";
  String get mainlabelNutrirntsIn100CookedWeight =>
      "100 (پکے ہوئے) وزن میں غذائی اجزاء";
  String get mainlabelSetNutritionTargetInG =>
      "گرام میں غذائیت کا ہدف مقرر کریں۔";
  String get mainlabelFoodAnalyse => "دریافت کریں۔";
  String get mainlabelExploreTop10Foods =>
      "سرفہرست 10 کھانے کی اشیاء دریافت کریں۔";
  String get mainlabelSearchCookedFood => "ترکیبوں میں غذائی اجزاء تلاش کریں۔";
  String get mainlabelNutritionBasedOnEAR => "EAR پر مبنی غذائیت کی ضرورت";
  String get mainlabelDietDiary => "غذا کی ڈائری";
  String get mainlabelRecipes => "ترکیبیں";
  String get mainlabelSearchByFoodName => "کھانے کے نام سے تلاش کریں۔";
  String get mainlabelAllRecipeOf100G => "تمام نسخہ 100 گرام";
  String get mainlabelNutritionRequirement => "غذائیت کی ضرورت";
  String get mainlabelGender => "صنف";
  String get mainlabelParticulars => "تفصیلات";
  String get mainlabelBodyWeight => "جسم کے وزن";
  String get mainlabelDietaryDiaryReports => "غذائی اجزاء کی مقدار";
  String get mainlabelTotalNutritionTakenOn => "مکمل غذائیت";
  String get mainlabelAttachImage => "تصویر منسلک کریں۔";
  String get mainlabelFixedRecipy => "فکسڈ نسخہ";
  String get mainlabelFoodInDetail => "تفصیل سے کھانا";
  String get TextAppNutrientsInMyFood =>
      "کھانے کی اشیاء میں غذائی اجزاء تلاش کریں۔";
  String get TextAppMyActivity => "میری سرگرمی";
  String get TextAppToday => "آج";
  String get TextAppMyNutrientRequirements => "میری غذائیت کی ضروریات";
  String get TextAppTotalNutrition => "کل غذائیت";
  String get TextAppTaken => "لیا";
  String get TextAppRatings => "ریٹنگز";
  String get TextAppSearchComponents => "اجزاء تلاش کریں۔";
  String get TextAppTotalNutrientTaken => "آج میرا غذائی اجزاء";
  String get TextAppShareApp => "ایپ شیئر کریں۔";
  String get TextAppNoNotificationsFound => "کوئی اطلاع نہیں ملی";
  String get TextAppConnectWatch => "واچ کو مربوط کریں۔";
  String get TextAppYourBMIIs => "آپ کا BMI ہے۔";
  String get TextAppBMI => "BMI";
  String get TextAppBMICategories => "BMI زمرہ جات";
  String get TextAppUnderweight => "کم وزن";
  String get TextAppNormal => "نارمل";
  String get TextAppOverweight => "زیادہ وزن";
  String get TextAppObesity => "موٹاپا";
  String get TextAppSelectDate => "تاریخ منتخب کریں۔";
  String get TextAppOxygen => "آکسیجن";
  String get TextAppBlood => "خون";
  String get TextAppNoRecord => "کوئی ریکارڈ نہیں";
  String get TextAppAllExercise => "تمام ورزش";
  String get TextAppCleaningOrMopping => "صفائی یا موپنگ";
  String get TextAppGardening => "باغبانی";
  String get TextAppWatchingTV => "ٹی وی دیکھ رہے ہیں۔";
  String get TextAppCycling => "سائیکلنگ";
  String get TextAppRunning => "چل رہا ہے۔";
  String get TextAppWalking => "چلنا";
  String get TextAppShuttle => "شٹل";
  String get TextAppTableTennis => "ٹیبل ٹینس";
  String get TextAppTennis => "ٹینس";
  String get TextAppVolleyBall => "والی بال";
  String get TextAppDancing => "رقص";
  String get TextAppFishing => "ماہی گیری";
  String get TextAppShopping => "خریداری";
  String get TextAppTyping => "ٹائپنگ";
  String get TextAppSleeping => "سو رہا ہے۔";
  String get TextAppStanding => "کھڑا ہے۔";
  String get TextAppSitting => "بیٹھے";
  String get TextAppClickStartToStartActivity =>
      "سرگرمی شروع کرنے کے لیے اسٹارٹ پر کلک کریں۔";
  String get TextAppCaloriesBurn => "کیلوری جل گئی۔";
  String get TextAppAddDurationManually => "دستی طور پر دورانیہ شامل کریں۔";
  String get TextAppStartOrMopping => "شروع کریں یا موپنگ کریں۔";
  String get TextAppMale => "مرد";
  String get TextAppFemale => "عورت";
  String get TextAppWeightManager => "میرے جسمانی وزن کو ٹریک کریں۔";
  String get TextAppUpdateWeight => "وزن کو اپ ڈیٹ کریں۔";
  String get TextAppSetWeightGoal => "وزن کا ہدف مقرر کریں۔";
  String get TextAppCurrentWeight => "موجودہ وزن";
  String get TextAppWeightProgress => "وزن کی پیشرفت";
  String get TextAppPrevious30Days => "پچھلے 30 دن";
  String get TextAppYourWeightGoalIsSet => "آپ کا مقصد ہے";
  String get TextAppMaintain => "برقرار رکھنا";
  String get TextAppInitialWeightOf => "ابتدائی وزن";
  String get TextAppFinalWeightOf => "تازہ ترین وزن";
  String get TextAppWeight => "وزن";
  String get TextAppYouAreNotYetAchievingYourWeightGoalKeepGoing =>
      "آپ ابھی تک اپنے وزن کا مقصد حاصل نہیں کر رہے ہیں۔ چلتے رہو!";
  String get TextAppYouAreAchievedYourWeightGoalKeepGoing =>
      "آپ اپنے وزن کا مقصد حاصل کر چکے ہیں۔ چلتے رہو!";
  String get TextAppAndYourWeightChangeIsSet =>
      "اور آپ کے وزن میں تبدیلی سیٹ ہو گئی ہے۔";
  String get TextApp1NutrientsInMyFood => "میرے کھانے میں غذائی اجزاء";
  String get TextAppSearchNutrientsInRawFoods =>
      "خام کھانوں میں غذائی اجزاء تلاش کریں۔";
  String get TextAppRawIngredients => "خام اجزاء";
  String get TextAppSearchRawFoodByName => "نام سے کچا کھانا تلاش کریں۔";
  String get TextApp1MyActivity => "میری سرگرمی کی رپورٹ";
  String get TextAppCheckOthersDates => "دوسروں کی تاریخیں چیک کریں۔";
  String get TextAppYour24HoursChart => "آپ کا 24 گھنٹے کا چارٹ";
  String get TextAppActivity => "سرگرمی";
  String get TextAppOthers => "دوسرے";
  String get TextAppExerciseDetails => "ورزش کی تفصیلات";
  String get TextAppActivityType => "سرگرمی کی قسم";
  String get TextAppDuration => "دورانیہ";
  String get moisture => "نمی";
  String get indianFoodCompositionTitle =>
      "بھارتی خوراک کی ترکیب کی جدولیں (2017)";

  String get indianFoodCompositionDescription =>
      "بھارتی خوراک کی ترکیب کی جدولیں (2017): بھارتی کھانوں کے لئے جامع غذائیت کے ڈیٹا۔";

  String get TextAppMyActivityOfCustomDates =>
      "اپنی مرضی کی تاریخوں کی میری سرگرمی";
  String get TextAppOurCustomerFeedback => "ہمارے گاہک کی رائے";
  String get TextAppOverallRatings => "مجموعی درجہ بندی";
  String get TextAppEnterCookedWeight => "پکا ہوا وزن درج کریں۔";
  String get TextAppCookedWeightGram => "پکا ہوا وزن (گرام)";
  String get TextAppNutrientIn100gCooked => "100 گرام میں غذائیت (پکا ہوا)";
  String get TextAppEnterServingSize => "سرونگ سائز درج کریں۔";
  String get TextAppSearchByRecipeName => "ترکیب کے نام سے تلاش کریں۔";
  String get TextAppMyPersonalRecipe => "میرا ذاتی نسخہ";
  String get TextAppFixedRecipe => "مقررہ نسخہ";
  String get TextApp2NutrientsInMyFood => "میرے کھانے میں غذائی اجزاء";
  String get TextAppMyDietDiary => "میری خوراک کی ڈائری";
  String get TextApp2MyActivity => "میری سرگرمی";
  String get TextAppDownloadFile => "فائل ڈاؤن لوڈ کریں";
  String get TextAppStartMyNewDietDiary => "میری نئی خوراک کی ڈائری شروع کریں۔";
  String get TextAppGoogle => "گوگل";
  String get TextAppFacebook => "فیس بک";
  String get TextAppLinkedin => "لنکڈن";
  String get TextAppTwitter => "ٹویٹر";
  String get TextAppContactUs => "ہم سے رابطہ کریں۔";
  String get TextAppReportBug => "بگ کی اطلاع دیں۔";
  String get TextAppAttachImage => "تصویر منسلک کریں۔";
  String get TextAppResetPassword => "پاس ورڈ ری سیٹ";
  String get TextAppNINAppCreditsPage => "NIN ایپ کریڈٹس صفحہ";
  String get NINTextOopsSomethingWentWrong => "افوہ! کچھ غلط ہو گیا";
  String get NINTextPleaseEnterAllFields => "براہ کرم تمام فیلڈز درج کریں۔";
  String get NINTextSubmittedSuccessfully1 => "کامیابی کے ساتھ جمع کرایا گیا۔";
  String get NINTextSubmittedSuccessfully2 => "کامیابی کے ساتھ جمع کرایا گیا۔";
  String get NINTextFitbitAuthentication => "Fitbit کی توثیق";
  String get NINTextHours => "گھنٹے";
  String get NINTextMinutes => "منٹ";
  String get NINTextEnterDurationFor => "کے لیے مدت درج کریں۔";
  String get NINTextTimerRunning => "ٹائمر چل رہا ہے۔";
  String get NINTextPleaseStopTheTimerBeforeSubmitting =>
      "براہ کرم جمع کرانے سے پہلے ٹائمر بند کر دیں۔";
  String get NINTextTotalDuration => "کل دورانیہ";
  String get NINTextSec => "سیکنڈ";
  String get NINTextStartYourActivity => "اپنی سرگرمی شروع کریں!";
  String get NINTextPause => "توقف";
  String get NINTextReset => "دوبارہ ترتیب دیں۔";
  String get NINTextError => "خرابی";
  String get NINTextPleaseEnterCookedWeightAndServingSize =>
      "براہ کرم پکا ہوا وزن اور سرونگ سائز درج کریں۔";
  String get NINTextEditIngredient => "اجزاء میں ترمیم کریں۔";
  String get NINTextAlert => "الرٹ";
  String get NINTextEnterWeightFor => "کے لیے وزن درج کریں۔";
  String get NINTextNewWeightGram => "نیا وزن (جی)";
  String get NINTextEditRecipeName => "ترکیب کے نام میں ترمیم کریں۔";
  String get NINTextNewRecipeName => "نیا ریسیپی کا نام";
  String get NINTextSubmitted => "جمع کرایا";
  String get NINTextSuccess => "کامیابی";
  String get NINTextDietaryDiaryReportSavedTo =>
      "غذائی ڈائری کی رپورٹ کو محفوظ کر لیا گیا۔";
  String get NINTextErrorSavingFile => "فائل محفوظ کرنے میں خرابی";
  String get NINTextClose => "بند کریں";
  String get NINTextIWantTo => "میں چاہتا ہوں";
  String get NINTextGain => "حاصل کرنا";
  String get NINTextMaintain => "برقرار رکھنا";
  String get NINTextLose => "کھو جانا";
  String get NINTextWeightChangeKg => "وزن میں تبدیلی (کلوگرام)";
  String get NINTextAddNewWeight => "نیا وزن شامل کریں۔";
  String get NINTextEnterWeight => "وزن درج کریں۔";
  String get NINTextOf100Gram => "100 گرام";
  String get NINTextProximateComposition => "قربت کی ترکیب";
  String get NINTextVitamins => "وٹامنز";
  String get NINTextMinerals => "معدنیات";
  String get NINTextTotalSaturatedFattyAcids => "کل سیر شدہ فیٹی ایسڈ";
  String get NINTextAllRecipeOf100Grams => "تمام نسخہ 100 گرام";
  String get NINTextOurCustomerFeedback => "ہمارے گاہک کی رائے";
  String get NINTextOverallRatings => "مجموعی درجہ بندی";
  String get NINTextRateUs => "ہمیں درجہ دیں۔";
  String get NINTextBookDetails => "کتاب کی تفصیلات";
  String get NINTextOne => "ایک";
  String get NINTextWeightOf => "wt کی";
  String get NINTextSelectStartDate => "آغاز کی تاریخ منتخب کریں۔";
  String get NINTextSelectEndDate => "اختتامی تاریخ منتخب کریں۔";
  String get NINTextNoData => "کوئی مواد نہیں";
  String get NINTextWorkLevel => "کام کی سطح";
  String get NINTextOldPassword => "پرانا پاسورڈ";
  String get NINTextNewPassword => "نیا پاس ورڈ";
  String get NINTextUpdateProfile => "پروفائل کو اپ ڈیٹ کریں۔";
  String get NINTextChangeImage => "تصویر تبدیل کریں۔";
  String get NINTextNoFavouriteFoodFound => "کوئی پسندیدہ کھانا نہیں ملا";
  String get NINTextCookedQuantity => "پکی ہوئی مقدار";
  String get NINTextServingQuantity => "سرونگ کی مقدار";
  String get NINTextNutrientInformation => "غذائیت کی معلومات";
  String get NINTextIngredient => "اجزاء";
  String get NINTextMealsTakenOn => "کھانا کھایا گیا۔";
  String get NINTextPercentage => "فیصد";
  String get NINTextEAR => "کان";
  String get NINTextValue => "قدر";
  String get NINTextNutrient => "غذائیت";
  String get NINTextEnergyKcal => "توانائی (kcal)";
  String get NINTextProteinG => "پروٹین (جی)";
  String get NINTextFatG => "چربی (جی)";
  String get NINTextCarbohydratesG => "کاربوہائیڈریٹس (جی)";
  String get NINTextCalciumMg => "کیلشیم (ملی گرام)";
  String get NINTextFiberG => "فائبر (جی)";
  String get NINTextIronMg => "آئرن (ملی گرام)";
  String get NINTextZincMg => "زنک (ملی گرام)";
  String get NINTextMagnesiumMg => "میگنیشیم (ملی گرام)";
  String get NINTextThiamineB1Mg => "تھامین (B1) (ملی گرام)";
  String get NINTextRiboflavinB2Mg => "Riboflavin (B2) (mg)";
  String get NINTextNiacinB3Mg => "نیاسین (B3) (ملی گرام)";
  String get NINTextFolatesB9Mcg => "فولیٹس (B9) (mcg)";
  String get NINTextRetinolVitAMcg => "وٹامن اے (ایم سی جی)";
  String get VitaminCmg => "وٹامن سی (ملی گرام)";
  String get Iodinemcg => "آیوڈین (ایم سی جی)";
  String get serving => "سرونگ";
  String get Mynutritionstatus => "میری غذائیت کی حیثیت";

  String get ninTextMyHealthStatus => 'میری صحت کی حیثیت';
  String get ninTextNutrientsInRawFoods => 'خام کھانوں میں غذائی اجزاء';
  String get ninTextNutrientsInRecipes => 'ترکیبوں میں غذائی اجزاء';
  String get ninTextIcmrNinMyPlateForTheDay => 'ICMR-NIN دن کے لیے میری پلیٹ';
  String get ninTextToday => 'آج';
  String get ninTextTrackMyActivity => 'میری سرگرمی کو ٹریک کریں۔';
  String get ninTextMyHeartRate => 'میرے دل کی دھڑکن';
  String get ninTextMyWaterIntake => 'میرا پانی کی مقدار';
  String get ninTextSleepTracker => 'سلیپ ٹریکر';
  String get ninTextLit => 'روشن';
  String get ninTextRecordMyBloodPressure =>
      'میرا بلڈ پریشر / بلڈ گلوکوز / SPO2 ریکارڈ کریں۔';
  String get ninTextNutritionEducationContent => 'غذائیت کی تعلیم کا مواد';
  String get ninTextMyNutrientIntake => 'میرا غذائی اجزاء';
  String get ninTextOn => 'پر';
  String get ninTextWithReferenceToEAR => 'کان کے حوالے سے';
  String get ninTextAchieveYourHealthGoals => 'اپنے صحت کے اہداف حاصل کریں۔';
  String get ninTextPercentage => 'فیصد';
  String get ninTextMyPreviousDietDiaries => 'میری پچھلی خوراک کی ڈائری';
  String get ninTextRecordReviewSleep => 'نیند کا جائزہ لیں / ریکارڈ کریں۔';
  String get ninTextHours => 'گھنٹے';
  String get ninTextIngredient => 'اجزاء';
  String get ninTextOthersSpecify => 'دوسرے بیان کرتے ہیں۔';
  String get ninTextAddNewIngredient => 'نیا اجزاء شامل کریں۔';
  String get ninTextFoodName => 'کھانے کا نام';
  String get ninTextSource => 'ذریعہ';
  String get ninTextEnterBrandAndProductName =>
      'برانڈ اور پروڈکٹ کا نام درج کریں۔';
  String get ninTextEnterAuthorDetails =>
      'مصنف کا نام، سال، جریدہ، صفحہ درج کریں۔';
  String get ninTextEnterFctName => 'FCT کا نام درج کریں۔';
  String get ninTextName => 'نام';
  String get ninTextProductName => 'پروڈکٹ کا نام';
  String get ninTextSelectStartDate => 'آغاز کی تاریخ منتخب کریں۔';
  String get ninTextSelectEndDate => 'اختتامی تاریخ منتخب کریں۔';
  String get ninTextNoExercise => 'کوئی مشق نہیں۔';
  String get ninTextDevelopedWithExpertiseAndInputs =>
      'سنٹر فار ڈویلپمنٹ اینڈ ایڈوانسڈ کمپیوٹنگ (C-DAC)، حیدرآباد لینگویج لنک کے ذریعے NIN کی مہارت اور ان پٹ کے ساتھ تیار کیا گیا';
  String get ninTextMyNutrientIntakeToday => 'آج میرا غذائی اجزاء';
  String get ninTextIcmrNationalInstituteOfNutritionAddress =>
      'ICMR - ترناکا میٹرو اسٹیشن کے پاس نیشنل انسٹی ٹیوٹ آف نیوٹریشن، جمائی-عثمانیہ PO، حیدرآباد-500 007، انڈیا۔';

  String get ninTextKcal => 'kcal';
  String get ninTextKcalPerDay => 'kcal/day';
  String get ninTextDelete => 'حذف کریں۔';
  String get ninTextDeleteNotification => 'اطلاع حذف کریں۔';
  String get ninTextConfirmDeleteNotification =>
      'کیا آپ واقعی اس اطلاع کو حذف کرنا چاہتے ہیں؟';
  String get ninTextTimeFor => 'ارے، یہ\'s time for';
  String get ninTextFitbitWatch => 'فٹ بٹ گھڑی';
  String get ninTextGoogleFitApp => 'گوگل فٹ ایپ';
  String get ninTextUnderweight => 'کم وزن';
  String get ninTextNormal => 'نارمل';
  String get ninTextOverweight => 'زیادہ وزن';
  String get ninTextObesity => 'موٹاپا';
  String get ninTextMale => 'مرد';
  String get ninTextFemale => 'عورت';
  String get ninTextAgeInYears => 'سال میں عمر';
  String get ninTextChangeInWeight => 'وزن میں تبدیلی';
  String get ninTextSteps => 'قدم';
  String get ninTextFor => 'کے لیے';
  String get ninTextMinutes => 'منٹ';
  String get ninTextPause => 'توقف';
  String get ninTextReset => 'دوبارہ ترتیب دیں۔';
  String get ninTextStartActivity => 'اپنی سرگرمی شروع کریں۔';
  String get ninTextCartIsEmpty => 'آپ کی ٹوکری خالی ہے';
  String get ninTextMyPersonalRecipe => 'میرا ذاتی نسخہ';
  String get ninTextSearchByRecipeName => 'ترکیب کے نام سے تلاش کریں۔';
  String get ninTextHelpCenter => 'مدداور تعاون کا مرکز';
  String get ninTextCommonProblems => 'عام مسائل';
  String get ninTextFAQs => 'اکثر پوچھے گئے سوالات';
  String get ninTextHowActiveAreYou => 'آپ کتنے متحرک ہیں۔';
  String get ninTextVitaminC => 'وٹامن سی (ملی گرام)';
  String get ninTextVitaminA => 'وٹامن اے (IU)';
  String get ninTextSodium => 'سوڈیم (ملی گرام)';
  String get ninTextJournal => 'جرنل';
  String get ninTextPage => 'صفحہ';
  String get ninTextAdequateIntakeCarbs =>
      '*کاربوہائیڈریٹس کے لیے مناسب مقدار (AI) تجویز کردہ: بالغ مردوں اور عورتوں کے لیے 130 گرام۔';
  String get ninTextAdequateIntakeFiber =>
      '** فائبر کے لیے تجویز کردہ AI: خواتین کے لیے 25 جی اور مردوں کے لیے 38 جی۔';
  String get your => 'آپ کا';
  String get question1 => 'کیا میں اپنی ذاتی تفصیلات میں ترمیم کر سکتا ہوں؟';
  String get answer1 =>
      'جی ہاں. آپ کے ذاتی ڈیٹا کو آپ کے پروفائل میں ایڈٹ کیا جا سکتا ہے۔';
  String get linkText1 =>
      'اپنی ذاتی تفصیلات میں ترمیم کرنے کے لیے یہاں کلک کریں۔';

  String get question2 => 'کیا میں اپنے رابطے کی تفصیلات تبدیل کر سکتا ہوں؟';
  String get answer2 =>
      "جی ہاں. آپ کے رابطے کی تفصیلات آپ کے پروفائل میں 'ذاتی ڈیٹا' آپشن پر جا کر تبدیل کی جا سکتی ہیں۔";
  String get linkText2 =>
      'اپنے رابطے کی تفصیلات میں ترمیم کرنے کے لیے یہاں کلک کریں۔';

  String get question3 => 'کیا میں اپنا صارف پاس ورڈ تبدیل کر سکتا ہوں؟';
  String get answer3 =>
      "جی ہاں. آپ کے پروفائل میں 'سیٹنگ' آپشن میں جا کر آپ کا پاس ورڈ تبدیل کیا جا سکتا ہے۔";
  String get linkText3 => 'اپنا پاس ورڈ تبدیل کرنے کے لیے یہاں کلک کریں۔';

  String get question4 => 'میں اپنا BMI کیسے چیک کر سکتا ہوں؟';
  String get answer4 =>
      "آپ ہوم پیج پر دکھائے گئے 'ہیلتھ کیلکولیٹر' آپشن میں فراہم کردہ 'BMI کیلکولیٹر' میں اپنا قد اور جسمانی وزن درج کر کے اپنا BMI چیک کر سکتے ہیں۔";
  String get linkText4 => 'BMI کیلکولیٹر استعمال کرنے کے لیے یہاں کلک کریں۔';

  String get question5 =>
      'کیا میں پچھلے مہینے کے لیے اپنے وزن کو ٹریک کر سکتا ہوں؟';
  String get answer5 =>
      "جی ہاں. آپ ہوم پیج پر فراہم کردہ 'ویٹ مینیجر' آپشن میں گزشتہ ماہ/سال کے دوران اپنے جسمانی وزن میں ہونے والی تبدیلیوں کی تفصیلات دیکھ سکتے ہیں۔";
  String get linkText5 => 'اپنا وزن ٹریک کرنے کے لیے یہاں کلک کریں۔';

  String get question6 =>
      "'میں کسی خاص دن اپنی مجموعی جسمانی سرگرمی کو کیسے چیک کرسکتا ہوں؟";
  String get answer6 =>
      "آپ ہوم پیج میں 'میری سرگرمی' کے آپشن سے اپنی جسمانی سرگرمی کو ٹریک کرسکتے ہیں۔";
  String get linkText6 => 'اپنی سرگرمی دیکھنے کے لیے یہاں کلک کریں۔';

  String get question7 =>
      'میں پانی کی مقدار کے لیے یاد دہانی کیسے ترتیب دے سکتا ہوں؟';
  String get answer7 =>
      "آپ ہوم پیج پر فراہم کردہ 'سیٹ نوٹیفکیشن' آپشن میں پانی کی مقدار کی یاد دہانی کے لیے وقت مقرر کر سکتے ہیں۔";
  String get linkText7 =>
      'پانی کی مقدار کی یاد دہانی سیٹ کرنے کے لیے یہاں کلک کریں۔';

  String get question8 =>
      'میں اپنی سمارٹ گھڑی کے ساتھ ایپ کو کیسے ضم کر سکتا ہوں؟';
  String get answer8 =>
      "ہوم پیج میں فراہم کردہ 'connect watch' آپشن پر جا کر آپ اپنی سمارٹ واچ کو ایپ کے ساتھ ضم کر سکتے ہیں۔";
  String get linkText8 => 'اپنی سمارٹ گھڑی کو جوڑنے کے لیے یہاں کلک کریں۔';

  String get question9 =>
      'میں ایک وقت میں کتنے پہننے کے قابل ایپ کے ساتھ ضم کر سکتا ہوں؟';
  String get answer9 =>
      'آپ Fitbit واچ اور Google Fit کو ایپ کے ساتھ ضم کر سکتے ہیں۔';
  String get linkText9 => '';

  String get question10 => 'کون سی سمارٹ گھڑیاں ایپ کے ساتھ مطابقت رکھتی ہیں؟';
  String get answer10 => 'Fitbit واچ اور گوگل فٹ۔';
  String get linkText10 => '';

  String get question11 =>
      'اگر میرے پاس سمارٹ واچ نہیں ہے تو کیا میں اپنی سرگرمی کو ٹریک کر سکتا ہوں؟';
  String get answer11 =>
      'ہاں، آپ اپنی سرگرمی کو ٹریک کر سکتے ہیں۔ اس کے لیے، آپ کو گوگل فٹ ایپ ڈاؤن لوڈ کرنے، گوگل اکاؤنٹ سے سائن ان کرنے اور اسی گوگل اکاؤنٹ کے ساتھ، آپ کو ہمارے واچ سیکشن میں لاگ ان کرنے کی ضرورت ہے۔';
  String get linkText11 => '';

  String get question12 => 'میں اپنی نیند کو کیسے ٹریک کرسکتا ہوں؟';
  String get answer12 =>
      'ہوم پیج میں فراہم کردہ سلیپ ٹریکر آپشن پر جا کر آپ ہفتہ وار/ماہانہ بنیاد پر اپنی نیند کو ٹریک کر سکتے ہیں۔';
  String get linkText12 => 'اپنی نیند کو ٹریک کرنے کے لیے یہاں کلک کریں۔';

  String get question13 =>
      'میں ایپ کے ذریعے کوئی بھی NIN اشاعت کیسے خرید سکتا ہوں؟';
  String get answer13 =>
      "آپ ہوم پیج میں فراہم کردہ 'بک اسٹور' آپشن سے NIN پبلیکیشنز خرید سکتے ہیں۔";
  String get linkText13 => 'بک اسٹور پر جانے کے لیے یہاں کلک کریں۔';

  String get question14 => 'میں اپنی ذاتی خوراک کی ڈائری کیسے بنا سکتا ہوں؟';
  String get answer14 =>
      "آپ 'مائی ڈائیٹ ڈائری آپشن' پر جا کر پورے دن میں کھائے گئے کھانے کی تفصیلات درج کر سکتے ہیں۔";
  String get linkText14 => 'اپنی خوراک کی ڈائری بنانے کے لیے یہاں کلک کریں۔';

  String get question15 =>
      'میں ایسی ترکیب کیسے تلاش کرسکتا ہوں جو کسی خاص غذائیت سے بھرپور ہو؟';
  String get answer15 =>
      "آپ سب سے پہلے ہوم پیج پر 'میرے کھانے میں غذائی اجزاء' ٹیب میں دیے گئے 'ترکیب میں غذائی اجزاء تلاش کریں' کے آپشن کو منتخب کر سکتے ہیں۔ پھر اوپری دائیں کونے میں ڈراپ ڈاؤن فہرست سے مطلوبہ غذائی اجزاء کو منتخب کریں۔";
  String get linkText15 => 'ترکیبیں تلاش کرنے کے لیے یہاں کلک کریں۔';

  String get question16 =>
      'میں ایک ایسے دن کے لیے اپنے غذائی اجزاء کی مقدار کی جانچ کیسے کر سکتا ہوں جو پچھلے مہینے بچایا گیا تھا؟';
  String get answer16 =>
      "آپ 'کھانے کی فہرست' کے صفحہ میں 'کیلنڈر آئیکون' سے ایک تاریخ منتخب کر کے مخصوص دن پر اپنے غذائی اجزاء کی مقدار دیکھ سکتے ہیں۔";
  String get linkText16 =>
      'اپنے غذائی اجزاء کی مقدار کو چیک کرنے کے لیے یہاں کلک کریں۔';

  String get question17 =>
      'میں اپنی ترکیبوں میں استعمال ہونے والے خام اجزاء میں غذائی اجزاء کیسے تلاش کرسکتا ہوں؟';
  String get answer17 =>
      "آپ ہوم پیج پر موجود 'مائی فوڈ میں غذائی اجزاء' ٹیب میں دیے گئے 'خام کھانوں میں غذائی اجزاء تلاش کریں' کے آپشن کو منتخب کرکے کسی خاص اجزاء میں موجود غذائی اجزاء کو جان سکتے ہیں۔";
  String get linkText17 =>
      'کچے کھانوں میں غذائی اجزاء تلاش کرنے کے لیے یہاں کلک کریں۔';

  String get question18 =>
      "میں کسی ترکیب کی غذائیت کی ترکیب کو کیسے جان سکتا ہوں؟";
  String get answer18 =>
      "آپ ہوم پیج پر موجود 'نیوٹرینٹس ان مائی فوڈ' ٹیب میں دیے گئے 'ترکیب میں غذائی اجزاء تلاش کریں' کے آپشن کو منتخب کرکے کسی خاص اجزاء میں موجود غذائی اجزاء کو جان سکتے ہیں۔";
  String get linkText18 => 'غذائی اجزاء کی ترکیب جاننے کے لیے یہاں کلک کریں۔';

  String get question19 =>
      'کیا میں ایک نئی ترکیب شامل کر سکتا ہوں جو ایپ میں دستیاب نہیں ہے؟';
  String get answer19 =>
      "جی ہاں. آپ مخصوص فکسڈ ریسیپی کے نیچے دیئے گئے لنک کا استعمال کرتے ہوئے موجودہ ریسیپی میں ترمیم کرسکتے ہیں یا ڈائٹ ڈائری پیج میں ہر کھانے کے لیے فراہم کردہ 'کسٹم ڈش بنائیں' کے آپشن پر کلک کرکے بالکل نئی ریسیپی بنا سکتے ہیں۔";
  String get linkText19 => 'حسب ضرورت نسخہ بنانے کے لیے یہاں کلک کریں۔';

  String get question20 =>
      'کیا میں صحت کی مخصوص حالت کے لیے غذائی سفارشات حاصل کر سکتا ہوں؟';
  String get answer20 =>
      "جی ہاں. آپ ہوم پیج میں موجود 'سرچ کمپوننٹ' آپشن سے صحت کی سفارشات یا ڈائیٹ چارٹ کے رہنما خطوط حاصل کر سکتے ہیں۔";
  String get linkText20 => 'غذائی سفارشات حاصل کرنے کے لیے یہاں کلک کریں۔';

  String get question21 =>
      'کیا میں ایپ کو انگریزی کے علاوہ کسی اور زبان میں استعمال کر سکتا ہوں؟';
  String get answer21 =>
      "جی ہاں. آپ اپنے پروفائل میں فراہم کردہ 'سیٹنگ' آپشن سے مطلوبہ زبان منتخب کر سکتے ہیں۔";
  String get linkText21 => 'زبان تبدیل کرنے کے لیے یہاں کلک کریں۔';

  String get ninTextBmiHwading => 'باڈی ماس انڈیکس (BMI):';
  String get ninTextBmiDiscription =>
      'BMI ایک شخص کے وزن کو کلوگرام میں تقسیم کرنے والے شخص کی اونچائی کے مربع میٹر (kg/m2) کے طور پر بیان کیا جاتا ہے۔ بی ایم آئی کی حدیں اس بات پر مبنی ہیں کہ جسم کی ضرورت سے زیادہ چربی بیماری اور موت پر اثر انداز ہوتی ہے اور اس کا معقول حد تک بالغ ہونے سے تعلق ہے۔ BMI بیماری کے خطرے کے اشارے کے طور پر تیار کیا گیا تھا۔ جیسا کہ BMI بڑھتا ہے، اسی طرح بعض بیماریوں کا خطرہ بھی بڑھ جاتا ہے۔ زیادہ وزن اور موٹاپے سے متعلق کچھ عام حالات میں شامل ہیں: قبل از وقت موت، قلبی امراض، ہائی بلڈ پریشر، اوسٹیو ارتھرائٹس، کچھ کینسر اور ذیابیطس۔';
  String get ninTextbminutritionsta => 'BMI غذائیت کی حیثیت';
  String get ninTextNutritionstat => 'غذائیت کی حیثیت';
  String get ninTextBelow => 'نیچے';
  String get ninTextPreobesity => 'پری موٹاپا';

  String get ninTextbesity => 'موٹاپا کلاس I';
  String get ninTextbesity2 => 'موٹاپا کلاس II';
  String get ninTextbesity3 => 'موٹاپا کلاس II';
  String get ninTextBMRfull => 'بیسل میٹابولک ریٹ (BMR)';
  String get ninTextBMRDiscription =>
      'بیسل میٹابولک ریٹ (BMR) وہ شرح ہے جس پر کوئی شخص آرام کے دوران توانائی خرچ کرتا ہے۔';
  String get ninTextPreviousdays => 'پچھلے 30 دن';
  String get ninTextason => 'بیٹا';
  String get ninTextYearly => 'سالانہ';
  String get ninTextabove => 'اوپر';
  String get ninTextAchieveyourhealthgoal => 'اپنی صحت کا مقصد حاصل کریں۔';
  String get heavyDescription =>
      'اس زمرے میں ایسے پیشے شامل ہیں جن میں باقاعدہ اور شدید جسمانی سرگرمیاں شامل ہیں، جیسے کہ دوڑنا، سائیکل چلانا، یا بھاری وزن اٹھانا، ہر روز ایک گھنٹے سے زیادہ۔ مثالوں میں لوہار، کان کن اور تعمیراتی کارکن شامل ہیں۔';
  String get moderateDescription =>
      'اس زمرے کے افراد روزانہ تقریباً 30 منٹ سے ایک گھنٹہ تک کسی نہ کسی سطح کی جسمانی سرگرمی میں مشغول ہوتے ہیں، جیسے چہل قدمی یا ہلکی سی جاگنگ۔ دستی مزدور، کاریگر، اور کچھ قسم کے ہنر مند کارکن جیسے پیشے اس زمرے میں آتے ہیں۔';
  String get sedentaryDescription =>
      'اس زمرے میں وہ پیشے شامل ہیں جن میں دن بھر جسمانی حرکت بہت کم ہوتی ہے۔ ان ملازمتوں میں لوگ اپنا زیادہ تر وقت بیٹھے یا لیٹنے میں گزارتے ہیں۔ مثالوں میں دفتری کارکنان، اساتذہ اور انتظامی کرداروں میں شامل ہیں۔';
  String get Foodprotein => "پروٹین";
  String get Foodfat => "موٹا";
  String get Foodenergy => "توانائی";
  String get FoodtotalB2 => "کل B2";
  String get Foodvitamins => "وٹامنز";
  String get FoodtotalFat => "کل چربی";
  String get FoodproximateComposition => "قربت کی ترکیب";
  String get FoodnutrientsIn100g => "100 گرام میں غذائی اجزاء";
  String get FoodtotalCarotenoids => "کل کیروٹینائڈز";
  String get FoodtotalAscorbicAcid => "کل ascorbic ایسڈ";
  String get FoodtotalB9 => "کل B9";
  String get FoodtotalB6 => "کل B6";
  String get Foodcalcium => "کیلشیم";
  String get Foodsodium => "سوڈیم";
  String get Foodpotassium => "پوٹاشیم";
  String get Foodzinc => "زنک";
  String get Foodiron => "لوہا";
  String get Foodminerals => "معدنیات";
  String get FoodtotalSaturatedFattyAcids => "کل سیر شدہ فیٹی ایسڈز";
  String get FoodfattyAcids => "فیٹی ایسڈ";
  String get FoodtotalDietaryFiber => "کل غذائی ریشہ";
  String get Foodmanganese => "مینگنیز";
  String get Foodcopper => "تانبا";
  String get Foodselenium => "سیلینیم";
  String get Foodmagnesium => "میگنیشیم";
  String get Foodphosphorus => "فاسفورس";
  String get Foodcholesterol => "کولیسٹرول";
  String get Foodcarbohydrate => "کاربوہائیڈریٹ";
  String get FoodvitaminB6 => "وٹامن بی 6 (ملی گرام)";
  String get Punjabi => "پنجابی";
  String get Gujarati => "گجراتی";
  String get Odia => "اوڈیا";
  String get Kannada => "کنڑ";
  String get Marathi => "مراٹھی";
  String get Tamil => "تامل";
  String get Bengali => "بنگالی";
  String get Telugu => "تیلگو";
  String get English => "انگریزی";
  String get Hindi => "ہندی";
  String get firstname => "پہلا نام";
  String get lastname => "آخری نام";
  String get labelSodium => "سوڈیم";
  String get labelVitaminC => "وٹامن سی";
  String get FinanameEnergy => "طاقت";
  String get FinanameCarbohydrate => "کاربوہائیڈریٹ";
  String get FinanameFat => "چربی";
  String get FinanameSodium => "سوڈیم";
  String get FinanameDietaryFibre => "غذائی فائبر";
  String get FinanameCalcium => "کیلشیم";
  String get FinanameIron => "لوہا";
  String get FinanameMagnesium => "میگنیشیم";
  String get FinanameZinc => "زنک";
  String get FinanameProtein => "پروٹین";
  String get FinanameThiamine => "تھائیمن";
  String get FinanameRiboflavin => "رائی بو فلیون";
  String get FinanameNiacin => "نیاسن";
  String get FinanameVitaminB => "وٹامن بی";
  String get FinanameFolate => "فولیٹ";
  String get FinanameVitaminC => "وٹامن سی";
  String get FinanameVitaminA => "وٹامن اے";
  String get FinanameVitaminb6 => "وٹامن بی 6";
  String get confirmDeleteAllNotifications =>
      "کیا آپ تمام اطلاعات کو حذف کرنا چاہتے ہیں؟";
  String get fillAllFields => "براہ کرم تمام شعبوں کو بھریں";
  String get successfullyAddedIngredient => "عنصر کامیابی سے شامل کیا گیا";
  String get confirmDeletion => "حذف کی تصدیق کریں";
  String get confirmDeleteIngredient => "کیا آپ اس عنصر کو حذف کرنا چاہتے ہیں؟";
  String get fileDownloaded =>
      "فائل کو کامیابی سے ڈاؤن لوڈ کیا گیا اور فائل کی جگہ";
  String get EssentialNutritionalGuidelines =>
      "بھارتیوں کی غذائی ضروریات کے لیے ضروری غذائیت کے رہنما اصول۔";
  String get NutrientRequirementsRDA2020 =>
      "بھارتیوں کے لیے غذائی اجزاء کی ضروریات اور تجویز کردہ غذائی الاؤنس (RDA 2020)۔";
  String get RecommendationsBalancedDiets =>
      "ہندوستان میں متوازن غذا اور صحت مند کھانے کی عادات کو فروغ دینے کے لیے سفارشات۔";
  String get DietaryGuidelinesForIndians => "بھارتیوں کے لیے غذائی ہدایات۔";
  String get Nutritionstat => "غذائیت کے اعدادوشمار";
  String get referenceMen65kg => "حوالہ مرد (65 کلو)";
  String get referenceWomen55kg => "حوالہ عورتیں (55 کلو)";
  String get valueForMen => "1506";
  String get valueForWomen => "1184";
  String get referenceMenWomenDescription =>
      "حوالہ مرد اور عورتیں صحت مند بالغوں کے طور پر 19-39 سال کی عمر کے ہوتے ہیں، ایک نارمل بی ایم آئی رکھتے ہیں، اور معتدل طور پر سرگرم ہوتے ہیں (ICMR-NIN). دیکھیں";
  String get personalizedDietDiaryDescription =>
      "ذاتی غذائی ڈائری آپ کی موجودہ سے گزشتہ ماہ تک کی غذائیت کی مقدار کو ٹریک کرتی ہے";

  String get confirmDeleteFood => "کیا آپ کھانا حذف کرنا چاہتے ہیں؟";
  String get estimatedAverageRequirement =>
      'تخمینی اوسط ضرورت (EAR): صحت مند افراد کی ضروریات کو پورا کرنے کے لئے دنیا کی اوسط درجہ حرارت کی مقدار';
  String get editQuantity => "مقدار میں ترمیم کریں";
  String get confirmDelete => "کیا آپ حذف کرنا چاہتے ہیں؟";
  String get exerciseDeleted => "ورزش کامیابی سے حذف کر دی گئی ہے۔";
  String get confirmDeleteExercise => "کیا آپ اس ورزش کو حذف کرنا چاہتے ہیں؟";
}
