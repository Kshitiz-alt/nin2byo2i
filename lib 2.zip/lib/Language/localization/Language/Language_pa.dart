// LanguagePa.dart
import 'languages.dart';

class LanguagePa extends Languages {
  @override
  String get appName => "NIN2.0";
  String get recordMyDiet => "ਮੇਰੀ ਖੁਰਾਕ ਦਰਜ ਕਰੋ";
  String get moisture => "ਨਮੀ";
  String get indianFoodCompositionTitle => "ਭਾਰਤੀ ਖ਼ਾਦਾ ਸੰਰਚਨਾ ਟੇਬਲ (2017)";

  String get indianFoodCompositionDescription =>
      "ਭਾਰਤੀ ਖ਼ਾਦਾ ਸੰਰਚਨਾ ਟੇਬਲ (2017): ਭਾਰਤੀ ਖ਼ਾਦਾ ਪਦਾਰਥਾਂ ਲਈ ਵਿਆਪਕ ਪੋਸ਼ਣ ਸਬੰਧੀ ਡੇਟਾ।";

  @override
  String get labelWelcome => "ਸੁਆਗਤ ਹੈ";
  String get inputActivityDataPrompt =>
      "ਆਪਣੇ ਊਰਜਾ ਖ਼ਰਚ ਅਤੇ ਸੰਤੁਲਨ ਦੇਖਣ ਲਈ, ਕਿਰਪਾ ਕਰਕੇ 24 ਘੰਟਿਆਂ ਦੀ ਸਰਗਰਮੀ ਦਾ ਡਾਟਾ ਦਰਜ ਕਰੋ।";
  String get myEnergyBalanceYesterday => "ਮੇਰਾ ਊਰਜਾ ਸੰਤੁਲਨ (ਕਲ੍ਹ)";
  String get caloriesBurnFromWatch => "ਘੜੀ ਤੋਂ ਸੜੀਆਂ ਕੈਲਰੀਆਂ";
  String get activities => "ਸਰਗਰਮੀਆਂ";
  String get searchActivityHere => "ਇੱਥੇ ਸਰਗਰਮੀ ਲੱਭੋ";
  String get orSelectActivityFromBelow => "ਜਾਂ ਹੇਠਾਂ ਤੋਂ ਸਰਗਰਮੀ ਚੁਣੋ";
  String get tryLater => "ਬਾਅਦ ਵਿੱਚ ਕੋਸ਼ਿਸ਼ ਕਰੋ";
  @override
  String get labelSelectLanguage => "ਭਾਸ਼ਾ ਚੁਣੋ";
  String get energybalance => "ਊਰਜਾ ਸੰਤੁਲਨ";
  String get indicatorhealth =>
      "('+' ਊਰਜਾ ਅਤੀਤ ਨੂੰ ਸੂਚਿਤ ਕਰਦਾ ਹੈ; '-' ਊਰਜਾ ਘਾਟ ਨੂੰ ਸੂਚਿਤ ਕਰਦਾ ਹੈ)";

  @override
  String get labelInfo => "ਇਹ ਬਹੁ-ਭਾਸ਼ਾਵਾਂ ਡੈਮੋ ਐਪਲੀਕੇਸ਼ਨ ਹੈ";
  String get totalEnergyConsumption => "ਕੁੱਲ ਊਰਜਾ ਖਪਤ";
  String get totalEnergyExpenditure => "ਕੁੱਲ ਊਰਜਾ ਖਰਚ";

  @override
  // TODO: implement labelChangeLanguage
  String get labelChangeLanguage => "ਭਾਸ਼ਾ ਬਦਲੋ";
  @override
  String get labelWelcomeBack => "ਵਾਪਸ ਸਵਾਗਤ,";

  @override
  String get labelUnderweight => "ਤੁਹਾਡਾ ਭਾਰ ਘੱਟ ਹੈ";

  @override
  String get labelNormalWeight => "ਤੁਹਾਡਾ ਭਾਰ ਆਮ ਹੈ";

  @override
  String get labelOverweight => "ਤੁਹਾਡਾ ਭਾਰ ਜ਼ਿਆਦਾ ਹੈ";

  @override
  String get labelObese => "ਤੁਸੀਂ ਮੋਟੇ ਹੋ";

  @override
  String get labelViewMore => "ਹੋਰ ਵੇਖੋ";

  @override
  String get labelTodaySteps => "ਅੱਜ ਦੇ ਕਦਮ";

  @override
  String get labelCheck => "ਚੈਕ";

  @override
  String get labelHealthData =>
      "ਮੇਰਾ ਬਲੱਡ ਪ੍ਰੈਸ਼ਰ / ਬਲੱਡ ਗਲੂਕੋਜ਼ / SPO2 ਰਿਕਾਰਡ ਕਰੋ";

  @override
  String get labelActivityStatus => "ਗਤੀਵਿਧੀ ਸਥਿਤੀ";

  @override
  String get labelHeartRate => "ਦਿਲ ਧੜਕਣ ਦੀ ਰਫ਼ਤਾਰ";

  @override
  String get labelHeartRateValue => "78 ਬੀਪੀਐਮ";

  @override
  String get labelMinutesAgo => "ਮਿੰਟ ਪਹਿਲਾਂ";

  @override
  String get labelWaterIntake => "ਮੇਰਾ ਪਾਣੀ ਦਾ ਸੇਵਨ";

  @override
  String get labelLiters => "ਲਿਟਰ";

  @override
  String get labelZeroLiters => "0 ਲੀਟਰ";

  @override
  String get labelRealTimeGoal => "ਅਸਲ ਸਮਾਂ, ਟੀਚਾ";

  @override
  String get labelCalories => "ਕੈਲੋਰੀ ਸਾੜ";

  @override
  String get labelCaloriesEarned => "ਕੈਲੋਰੀ ਪ੍ਰਾਪਤ ਕੀਤੀ";

  @override
  String get labelFoodPlan => "ਭੋਜਨ ਯੋਜਨਾ";

  @override
  String get labelWorkoutProgress => "ਕਸਰਤ ਦੀ ਪ੍ਰਗਤੀ";

  @override
  String get labelWeekly => "ਹਫਤਾਵਾਰੀ";

  @override
  String get labelMonthly => "ਮਹੀਨਾਵਾਰ";

  @override
  String get labelLatestWorkout => "ਨਵੀਨਤਮ ਕਸਰਤ";

  @override
  String get labelSeeMore => "ਹੋਰ ਵੇਖੋ";
  String get labelBreakfast => "ਨਾਸ਼ਤਾ";
  String get labelLunch => "ਦੁਪਹਿਰ ਦਾ ਖਾਣਾ";
  String get labelDinner => "ਰਾਤ ਦਾ ਖਾਣਾ";
  String get labelSnacks => "ਸਨੈਕਸ";
  String get labelTaken => "ਲਿਆ";
  String get labelTarget => "ਨਿਸ਼ਾਨਾ";

  //profile

  String get labelProfile => "ਪ੍ਰੋਫਾਈਲ";
  String get labelEdit => "ਸੰਪਾਦਿਤ ਕਰੋ";
  String get labelUser => "ਉਪਭੋਗਤਾ";
  String get labelProgram => "ਇੱਕ ਚਰਬੀ ਪ੍ਰੋਗਰਾਮ ਗੁਆ";
  String get labelHeight => "ਉਚਾਈ";
  String get labelWeight => "ਭਾਰ";
  String get labelAge => "ਉਮਰ";
  String get labelAccount => "ਖਾਤਾ";
  String get labelPersonalData => "ਨਿਜੀ ਸੂਚਨਾ";
  String get labelAchievement => "ਪ੍ਰਾਪਤੀ";
  String get labelActivityHistory => "ਗਤੀਵਿਧੀ ਦਾ ਇਤਿਹਾਸ";
//String get labelWorkoutProgress => "ਕਸਰਤ ਦੀ ਪ੍ਰਗਤੀ";
  String get labelNotification => "ਸੂਚਨਾ";
  String get labelPopupNotification => "ਪੌਪ-ਅੱਪ ਸੂਚਨਾ";
  String get labelMensurationCycle => "ਚੱਕਰ ਮਾਪ";
  String get labelOther => "ਹੋਰ";
  String get labelContactUs => "ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ";
  String get labelPrivacyPolicy => "ਪਰਾਈਵੇਟ ਨੀਤੀ";
  String get labelSetting => "ਸੈਟਿੰਗ";
  String get labelFeedback => "ਸੁਝਾਅ";
  String get labelConfirmLogout => "ਲਾਗਆਉਟ ਦੀ ਪੁਸ਼ਟੀ ਕਰੋ";
  String get labelConfirmLogoutMessage =>
      "ਕੀ ਤੁਸੀਂ ਯਕੀਨੀ ਤੌਰ 'ਤੇ ਲੌਗ ਆਊਟ ਕਰਨਾ ਚਾਹੁੰਦੇ ਹੋ?";
  String get labelLogout => "ਲਾੱਗ ਆਊਟ, ਬਾਹਰ ਆਉਣਾ";
  //select tab
  String get labelOptions => "ਵਿਕਲਪ";
  String get labelFoodTable => "ਭੋਜਨ ਸ਼ਾਮਲ ਕਰੋ";
  String get labelTop10Food => "ਚੋਟੀ ਦੇ 10 ਭੋਜਨ";
  String get labelActivityTrack => "ਗਤੀਵਿਧੀ ਟਰੈਕਰ";
  String get labelsteptracker => "ਸਟੈਪ ਟਰੈਕਰ";

  String get labelTodayTarget => "ਪਾਣੀ ਦਾ ਟੀਚਾ";
  String get labelJoggingTrack => "ਜੌਗਿੰਗ ਟਰੈਕ";
  String get labelMensurationTrack => "ਮਾਹਵਾਰੀ ਟਰੈਕ";
//String get labelFoodTable => "ਭੋਜਨ ਸਾਰਣੀ";
  String get labelPassword => "ਪਾਸਵਰਡ ਬਦਲੋ";
  String get labelDarkMode => "ਡਾਰਕ ਮੋਡ ਅਜ਼ਮਾਓ";
  String get labelconectWatch => "ਘੜੀ ਨੂੰ ਕਨੈਕਟ ਕਰੋ";
  @override
  String get labelSleep => "ਸਲੀਪ";
  @override
  String get labelBookStore => "ਕਿਤਾਬਾਂ ਦੀ ਦੁਕਾਨ";
  @override
  String get labelSearchBooks => "ਕਿਤਾਬਾਂ ਦੀ ਖੋਜ ਕਰੋ";
  @override
  String get labelPrice => "ਕੀਮਤ";
  @override
  String get labelAddToCart => "ਠੇਲ੍ਹੇ ਵਿੱਚ ਪਾਓ";
  @override
  String get labelAuthor => "ਲੇਖਕ";
  @override
  String get labelYear => "ਸਾਲ";
  @override
  String get labelQuantityAvailable => "ਉਪਲਬਧ ਮਾਤਰਾ";
  @override
  String get labelCart => "ਠੇਲ੍ਹੇ ਵਿੱਚ ਪਾਓ";
  @override
  String get labelMyOrders => "ਮੇਰੇ ਹੁਕਮ";
  @override
  String get labelAllOrders => "ਸਾਰੇ ਆਦੇਸ਼";
  @override
  String get labelOrderDetail => "ਆਰਡਰ ਦਾ ਵੇਰਵਾ";
  @override
  String get labelOrderId => "ਆਰਡਰ ਆਈ.ਡੀ";
  @override
  String get labelOrdersInMyOrders => "ਮੇਰੇ ਹੁਕਮ ਵਿਚ";
  @override
  String get labelItemsInMyOrders => "ਮੇਰੇ ਆਰਡਰ ਵਿੱਚ ਆਈਟਮਾਂ";
  @override
  String get labelTotal => "ਕੁੱਲ";
  @override
  String get labelTotalPrice => "ਕੁੱਲ ਕੀਮਤ";
  @override
  String get labelCheckout => "ਕਮਰਾ ਛੱਡ ਦਿਓ";

  // Meal List
  @override
  String get labelMealList => "ਮੇਰੀ ਖੁਰਾਕ";
  @override
  String get labelAnalyze => "ਵਿਸ਼ਲੇਸ਼ਣ ਕਰੋ";
  @override
  String get labelAddDish => "ਪਕਵਾਨ ਸ਼ਾਮਲ ਕਰੋ";
  @override
  String get labelTop10Foods => "ਚੋਟੀ ਦੇ 10 ਭੋਜਨ";
  @override
  String get labelRecentMeal => "ਤਾਜ਼ਾ ਭੋਜਨ";
  @override
  String get labelAnalyzeIngredientsTaken => "ਭੋਜਨ ਦੀ ਮਾਤਰਾ ਦਾ ਵਿਸ਼ਲੇਸ਼ਣ ਕਰੋ";

  // Nutrition Summary
  @override
  String get labelCarbs => "ਕਾਰਬੋਹਾਈਡਰੇਟ";
  // @override
  // String get labelCalories => "ਕੈਲੋਰੀ";
  @override
  String get labelFibers => "ਕੁੱਲ ਫਾਈਬਰ";
  @override
  String get labelFats => "ਚਰਬੀ";
  @override
  String get labelProteins => "ਪ੍ਰੋਟੀਨ";
  @override
  String get labelCalcium => "ਕੈਲਸ਼ੀਅਮ";

  @override
  String get labelNiacinB3 => "ਨਿਆਸੀਨ (B3)";

  @override
  String get labelThiamineB1 => "ਥਿਆਮੀਨ (B1)";

  @override
  String get labelIron => "ਲੋਹਾ";

  @override
  String get labelZinc => "ਜ਼ਿੰਕ";

  @override
  String get labelFolatesB9 => "ਫੋਲੇਟ (B9)";

  @override
  String get labelRiboflavinB2 => "ਰਿਬੋਫਲੇਵਿਨ (B2)";

  @override
  String get labelRetinolVitA => "ਰੈਟੀਨੌਲ (ਵਿਟਾਮਿਨ ਏ)";

  @override
  String get labelMagnesium => "ਮੈਗਨੀਸ਼ੀਅਮ";

  @override
  String get labelTodaysNutritionSummary => "ਅੱਜ ਦਾ ਪੋਸ਼ਣ ਸੰਖੇਪ";
  @override
  String get labelChangeGoal => "ਟੀਚਾ ਬਦਲੋ";
  @override
  String get labelIngredientsTaken => "ਸਮੱਗਰੀ ਲਿਆ";
  @override
  String get labelIngredientsLeft => "ਸਮੱਗਰੀ ਬਾਕੀ ਹੈ";

  // Food Table
  // @override
  // String get labelFoodTable => "ਭੋਜਨ ਸਾਰਣੀ";
  // @override
  // String get labelBreakfast => "ਨਾਸ਼ਤਾ";
  // @override
  // String get labelLunch => "ਦੁਪਹਿਰ ਦਾ ਖਾਣਾ";
  // @override
  // String get labelDinner => "ਰਾਤ ਦਾ ਖਾਣਾ";
  // @override
  // String get labelSnacks => "ਸਨੈਕਸ";
  @override
  String get labelTop10FoodsSleep => "ਚੋਟੀ ਦੇ 10 ਭੋਜਨ";
  @override
  String get labelFavouriteDishes => "ਮਨਪਸੰਦ ਪਕਵਾਨ";

  // User Profile
  @override
  String get labelHelp => "ਮਦਦ ਕਰੋ";
  // @override
  // String get labelLogout => "ਲਾੱਗ ਆਊਟ, ਬਾਹਰ ਆਉਣਾ";
  // @override
  // String get labelWeight => "ਭਾਰ";
  @override
  String get labelEmail => "ਈ - ਮੇਲ";
  // @override
  // String get labelHeight => "ਉਚਾਈ";
  @override
  String get labelLinkedInProfileLink => "ਲਿੰਕਡਇਨ ਪ੍ਰੋਫਾਈਲ ਲਿੰਕ";
  @override
  String get labelGoogleProfileLink => "ਗੂਗਲ ਪ੍ਰੋਫਾਈਲ ਲਿੰਕ";
  @override
  String get labelFacebookProfileLink => "ਫੇਸਬੁੱਕ ਪ੍ਰੋਫਾਈਲ ਲਿੰਕ";
  @override
  String get labelTwitterProfileLink => "ਟਵਿੱਟਰ ਪ੍ਰੋਫਾਈਲ ਲਿੰਕ";
  @override
  String get labelName => "ਨਾਮ";
  @override
  String get labelPhoneNumber => "ਫੋਨ ਨੰ.";
  @override
  String get labelDateOfBirth => "ਡੀ.ਓ.ਬੀ";
  @override
  String get labelBMI => "BMI";
  // @override
  // String get labelAge => "ਉਮਰ";

  // Contact Us
  @override
  String get labelMessage => "ਸੁਨੇਹਾ";
  @override
  String get labelSubmit => "ਜਮ੍ਹਾਂ ਕਰੋ";
  @override
  String get labelCompanyContacts => "ਕੰਪਨੀ ਦੇ ਸੰਪਰਕ";
  @override
  String get labelAddress => "ਪਤਾ";
  @override
  String get labelDirectorsEmail => "ਡਾਇਰੈਕਟਰ ਦੀ ਈਮੇਲ";
  @override
  String get labelFax => "FAX";

  // Settings
  @override
  String get labelResetPassword => "ਪਾਸਵਰਡ ਰੀਸੈਟ ਕਰੋ";
  // @override
  // String get labelFeedback => "ਸੁਝਾਅ";
  @override
  String get labelPleaseProvideFeedback => "ਕਿਰਪਾ ਕਰਕੇ ਆਪਣਾ ਫੀਡਬੈਕ ਪ੍ਰਦਾਨ ਕਰੋ";
  @override
  String get labelEnterYourFeedbackHere => "ਇੱਥੇ ਆਪਣਾ ਫੀਡਬੈਕ ਦਰਜ ਕਰੋ";
  @override
  String get labelSubmitFeedback => "ਫੀਡਬੈਕ ਸਪੁਰਦ ਕਰੋ";

  // Credits
  // @override
  // String get labelContactUs => "ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ";
  @override
  String get labelDevelopmentTeam => "ਵਿਕਾਸ ਟੀਮ";
  @override
  String get labelAcknowledgments => "ਮਾਨਤਾਵਾਂ";
  @override
  String get labelPartnerships => "ਭਾਈਵਾਲੀ";

  // Mobile
  @override
  String get labelSearchComponents => "ਖੋਜ ਭਾਗ";
  @override
  String get labelSearchComponentsHere => "ਇੱਥੇ ਭਾਗ ਖੋਜੋ";
  @override
  String get lablelDishName => 'ਪਕਵਾਨ ਦਾ ਨਾਮ';
  @override
  String get labelCredits => 'ਕ੍ਰੈਡਿਟ';
  @override
  String get labelShareAppButton => "ਸ਼ੇਅਰ ਕਰੋ";
  @override
  String get labelShareApp =>
      "ਬਾਰਕੋਡ ਸਕੈਨਰ ਐਪ ਨਾਲ QR ਕੋਡ ਨੂੰ ਸਕੈਨ ਕਰੋ ਅਤੇ ਐਪ ਡਾਊਨਲੋਡ ਕਰੋ";
  // New translations
  @override
  String get labelConnectedWatch => "ਜੁੜੀ ਘੜੀ ਹੈ";
  @override
  String get labelDisconnect => "ਡਿਸਕਨੈਕਟ ਕਰੋ";
  @override
  String get labelFitbit => "ਫਿਟਬਿਟ";
  @override
  String get labelGoogleFit => "Google Fit";
  @override
  String get labelAppleWatch => "ਐਪਲ ਘੜੀ";
  @override
  String get labelSamsungSmartWatch => "ਸੈਮਸੰਗ ਸਮਾਰਟ ਘੜੀ";
  @override
  String get labelBookDetails => "ਕਿਤਾਬ ਦੇ ਵੇਰਵੇ";
  @override
  String get labelDeliveryDate => "ਪਹੁੰਚਾਉਣ ਦੀ ਮਿਤੀ";
  @override
  String get labelOrderDate => "ਆਰਡਰ ਦੀ ਮਿਤੀ";
  @override
  String get labelAnalyseIngredientsTaken => "ਭੋਜਨ ਦੀ ਮਾਤਰਾ ਦਾ ਵਿਸ਼ਲੇਸ਼ਣ ਕਰੋ";
  @override
  String get labelAddDishIngredients => "ਪਕਵਾਨ ਸਮੱਗਰੀ ਸ਼ਾਮਲ ਕਰੋ";
  @override
  String get labelIngredientName => "ਸਮੱਗਰੀ ਦਾ ਨਾਮ";
  @override
  String get labelEnterIngredientName => "ਇੱਕ ਸਮੱਗਰੀ ਦਾ ਨਾਮ ਦਰਜ ਕਰੋ";
  @override
  String get labelIngredientQuantity => "ਸਮੱਗਰੀ ਦੀ ਮਾਤਰਾ";
  @override
  String get labelEnterIngredientQuantity => "ਸਮੱਗਰੀ ਦੀ ਮਾਤਰਾ ਦਰਜ ਕਰੋ";
  @override
  String get labelAdd => "ਸ਼ਾਮਲ ਕਰੋ";
  @override
  String get labelSave => "ਸੇਵ ਕਰੋ";
  @override
  String get labelwatch => "ਘੜੀ";

  //
  @override
  String get labelBloodOxygenHeart =>
      'ਮਹੱਤਵਪੂਰਣ ਸੰਕੇਤਾਂ ਨੂੰ ਮਾਪੋ ਅਤੇ ਸਮੁੱਚੀ ਸਿਹਤ ਨੂੰ ਟਰੈਕ ਕਰੋ।';
  @override
  String get labelTop10FoodS =>
      'ਸਿਹਤਮੰਦ ਜੀਵਨ ਸ਼ੈਲੀ ਬਣਾਈ ਰੱਖਣ ਲਈ ਸਿਫਾਰਸ਼ ਕੀਤੇ ਭੋਜਨਾਂ ਦੀ ਖੋਜ ਕਰੋ।';
  @override
  String get labelWaterTrack =>
      'ਰੋਜ਼ਾਨਾ ਫਿਟਨੈਸ ਹਾਈਡਰੇਸ਼ਨ ਟੀਚਿਆਂ ਨੂੰ ਸੈੱਟ ਕਰੋ ਅਤੇ ਪ੍ਰਾਪਤ ਕਰੋ।';
  @override
  String get labelPersonalDetails =>
      'ਨਿੱਜੀ ਜਾਣਕਾਰੀ ਨੂੰ ਸੁਰੱਖਿਅਤ ਢੰਗ ਨਾਲ ਪ੍ਰਬੰਧਿਤ ਅਤੇ ਅੱਪਡੇਟ ਕਰੋ।';
  @override
  String get labelFeedbackS => 'ਆਪਣੇ ਵਿਚਾਰ ਅਤੇ ਸੁਝਾਅ ਸਾਡੇ ਨਾਲ ਸਾਂਝੇ ਕਰੋ।';
  @override
  String get labelContactUsS =>
      'ਗਾਹਕ ਸਹਾਇਤਾ ਤੱਕ ਪਹੁੰਚੋ ਅਤੇ ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ।';
  @override
  String get labelBMICalculator =>
      'ਸਿਹਤ ਸੰਬੰਧੀ ਜਾਣਕਾਰੀ ਲਈ ਆਪਣੇ ਬਾਡੀ ਮਾਸ ਇੰਡੈਕਸ ਦੀ ਗਣਨਾ ਕਰੋ।';
  @override
  String get labelBMRCalculator =>
      'ਫਿਟਨੈਸ ਪਲੈਨਿੰਗ ਲਈ ਆਪਣੀ ਬੇਸਲ ਮੈਟਾਬੋਲਿਕ ਰੇਟ ਦੀ ਗਣਨਾ ਕਰੋ।';
  @override
  String get labelRunningJoggingSteps =>
      'ਇੱਕ ਸਿਹਤਮੰਦ ਜੀਵਨ ਸ਼ੈਲੀ ਲਈ ਆਪਣੇ ਦੌੜਨ ਅਤੇ ਜੌਗਿੰਗ ਦੇ ਕਦਮਾਂ ਨੂੰ ਟ੍ਰੈਕ ਕਰੋ।';
  @override
  String get labelHealthyDietChart =>
      'ਇੱਕ ਸਿਹਤਮੰਦ ਖੁਰਾਕ ਬਾਰੇ ਸੰਖੇਪ ਜਾਣਕਾਰੀ ਲਈ ਇੱਕ ਵਿਆਪਕ ਚਾਰਟ ਤੱਕ ਪਹੁੰਚ ਕਰੋ।';
  @override
  String get labelHealthyRecommendation =>
      'ਵਿਅਕਤੀਗਤ ਸਿਹਤ ਸਿਫ਼ਾਰਸ਼ਾਂ ਪ੍ਰਾਪਤ ਕਰੋ।';
  @override
  String get labelSleepTracker =>
      'ਆਪਣੇ ਨੀਂਦ ਦੇ ਪੈਟਰਨ ਨੂੰ ਟ੍ਰੈਕ ਕਰੋ ਅਤੇ ਨੀਂਦ ਦੀ ਗੁਣਵੱਤਾ ਵਿੱਚ ਸੁਧਾਰ ਕਰੋ।';
  @override
  String get labelSetReminder =>
      'ਸਿਹਤ ਅਤੇ ਤੰਦਰੁਸਤੀ ਦੀਆਂ ਗਤੀਵਿਧੀਆਂ ਲਈ ਰੀਮਾਈਂਡਰ ਸੈਟ ਕਰੋ।';
  // @override
  // String get labelMenstruationCycle =>
  //     'ਬਿਹਤਰ ਜਾਣਕਾਰੀ ਲਈ ਆਪਣੇ ਮਾਹਵਾਰੀ ਚੱਕਰ ਨੂੰ ਟ੍ਰੈਕ ਅਤੇ ਪ੍ਰਬੰਧਿਤ ਕਰੋ।';
  @override
  String get labelCSVDownload =>
      'ਆਸਾਨ ਵਿਸ਼ਲੇਸ਼ਣ ਲਈ ਆਪਣੇ ਡੇਟਾ ਨੂੰ CSV ਫਾਰਮੈਟ ਵਿੱਚ ਡਾਊਨਲੋਡ ਕਰੋ।';

  // New Headings
  @override
  String get headingBloodOxygenHeart => 'ਖੂਨ | ਆਕਸੀਜਨ';
  @override
  String get headingTop10Food => 'ਚੋਟੀ ਦੇ 10 ਭੋਜਨ';
  @override
  String get headingWaterTrack => 'ਪਾਣੀ ਦਾ ਟਰੈਕਰ';
  @override
  String get headingPersonalDetails => 'ਨਿੱਜੀ ਵੇਰਵੇ';
  @override
  String get headingFeedback => 'ਸੁਝਾਅ';
  @override
  String get headingContactUs => 'ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ';
  @override
  String get headingBMICalculator => 'BMI ਕੈਲਕੁਲੇਟਰ';
  @override
  String get headingBMRCalculator => 'BMR ਕੈਲਕੁਲੇਟਰ';
  @override
  String get headingRunningJoggingSteps => 'ਦੌੜਨਾ / ਜਾਗਿੰਗ / ਕਦਮ';
  @override
  String get headingHealthyDietChart => 'ਸਿਹਤਮੰਦ ਖੁਰਾਕ ਚਾਰਟ';
  @override
  String get headingHealthyRecommendation => 'ਸਿਹਤਮੰਦ ਸਿਫਾਰਸ਼';
  @override
  String get headingSleepTracker => 'ਸਲੀਪ ਟਰੈਕਰ';
  @override
  String get headingSetReminder => 'ਰੀਮਾਈਂਡਰ ਸੈੱਟ ਕਰੋ';
  // @override
  // String get headingMenstruationCycle => 'ਮਾਹਵਾਰੀ ਚੱਕਰ';
  @override
  String get headingCSVDownload => 'CSV ਡਾਊਨਲੋਡ ਕਰੋ';

  // Water-related phrases
  @override
  String get labelWaterTarget => "ਪਾਣੀ ਦਾ ਟੀਚਾ";
  // @override
  // String get labelTodayTarget => "ਅੱਜ ਦਾ ਟੀਚਾ";
  @override
  String get labelWaterGoal => "ਪਾਣੀ ਦਾ ਟੀਚਾ";
  // @override
  // String get labelWaterIntake => "ਪਾਣੀ ਦਾ ਸੇਵਨ";
  @override
  String get labelWaterProgress => "ਪਾਣੀ ਦੀ ਤਰੱਕੀ";
  // @override
  // String get labelWeekly => "ਹਫਤਾਵਾਰੀ";
  @override
  String get labelDateWise => "ਮਿਤੀ ਅਨੁਸਾਰ";
  @override
  String get labelSun => "ਸੂਰਜ";
  @override
  String get labelMon => "ਸੋਮ";
  @override
  String get labelTue => "ਮੰਗਲਵਾਰ";
  @override
  String get labelWed => "ਬੁੱਧ";
  @override
  String get labelThu => "ਥੁ";
  @override
  String get labelFri => "ਸ਼ੁਕਰਵਾਰ";

  // BMI Calculator
  // @override
  // String get labelBMI => "BMI";
  @override
  String get labelEnterHeight => "ਉਚਾਈ ਦਰਜ ਕਰੋ (ਸੈ.ਮੀ.)";
  @override
  String get labelEnterWeight => "ਭਾਰ ਦਰਜ ਕਰੋ (ਕਿਲੋ)";
  @override
  String get labelCalculateBMI => "BMI ਦੀ ਗਣਨਾ ਕਰੋ";

  // BMR Calculator
  @override
  String get labelMale => "ਨਰ";
  @override
  String get labelFemale => "ਔਰਤ";
  @override
  String get labelEnterAge => "ਉਮਰ ਦਰਜ ਕਰੋ";
  @override
  String get labelCalculateBMR => "BMR ਦੀ ਗਣਨਾ ਕਰੋ";
  @override
  String get labelBMR => "ਬੀ.ਐੱਮ.ਆਰ";
  @override
  String get labelCaloriesPerDay => "ਕੈਲੋਰੀ / ਦਿਨ";

  // Step Tracker
  @override
  String get labelStepsTracker => "ਸਟੈਪ ਟਰੈਕਰ";
  @override
  String get labelRunningTracker => "ਚੱਲ ਰਿਹਾ ਟਰੈਕਰ";
  @override
  String get labelAddStep => "ਕਦਮ ਜੋੜੋ";
  @override
  String get labelSelectDate => "ਮਿਤੀ ਚੁਣੋ";
  @override
  String get labelJoggingTracker => "ਜੌਗਿੰਗ ਟਰੈਕਰ";
  @override
  String get labelCaloriesBurn => "ਕੈਲੋਰੀ ਸਾੜ";

  // Sleep Tracker
  @override
  String get labelSleepTarget => "ਨੀਂਦ ਦਾ ਟੀਚਾ";
  @override
  String get labelTodaySleep => "ਅੱਜ ਨੀਂਦ";
  @override
  String get labelSleepProgress => "ਨੀਂਦ ਦੀ ਤਰੱਕੀ";
  @override
  String get labelTotalSleep => "ਕੁੱਲ ਨੀਂਦ";
  @override
  String get labelSleepGoal => "ਨੀਂਦ ਦਾ ਟੀਚਾ";
  @override
  String get labelSetNotification => "ਸੂਚਨਾ ਸੈੱਟ ਕਰੋ";
  @override
  String get labelStartTime => "ਸ਼ੁਰੂਆਤੀ ਸਮਾਂ";
  @override
  String get labelEndTime => "ਸਮਾਪਤੀ ਸਮਾਂ";
  @override
  String get labelSelect => "ਚੁਣੋ";
  @override
  String get labelSat => "ਸਤਿ";
  // @override
  // String get labelSave => "ਸੇਵ ਕਰੋ";
  @override
  String get labelStart => "ਸ਼ੁਰੂ ਕਰੋ";
  @override
  String get labelEnd => "ਅੰਤ";
  @override
  String get labelType => "ਟਾਈਪ ਕਰੋ";
  @override
  String get labelIsConnected => "ਜੁੜਿਆ ਹੋਇਆ ਹੈ";

  // @override
  // String get labelMensurationCycle => "ਚੱਕਰ ਮਾਪ";

  @override
  String get labelTrackAndManage =>
      "ਬਿਹਤਰ ਸਮਝ ਲਈ ਆਪਣੇ ਮਾਹਵਾਰੀ ਚੱਕਰ ਨੂੰ ਟ੍ਰੈਕ ਅਤੇ ਪ੍ਰਬੰਧਿਤ ਕਰੋ";

  @override
  String get labelMensurationStatus => "ਮਾਪ ਦੀ ਸਥਿਤੀ";

  @override
  String get labelDaysLength => "ਦਿਨਾਂ ਦੀ ਲੰਬਾਈ";

  @override
  String get labelDay => "ਦਿਨ";

  @override
  String get labelNextDate => "ਅਗਲੀ ਤਾਰੀਖ";

  @override
  String get labelLastPeriodStartDate => "ਆਖਰੀ ਮਿਆਦ ਸ਼ੁਰੂ ਹੋਣ ਦੀ ਮਿਤੀ";

  @override
  String get labelAverageCycleLength => "ਔਸਤ ਚੱਕਰ ਦੀ ਲੰਬਾਈ";

  @override
  String get labelChange => "ਬਦਲੋ";

  // Common Messages
  @override
  String get messageSent => "ਸੁਨੇਹਾ ਭੇਜਿਆ ਗਿਆ";

  @override
  String get thankYouForContactingUs => "ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰਨ ਲਈ ਤੁਹਾਡਾ ਧੰਨਵਾਦ!";

  @override
  String get alert => "ਚੇਤਾਵਨੀ";

  @override
  String get fillInAllFields => "ਕਿਰਪਾ ਕਰਕੇ ਸਾਰੇ ਖੇਤਰ ਭਰੋ।";

  @override
  String get thankYouFeedbackSubmitted => "ਤੁਹਾਡਾ ਫੀਡਬੈਕ ਸਪੁਰਦ ਕੀਤਾ ਗਿਆ ਹੈ।";

  @override
  String get resetPassword => "ਪਾਸਵਰਡ ਰੀਸੈਟ ਕਰੋ";

  @override
  String get dishAdded => "ਪਕਵਾਨ ਜੋੜਿਆ ਗਿਆ!";

  @override
  String get dishAndIngredientsAddedSuccessfully =>
      "ਸਫਲਤਾਪੂਰਵਕ ਪਕਵਾਨ ਅਤੇ ਸਮੱਗਰੀ ਸ਼ਾਮਲ ਕੀਤੀ ਗਈ।";

  @override
  String get failed => "ਅਸਫਲ ਰਿਹਾ";

  @override
  String get error => "ਗਲਤੀ";

  @override
  String get enterBloodGlucoseLevel =>
      "mg/dL ਵਿੱਚ ਖੂਨ ਵਿੱਚ ਗਲੂਕੋਜ਼ ਦਾ ਪੱਧਰ ਦਰਜ ਕਰੋ";

  @override
  String get enterBloodPressureLevel =>
      "mmHg ਵਿੱਚ ਬਲੱਡ ਪ੍ਰੈਸ਼ਰ ਦਾ ਪੱਧਰ ਦਰਜ ਕਰੋ";

  @override
  String get enterHeartLevel =>
      "ਕਿਰਪਾ ਕਰਕੇ ਧੜਕਣ ਪ੍ਰਤੀ ਮਿੰਟ (BPM) ਵਿੱਚ ਦਿਲ ਦੀ ਧੜਕਣ ਦਰਜ ਕਰੋ।";

  @override
  String get cancel => "ਰੱਦ ਕਰੋ";

  @override
  String get submit => "ਜਮ੍ਹਾਂ ਕਰੋ";

  @override
  String get valueCannotBeGreaterThan100 => "ਮੁੱਲ 100 ਤੋਂ ਵੱਧ ਨਹੀਂ ਹੋ ਸਕਦਾ।";

  @override
  String get bloodStatusSubmittedSuccessfully =>
      "ਖੂਨ ਦੀ ਸਥਿਤੀ ਸਫਲਤਾਪੂਰਵਕ ਸਪੁਰਦ ਕੀਤੀ ਗਈ।";

  @override
  String get failedToSubmitBlood => "ਖੂਨ ਜਮ੍ਹਾਂ ਕਰਨ ਵਿੱਚ ਅਸਫਲ।";

  @override
  String get enterHeartLevel1to100 =>
      "ਕਿਰਪਾ ਕਰਕੇ ਧੜਕਣ ਪ੍ਰਤੀ ਮਿੰਟ (BPM) ਵਿੱਚ ਦਿਲ ਦੀ ਧੜਕਣ ਦਰਜ ਕਰੋ।";

  @override
  String get heartLevelSubmittedSuccessfully =>
      "ਦਿਲ ਦਾ ਪੱਧਰ ਸਫਲਤਾਪੂਰਵਕ ਸਪੁਰਦ ਕੀਤਾ ਗਿਆ।";

  @override
  String get enterOxygenSaturationLevel1to100 =>
      "ਆਕਸੀਜਨ ਸੰਤ੍ਰਿਪਤਾ ਪੱਧਰ 1% -100% ਦਾਖਲ ਕਰੋ";

  @override
  String get oxygenLevelSubmittedSuccessfully =>
      "ਆਕਸੀਜਨ ਪੱਧਰ ਸਫਲਤਾਪੂਰਵਕ ਸਪੁਰਦ ਕੀਤਾ ਗਿਆ।";

  @override
  String get updateData => "ਡਾਟਾ ਅੱਪਡੇਟ ਕਰੋ";

  @override
  String get selectLastPeriodStartDate => "ਆਖਰੀ ਮਿਆਦ ਦੀ ਸ਼ੁਰੂਆਤੀ ਤਾਰੀਖ ਚੁਣੋ";

  @override
  String get update => "ਅੱਪਡੇਟ ਕਰੋ";

  @override
  String get failedToFetchBooks =>
      "ਕਿਤਾਬਾਂ ਪ੍ਰਾਪਤ ਕਰਨ ਵਿੱਚ ਅਸਫਲ। ਮੁੜ ਕੋਸ਼ਿਸ ਕਰੋ ਜੀ.";

  @override
  String get errorOccurred => "ਇੱਕ ਗਲਤੀ ਆਈ ਹੈ:";

  @override
  String get invalidEndTime => "ਅਵੈਧ ਸਮਾਪਤੀ ਸਮਾਂ";

  @override
  String get chooseTimeWithin1Hour =>
      "ਕਿਰਪਾ ਕਰਕੇ ਸ਼ੁਰੂਆਤੀ ਸਮੇਂ ਤੋਂ 1 ਘੰਟੇ ਦੇ ਅੰਦਰ ਇੱਕ ਸਮਾਂ ਚੁਣੋ।";

  @override
  String get notificationSaved => "ਸੂਚਨਾ ਸੁਰੱਖਿਅਤ ਕੀਤੀ ਗਈ";

  @override
  String get notificationSetSuccessfully => "ਸੂਚਨਾ ਸਫਲਤਾਪੂਰਵਕ ਸੈੱਟ ਕੀਤੀ ਗਈ।";

  @override
  String get thereIsSomeError => "ਕੁਝ ਗਲਤੀ ਹੈ।";

  @override
  String get watchDisconnected => "ਘੜੀ ਡਿਸਕਨੈਕਟ ਕੀਤੀ ਗਈ";

  @override
  String get watchDisconnectedSuccessfully =>
      "ਘੜੀ ਸਫਲਤਾਪੂਰਵਕ ਡਿਸਕਨੈਕਟ ਹੋ ਗਈ ਹੈ।";

  @override
  String get addCup => "ਕੱਪ ਸ਼ਾਮਲ ਕਰੋ";

  @override
  String get numberOfCups => "ਕੱਪ ਦੀ ਗਿਣਤੀ";

  @override
  String get addCupCapacityInMl => "ਮਿਲੀਲੀਟਰ ਵਿੱਚ ਕੱਪ ਸਮਰੱਥਾ ਸ਼ਾਮਲ ਕਰੋ";

  @override
  String get cupCapacitySubmittedSuccessfully =>
      "ਕੱਪ ਸਮਰੱਥਾ ਸਫਲਤਾਪੂਰਵਕ ਸਪੁਰਦ ਕੀਤੀ ਗਈ।";

  @override
  String get pleaseEnterValidValuesForAllFields =>
      "ਕਿਰਪਾ ਕਰਕੇ ਸਾਰੇ ਖੇਤਰਾਂ ਲਈ ਵੈਧ ਮੁੱਲ ਦਾਖਲ ਕਰੋ।";

  @override
  String get enterWater => "ਪਾਣੀ ਦਾਖਲ ਕਰੋ";

  @override
  String get waterGoalLiters => "ਪਾਣੀ ਦਾ ਟੀਚਾ (ਲੀਟਰ)";

  @override
  String get waterSubmittedSuccessfully =>
      "ਪਾਣੀ ਦਾ ਟੀਚਾ ਸਫਲਤਾਪੂਰਵਕ ਸਪੁਰਦ ਕੀਤਾ ਗਿਆ।";

  @override
  String get addActivityData => "ਗਤੀਵਿਧੀ ਡੇਟਾ ਸ਼ਾਮਲ ਕਰੋ";

  @override
  String get enterValue => "ਮੁੱਲ ਦਰਜ ਕਰੋ";

  @override
  String get addStepsData => "ਕਦਮ ਡੇਟਾ ਸ਼ਾਮਲ ਕਰੋ";

  @override
  String get numberOfSteps => "ਕਦਮਾਂ ਦੀ ਸੰਖਿਆ";

  @override
  String get stepsDataSubmittedSuccessfully =>
      "ਕਦਮਾਂ ਦਾ ਡਾਟਾ ਸਫਲਤਾਪੂਰਵਕ ਸਪੁਰਦ ਕੀਤਾ ਗਿਆ।";

  @override
  String get enterSleepTarget => "ਨੀਂਦ ਦਾ ਟੀਚਾ ਦਰਜ ਕਰੋ";

  @override
  String get sleepTargetInHours => "ਘੰਟਿਆਂ ਵਿੱਚ ਨੀਂਦ ਦਾ ਟੀਚਾ";

  @override
  String get addYourSleepDuration => "ਆਪਣੀ ਨੀਂਦ ਦੀ ਮਿਆਦ ਸ਼ਾਮਲ ਕਰੋ";

  @override
  String get enterDurationInMinutes => "ਮਿੰਟਾਂ ਵਿੱਚ ਮਿਆਦ ਦਾਖਲ ਕਰੋ:";

  @override
  String get add => "ਸ਼ਾਮਲ ਕਰੋ";

  @override
  String get ok => "ਠੀਕ ਹੈ";

  @override
  String get csvFileSavedTo => "CSV ਫ਼ਾਈਲ ਵਿੱਚ ਰੱਖਿਅਤ ਕੀਤੀ ਗਈ";

  @override
  String get ageMustBeBetween2And100Years =>
      "ਉਮਰ 2 ਤੋਂ 100 ਸਾਲ ਦੇ ਵਿਚਕਾਰ ਹੋਣੀ ਚਾਹੀਦੀ ਹੈ";

  @override
  String get next => "ਅਗਲਾ";

  @override
  String get register => "ਰਜਿਸਟਰ";

  @override
  String get oopsSomethingWentWrong => "ਓਹ! ਕੁਝ ਗਲਤ ਹੋ ਗਿਆ";

  @override
  String get errorFetchingMeals =>
      "ਭੋਜਨ ਪ੍ਰਾਪਤ ਕਰਨ ਦੌਰਾਨ ਇੱਕ ਤਰੁੱਟੀ ਉਤਪੰਨ ਹੋਈ:";

  @override
  String get reviewAddedSuccessfully => "ਸਮੀਖਿਆ ਸਫਲਤਾਪੂਰਵਕ ਸ਼ਾਮਲ ਕੀਤੀ ਗਈ!";

  @override
  String get failedToAddReview => "ਸਮੀਖਿਆ ਸ਼ਾਮਲ ਕਰਨ ਵਿੱਚ ਅਸਫਲ:";

  @override
  String get alreadyInCart => "ਪਹਿਲਾਂ ਹੀ ਕਾਰਟ ਵਿੱਚ ਹੈ";

  @override
  String get addedToCart => "ਕਾਰਟ ਵਿੱਚ ਸ਼ਾਮਲ ਕੀਤਾ ਗਿਆ";

  @override
  String get quantityNotBetween1And2 => "ਮਾਤਰਾ 2 ਤੋਂ ਵੱਧ ਅਤੇ 1 ਤੋਂ ਘੱਟ ਨਹੀਂ ਹੈ";

  String get createcustomdish => "ਕਸਟਮ ਡਿਸ਼ ਬਣਾਓ";
  String get quantityingram => "ਮਾਤਰਾ (ਗ੍ਰਾਮ)";
  String get labelCaloriestaken => 'ਊਰਜਾ';
  String get mainlabelEarlyMorning => "ਪਹੁ ਫੁੱਟਦਿਆਂ ਹੀ, ਸੁਬ੍ਹਾ - ਸੁਬ੍ਹਾ";
  String get mainlabelMidMorning => "ਅੱਧੀ ਸਵੇਰ";
  String get mainlabelEvening => "ਸ਼ਾਮ";
  String get mainlabelBedtime => "ਸੌਣ ਦਾ ਸਮਾਂ";
  String get mainlabelTimeSpentOn => "ਵੱਖ-ਵੱਖ ਗਤੀਵਿਧੀਆਂ ਵਿੱਚ ਸਮਾਂ ਬਤੀਤ ਕੀਤਾ";
  String get mainlabelHealthCalculator => "ਸਿਹਤ ਕੈਲਕੁਲੇਟਰ";
  String get mainlabelStepProgress => "ਕਦਮ ਤਰੱਕੀ";
  String get mainlabelRealTimeIntakes => "ਰੀਅਲ ਟਾਈਮ ਇਨਟੈਕਸ";
  String get mainlabelCaloriesBurnProgress => "ਕੈਲੋਰੀ ਬਰਨ ਪ੍ਰਗਤੀ";
  String get mainlabelCaloriesBurnBreakdown => "ਕੈਲੋਰੀ ਬਰੇਕਡਾਊਨ 'ਤੇ";
  String get mainlabelHeartReportsTrends => "ਦਿਲ ਰੁਝਾਨਾਂ ਦੀ ਰਿਪੋਰਟ ਕਰਦਾ ਹੈ";
  String get mainlabelOxygenStatus => "ਆਕਸੀਜਨ ਸਥਿਤੀ";
  String get mainlabelNoRecord => "ਮੈਨੂੰ ਯਾਦ ਨਹੀਂ";
  String get mainlabelSystolicBloodPressure => "ਸਿਸਟੋਲਿਕ ਬਲੱਡ ਪ੍ਰੈਸ਼ਰ";
  String get mainlabelMeasuredon => "'ਤੇ ਮਾਪਿਆ";
  String get mainlabelEnterBloodPressure => "ਬਲੱਡ ਪ੍ਰੈਸ਼ਰ ਦਰਜ ਕਰੋ";
  String get mainlabelBloodPressure => "ਬਲੱਡ ਪ੍ਰੈਸ਼ਰ";
  String get mainlabelDiastolicBloodPressure => "ਡਾਇਸਟੋਲਿਕ ਬਲੱਡ ਪ੍ਰੈਸ਼ਰ";
  String get mainlabelBloodGlucose => "ਖੂਨ ਵਿੱਚ ਗਲੂਕੋਜ਼";
  String get mainlabelHeartStatus => "ਦਿਲ ਦੀ ਸਥਿਤੀ";
  String get mainlabelAllExercise => "ਸਾਰੇ ਕਸਰਤ";
  String get mainlabelCleaningOrMopping => "ਸਫਾਈ ਜਾਂ ਮੋਪਿੰਗ";
  String get mainlabelGardening => "ਬਾਗਬਾਨੀ";
  String get mainlabelWatchingTV => "ਟੀਵੀ ਦੇਖਣਾ";
  String get mainlabelCycling => "ਸਾਈਕਲਿੰਗ";
  String get mainlabelRunning => "ਚੱਲ ਰਿਹਾ ਹੈ";
  String get mainlabelWalking => "ਤੁਰਨਾ";
  String get mainlabelShuttle => "ਸ਼ਟਲ";
  String get mainlabelTableTennis => "ਟੇਬਲ ਟੈਨਿਸ";
  String get mainlabelTennis => "ਟੈਨਿਸ";
  String get mainlabelVolleyBall => "ਵਾਲੀਬਾਲ";
  String get mainlabelDancing => "ਨੱਚਣਾ";
  String get mainlabelFishing => "ਮੱਛੀ ਫੜਨ";
  String get mainlabelShopping => "ਖਰੀਦਦਾਰੀ";
  String get mainlabelTyping => "ਟਾਈਪਿੰਗ";
  String get mainlabelSleeping => "ਸੁੱਤੇ ਹੋਏ";
  String get mainlabelStanding => "ਖੜ੍ਹਾ ਹੈ";
  String get mainlabelSitting => "ਬੈਠਾ";
  String get mainlabelClickToStartActivity => "ਸਰਗਰਮੀ ਸ਼ੁਰੂ ਕਰਨ ਲਈ ਕਲਿੱਕ ਕਰੋ";
  String get mainlabelBMICalculator => "BMI ਕੈਲਕੁਲੇਟਰ";
  String get mainlabelBMRCalculator => "BMR ਕੈਲਕੁਲੇਟਰ";
  String get mainlabelDownloadActivityReportInCsv =>
      "csv ਵਿੱਚ ਗਤੀਵਿਧੀ ਰਿਪੋਰਟ ਡਾਊਨਲੋਡ ਕਰੋ";
  String get mainlabelSelectStartDate => "ਸ਼ੁਰੂਆਤੀ ਤਾਰੀਖ ਚੁਣੋ";
  String get mainlabelSelectEndDate => "ਸਮਾਪਤੀ ਮਿਤੀ ਚੁਣੋ";
  String get mainlabelDownloadFile => "ਫਾਈਲ ਡਾਊਨਲੋਡ ਕਰੋ";
  String get mainlabelDate => "ਤਾਰੀਖ਼";
  String get mainlabelValue => "ਮੁੱਲ";
  String get mainlabelLink => "ਲਿੰਕ";
  String get mainlabelNoNotificationFound => "ਕੋਈ ਸੂਚਨਾ ਨਹੀਂ ਮਿਲੀ";
  String get mainlabelTotalNutritionTaken => "= ਲਿਆ ਗਿਆ ਕੁੱਲ ਪੋਸ਼ਣ";
  String get mainlabelSearchFood => "ਪਕਵਾਨਾਂ ਦੀ ਖੋਜ ਕਰੋ";
  String get mainlabelSelectFromPersonalFood => "ਨਿੱਜੀ ਪਕਵਾਨਾਂ ਵਿੱਚੋਂ ਚੁਣੋ";
  String get mainlabelRecipeName => "ਵਿਅੰਜਨ ਦਾ ਨਾਮ";
  String get mainlabelSelectDate => "ਮਿਤੀ ਚੁਣੋ";
  String get mainlabelNutrientOfAllIngredientsRaw =>
      "ਸਾਰੇ ਤੱਤਾਂ ਦੇ ਪੌਸ਼ਟਿਕ ਤੱਤ (ਕੱਚੇ)";
  String get mainlabelNutrientsCompostionOfCookedWeight =>
      "ਲਈ ਪਕਾਏ ਹੋਏ ਭਾਰ ਦੇ ਪੌਸ਼ਟਿਕ ਤੱਤ";
  String get mainlabelWantToEditThisRecipyFollowThe =>
      "ਇਸ ਵਿਅੰਜਨ ਨੂੰ ਸੰਪਾਦਿਤ ਕਰਨਾ ਚਾਹੁੰਦੇ ਹੋ? ਦੀ ਪਾਲਣਾ ਕਰੋ";
  String get mainlabelAddIngredientFrom => "ਤੋਂ ਸਮੱਗਰੀ ਸ਼ਾਮਲ ਕਰੋ";
  String get mainlabelAddFromNutrientSpecifcFood =>
      "ਪੌਸ਼ਟਿਕ ਵਿਸ਼ੇਸ਼ ਭੋਜਨ ਤੋਂ ਸ਼ਾਮਲ ਕਰੋ";
  String get mainlabelAddFromAllFoods => "ਸਾਰੇ ਭੋਜਨਾਂ ਵਿੱਚੋਂ ਸ਼ਾਮਲ ਕਰੋ";
  String get mainlabelNumberOfServing => "ਸਰਵਿੰਗ ਦੀ ਸੰਖਿਆ";
  String get mainlabelWeightInG => "ਭਾਰ (g)";
  String get mainlabelEditIngredientsWeight => "ਸਮੱਗਰੀ ਦੇ ਭਾਰ ਨੂੰ ਸੋਧੋ";
  String get mainlabelIngredient => "ਸਮੱਗਰੀ";
  String get mainlabelNewWeightInG => "ਨਵਾਂ ਭਾਰ (g)";
  String get mainlabelCancel => "ਰੱਦ ਕਰੋ";
  String get mainlabelUpdate => "ਅੱਪਡੇਟ";
  String get mainlabelCookedWeightInG => "ਪਕਾਇਆ ਭਾਰ (g)";
  String get mainlabelEnterWeight => "ਭਾਰ ਦਰਜ ਕਰੋ";
  String get mainlabelEditRecipy => "ਵਿਅੰਜਨ ਦਾ ਸੰਪਾਦਨ ਕਰੋ";
  String get mainlabelAlert => "ਚੇਤਾਵਨੀ";
  String get mainlabelToSeeNutritionCompositionPleaseEnterNoOfServing =>
      "ਪੋਸ਼ਣ ਦੀ ਰਚਨਾ ਦੇਖਣ ਲਈ, ਕਿਰਪਾ ਕਰਕੇ ਸਰਵਿੰਗ ਦੀ ਗਿਣਤੀ ਦਰਜ ਕਰੋ";
  String get mainlabelNutrirntsIn100CookedWeight =>
      "100 (ਪਕਾਏ) ਭਾਰ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤ";
  String get mainlabelSetNutritionTargetInG =>
      "ਗ੍ਰਾਮ ਵਿੱਚ ਪੋਸ਼ਣ ਦਾ ਟੀਚਾ ਨਿਰਧਾਰਤ ਕਰੋ";
  String get mainlabelFoodAnalyse => "ਪੜਚੋਲ ਕਰੋ";
  String get mainlabelExploreTop10Foods => "ਚੋਟੀ ਦੇ 10 ਭੋਜਨਾਂ ਦੀ ਪੜਚੋਲ ਕਰੋ";
  String get mainlabelSearchCookedFood =>
      "ਪਕਵਾਨਾਂ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤਾਂ ਦੀ ਖੋਜ ਕਰੋ";
  String get mainlabelNutritionBasedOnEAR =>
      "ਈਏਆਰ 'ਤੇ ਆਧਾਰਿਤ ਪੌਸ਼ਟਿਕ ਤੱਤਾਂ ਦੀ ਲੋੜ";
  String get mainlabelDietDiary => "ਖੁਰਾਕ ਡਾਇਰੀ";
  String get mainlabelRecipes => "ਪਕਵਾਨਾਂ";
  String get mainlabelSearchByFoodName => "ਭੋਜਨ ਦੇ ਨਾਮ ਦੁਆਰਾ ਖੋਜ ਕਰੋ";
  String get mainlabelAllRecipeOf100G => "100 ਗ੍ਰਾਮ ਦੇ ਸਾਰੇ ਵਿਅੰਜਨ";
  String get mainlabelNutritionRequirement => "ਪੋਸ਼ਣ ਦੀ ਲੋੜ";
  String get mainlabelGender => "ਲਿੰਗ";
  String get mainlabelParticulars => "ਵੇਰਵੇ";
  String get mainlabelBodyWeight => "ਸਰੀਰ ਦਾ ਭਾਰ";
  String get mainlabelDietaryDiaryReports => "ਪੌਸ਼ਟਿਕ ਤੱਤ ਦਾ ਸੇਵਨ";
  String get mainlabelTotalNutritionTakenOn => "ਪੂਰਾ ਪੋਸ਼ਣ ਲਿਆ ਗਿਆ";
  String get mainlabelAttachImage => "ਚਿੱਤਰ ਨੱਥੀ ਕਰੋ";
  String get mainlabelFixedRecipy => "ਸਥਿਰ ਵਿਅੰਜਨ";
  String get mainlabelFoodInDetail => "ਵਿਸਥਾਰ ਵਿੱਚ ਭੋਜਨ";
  String get TextAppNutrientsInMyFood => "ਭੋਜਨ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤਾਂ ਦੀ ਖੋਜ ਕਰੋ";
  String get TextAppMyActivity => "ਮੇਰੀ ਗਤੀਵਿਧੀ";
  String get TextAppToday => "ਅੱਜ";
  String get TextAppMyNutrientRequirements => "ਮੇਰੀਆਂ ਪੌਸ਼ਟਿਕ ਲੋੜਾਂ";
  String get TextAppTotalNutrition => "ਕੁੱਲ ਪੋਸ਼ਣ";
  String get TextAppTaken => "ਲਿਆ";
  String get TextAppRatings => "ਰੇਟਿੰਗ";
  String get TextAppSearchComponents => "ਖੋਜ ਭਾਗ";
  String get TextAppTotalNutrientTaken => "ਅੱਜ ਮੇਰਾ ਪੌਸ਼ਟਿਕ ਤੱਤ";
  String get TextAppShareApp => "ਸ਼ੇਅਰ ਐਪ";
  String get TextAppNoNotificationsFound => "ਕੋਈ ਸੂਚਨਾਵਾਂ ਨਹੀਂ ਮਿਲੀਆਂ";
  String get TextAppConnectWatch => "ਵਾਚ ਨੂੰ ਕਨੈਕਟ ਕਰੋ";
  String get TextAppYourBMIIs => "ਤੁਹਾਡਾ BMI ਹੈ";
  String get TextAppBMI => "BMI";
  String get TextAppBMICategories => "BMI ਸ਼੍ਰੇਣੀਆਂ";
  String get TextAppUnderweight => "ਘੱਟ ਭਾਰ";
  String get TextAppNormal => "ਸਧਾਰਣ";
  String get TextAppOverweight => "ਵੱਧ ਭਾਰ";
  String get TextAppObesity => "ਮੋਟਾਪਾ";
  String get TextAppSelectDate => "ਮਿਤੀ ਚੁਣੋ";
  String get TextAppOxygen => "ਆਕਸੀਜਨ";
  String get TextAppBlood => "ਖੂਨ";
  String get TextAppNoRecord => "ਕੋਈ ਰਿਕਾਰਡ ਨਹੀਂ";
  String get TextAppAllExercise => "ਸਾਰੇ ਅਭਿਆਸ";
  String get TextAppCleaningOrMopping => "ਸਫਾਈ ਜਾਂ ਮੋਪਿੰਗ";
  String get TextAppGardening => "ਬਾਗਬਾਨੀ";
  String get TextAppWatchingTV => "ਟੀਵੀ ਦੇਖਣਾ";
  String get TextAppCycling => "ਸਾਈਕਲਿੰਗ";
  String get TextAppRunning => "ਚੱਲ ਰਿਹਾ ਹੈ";
  String get TextAppWalking => "ਤੁਰਨਾ";
  String get TextAppShuttle => "ਸ਼ਟਲ";
  String get TextAppTableTennis => "ਟੇਬਲ ਟੈਨਿਸ";
  String get TextAppTennis => "ਟੈਨਿਸ";
  String get TextAppVolleyBall => "ਵਾਲੀਬਾਲ";
  String get TextAppDancing => "ਨੱਚਣਾ";
  String get TextAppFishing => "ਮੱਛੀ ਫੜਨ";
  String get TextAppShopping => "ਖਰੀਦਦਾਰੀ";
  String get TextAppTyping => "ਟਾਈਪਿੰਗ";
  String get TextAppSleeping => "ਸੁੱਤੇ ਹੋਏ";
  String get TextAppStanding => "ਖੜ੍ਹਾ ਹੈ";
  String get TextAppSitting => "ਬੈਠਾ";
  String get TextAppClickStartToStartActivity =>
      "ਗਤੀਵਿਧੀ ਸ਼ੁਰੂ ਕਰਨ ਲਈ ਸ਼ੁਰੂ 'ਤੇ ਕਲਿੱਕ ਕਰੋ";
  String get TextAppCaloriesBurn => "ਕੈਲੋਰੀ ਸਾੜ";
  String get TextAppAddDurationManually => "ਹੱਥੀਂ ਮਿਆਦ ਸ਼ਾਮਲ ਕਰੋ";
  String get TextAppStartOrMopping => "ਸ਼ੁਰੂ ਕਰੋ ਜਾਂ ਮੋਪਿੰਗ ਕਰੋ";
  String get TextAppMale => "ਨਰ";
  String get TextAppFemale => "ਔਰਤ";
  String get TextAppWeightManager => "ਮੇਰੇ ਸਰੀਰ ਦੇ ਭਾਰ ਨੂੰ ਟਰੈਕ ਕਰੋ";
  String get TextAppUpdateWeight => "ਭਾਰ ਅੱਪਡੇਟ ਕਰੋ";
  String get TextAppSetWeightGoal => "ਭਾਰ ਦਾ ਟੀਚਾ ਨਿਰਧਾਰਤ ਕਰੋ";
  String get TextAppCurrentWeight => "ਮੌਜੂਦਾ ਭਾਰ";
  String get TextAppWeightProgress => "ਭਾਰ ਦੀ ਤਰੱਕੀ";
  String get TextAppPrevious30Days => "ਪਿਛਲੇ 30 ਦਿਨ";
  String get TextAppYourWeightGoalIsSet => "ਤੁਹਾਡਾ ਟੀਚਾ ਹੈ";
  String get TextAppMaintain => "ਬਣਾਈ ਰੱਖੋ";
  String get TextAppInitialWeightOf => "ਸ਼ੁਰੂਆਤੀ ਭਾਰ";
  String get TextAppFinalWeightOf => "ਤਾਜ਼ਾ ਭਾਰ";
  String get TextAppWeight => "ਭਾਰ";
  String get TextAppYouAreNotYetAchievingYourWeightGoalKeepGoing =>
      "ਤੁਸੀਂ ਅਜੇ ਤੱਕ ਆਪਣਾ ਭਾਰ ਟੀਚਾ ਪ੍ਰਾਪਤ ਨਹੀਂ ਕਰ ਰਹੇ ਹੋ। ਚੱਲਦੇ ਰਹੋ!";
  String get TextAppYouAreAchievedYourWeightGoalKeepGoing =>
      "ਤੁਸੀਂ ਆਪਣਾ ਭਾਰ ਟੀਚਾ ਪ੍ਰਾਪਤ ਕਰ ਲਿਆ ਹੈ। ਚੱਲਦੇ ਰਹੋ!";
  String get TextAppAndYourWeightChangeIsSet =>
      "ਅਤੇ ਤੁਹਾਡੇ ਭਾਰ ਵਿੱਚ ਬਦਲਾਅ ਸੈੱਟ ਕੀਤਾ ਗਿਆ ਹੈ";
  String get TextApp1NutrientsInMyFood => "ਮੇਰੇ ਭੋਜਨ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤ";
  String get TextAppSearchNutrientsInRawFoods =>
      "ਕੱਚੇ ਭੋਜਨਾਂ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤਾਂ ਦੀ ਖੋਜ ਕਰੋ";
  String get TextAppRawIngredients => "ਕੱਚੀ ਸਮੱਗਰੀ";
  String get TextAppSearchRawFoodByName => "ਨਾਮ ਦੁਆਰਾ ਕੱਚੇ ਭੋਜਨ ਦੀ ਖੋਜ ਕਰੋ";
  String get TextApp1MyActivity => "ਮੇਰੀ ਗਤੀਵਿਧੀ ਰਿਪੋਰਟ";
  String get TextAppCheckOthersDates => "ਹੋਰ ਤਾਰੀਖਾਂ ਦੀ ਜਾਂਚ ਕਰੋ";
  String get TextAppYour24HoursChart => "ਤੁਹਾਡਾ 24 ਘੰਟਿਆਂ ਦਾ ਚਾਰਟ";
  String get TextAppActivity => "ਸਰਗਰਮੀ";
  String get TextAppOthers => "ਹੋਰ";
  String get TextAppExerciseDetails => "ਕਸਰਤ ਦੇ ਵੇਰਵੇ";
  String get TextAppActivityType => "ਗਤੀਵਿਧੀ ਦੀ ਕਿਸਮ";
  String get TextAppDuration => "ਮਿਆਦ";
  String get TextAppMyActivityOfCustomDates => "ਕਸਟਮ ਮਿਤੀਆਂ ਦੀ ਮੇਰੀ ਗਤੀਵਿਧੀ";
  String get TextAppOurCustomerFeedback => "ਸਾਡੇ ਗਾਹਕ ਫੀਡਬੈਕ";
  String get TextAppOverallRatings => "ਸਮੁੱਚੀ ਰੇਟਿੰਗਾਂ";
  String get TextAppEnterCookedWeight => "ਪਕਾਇਆ ਭਾਰ ਦਰਜ ਕਰੋ";
  String get TextAppCookedWeightGram => "ਪਕਾਇਆ ਭਾਰ (ਗ੍ਰਾਮ)";
  String get TextAppNutrientIn100gCooked =>
      "100 ਗ੍ਰਾਮ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤ (ਪਕਾਇਆ ਹੋਇਆ)";
  String get TextAppEnterServingSize => "ਸਰਵਿੰਗ ਦਾ ਆਕਾਰ ਦਾਖਲ ਕਰੋ";
  String get TextAppSearchByRecipeName => "ਵਿਅੰਜਨ ਦੇ ਨਾਮ ਦੁਆਰਾ ਖੋਜੋ";
  String get TextAppMyPersonalRecipe => "ਮੇਰੀ ਨਿੱਜੀ ਵਿਅੰਜਨ";
  String get TextAppFixedRecipe => "ਸਥਿਰ ਵਿਅੰਜਨ";
  String get TextApp2NutrientsInMyFood => "ਮੇਰੇ ਭੋਜਨ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤ";
  String get TextAppMyDietDiary => "ਮੇਰੀ ਖੁਰਾਕ ਡਾਇਰੀ";
  String get TextApp2MyActivity => "ਮੇਰੀ ਗਤੀਵਿਧੀ";
  String get TextAppDownloadFile => "ਫਾਈਲ ਡਾਊਨਲੋਡ ਕਰੋ";
  String get TextAppStartMyNewDietDiary => "ਮੇਰੀ ਨਵੀਂ ਖੁਰਾਕ ਡਾਇਰੀ ਸ਼ੁਰੂ ਕਰੋ";
  String get TextAppGoogle => "ਗੂਗਲ";
  String get TextAppFacebook => "ਫੇਸਬੁੱਕ";
  String get TextAppLinkedin => "ਲਿੰਕਡਇਨ";
  String get TextAppTwitter => "ਟਵਿੱਟਰ";
  String get TextAppContactUs => "ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ";
  String get TextAppReportBug => "ਬੱਗ ਦੀ ਰਿਪੋਰਟ ਕਰੋ";
  String get TextAppAttachImage => "ਚਿੱਤਰ ਨੱਥੀ ਕਰੋ";
  String get TextAppResetPassword => "ਪਾਸਵਰਡ ਰੀਸੈਟ ਕਰੋ";
  String get TextAppNINAppCreditsPage => "NIN ਐਪ ਕ੍ਰੈਡਿਟ ਪੰਨਾ";
  String get NINTextOopsSomethingWentWrong => "ਓਹ! ਕੁਝ ਗਲਤ ਹੋ ਗਿਆ";
  String get NINTextPleaseEnterAllFields => "ਕਿਰਪਾ ਕਰਕੇ ਸਾਰੇ ਖੇਤਰ ਦਾਖਲ ਕਰੋ";
  String get NINTextSubmittedSuccessfully1 => "ਸਫਲਤਾਪੂਰਵਕ ਸਪੁਰਦ ਕੀਤਾ ਗਿਆ";
  String get NINTextSubmittedSuccessfully2 => "ਸਫਲਤਾਪੂਰਵਕ ਸਪੁਰਦ ਕੀਤਾ ਗਿਆ";
  String get NINTextFitbitAuthentication => "Fitbit ਪ੍ਰਮਾਣਿਕਤਾ";
  String get NINTextHours => "ਘੰਟੇ";
  String get NINTextMinutes => "ਮਿੰਟ";
  String get NINTextEnterDurationFor => "ਲਈ ਮਿਆਦ ਦਾਖਲ ਕਰੋ";
  String get NINTextTimerRunning => "ਟਾਈਮਰ ਚੱਲ ਰਿਹਾ ਹੈ";
  String get NINTextPleaseStopTheTimerBeforeSubmitting =>
      "ਕਿਰਪਾ ਕਰਕੇ ਸਪੁਰਦ ਕਰਨ ਤੋਂ ਪਹਿਲਾਂ ਟਾਈਮਰ ਬੰਦ ਕਰੋ";
  String get NINTextTotalDuration => "ਕੁੱਲ ਮਿਆਦ";
  String get NINTextSec => "ਸਕਿੰਟ";
  String get NINTextStartYourActivity => "ਆਪਣੀ ਗਤੀਵਿਧੀ ਸ਼ੁਰੂ ਕਰੋ!";
  String get NINTextPause => "ਵਿਰਾਮ";
  String get NINTextReset => "ਰੀਸੈਟ ਕਰੋ";
  String get NINTextError => "ਗਲਤੀ";
  String get NINTextPleaseEnterCookedWeightAndServingSize =>
      "ਕਿਰਪਾ ਕਰਕੇ ਪਕਾਇਆ ਹੋਇਆ ਵਜ਼ਨ ਅਤੇ ਸਰਵਿੰਗ ਸਾਈਜ਼ ਦਰਜ ਕਰੋ";
  String get NINTextEditIngredient => "ਸਮੱਗਰੀ ਨੂੰ ਸੋਧੋ";
  String get NINTextAlert => "ਚੇਤਾਵਨੀ";
  String get NINTextEnterWeightFor => "ਲਈ ਭਾਰ ਦਰਜ ਕਰੋ";
  String get NINTextNewWeightGram => "ਨਵਾਂ ਭਾਰ (g)";
  String get NINTextEditRecipeName => "ਵਿਅੰਜਨ ਦੇ ਨਾਮ ਦਾ ਸੰਪਾਦਨ ਕਰੋ";
  String get NINTextNewRecipeName => "ਨਵਾਂ ਰੈਸਿਪੀ ਦਾ ਨਾਮ";
  String get NINTextSubmitted => "ਪੇਸ਼ ਕੀਤਾ";
  String get NINTextSuccess => "ਸਫਲਤਾ";
  String get NINTextDietaryDiaryReportSavedTo =>
      "ਖੁਰਾਕ ਡਾਇਰੀ ਰਿਪੋਰਟ ਨੂੰ ਸੰਭਾਲਿਆ";
  String get NINTextErrorSavingFile => "ਫ਼ਾਈਲ ਰੱਖਿਅਤ ਕਰਨ ਵਿੱਚ ਗੜਬੜ ਹੋਈ";
  String get NINTextClose => "ਬੰਦ ਕਰੋ";
  String get NINTextIWantTo => "ਮੈਂ ਚਾਹੁੰਦਾ ਹਾਂ";
  String get NINTextGain => "ਹਾਸਲ ਕਰੋ";
  String get NINTextMaintain => "ਬਣਾਈ ਰੱਖੋ";
  String get NINTextLose => "ਹਾਰੋ";
  String get NINTextWeightChangeKg => "ਵਜ਼ਨ ਤਬਦੀਲੀ (ਕਿਲੋ)";
  String get NINTextAddNewWeight => "ਨਵਾਂ ਭਾਰ ਸ਼ਾਮਲ ਕਰੋ";
  String get NINTextEnterWeight => "ਭਾਰ ਦਰਜ ਕਰੋ";
  String get NINTextOf100Gram => "100 ਗ੍ਰਾਮ ਦਾ";
  String get NINTextProximateComposition => "ਨਜ਼ਦੀਕੀ ਰਚਨਾ";
  String get NINTextVitamins => "ਵਿਟਾਮਿਨ";
  String get NINTextMinerals => "ਖਣਿਜ";
  String get NINTextTotalSaturatedFattyAcids => "ਕੁੱਲ ਸੰਤ੍ਰਿਪਤ ਫੈਟੀ ਐਸਿਡ";
  String get NINTextAllRecipeOf100Grams => "100 ਗ੍ਰਾਮ ਦੇ ਸਾਰੇ ਵਿਅੰਜਨ";
  String get NINTextOurCustomerFeedback => "ਸਾਡੇ ਗਾਹਕ ਫੀਡਬੈਕ";
  String get NINTextOverallRatings => "ਸਮੁੱਚੀ ਰੇਟਿੰਗਾਂ";
  String get NINTextRateUs => "ਸਾਨੂੰ ਦਰਜਾ ਦਿਓ";
  String get NINTextBookDetails => "ਕਿਤਾਬ ਦੇ ਵੇਰਵੇ";
  String get NINTextOne => "ਇੱਕ";
  String get NINTextWeightOf => "wt. ਦੇ";
  String get NINTextSelectStartDate => "ਸ਼ੁਰੂਆਤੀ ਤਾਰੀਖ ਚੁਣੋ";
  String get NINTextSelectEndDate => "ਸਮਾਪਤੀ ਮਿਤੀ ਚੁਣੋ";
  String get NINTextNoData => "ਕੋਈ ਡਾਟਾ ਨਹੀਂ";
  String get NINTextWorkLevel => "ਕੰਮ ਦਾ ਪੱਧਰ";
  String get NINTextOldPassword => "ਪੁਰਾਣਾ ਪਾਸਵਰਡ";
  String get NINTextNewPassword => "ਨਵਾਂ ਪਾਸਵਰਡ";
  String get NINTextUpdateProfile => "ਪ੍ਰੋਫਾਈਲ ਅੱਪਡੇਟ ਕਰੋ";
  String get NINTextChangeImage => "ਚਿੱਤਰ ਬਦਲੋ";
  String get NINTextNoFavouriteFoodFound => "ਕੋਈ ਮਨਪਸੰਦ ਭੋਜਨ ਨਹੀਂ ਮਿਲਿਆ";
  String get NINTextCookedQuantity => "ਪਕਾਈ ਮਾਤਰਾ";
  String get NINTextServingQuantity => "ਸੇਵਾ ਦੀ ਮਾਤਰਾ";
  String get NINTextNutrientInformation => "ਪੌਸ਼ਟਿਕ ਜਾਣਕਾਰੀ";
  String get NINTextIngredient => "ਸਮੱਗਰੀ";
  String get NINTextMealsTakenOn => "'ਤੇ ਭੋਜਨ ਲਿਆ ਗਿਆ";
  String get NINTextPercentage => "ਪ੍ਰਤੀਸ਼ਤ";
  String get NINTextEAR => "ਈ.ਆਰ";
  String get NINTextValue => "ਮੁੱਲ";
  String get NINTextNutrient => "ਪੌਸ਼ਟਿਕ ਤੱਤ";
  String get NINTextEnergyKcal => "ਊਰਜਾ (kcal)";
  String get NINTextProteinG => "ਪ੍ਰੋਟੀਨ (ਜੀ)";
  String get NINTextFatG => "ਚਰਬੀ (ਜੀ)";
  String get NINTextCarbohydratesG => "ਕਾਰਬੋਹਾਈਡਰੇਟ (ਜੀ)";
  String get NINTextCalciumMg => "ਕੈਲਸ਼ੀਅਮ (mg)";
  String get NINTextFiberG => "ਫਾਈਬਰ (ਜੀ)";
  String get NINTextIronMg => "ਆਇਰਨ (mg)";
  String get NINTextZincMg => "ਜ਼ਿੰਕ (mg)";
  String get NINTextMagnesiumMg => "ਮੈਗਨੀਸ਼ੀਅਮ (mg)";
  String get NINTextThiamineB1Mg => "ਥਿਆਮੀਨ (B1) (mg)";
  String get NINTextRiboflavinB2Mg => "ਰਿਬੋਫਲੇਵਿਨ (B2) (mg)";
  String get NINTextNiacinB3Mg => "ਨਿਆਸੀਨ (B3) (mg)";
  String get NINTextFolatesB9Mcg => "ਫੋਲੇਟਸ (B9) (mcg)";
  String get NINTextRetinolVitAMcg => "ਵਿਟਾਮਿਨ ਏ (ਐਮਸੀਜੀ)";
  String get VitaminCmg => "ਵਿਟਾਮਿਨ ਸੀ (mg)";
  String get Iodinemcg => "ਆਇਓਡੀਨ (ਐਮਸੀਜੀ)";
  String get serving => "ਸੇਵਾ";
  String get Mynutritionstatus => "ਮੇਰੀ ਪੋਸ਼ਣ ਸਥਿਤੀ";

  String get ninTextMyHealthStatus => 'ਮੇਰੀ ਸਿਹਤ ਸਥਿਤੀ';
  String get ninTextNutrientsInRawFoods => 'ਕੱਚੇ ਭੋਜਨ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤ';
  String get ninTextNutrientsInRecipes => 'ਪਕਵਾਨਾਂ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤ';
  String get ninTextIcmrNinMyPlateForTheDay => 'ICMR-NIN ਦਿਨ ਲਈ ਮੇਰੀ ਪਲੇਟ';
  String get ninTextToday => 'ਅੱਜ';
  String get ninTextTrackMyActivity => "ਮੇਰੀ ਗਤੀਵਿਧੀ 'ਤੇ ਨਜ਼ਰ ਰੱਖੋ";
  String get ninTextMyHeartRate => 'ਮੇਰੇ ਦਿਲ ਦੀ ਧੜਕਨ';
  String get ninTextMyWaterIntake => 'ਮੇਰਾ ਪਾਣੀ ਦਾ ਸੇਵਨ';
  String get ninTextSleepTracker => 'ਸਲੀਪ ਟਰੈਕਰ';
  String get ninTextLit => 'ਲਿਟ';
  String get ninTextRecordMyBloodPressure =>
      'ਮੇਰਾ ਬਲੱਡ ਪ੍ਰੈਸ਼ਰ / ਬਲੱਡ ਗਲੂਕੋਜ਼ / SPO2 ਰਿਕਾਰਡ ਕਰੋ';
  String get ninTextNutritionEducationContent => 'ਪੋਸ਼ਣ ਸੰਬੰਧੀ ਸਿੱਖਿਆ ਸਮੱਗਰੀ';
  String get ninTextMyNutrientIntake => 'ਮੇਰੀ ਪੌਸ਼ਟਿਕ ਖੁਰਾਕ';
  String get ninTextOn => "'ਤੇ";
  String get ninTextWithReferenceToEAR => 'EAR ਦੇ ਹਵਾਲੇ ਨਾਲ';
  String get ninTextAchieveYourHealthGoals => 'ਆਪਣੇ ਸਿਹਤ ਟੀਚਿਆਂ ਨੂੰ ਪ੍ਰਾਪਤ ਕਰੋ';
  String get ninTextPercentage => 'ਪ੍ਰਤੀਸ਼ਤ';
  String get ninTextMyPreviousDietDiaries => 'ਮੇਰੀ ਪਿਛਲੀ ਖੁਰਾਕ ਡਾਇਰੀ';
  String get ninTextRecordReviewSleep => 'ਨੀਂਦ ਨੂੰ ਰਿਕਾਰਡ / ਸਮੀਖਿਆ ਕਰੋ';
  String get ninTextHours => 'ਘੰਟੇ';
  String get ninTextIngredient => 'ਸਮੱਗਰੀ';
  String get ninTextOthersSpecify => 'ਦੂਸਰੇ ਨਿਸ਼ਚਿਤ ਕਰਦੇ ਹਨ';
  String get ninTextAddNewIngredient => 'ਨਵੀਂ ਸਮੱਗਰੀ ਸ਼ਾਮਲ ਕਰੋ';
  String get ninTextFoodName => 'ਭੋਜਨ ਦਾ ਨਾਮ';
  String get ninTextSource => 'ਸਰੋਤ';
  String get ninTextEnterBrandAndProductName =>
      'ਬ੍ਰਾਂਡ ਅਤੇ ਉਤਪਾਦ ਦਾ ਨਾਮ ਦਰਜ ਕਰੋ';
  String get ninTextEnterAuthorDetails =>
      'ਲੇਖਕ ਦਾ ਨਾਮ, ਸਾਲ, ਜਰਨਲ, ਪੰਨਾ ਦਰਜ ਕਰੋ';
  String get ninTextEnterFctName => 'FCT ਦਾ ਨਾਮ ਦਰਜ ਕਰੋ';
  String get ninTextName => 'ਨਾਮ';
  String get ninTextProductName => 'ਉਤਪਾਦ ਦਾ ਨਾਮ';
  String get ninTextSelectStartDate => 'ਸ਼ੁਰੂਆਤੀ ਤਾਰੀਖ ਚੁਣੋ';
  String get ninTextSelectEndDate => 'ਸਮਾਪਤੀ ਮਿਤੀ ਚੁਣੋ';
  String get ninTextNoExercise => 'ਕੋਈ ਅਭਿਆਸ ਨਹੀਂ';
  String get ninTextDevelopedWithExpertiseAndInputs =>
      'ਸੈਂਟਰ ਫਾਰ ਡਿਵੈਲਪਮੈਂਟ ਐਂਡ ਐਡਵਾਂਸਡ ਕੰਪਿਊਟਿੰਗ (C-DAC), ਹੈਦਰਾਬਾਦ ਲੈਂਗੂਏਜ ਲਿੰਕ ਦੁਆਰਾ NIN ਤੋਂ ਮੁਹਾਰਤ ਅਤੇ ਇਨਪੁਟਸ ਨਾਲ ਵਿਕਸਤ';
  String get ninTextMyNutrientIntakeToday => 'ਅੱਜ ਮੇਰਾ ਪੌਸ਼ਟਿਕ ਤੱਤ';
  String get ninTextIcmrNationalInstituteOfNutritionAddress =>
      'ICMR - ਤਰਨਾਕਾ ਮੈਟਰੋ ਸਟੇਸ਼ਨ, ਜਮਾਈ-ਓਸਮਾਨੀਆ ਪੀਓ, ਹੈਦਰਾਬਾਦ-500 007, ਭਾਰਤ ਦੇ ਕੋਲ ਨੈਸ਼ਨਲ ਇੰਸਟੀਚਿਊਟ ਆਫ਼ ਨਿਊਟ੍ਰੀਸ਼ਨ।';

  String get ninTextKcal => 'kcal';
  String get ninTextKcalPerDay => 'kcal/ਦਿਨ';
  String get ninTextDelete => 'ਮਿਟਾਓ';
  String get ninTextDeleteNotification => 'ਸੂਚਨਾ ਮਿਟਾਓ';
  String get ninTextConfirmDeleteNotification =>
      "ਕੀ ਤੁਸੀਂ ਯਕੀਨੀ ਤੌਰ 'ਤੇ ਇਸ ਸੂਚਨਾ ਨੂੰ ਮਿਟਾਉਣਾ ਚਾਹੁੰਦੇ ਹੋ?";
  String get ninTextTimeFor => 'ਹੇ, ਇਹ\'s time for';
  String get ninTextFitbitWatch => 'Fitbit ਘੜੀ';
  String get ninTextGoogleFitApp => 'Google Fit ਐਪ';
  String get ninTextUnderweight => 'ਘੱਟ ਭਾਰ';
  String get ninTextNormal => 'ਸਧਾਰਣ';
  String get ninTextOverweight => 'ਵੱਧ ਭਾਰ';
  String get ninTextObesity => 'ਮੋਟਾਪਾ';
  String get ninTextMale => 'ਨਰ';
  String get ninTextFemale => 'ਔਰਤ';
  String get ninTextAgeInYears => 'ਸਾਲਾਂ ਵਿੱਚ ਉਮਰ';
  String get ninTextChangeInWeight => 'ਭਾਰ ਵਿੱਚ ਤਬਦੀਲੀ';
  String get ninTextSteps => 'ਕਦਮ';
  String get ninTextFor => 'ਲਈ';
  String get ninTextMinutes => 'ਮਿੰਟ';
  String get ninTextPause => 'ਵਿਰਾਮ';
  String get ninTextReset => 'ਰੀਸੈਟ ਕਰੋ';
  String get ninTextStartActivity => 'ਆਪਣੀ ਗਤੀਵਿਧੀ ਸ਼ੁਰੂ ਕਰੋ';
  String get ninTextCartIsEmpty => 'ਤੁਹਾਡਾ ਕਾਰਟ ਖਾਲੀ ਹੈ';
  String get ninTextMyPersonalRecipe => 'ਮੇਰੀ ਨਿੱਜੀ ਵਿਅੰਜਨ';
  String get ninTextSearchByRecipeName => 'ਵਿਅੰਜਨ ਦੇ ਨਾਮ ਦੁਆਰਾ ਖੋਜੋ';
  String get ninTextHelpCenter => 'ਮਦਦ ਕੇਂਦਰ';
  String get ninTextCommonProblems => 'ਆਮ ਸਮੱਸਿਆਵਾਂ';
  String get ninTextFAQs => 'ਅਕਸਰ ਪੁੱਛੇ ਜਾਂਦੇ ਸਵਾਲ';
  String get ninTextHowActiveAreYou => 'ਤੁਸੀਂ ਕਿੰਨੇ ਕਿਰਿਆਸ਼ੀਲ ਹੋ';
  String get ninTextVitaminC => 'ਵਿਟਾਮਿਨ ਸੀ (mg)';
  String get ninTextVitaminA => 'ਵਿਟਾਮਿਨ ਏ (IU)';
  String get ninTextSodium => 'ਸੋਡੀਅਮ (mg)';
  String get ninTextJournal => 'ਰਸਾਲਾ';
  String get ninTextPage => 'ਪੰਨਾ';
  String get ninTextAdequateIntakeCarbs =>
      '*ਕਾਰਬੋਹਾਈਡਰੇਟ ਲਈ ਲੋੜੀਂਦੀ ਮਾਤਰਾ (AI) ਦੀ ਸਿਫਾਰਸ਼ ਕੀਤੀ ਜਾਂਦੀ ਹੈ: ਬਾਲਗ ਮਰਦਾਂ ਅਤੇ ਔਰਤਾਂ ਲਈ 130 ਗ੍ਰਾਮ।';
  String get ninTextAdequateIntakeFiber =>
      '**ਫਾਈਬਰ ਲਈ AI ਦੀ ਸਿਫ਼ਾਰਸ਼ ਕੀਤੀ ਗਈ: ਔਰਤਾਂ ਲਈ 25 ਗ੍ਰਾਮ ਅਤੇ ਮਰਦਾਂ ਲਈ 38 ਗ੍ਰਾਮ।';
  String get your => 'ਤੁਹਾਡਾ';
  String get question1 => 'ਕੀ ਮੈਂ ਆਪਣੇ ਨਿੱਜੀ ਵੇਰਵਿਆਂ ਨੂੰ ਸੰਪਾਦਿਤ ਕਰ ਸਕਦਾ ਹਾਂ?';
  String get answer1 =>
      'ਹਾਂ। ਤੁਹਾਡਾ ਨਿੱਜੀ ਡੇਟਾ ਤੁਹਾਡੀ ਪ੍ਰੋਫਾਈਲ ਵਿੱਚ ਸੰਪਾਦਿਤ ਕੀਤਾ ਜਾ ਸਕਦਾ ਹੈ।';
  String get linkText1 =>
      'ਆਪਣੇ ਨਿੱਜੀ ਵੇਰਵਿਆਂ ਨੂੰ ਸੰਪਾਦਿਤ ਕਰਨ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question2 => 'ਕੀ ਮੈਂ ਆਪਣੇ ਸੰਪਰਕ ਵੇਰਵੇ ਬਦਲ ਸਕਦਾ/ਸਕਦੀ ਹਾਂ?';
  String get answer2 =>
      "ਹਾਂ। ਤੁਹਾਡੇ ਸੰਪਰਕ ਵੇਰਵਿਆਂ ਨੂੰ ਤੁਹਾਡੀ ਪ੍ਰੋਫਾਈਲ ਵਿੱਚ 'ਪਰਸਨਲ ਡੇਟਾ' ਵਿਕਲਪ 'ਤੇ ਜਾ ਕੇ ਬਦਲਿਆ ਜਾ ਸਕਦਾ ਹੈ।";
  String get linkText2 =>
      'ਆਪਣੇ ਸੰਪਰਕ ਵੇਰਵਿਆਂ ਨੂੰ ਸੰਪਾਦਿਤ ਕਰਨ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question3 => 'ਕੀ ਮੈਂ ਆਪਣਾ ਉਪਭੋਗਤਾ ਪਾਸਵਰਡ ਬਦਲ ਸਕਦਾ ਹਾਂ?';
  String get answer3 =>
      "ਹਾਂ। ਤੁਹਾਡੀ ਪ੍ਰੋਫਾਈਲ ਵਿੱਚ 'ਸੈਟਿੰਗ' ਵਿਕਲਪ 'ਤੇ ਜਾ ਕੇ ਤੁਹਾਡਾ ਪਾਸਵਰਡ ਬਦਲਿਆ ਜਾ ਸਕਦਾ ਹੈ।";
  String get linkText3 => 'ਆਪਣਾ ਪਾਸਵਰਡ ਬਦਲਣ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question4 => 'ਮੈਂ ਆਪਣਾ BMI ਕਿਵੇਂ ਚੈੱਕ ਕਰ ਸਕਦਾ/ਸਕਦੀ ਹਾਂ?';
  String get answer4 =>
      "ਤੁਸੀਂ ਹੋਮ ਪੇਜ 'ਤੇ ਪ੍ਰਦਰਸ਼ਿਤ 'ਸਿਹਤ ਕੈਲਕੁਲੇਟਰ' ਵਿਕਲਪ ਵਿੱਚ ਪ੍ਰਦਾਨ ਕੀਤੇ ਗਏ 'BMI ਕੈਲਕੁਲੇਟਰ' ਵਿੱਚ ਆਪਣੀ ਉਚਾਈ ਅਤੇ ਸਰੀਰ ਦਾ ਭਾਰ ਦਰਜ ਕਰਕੇ ਆਪਣੇ BMI ਦੀ ਜਾਂਚ ਕਰ ਸਕਦੇ ਹੋ।";
  String get linkText4 => 'BMI ਕੈਲਕੁਲੇਟਰ ਦੀ ਵਰਤੋਂ ਕਰਨ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question5 =>
      'ਕੀ ਮੈਂ ਪਿਛਲੇ ਮਹੀਨੇ ਲਈ ਆਪਣਾ ਭਾਰ ਟ੍ਰੈਕ ਕਰ ਸਕਦਾ/ਸਕਦੀ ਹਾਂ?';
  String get answer5 =>
      "ਹਾਂ। ਤੁਸੀਂ ਹੋਮ ਪੇਜ 'ਤੇ ਦਿੱਤੇ ਗਏ 'ਵੇਟ ਮੈਨੇਜਰ' ਵਿਕਲਪ ਵਿੱਚ ਪਿਛਲੇ ਮਹੀਨੇ/ਸਾਲ ਲਈ ਆਪਣੇ ਸਰੀਰ ਦੇ ਭਾਰ ਵਿੱਚ ਬਦਲਾਅ ਦੇ ਵੇਰਵੇ ਦੇਖ ਸਕਦੇ ਹੋ।";
  String get linkText5 => 'ਆਪਣੇ ਭਾਰ ਨੂੰ ਟਰੈਕ ਕਰਨ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question6 =>
      "ਮੈਂ ਕਿਸੇ ਖਾਸ ਦਿਨ 'ਤੇ ਆਪਣੀ ਸਮੁੱਚੀ ਸਰੀਰਕ ਗਤੀਵਿਧੀ ਦੀ ਜਾਂਚ ਕਿਵੇਂ ਕਰ ਸਕਦਾ ਹਾਂ?";
  String get answer6 =>
      "ਤੁਸੀਂ ਹੋਮ ਪੇਜ 'ਤੇ 'ਮਾਈ ਐਕਟੀਵਿਟੀ' ਵਿਕਲਪ ਤੋਂ ਆਪਣੀ ਸਰੀਰਕ ਗਤੀਵਿਧੀ ਨੂੰ ਟ੍ਰੈਕ ਕਰ ਸਕਦੇ ਹੋ।";
  String get linkText6 => 'ਆਪਣੀ ਗਤੀਵਿਧੀ ਦੇਖਣ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question7 =>
      'ਮੈਂ ਪਾਣੀ ਦੇ ਸੇਵਨ ਲਈ ਰੀਮਾਈਂਡਰ ਕਿਵੇਂ ਸੈਟ ਕਰ ਸਕਦਾ/ਸਕਦੀ ਹਾਂ?';
  String get answer7 =>
      "ਤੁਸੀਂ ਹੋਮ ਪੇਜ 'ਤੇ ਦਿੱਤੇ ਗਏ 'ਸੈੱਟ ਨੋਟੀਫਿਕੇਸ਼ਨ' ਵਿਕਲਪ ਵਿੱਚ ਪਾਣੀ ਦੇ ਸੇਵਨ ਦੇ ਰੀਮਾਈਂਡਰ ਲਈ ਸਮਾਂ ਨਿਰਧਾਰਤ ਕਰ ਸਕਦੇ ਹੋ।";
  String get linkText7 => 'ਪਾਣੀ ਦੇ ਸੇਵਨ ਲਈ ਰੀਮਾਈਂਡਰ ਸੈੱਟ ਕਰਨ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question8 =>
      'ਮੈਂ ਆਪਣੀ ਸਮਾਰਟ ਵਾਚ ਨਾਲ ਐਪ ਨੂੰ ਕਿਵੇਂ ਏਕੀਕ੍ਰਿਤ ਕਰ ਸਕਦਾ/ਸਕਦੀ ਹਾਂ?';
  String get answer8 =>
      "ਤੁਸੀਂ ਹੋਮ ਪੇਜ 'ਤੇ ਦਿੱਤੇ ਗਏ 'ਕਨੈਕਟ ਵਾਚ' ਵਿਕਲਪ 'ਤੇ ਜਾ ਕੇ ਆਪਣੀ ਸਮਾਰਟ ਵਾਚ ਨੂੰ ਐਪ ਨਾਲ ਜੋੜ ਸਕਦੇ ਹੋ।";
  String get linkText8 => 'ਆਪਣੀ ਸਮਾਰਟ ਘੜੀ ਨਾਲ ਜੁੜਨ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question9 =>
      'ਮੈਂ ਇੱਕ ਸਮੇਂ ਵਿੱਚ ਕਿੰਨੇ ਪਹਿਨਣਯੋਗ ਚੀਜ਼ਾਂ ਨੂੰ ਐਪ ਨਾਲ ਜੋੜ ਸਕਦਾ ਹਾਂ?';
  String get answer9 =>
      'ਤੁਸੀਂ Fitbit ਵਾਚ ਅਤੇ Google Fit ਨੂੰ ਐਪ ਨਾਲ ਜੋੜ ਸਕਦੇ ਹੋ।';
  String get linkText9 => '';

  String get question10 => 'ਕਿਹੜੀਆਂ ਸਮਾਰਟ ਘੜੀਆਂ ਐਪ ਦੇ ਅਨੁਕੂਲ ਹਨ?';
  String get answer10 => 'Fitbit ਵਾਚ ਅਤੇ Google Fit।';
  String get linkText10 => '';

  String get question11 =>
      'ਕੀ ਮੈਂ ਆਪਣੀ ਗਤੀਵਿਧੀ ਨੂੰ ਟਰੈਕ ਕਰ ਸਕਦਾ/ਸਕਦੀ ਹਾਂ ਜੇਕਰ ਮੇਰੇ ਕੋਲ ਸਮਾਰਟ ਘੜੀ ਨਹੀਂ ਹੈ?';
  String get answer11 =>
      'ਹਾਂ, ਤੁਸੀਂ ਆਪਣੀ ਗਤੀਵਿਧੀ ਨੂੰ ਟਰੈਕ ਕਰ ਸਕਦੇ ਹੋ। ਇਸਦੇ ਲਈ, ਤੁਹਾਨੂੰ Google Fit ਐਪ ਨੂੰ ਡਾਉਨਲੋਡ ਕਰਨ, ਇੱਕ Google ਖਾਤੇ ਨਾਲ ਸਾਈਨ ਇਨ ਕਰਨ, ਅਤੇ ਉਸੇ Google ਖਾਤੇ ਨਾਲ, ਤੁਹਾਨੂੰ ਸਾਡੇ ਵਾਚ ਸੈਕਸ਼ਨ ਵਿੱਚ ਲੌਗਇਨ ਕਰਨ ਦੀ ਲੋੜ ਹੈ।';
  String get linkText11 => '';

  String get question12 => 'ਮੈਂ ਆਪਣੀ ਨੀਂਦ ਨੂੰ ਕਿਵੇਂ ਟਰੈਕ ਕਰ ਸਕਦਾ ਹਾਂ?';
  String get answer12 =>
      "ਤੁਸੀਂ ਹੋਮ ਪੇਜ 'ਤੇ ਦਿੱਤੇ ਸਲੀਪ ਟਰੈਕਰ ਵਿਕਲਪ 'ਤੇ ਜਾ ਕੇ ਹਫਤਾਵਾਰੀ/ਮਾਸਿਕ ਆਧਾਰ 'ਤੇ ਆਪਣੀ ਨੀਂਦ ਨੂੰ ਟ੍ਰੈਕ ਕਰ ਸਕਦੇ ਹੋ।";
  String get linkText12 => 'ਆਪਣੀ ਨੀਂਦ ਨੂੰ ਟਰੈਕ ਕਰਨ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question13 =>
      'ਮੈਂ ਐਪ ਰਾਹੀਂ ਕੋਈ ਵੀ NIN ਪ੍ਰਕਾਸ਼ਨ ਕਿਵੇਂ ਖਰੀਦ ਸਕਦਾ/ਸਕਦੀ ਹਾਂ?';
  String get answer13 =>
      "ਤੁਸੀਂ ਹੋਮ ਪੇਜ 'ਤੇ ਦਿੱਤੇ ਗਏ 'ਬੁੱਕ ਸਟੋਰ' ਵਿਕਲਪ ਤੋਂ NIN ਪ੍ਰਕਾਸ਼ਨ ਖਰੀਦ ਸਕਦੇ ਹੋ।";
  String get linkText13 => "ਕਿਤਾਬਾਂ ਦੀ ਦੁਕਾਨ 'ਤੇ ਜਾਣ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ";

  String get question14 => 'ਮੈਂ ਆਪਣੀ ਨਿੱਜੀ ਖੁਰਾਕ ਡਾਇਰੀ ਕਿਵੇਂ ਬਣਾ ਸਕਦਾ ਹਾਂ?';
  String get answer14 =>
      "ਤੁਸੀਂ 'ਮਾਈ ਡਾਈਟ ਡਾਇਰੀ ਵਿਕਲਪ' 'ਤੇ ਜਾ ਕੇ ਪੂਰੇ ਦਿਨ ਵਿਚ ਖਾਧੇ ਗਏ ਭੋਜਨ ਦੇ ਵੇਰਵੇ ਦਰਜ ਕਰ ਸਕਦੇ ਹੋ।";
  String get linkText14 => 'ਆਪਣੀ ਖੁਰਾਕ ਡਾਇਰੀ ਬਣਾਉਣ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question15 =>
      'ਮੈਂ ਇੱਕ ਵਿਅੰਜਨ ਦੀ ਖੋਜ ਕਿਵੇਂ ਕਰ ਸਕਦਾ ਹਾਂ ਜੋ ਕਿਸੇ ਖਾਸ ਪੌਸ਼ਟਿਕ ਤੱਤ ਨਾਲ ਭਰਪੂਰ ਹੈ?';
  String get answer15 =>
      "ਤੁਸੀਂ ਸਭ ਤੋਂ ਪਹਿਲਾਂ ਹੋਮ ਪੇਜ 'ਤੇ 'ਨਿਊਟਰੀਐਂਟਸ ਇਨ ਮਾਈ ਫੂਡ' ਟੈਬ 'ਚ ਦਿੱਤੇ ਗਏ 'ਸਰਚ ਨਿਊਟਰੀਐਂਟਸ ਇਨ ਰੈਸਿਪੀਜ਼' ਵਿਕਲਪ ਨੂੰ ਚੁਣ ਸਕਦੇ ਹੋ। ਫਿਰ ਉੱਪਰੀ ਸੱਜੇ ਕੋਨੇ 'ਤੇ ਡ੍ਰੌਪ-ਡਾਉਨ ਸੂਚੀ ਤੋਂ ਲੋੜੀਂਦੇ ਪੌਸ਼ਟਿਕ ਤੱਤ ਦੀ ਚੋਣ ਕਰੋ।";
  String get linkText15 => 'ਪਕਵਾਨਾਂ ਦੀ ਖੋਜ ਕਰਨ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question16 =>
      'ਮੈਂ ਪਿਛਲੇ ਮਹੀਨੇ ਬਚਾਏ ਗਏ ਇੱਕ ਦਿਨ ਲਈ ਆਪਣੇ ਪੌਸ਼ਟਿਕ ਤੱਤਾਂ ਦੀ ਕਿਵੇਂ ਜਾਂਚ ਕਰ ਸਕਦਾ ਹਾਂ?';
  String get answer16 =>
      "ਤੁਸੀਂ 'ਭੋਜਨ ਸੂਚੀ' ਪੰਨੇ 'ਤੇ 'ਕੈਲੰਡਰ ਆਈਕਨ' ਤੋਂ ਇੱਕ ਮਿਤੀ ਚੁਣ ਕੇ ਕਿਸੇ ਖਾਸ ਦਿਨ 'ਤੇ ਆਪਣੇ ਪੌਸ਼ਟਿਕ ਤੱਤਾਂ ਦੀ ਮਾਤਰਾ ਦੇਖ ਸਕਦੇ ਹੋ।";
  String get linkText16 => 'ਆਪਣੇ ਪੌਸ਼ਟਿਕ ਤੱਤ ਦੀ ਜਾਂਚ ਕਰਨ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question17 =>
      'ਮੈਂ ਆਪਣੇ ਪਕਵਾਨਾਂ ਵਿੱਚ ਵਰਤੇ ਗਏ ਕੱਚੇ ਤੱਤਾਂ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤਾਂ ਦਾ ਕਿਵੇਂ ਪਤਾ ਲਗਾ ਸਕਦਾ ਹਾਂ?';
  String get answer17 =>
      "ਤੁਸੀਂ ਹੋਮ ਪੇਜ 'ਤੇ 'ਮੇਰੇ ਭੋਜਨ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤ' ਟੈਬ ਵਿੱਚ ਦਿੱਤੇ ਗਏ 'ਕੱਚੇ ਭੋਜਨ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤ ਖੋਜੋ' ਵਿਕਲਪ ਨੂੰ ਚੁਣ ਕੇ ਕਿਸੇ ਖਾਸ ਸਮੱਗਰੀ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤਾਂ ਨੂੰ ਜਾਣ ਸਕਦੇ ਹੋ।";
  String get linkText17 => 'ਕੱਚੇ ਭੋਜਨ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤ ਖੋਜਣ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question18 =>
      'ਮੈਂ ਇੱਕ ਵਿਅੰਜਨ ਦੀ ਪੌਸ਼ਟਿਕ ਰਚਨਾ ਨੂੰ ਕਿਵੇਂ ਜਾਣ ਸਕਦਾ ਹਾਂ?';
  String get answer18 =>
      "ਤੁਸੀਂ ਹੋਮ ਪੇਜ 'ਤੇ 'ਮੇਰੇ ਭੋਜਨ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤ' ਟੈਬ ਵਿੱਚ ਦਿੱਤੇ ਗਏ 'ਪਕਵਾਨਾਂ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤ ਖੋਜੋ' ਵਿਕਲਪ ਨੂੰ ਚੁਣ ਕੇ ਕਿਸੇ ਖਾਸ ਸਮੱਗਰੀ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤਾਂ ਨੂੰ ਜਾਣ ਸਕਦੇ ਹੋ।";
  String get linkText18 => 'ਪੌਸ਼ਟਿਕ ਤੱਤਾਂ ਦੀ ਰਚਨਾ ਜਾਣਨ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question19 =>
      'ਕੀ ਮੈਂ ਇੱਕ ਨਵੀਂ ਵਿਅੰਜਨ ਸ਼ਾਮਲ ਕਰ ਸਕਦਾ ਹਾਂ ਜੋ ਐਪ ਵਿੱਚ ਉਪਲਬਧ ਨਹੀਂ ਹੈ?';
  String get answer19 =>
      "ਹਾਂ। ਤੁਸੀਂ ਜਾਂ ਤਾਂ ਖਾਸ ਨਿਸ਼ਚਿਤ ਵਿਅੰਜਨ ਦੇ ਹੇਠਾਂ ਦਿੱਤੇ ਲਿੰਕ ਦੀ ਵਰਤੋਂ ਕਰਕੇ ਮੌਜੂਦਾ ਵਿਅੰਜਨ ਨੂੰ ਸੋਧ ਸਕਦੇ ਹੋ ਜਾਂ ਖੁਰਾਕ ਡਾਇਰੀ ਪੰਨੇ ਵਿੱਚ ਹਰੇਕ ਭੋਜਨ ਲਈ ਪ੍ਰਦਾਨ ਕੀਤੇ ਗਏ 'ਕਸਟਮ ਡਿਸ਼ ਬਣਾਓ' ਵਿਕਲਪ 'ਤੇ ਕਲਿੱਕ ਕਰਕੇ ਇੱਕ ਪੂਰੀ ਤਰ੍ਹਾਂ ਨਵੀਂ ਵਿਅੰਜਨ ਬਣਾ ਸਕਦੇ ਹੋ।";
  String get linkText19 => 'ਇੱਕ ਕਸਟਮ ਵਿਅੰਜਨ ਬਣਾਉਣ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question20 =>
      'ਕੀ ਮੈਨੂੰ ਕਿਸੇ ਖਾਸ ਸਿਹਤ ਸਥਿਤੀ ਲਈ ਖੁਰਾਕ ਸੰਬੰਧੀ ਸਿਫ਼ਾਰਿਸ਼ਾਂ ਮਿਲ ਸਕਦੀਆਂ ਹਨ?';
  String get answer20 =>
      "ਹਾਂ। ਤੁਸੀਂ ਹੋਮ ਪੇਜ 'ਤੇ 'ਸਰਚ ਕੰਪੋਨੈਂਟ' ਵਿਕਲਪ ਤੋਂ ਸਿਹਤ ਸਿਫ਼ਾਰਸ਼ਾਂ ਜਾਂ ਖੁਰਾਕ ਚਾਰਟ ਦਿਸ਼ਾ-ਨਿਰਦੇਸ਼ ਪ੍ਰਾਪਤ ਕਰ ਸਕਦੇ ਹੋ।";
  String get linkText20 =>
      'ਖੁਰਾਕ ਸੰਬੰਧੀ ਸਿਫਾਰਸ਼ਾਂ ਪ੍ਰਾਪਤ ਕਰਨ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get question21 =>
      'ਕੀ ਮੈਂ ਅੰਗਰੇਜ਼ੀ ਤੋਂ ਇਲਾਵਾ ਕਿਸੇ ਹੋਰ ਭਾਸ਼ਾ ਵਿੱਚ ਐਪ ਦੀ ਵਰਤੋਂ ਕਰ ਸਕਦਾ ਹਾਂ?';
  String get answer21 =>
      "ਹਾਂ। ਤੁਸੀਂ ਆਪਣੀ ਪ੍ਰੋਫਾਈਲ ਵਿੱਚ ਦਿੱਤੇ ਗਏ 'ਸੈਟਿੰਗ' ਵਿਕਲਪ ਵਿੱਚੋਂ ਲੋੜੀਂਦੀ ਭਾਸ਼ਾ ਚੁਣ ਸਕਦੇ ਹੋ।";
  String get linkText21 => 'ਭਾਸ਼ਾ ਬਦਲਣ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ';

  String get ninTextBmiHwading => 'ਬਾਡੀ ਮਾਸ ਇੰਡੈਕਸ (BMI):';
  String get ninTextBmiDiscription =>
      "BMI ਨੂੰ ਇੱਕ ਵਿਅਕਤੀ ਦੇ ਭਾਰ ਨੂੰ ਕਿਲੋਗ੍ਰਾਮ ਵਿੱਚ ਮੀਟਰਾਂ (kg/m2) ਵਿੱਚ ਵਿਅਕਤੀ ਦੀ ਉਚਾਈ ਦੇ ਵਰਗ ਨਾਲ ਵੰਡਿਆ ਜਾਂਦਾ ਹੈ। BMI ਰੇਂਜ ਸਰੀਰ ਦੀ ਬਹੁਤ ਜ਼ਿਆਦਾ ਚਰਬੀ ਦੇ ਰੋਗ ਅਤੇ ਮੌਤ 'ਤੇ ਪੈਣ ਵਾਲੇ ਪ੍ਰਭਾਵ 'ਤੇ ਅਧਾਰਤ ਹਨ ਅਤੇ ਵਾਜਬ ਤੌਰ 'ਤੇ ਅਡੋਲਤਾ ਨਾਲ ਸਬੰਧਤ ਹਨ। BMI ਨੂੰ ਬਿਮਾਰੀ ਦੇ ਜੋਖਮ ਸੂਚਕ ਵਜੋਂ ਵਿਕਸਤ ਕੀਤਾ ਗਿਆ ਸੀ; ਜਿਵੇਂ ਕਿ BMI ਵਧਦਾ ਹੈ, ਉਸੇ ਤਰ੍ਹਾਂ ਕੁਝ ਬਿਮਾਰੀਆਂ ਦਾ ਜੋਖਮ ਵੀ ਵਧਦਾ ਹੈ। ਜ਼ਿਆਦਾ ਭਾਰ ਅਤੇ ਮੋਟਾਪੇ ਨਾਲ ਸਬੰਧਤ ਕੁਝ ਆਮ ਸਥਿਤੀਆਂ ਵਿੱਚ ਸ਼ਾਮਲ ਹਨ: ਸਮੇਂ ਤੋਂ ਪਹਿਲਾਂ ਮੌਤ, ਕਾਰਡੀਓਵੈਸਕੁਲਰ ਬਿਮਾਰੀਆਂ, ਹਾਈ ਬਲੱਡ ਪ੍ਰੈਸ਼ਰ, ਗਠੀਏ, ਕੁਝ ਕੈਂਸਰ, ਅਤੇ ਸ਼ੂਗਰ।";
  String get ninTextbminutritionsta => 'BMI ਪੋਸ਼ਣ ਸਥਿਤੀ';
  String get ninTextNutritionstat => 'ਪੋਸ਼ਣ ਦੀ ਸਥਿਤੀ';
  String get ninTextBelow => 'ਹੇਠਾਂ';
  String get ninTextPreobesity => 'ਪੂਰਵ ਮੋਟਾਪਾ';

  String get ninTextbesity => 'ਮੋਟਾਪਾ ਕਲਾਸ I';
  String get ninTextbesity2 => 'ਮੋਟਾਪਾ ਕਲਾਸ II';
  String get ninTextbesity3 => 'ਮੋਟਾਪਾ ਕਲਾਸ II';
  String get ninTextBMRfull => 'ਬੇਸਲ ਮੈਟਾਬੋਲਿਕ ਰੇਟ (BMR)';
  String get ninTextBMRDiscription =>
      "ਬੇਸਲ ਮੈਟਾਬੋਲਿਕ ਰੇਟ (BMR) ਉਹ ਦਰ ਹੈ ਜਿਸ 'ਤੇ ਕੋਈ ਵਿਅਕਤੀ ਆਰਾਮ ਕਰਦੇ ਹੋਏ ਊਰਜਾ ਖਰਚ ਕਰਦਾ ਹੈ।";
  String get ninTextPreviousdays => 'ਪਿਛਲੇ 30 ਦਿਨ';
  String get ninTextason => "ਦੇ ਤੌਰ 'ਤੇ";
  String get ninTextYearly => 'ਸਾਲਾਨਾ';
  String get ninTextabove => 'ਉੱਪਰ';
  String get ninTextAchieveyourhealthgoal => 'ਆਪਣੇ ਸਿਹਤ ਟੀਚੇ ਨੂੰ ਪ੍ਰਾਪਤ ਕਰੋ';
  String get heavyDescription =>
      'ਇਸ ਸ਼੍ਰੇਣੀ ਵਿੱਚ ਨਿਯਮਤ ਅਤੇ ਤੀਬਰ ਸਰੀਰਕ ਗਤੀਵਿਧੀ, ਜਿਵੇਂ ਕਿ ਦੌੜਨਾ, ਸਾਈਕਲ ਚਲਾਉਣਾ, ਜਾਂ ਭਾਰੀ ਲਿਫਟਿੰਗ, ਹਰ ਰੋਜ਼ ਇੱਕ ਘੰਟੇ ਤੋਂ ਵੱਧ ਸਮੇਂ ਲਈ ਸ਼ਾਮਲ ਕਿੱਤੇ ਸ਼ਾਮਲ ਹਨ। ਉਦਾਹਰਨਾਂ ਵਿੱਚ ਲੋਹਾਰ, ਖਣਨ, ਅਤੇ ਉਸਾਰੀ ਕਾਮੇ ਸ਼ਾਮਲ ਹਨ।';
  String get moderateDescription =>
      'ਇਸ ਸ਼੍ਰੇਣੀ ਦੇ ਵਿਅਕਤੀ ਰੋਜ਼ਾਨਾ ਲਗਭਗ 30 ਮਿੰਟ ਤੋਂ ਇੱਕ ਘੰਟੇ ਤੱਕ ਕੁਝ ਪੱਧਰ ਦੀ ਸਰੀਰਕ ਗਤੀਵਿਧੀ ਵਿੱਚ ਸ਼ਾਮਲ ਹੁੰਦੇ ਹਨ, ਜਿਵੇਂ ਕਿ ਪੈਦਲ ਜਾਂ ਹਲਕਾ ਜਾਗਿੰਗ। ਹੱਥੀਂ ਮਜ਼ਦੂਰ, ਕਾਰੀਗਰ ਅਤੇ ਕੁਝ ਕਿਸਮ ਦੇ ਹੁਨਰਮੰਦ ਕਾਮੇ ਵਰਗੇ ਕਿੱਤੇ ਇਸ ਸ਼੍ਰੇਣੀ ਵਿੱਚ ਆਉਂਦੇ ਹਨ।';
  String get sedentaryDescription =>
      'ਇਸ ਸ਼੍ਰੇਣੀ ਵਿੱਚ ਉਹ ਪੇਸ਼ੇ ਸ਼ਾਮਲ ਹਨ ਜਿਨ੍ਹਾਂ ਵਿੱਚ ਦਿਨ ਭਰ ਘੱਟ ਤੋਂ ਘੱਟ ਸਰੀਰਕ ਗਤੀਵਿਧੀ ਹੁੰਦੀ ਹੈ। ਇਨ੍ਹਾਂ ਨੌਕਰੀਆਂ ਵਾਲੇ ਲੋਕ ਆਪਣਾ ਜ਼ਿਆਦਾਤਰ ਸਮਾਂ ਬੈਠ ਕੇ ਜਾਂ ਲੇਟ ਕੇ ਬਿਤਾਉਂਦੇ ਹਨ। ਉਦਾਹਰਨਾਂ ਵਿੱਚ ਦਫ਼ਤਰੀ ਕਰਮਚਾਰੀ, ਅਧਿਆਪਕ, ਅਤੇ ਪ੍ਰਬੰਧਕੀ ਭੂਮਿਕਾਵਾਂ ਵਿੱਚ ਸ਼ਾਮਲ ਹਨ।';
  String get Foodprotein => "ਪ੍ਰੋਟੀਨ";
  String get Foodfat => "ਚਰਬੀ";
  String get Foodenergy => "ਊਰਜਾ";
  String get FoodtotalB2 => "ਕੁੱਲ B2";
  String get Foodvitamins => "ਵਿਟਾਮਿਨ";
  String get FoodtotalFat => "ਕੁੱਲ ਚਰਬੀ";
  String get FoodproximateComposition => "ਨਜ਼ਦੀਕੀ ਰਚਨਾ";
  String get FoodnutrientsIn100g => "100 ਗ੍ਰਾਮ ਵਿੱਚ ਪੌਸ਼ਟਿਕ ਤੱਤ";
  String get FoodtotalCarotenoids => "ਕੁੱਲ ਕੈਰੋਟੀਨੋਇਡਜ਼";
  String get FoodtotalAscorbicAcid => "ਕੁੱਲ ascorbic ਐਸਿਡ";
  String get FoodtotalB9 => "ਕੁੱਲ B9";
  String get FoodtotalB6 => "ਕੁੱਲ B6";
  String get Foodcalcium => "ਕੈਲਸ਼ੀਅਮ";
  String get Foodsodium => "ਸੋਡੀਅਮ";
  String get Foodpotassium => "ਪੋਟਾਸ਼ੀਅਮ";
  String get Foodzinc => "ਜ਼ਿੰਕ";
  String get Foodiron => "ਲੋਹਾ";
  String get Foodminerals => "ਖਣਿਜ";
  String get FoodtotalSaturatedFattyAcids => "ਕੁੱਲ ਸੰਤ੍ਰਿਪਤ ਫੈਟੀ ਐਸਿਡ";
  String get FoodfattyAcids => "ਫੈਟੀ ਐਸਿਡ";
  String get FoodtotalDietaryFiber => "ਕੁੱਲ ਖੁਰਾਕ ਫਾਈਬਰ";
  String get Foodmanganese => "ਮੈਂਗਨੀਜ਼";
  String get Foodcopper => "ਤਾਂਬਾ";
  String get Foodselenium => "ਸੇਲੇਨਿਅਮ";
  String get Foodmagnesium => "ਮੈਗਨੀਸ਼ੀਅਮ";
  String get Foodphosphorus => "ਫਾਸਫੋਰਸ";
  String get Foodcholesterol => "ਕੋਲੇਸਟ੍ਰੋਲ";
  String get Foodcarbohydrate => "ਕਾਰਬੋਹਾਈਡਰੇਟ";
  String get FoodvitaminB6 => "ਵਿਟਾਮਿਨ B6 (mg)";
  String get Punjabi => "ਪੰਜਾਬੀ";
  String get Gujarati => "ਗੁਜਰਾਤੀ";
  String get Odia => "ਓਡੀਆ";
  String get Kannada => "ਕੰਨੜ";
  String get Marathi => "ਮਰਾਠੀ";
  String get Tamil => "ਤਾਮਿਲ";
  String get Bengali => "ਬੰਗਾਲੀ";
  String get Telugu => "ਤੇਲਗੂ";
  String get English => "ਅੰਗਰੇਜ਼ੀ";
  String get Hindi => "ਹਿੰਦੀ";
  String get firstname => "ਪਹਿਲਾ ਨਾਂ";
  String get lastname => "ਆਖਰੀ ਨਾਂ";
  String get labelSodium => "ਸੋਡੀਅਮ";
  String get labelVitaminC => "ਵਿਟਾਮਿਨ C";
  String get FinanameEnergy => "ਊਰਜਾ";
  String get FinanameCarbohydrate => "ਕਾਰਬੋਹਾਇਡਰੇਟ";
  String get FinanameFat => "ਚਰਬੀ";
  String get FinanameSodium => "ਸੋਡੀਅਮ";
  String get FinanameDietaryFibre => "ਆਹਾਰੀ ਫਾਈਬਰ";
  String get FinanameCalcium => "ਕੈਲਸ਼ੀਅਮ";
  String get FinanameIron => "ਲੋਹਾ";
  String get FinanameMagnesium => "ਮੈਗਨੀਸੀਅਮ";
  String get FinanameZinc => "ਜ਼ਿੰਕ";
  String get FinanameProtein => "ਪ੍ਰੋਟੀਨ";
  String get FinanameThiamine => "ਥਾਈਮਿਨ";
  String get FinanameRiboflavin => "ਰਾਈਬੋਫਲੇਵਿਨ";
  String get FinanameNiacin => "ਨਾਈਏਸਿਨ";
  String get FinanameVitaminB => "ਵਿਟਾਮਿਨ B";
  String get FinanameFolate => "ਫੋਲੇਟ";
  String get FinanameVitaminC => "ਵਿਟਾਮਿਨ C";
  String get FinanameVitaminA => "ਵਿਟਾਮਿਨ A";
  String get FinanameVitaminb6 => "ਵਿਟਾਮਿਨ B6";
  String get confirmDeleteAllNotifications =>
      "ਕੀ ਤੁਸੀਂ ਸਭ ਸੂਚਨਾਵਾਂ ਮਿਟਾਉਣਾ ਚਾਹੁੰਦੇ ਹੋ?";
  String get fillAllFields => "ਕਿਰਪਾ ਕਰਕੇ ਸਭ ਖੇਤਰ ਭਰੋ";
  String get successfullyAddedIngredient =>
      "ਸਫਲਤਾਪੂਰਵਕ ਸਮੱਗਰੀ ਸ਼ਾਮਲ ਕੀਤੀ ਗਈ ਹੈ";
  String get EssentialNutritionalGuidelines =>
      "ਭਾਰਤੀਆਂ ਦੀਆਂ ਖੁਰਾਕੀ ਲੋੜਾਂ ਲਈ ਲੋੜੀਂਦੀਆਂ ਪੋਸ਼ਣ ਦੇ ਰਹਿਨੁਮਾ ਨਿਯਮ।";
  String get NutrientRequirementsRDA2020 =>
      "ਭਾਰਤੀਆਂ ਲਈ ਪੋਸ਼ਣ ਦੀਆਂ ਲੋੜਾਂ ਅਤੇ ਸਿਫ਼ਾਰਸ਼ੀ ਖੁਰਾਕ ਭੱਤੇ (RDA 2020)।";
  String get RecommendationsBalancedDiets =>
      "ਭਾਰਤ ਵਿੱਚ ਸੰਤੁਲਿਤ ਖੁਰਾਕ ਅਤੇ ਸਿਹਤਮੰਦ ਖਾਣ ਦੀਆਂ ਆਦਤਾਂ ਨੂੰ ਵਧਾਉਣ ਲਈ ਸਿਫ਼ਾਰਸ਼ਾਂ।";
  String get DietaryGuidelinesForIndians => "ਭਾਰਤੀਆਂ ਲਈ ਖੁਰਾਕੀ ਰਹਿਨੁਮਾ ਨਿਯਮ।";
  String get Nutritionstat => "ਪੋਸ਼ਣ ਅੰਕੜੇ";
  String get referenceMen65kg => "ਹਵਾਲਾ ਮਰਦ (65 ਕਿ.ਗ੍ਰਾ.)";
  String get referenceWomen55kg => "ਹਵਾਲਾ ਔਰਤਾਂ (55 ਕਿ.ਗ੍ਰਾ.)";
  String get valueForMen => "1506";
  String get valueForWomen => "1184";
  String get referenceMenWomenDescription =>
      "ਹਵਾਲਾ ਮਰਦ ਅਤੇ ਮਹਿਲਾ 19-39 ਸਾਲ ਦੀ ਉਮਰ ਦੇ ਸਿਹਤਮੰਦ ਵਯੱਕ ਹਨ, ਜਿਨ੍ਹਾਂ ਦਾ ਬੀਐਮਆਈ ਸਧਾਰਨ ਹੈ ਅਤੇ ਜੋ ਦਰਮਿਆਨੀ ਤੌਰ 'ਤੇ ਸਰਗਰਮ ਹਨ (ICMR-NIN)। ਵੇਖੋ";
  String get personalizedDietDiaryDescription =>
      "ਵੈਕਤੀਗਤ ਡਾਇਟ ਡਾਇਰੀ ਤੁਹਾਡੀ ਮੌਜੂਦਾ ਤੋਂ ਪਿਛਲੇ ਮਹੀਨੇ ਤੱਕ ਦੀ ਪੋਸ਼ਣ ਖੁਰਾਕ ਨੂੰ ਟਰੈਕ ਕਰਦੀ ਹੈ";

  String get confirmDeletion => "ਮਿਟਾਉਣ ਦੀ ਪੁਸ਼ਟੀ ਕਰੋ";
  String get confirmDeleteIngredient =>
      "ਕੀ ਤੁਸੀਂ ਇਹ ਸਮੱਗਰੀ ਮਿਟਾਉਣਾ ਚਾਹੁੰਦੇ ਹੋ?";
  String get fileDownloaded => "ਫਾਈਲ ਸਫਲਤਾਪੂਰਵਕ ਡਾਊਨਲੋਡ ਹੋਈ ਅਤੇ ਫਾਈਲ ਦਾ ਸਥਾਨ";
  String get confirmDeleteFood => "ਕੀ ਤੁਸੀਂ ਖਾਣਾ ਮਿਟਾਉਣਾ ਚਾਹੁੰਦੇ ਹੋ?";
  String get estimatedAverageRequirement =>
      'ਅਨੁਮਾਨਤ ਔਸਤ ਜਰੂਰਤ (EAR): 50% ਸਿਹਤੀ ਵਿਅਕਤੀਆਂ ਦੀ ਦਿਨਲੀ ਦੀ ਮਾਤਰਾ ਜੋ ਜਰੂਰਤਾਂ ਨੂੰ ਪੂਰਾ ਕਰਨ ਲਈ ਅਨੁਮਾਨਿਤ ਹੈ';
  String get editQuantity => "ਮਾਤਰਾ ਸੋਧਣਾ";
  String get confirmDelete => "ਕੀ ਤੁਸੀਂ ਮਿਟਾਉਣਾ ਚਾਹੁੰਦੇ ਹੋ?";
  String get exerciseDeleted => "ਵਾਰਜਿਸ ਸਫਲਤਾਪੂਰਵਕ ਹਟਾਇਆ ਗਿਆ ਹੈ।";
  String get confirmDeleteExercise => "ਕੀ ਤੁਸੀਂ ਇਹ ਵਾਰਜਿਸ ਮਿਟਾਉਣਾ ਚਾਹੁੰਦੇ ਹੋ?";
}
