// LanguageKn.dart
import 'languages.dart';

class LanguageKn extends Languages {
  @override
  String get appName => "NIN2.0";

  @override
  String get labelWelcome => "ಸ್ವಾಗತ";
  String get inputActivityDataPrompt =>
      "ನಿಮ್ಮ ಶಕ್ತಿ ವೆಚ್ಚ ಮತ್ತು ಸಮತೋಲನವನ್ನು ನೋಡಲು, ದಯವಿಟ್ಟು 24 ಗಂಟೆಗಳ ಕ್ರಿಯಾತ್ಮಕ ಡೇಟಾವನ್ನು ನಮೂದಿಸಿ.";
  String get myEnergyBalanceYesterday => "ನನ್ನ ಶಕ್ತಿ ಸಮತೋಲನ (ನಿನ್ನೆ)";
  String get caloriesBurnFromWatch => "ಗಡಿಯಾರದಿಂದ ಬೆಂದ ಕ್ಯಾಲೊರಿಗಳು";
  String get activities => "ಕೃತಿ";
  String get searchActivityHere => "ಇಲ್ಲಿ ಚಟುವಟಿಕೆ ಹುಡುಕಿ";
  String get orSelectActivityFromBelow => "ಅಥವಾ ಕೆಳಗಿನ ಚಟುವಟಿಕೆ ಆಯ್ಕೆಮಾಡಿ";
  String get tryLater => "ನಂತರ ಪ್ರಯತ್ನಿಸಿ";
  @override
  String get labelSelectLanguage => "ಭಾಷೆಯನ್ನು ಆಯ್ಕೆಮಾಡಿ";

  @override
  String get labelInfo => "ಇದು ಬಹು-ಭಾಷಾ ಡೆಮೊ ಅಪ್ಲಿಕೇಶನ್ ಆಗಿದೆ";
  String get totalEnergyConsumption => "ಒಟ್ಟು ಶಕ್ತಿ ಬಳಕೆ";
  String get totalEnergyExpenditure => "ಒಟ್ಟು ಶಕ್ತಿ ಖರ್ಚು";
  String get energybalance => "ಶಕ್ತಿ ಸಂತುಲನ";
  String get indicatorhealth =>
      "('+' ಶಕ್ತಿ ಅತಿಶೇಷವನ್ನು ಸೂಚಿಸುತ್ತದೆ; '-' ಶಕ್ತಿ ಘಾಟಕವನ್ನು ಸೂಚಿಸುತ್ತದೆ)";

  @override
  // TODO: implement labelChangeLanguage
  String get labelChangeLanguage => "ಭಾಷೆ ಬದಲಾಯಿಸಿ";
  @override
  String get labelWelcomeBack => "ಮರಳಿ ಸ್ವಾಗತ,";

  @override
  String get labelUnderweight => "ನೀವು ಕಡಿಮೆ ತೂಕ ಹೊಂದಿದ್ದೀರಿ";

  @override
  String get labelNormalWeight => "ನೀವು ಸಾಮಾನ್ಯ ತೂಕ";

  @override
  String get labelOverweight => "ನೀವು ಅಧಿಕ ತೂಕ ಹೊಂದಿದ್ದೀರಿ";

  @override
  String get labelObese => "ನೀವು ಸ್ಥೂಲಕಾಯರು";

  @override
  String get labelViewMore => "ಇನ್ನಷ್ಟು ವೀಕ್ಷಿಸಿ";

  @override
  String get labelTodaySteps => "ಇಂದಿನ ಹಂತಗಳು";

  @override
  String get labelCheck => "ಪರಿಶೀಲಿಸಿ";

  @override
  String get labelHealthData =>
      "ನನ್ನ ರಕ್ತದೊತ್ತಡ / ರಕ್ತದ ಗ್ಲೂಕೋಸ್ / SPO2 ಅನ್ನು ರೆಕಾರ್ಡ್ ಮಾಡಿ";

  @override
  String get labelActivityStatus => "ಚಟುವಟಿಕೆಯ ಸ್ಥಿತಿ";

  @override
  String get labelHeartRate => "ಹೃದಯ ಬಡಿತ";

  @override
  String get labelHeartRateValue => "78 ಬಿಪಿಎಂ";

  @override
  String get labelMinutesAgo => "ನಿಮಿಷಗಳ ಹಿಂದೆ";

  @override
  String get labelWaterIntake => "ನನ್ನ ನೀರಿನ ಸೇವನೆ";

  @override
  String get labelLiters => "ಲೀಟರ್";

  @override
  String get labelZeroLiters => "0 ಲೀಟರ್";

  @override
  String get labelRealTimeGoal => "ನೈಜ ಸಮಯ, ಗುರಿ";

  @override
  String get labelCalories => "ಕ್ಯಾಲೋರಿಗಳು ಸುಟ್ಟುಹೋದವು";

  @override
  String get labelCaloriesEarned => "ಗಳಿಸಿದ ಕ್ಯಾಲೋರಿಗಳು";

  @override
  String get labelFoodPlan => "ಆಹಾರ ಯೋಜನೆ";

  @override
  String get labelWorkoutProgress => "ತಾಲೀಮು ಪ್ರಗತಿ";

  @override
  String get labelWeekly => "ಸಾಪ್ತಾಹಿಕ";

  @override
  String get labelMonthly => "ಮಾಸಿಕ";

  @override
  String get labelLatestWorkout => "ಇತ್ತೀಚಿನ ತಾಲೀಮು";

  @override
  String get labelSeeMore => "ಇನ್ನೂ ಹೆಚ್ಚು ನೋಡು";
  String get labelBreakfast => "ಉಪಹಾರ";
  String get labelLunch => "ಊಟ";
  String get labelDinner => "ಊಟ";
  String get labelSnacks => "ತಿಂಡಿಗಳು";
  String get labelTaken => "ತೆಗೆದುಕೊಳ್ಳಲಾಗಿದೆ";
  String get labelTarget => "ಗುರಿ";

  //profile

  String get labelProfile => "ಪ್ರೊಫೈಲ್";
  String get labelEdit => "ತಿದ್ದು";
  String get labelUser => "ಬಳಕೆದಾರ";
  String get labelProgram => "ಕೊಬ್ಬಿನ ಕಾರ್ಯಕ್ರಮವನ್ನು ಕಳೆದುಕೊಳ್ಳಿ";
  String get labelHeight => "ಎತ್ತರ";
  String get labelWeight => "ತೂಕ";
  String get labelAge => "ವಯಸ್ಸು";
  String get labelAccount => "ಖಾತೆ";
  String get labelPersonalData => "ವಯಕ್ತಿಕ ವಿಷಯ";
  String get labelAchievement => "ಸಾಧನೆ";
  String get labelActivityHistory => "ಚಟುವಟಿಕೆ ಇತಿಹಾಸ";
//String get labelWorkoutProgress => "ತಾಲೀಮು ಪ್ರಗತಿ";
  String get labelNotification => "ಅಧಿಸೂಚನೆ";
  String get labelPopupNotification => "ಪಾಪ್-ಅಪ್ ಅಧಿಸೂಚನೆ";
  String get labelMensurationCycle => "ಸೈಕಲ್ ಮಾಪನ";
  String get labelOther => "ಇತರೆ";
  String get labelContactUs => "ನಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸಿ";
  String get labelPrivacyPolicy => "ಗೌಪ್ಯತಾ ನೀತಿ";
  String get labelSetting => "ಸೆಟ್ಟಿಂಗ್";
  String get labelFeedback => "ಪ್ರತಿಕ್ರಿಯೆ";
  String get labelConfirmLogout => "ಲಾಗ್ಔಟ್ ಅನ್ನು ದೃಢೀಕರಿಸಿ";
  String get labelConfirmLogoutMessage =>
      "ನೀವು ಲಾಗ್ ಔಟ್ ಮಾಡಲು ಖಚಿತವಾಗಿ ಬಯಸುವಿರಾ?";
  String get labelLogout => "ಲಾಗ್ ಔಟ್";
  //select tab
  String get labelOptions => "ಆಯ್ಕೆಗಳು";
  String get labelFoodTable => "ಆಹಾರವನ್ನು ಸೇರಿಸಿ";
  String get labelTop10Food => "ಟಾಪ್ 10 ಆಹಾರ";
  String get labelActivityTrack => "ಚಟುವಟಿಕೆ ಟ್ರ್ಯಾಕರ್";
  String get labelsteptracker => "ಹಂತ ಟ್ರ್ಯಾಕರ್";

  String get labelTodayTarget => "ನೀರಿನ ಗುರಿ";
  String get labelJoggingTrack => "ಜಾಗಿಂಗ್ ಟ್ರ್ಯಾಕ್";
  String get labelMensurationTrack => "ಮುಟ್ಟಿನ ಟ್ರ್ಯಾಕ್";
//String get labelFoodTable => "ಆಹಾರ ಮೇಜು";
  String get labelPassword => "ಗುಪ್ತಪದವನ್ನು ಬದಲಿಸಿ";
  String get labelDarkMode => "ಡಾರ್ಕ್ ಮೋಡ್ ಅನ್ನು ಪ್ರಯತ್ನಿಸಿ";
  String get labelconectWatch => "ಗಡಿಯಾರವನ್ನು ಸಂಪರ್ಕಿಸಿ";
  @override
  String get labelSleep => "ನಿದ್ರೆ";
  @override
  String get labelBookStore => "ಪುಸ್ತಕದ ಅಂಗಡಿ";
  @override
  String get labelSearchBooks => "ಪುಸ್ತಕಗಳನ್ನು ಹುಡುಕಿ";
  @override
  String get labelPrice => "ಬೆಲೆ";
  @override
  String get labelAddToCart => "ಕಾರ್ಟ್ಗೆ ಸೇರಿಸಿ";
  @override
  String get labelAuthor => "ಲೇಖಕ";
  @override
  String get labelYear => "ವರ್ಷ";
  @override
  String get labelQuantityAvailable => "ಲಭ್ಯವಿರುವ ಪ್ರಮಾಣ";
  @override
  String get labelCart => "ಕಾರ್ಟ್ಗೆ ಸೇರಿಸಿ";
  @override
  String get labelMyOrders => "ನನ್ನ ಆಜ್ಞೆಗಳು";
  @override
  String get labelAllOrders => "ಎಲ್ಲಾ ಆದೇಶಗಳು";
  @override
  String get labelOrderDetail => "ಆದೇಶದ ವಿವರ";
  @override
  String get labelOrderId => "ಆರ್ಡರ್ ಐಡಿ";
  @override
  String get labelOrdersInMyOrders => "ನನ್ನ ಆದೇಶಗಳಲ್ಲಿ ಆದೇಶಗಳು";
  @override
  String get labelItemsInMyOrders => "ನನ್ನ ಆರ್ಡರ್‌ನಲ್ಲಿರುವ ವಸ್ತುಗಳು";
  @override
  String get labelTotal => "ಒಟ್ಟು";
  @override
  String get labelTotalPrice => "ಒಟ್ಟು ಬೆಲೆ";
  @override
  String get labelCheckout => "ಚೆಕ್ಔಟ್";

  // Meal List
  @override
  String get labelMealList => "ನನ್ನ ಆಹಾರಕ್ರಮ";
  @override
  String get labelAnalyze => "ವಿಶ್ಲೇಷಿಸಿ";
  @override
  String get labelAddDish => "ಭಕ್ಷ್ಯವನ್ನು ಸೇರಿಸಿ";
  @override
  String get labelTop10Foods => "ಟಾಪ್ 10 ಆಹಾರಗಳು";
  @override
  String get labelRecentMeal => "ಇತ್ತೀಚಿನ ಊಟ";
  @override
  String get labelAnalyzeIngredientsTaken => "ಆಹಾರ ಸೇವನೆಯನ್ನು ವಿಶ್ಲೇಷಿಸಿ";

  // Nutrition Summary
  @override
  String get labelCarbs => "ಕಾರ್ಬೋಹೈಡ್ರೇಟ್";
  // @override
  // String get labelCalories => "ಕ್ಯಾಲೋರಿಗಳು";
  @override
  String get labelFibers => "ಒಟ್ಟು ಫೈಬರ್";
  @override
  String get labelFats => "ಕೊಬ್ಬು";
  @override
  String get labelProteins => "ಪ್ರೋಟೀನ್";
  @override
  String get labelCalcium => "ಕ್ಯಾಲ್ಸಿಯಂ";

  @override
  String get labelNiacinB3 => "ನಿಯಾಸಿನ್ (B3)";

  @override
  String get labelThiamineB1 => "ಥಯಾಮಿನ್ (B1)";

  @override
  String get labelIron => "ಕಬ್ಬಿಣ";

  @override
  String get labelZinc => "ಸತು";

  @override
  String get labelFolatesB9 => "ಫೋಲೇಟ್ (B9)";

  @override
  String get labelRiboflavinB2 => "ರಿಬೋಫ್ಲಾವಿನ್ (B2)";

  @override
  String get labelRetinolVitA => "ರೆಟಿನಾಲ್ (ವಿಟಮಿನ್ ಎ)";

  @override
  String get labelMagnesium => "ಮೆಗ್ನೀಸಿಯಮ್";

  @override
  String get labelTodaysNutritionSummary => "ಇಂದಿನ ಪೌಷ್ಟಿಕಾಂಶದ ಸಾರಾಂಶ";
  @override
  String get labelChangeGoal => "ಗುರಿಯನ್ನು ಬದಲಾಯಿಸಿ";
  @override
  String get labelIngredientsTaken => "ತೆಗೆದುಕೊಂಡ ಪದಾರ್ಥಗಳು";
  @override
  String get labelIngredientsLeft => "ಪದಾರ್ಥಗಳು ಉಳಿದಿವೆ";

  // Food Table
  // @override
  // String get labelFoodTable => "ಆಹಾರ ಮೇಜು";
  // @override
  // String get labelBreakfast => "ಉಪಹಾರ";
  // @override
  // String get labelLunch => "ಊಟ";
  // @override
  // String get labelDinner => "ಊಟ";
  // @override
  // String get labelSnacks => "ತಿಂಡಿಗಳು";
  @override
  String get labelTop10FoodsSleep => "ಟಾಪ್ 10 ಆಹಾರಗಳು";
  @override
  String get labelFavouriteDishes => "ಮೆಚ್ಚಿನ ಭಕ್ಷ್ಯಗಳು";

  // User Profile
  @override
  String get labelHelp => "ಸಹಾಯ";
  // @override
  // String get labelLogout => "ಲಾಗ್ ಔಟ್";
  // @override
  // String get labelWeight => "ತೂಕ";
  @override
  String get labelEmail => "ಇಮೇಲ್";
  // @override
  // String get labelHeight => "ಎತ್ತರ";
  @override
  String get labelLinkedInProfileLink => "ಲಿಂಕ್ಡ್‌ಇನ್ ಪ್ರೊಫೈಲ್ ಲಿಂಕ್";
  @override
  String get labelGoogleProfileLink => "Google ಪ್ರೊಫೈಲ್ ಲಿಂಕ್";
  @override
  String get labelFacebookProfileLink => "ಫೇಸ್ಬುಕ್ ಪ್ರೊಫೈಲ್ ಲಿಂಕ್";
  @override
  String get labelTwitterProfileLink => "Twitter ಪ್ರೊಫೈಲ್ ಲಿಂಕ್";
  @override
  String get labelName => "ಹೆಸರು";
  @override
  String get labelPhoneNumber => "ದೂರವಾಣಿ ಸಂಖ್ಯೆ.";
  @override
  String get labelDateOfBirth => "ಡಿ.ಒ.ಬಿ";
  @override
  String get labelBMI => "BMI";
  // @override
  // String get labelAge => "ವಯಸ್ಸು";

  // Contact Us
  @override
  String get labelMessage => "ಸಂದೇಶ";
  @override
  String get labelSubmit => "ಸಲ್ಲಿಸು";
  @override
  String get labelCompanyContacts => "ಕಂಪನಿ ಸಂಪರ್ಕಗಳು";
  @override
  String get labelAddress => "ವಿಳಾಸ";
  @override
  String get labelDirectorsEmail => "ನಿರ್ದೇಶಕರ ಇಮೇಲ್";
  @override
  String get labelFax => "ಫ್ಯಾಕ್ಸ್";

  // Settings
  @override
  String get labelResetPassword => "ಪಾಸ್ವರ್ಡ್ ಮರುಹೊಂದಿಸಿ";
  // @override
  // String get labelFeedback => "ಪ್ರತಿಕ್ರಿಯೆ";
  @override
  String get labelPleaseProvideFeedback =>
      "ದಯವಿಟ್ಟು ನಿಮ್ಮ ಪ್ರತಿಕ್ರಿಯೆಯನ್ನು ಒದಗಿಸಿ";
  @override
  String get labelEnterYourFeedbackHere =>
      "ನಿಮ್ಮ ಪ್ರತಿಕ್ರಿಯೆಯನ್ನು ಇಲ್ಲಿ ನಮೂದಿಸಿ";
  @override
  String get labelSubmitFeedback => "ಪ್ರತಿಕ್ರಿಯೆಯನ್ನು ಸಲ್ಲಿಸಿ";

  // Credits
  // @override
  // String get labelContactUs => "ನಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸಿ";
  @override
  String get labelDevelopmentTeam => "ಅಭಿವೃದ್ಧಿ ತಂಡ";
  @override
  String get labelAcknowledgments => "ಸ್ವೀಕೃತಿಗಳು";
  @override
  String get labelPartnerships => "ಪಾಲುದಾರಿಕೆಗಳು";

  // Mobile
  @override
  String get labelSearchComponents => "ಹುಡುಕಾಟ ಘಟಕಗಳು";
  @override
  String get labelSearchComponentsHere => "ಘಟಕಗಳನ್ನು ಇಲ್ಲಿ ಹುಡುಕಿ";
  @override
  String get lablelDishName => 'ಭಕ್ಷ್ಯದ ಹೆಸರು';
  @override
  String get labelCredits => 'ಕ್ರೆಡಿಟ್‌ಗಳು';
  @override
  String get labelShareAppButton => "ಹಂಚಿಕೊಳ್ಳಿ";
  @override
  String get labelShareApp =>
      "ಬಾರ್‌ಕೋಡ್ ಸ್ಕ್ಯಾನರ್ ಅಪ್ಲಿಕೇಶನ್‌ನೊಂದಿಗೆ QR ಕೋಡ್ ಅನ್ನು ಸ್ಕ್ಯಾನ್ ಮಾಡಿ ಮತ್ತು ಅಪ್ಲಿಕೇಶನ್ ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ";
  // New translations
  @override
  String get labelConnectedWatch => "ಸಂಪರ್ಕಿತ ಗಡಿಯಾರ ಆಗಿದೆ";
  @override
  String get labelDisconnect => "ಸಂಪರ್ಕ ಕಡಿತಗೊಳಿಸಿ";
  @override
  String get labelFitbit => "ಫಿಟ್‌ಬಿಟ್";
  @override
  String get labelGoogleFit => "ಗೂಗಲ್ ಫಿಟ್";
  @override
  String get labelAppleWatch => "ಆಪಲ್ ವಾಚ್";
  @override
  String get labelSamsungSmartWatch => "ಸ್ಯಾಮ್ಸಂಗ್ ಸ್ಮಾರ್ಟ್ ವಾಚ್";
  @override
  String get labelBookDetails => "ಪುಸ್ತಕದ ವಿವರಗಳು";
  @override
  String get labelDeliveryDate => "ವಿತರಣಾ ದಿನಾಂಕ";
  @override
  String get labelOrderDate => "ಆದೇಶದ ದಿನಾಂಕ";
  @override
  String get labelAnalyseIngredientsTaken => "ಆಹಾರ ಸೇವನೆಯನ್ನು ವಿಶ್ಲೇಷಿಸಿ";
  @override
  String get labelAddDishIngredients => "ಭಕ್ಷ್ಯದ ಪದಾರ್ಥಗಳನ್ನು ಸೇರಿಸಿ";
  @override
  String get labelIngredientName => "ಪದಾರ್ಥದ ಹೆಸರು";
  @override
  String get labelEnterIngredientName => "ಘಟಕಾಂಶದ ಹೆಸರನ್ನು ನಮೂದಿಸಿ";
  @override
  String get labelIngredientQuantity => "ಘಟಕಾಂಶದ ಪ್ರಮಾಣ";
  @override
  String get labelEnterIngredientQuantity => "ಘಟಕಾಂಶದ ಪ್ರಮಾಣವನ್ನು ನಮೂದಿಸಿ";
  @override
  String get labelAdd => "ಸೇರಿಸಿ";
  @override
  String get labelSave => "ಉಳಿಸಿ";
  @override
  String get labelwatch => "ವೀಕ್ಷಿಸಲು";

  //
  @override
  String get labelBloodOxygenHeart =>
      'ಪ್ರಮುಖ ಚಿಹ್ನೆಗಳನ್ನು ಅಳೆಯಿರಿ ಮತ್ತು ಒಟ್ಟಾರೆ ಆರೋಗ್ಯವನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ.';
  @override
  String get labelTop10FoodS =>
      'ಆರೋಗ್ಯಕರ ಜೀವನಶೈಲಿಯನ್ನು ಕಾಪಾಡಿಕೊಳ್ಳಲು ಶಿಫಾರಸು ಮಾಡಿದ ಆಹಾರಗಳನ್ನು ಅನ್ವೇಷಿಸಿ.';
  @override
  String get labelWaterTrack =>
      'ದೈನಂದಿನ ಫಿಟ್ನೆಸ್ ಜಲಸಂಚಯನ ಗುರಿಗಳನ್ನು ಹೊಂದಿಸಿ ಮತ್ತು ಸಾಧಿಸಿ.';
  @override
  String get labelPersonalDetails =>
      'ವೈಯಕ್ತಿಕ ಮಾಹಿತಿಯನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ನಿರ್ವಹಿಸಿ ಮತ್ತು ನವೀಕರಿಸಿ.';
  @override
  String get labelFeedbackS =>
      'ನಿಮ್ಮ ಆಲೋಚನೆಗಳು ಮತ್ತು ಸಲಹೆಗಳನ್ನು ನಮ್ಮೊಂದಿಗೆ ಹಂಚಿಕೊಳ್ಳಿ.';
  @override
  String get labelContactUsS =>
      'ಗ್ರಾಹಕರ ಬೆಂಬಲವನ್ನು ತಲುಪಿ ಮತ್ತು ನಮ್ಮೊಂದಿಗೆ ಸಂಪರ್ಕದಲ್ಲಿರಿ.';
  @override
  String get labelBMICalculator =>
      'ಆರೋಗ್ಯ ಒಳನೋಟಗಳಿಗಾಗಿ ನಿಮ್ಮ ಬಾಡಿ ಮಾಸ್ ಇಂಡೆಕ್ಸ್ ಅನ್ನು ಲೆಕ್ಕ ಹಾಕಿ.';
  @override
  String get labelBMRCalculator =>
      'ಫಿಟ್ನೆಸ್ ಯೋಜನೆಗಾಗಿ ನಿಮ್ಮ ತಳದ ಚಯಾಪಚಯ ದರವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡಿ.';
  @override
  String get labelRunningJoggingSteps =>
      'ಆರೋಗ್ಯಕರ ಜೀವನಶೈಲಿಗಾಗಿ ನಿಮ್ಮ ಓಟ ಮತ್ತು ಜಾಗಿಂಗ್ ಹಂತಗಳನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ.';
  @override
  String get labelHealthyDietChart =>
      'ಆರೋಗ್ಯಕರ ಆಹಾರದ ಅವಲೋಕನಕ್ಕಾಗಿ ಸಮಗ್ರ ಚಾರ್ಟ್ ಅನ್ನು ಪ್ರವೇಶಿಸಿ.';
  @override
  String get labelHealthyRecommendation =>
      'ವೈಯಕ್ತಿಕಗೊಳಿಸಿದ ಆರೋಗ್ಯ ಶಿಫಾರಸುಗಳನ್ನು ಸ್ವೀಕರಿಸಿ.';
  @override
  String get labelSleepTracker =>
      'ನಿಮ್ಮ ನಿದ್ರೆಯ ಮಾದರಿಗಳನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ ಮತ್ತು ನಿದ್ರೆಯ ಗುಣಮಟ್ಟವನ್ನು ಸುಧಾರಿಸಿ.';
  @override
  String get labelSetReminder =>
      'ಆರೋಗ್ಯ ಮತ್ತು ಫಿಟ್ನೆಸ್ ಚಟುವಟಿಕೆಗಳಿಗಾಗಿ ಜ್ಞಾಪನೆಗಳನ್ನು ಹೊಂದಿಸಿ.';
  // @override
  // String get labelMenstruationCycle =>
  //     'ಉತ್ತಮ ಒಳನೋಟಗಳಿಗಾಗಿ ನಿಮ್ಮ ಋತುಚಕ್ರವನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ ಮತ್ತು ನಿರ್ವಹಿಸಿ.';
  @override
  String get labelCSVDownload =>
      'ಸುಲಭ ವಿಶ್ಲೇಷಣೆಗಾಗಿ ನಿಮ್ಮ ಡೇಟಾವನ್ನು CSV ಸ್ವರೂಪದಲ್ಲಿ ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ.';

  // New Headings
  @override
  String get headingBloodOxygenHeart => 'ರಕ್ತ | ಆಮ್ಲಜನಕ';
  @override
  String get headingTop10Food => 'ಟಾಪ್ 10 ಆಹಾರ';
  @override
  String get headingWaterTrack => 'ವಾಟರ್ ಟ್ರ್ಯಾಕರ್';
  @override
  String get headingPersonalDetails => 'ವೈಯಕ್ತಿಕ ವಿವರಗಳು';
  @override
  String get headingFeedback => 'ಪ್ರತಿಕ್ರಿಯೆ';
  @override
  String get headingContactUs => 'ನಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸಿ';
  @override
  String get headingBMICalculator => 'BMI ಕ್ಯಾಲ್ಕುಲೇಟರ್';
  @override
  String get headingBMRCalculator => 'BMR ಕ್ಯಾಲ್ಕುಲೇಟರ್';
  @override
  String get headingRunningJoggingSteps => 'ರನ್ನಿಂಗ್ / ಜಾಗಿಂಗ್ / ಹಂತಗಳು';
  @override
  String get headingHealthyDietChart => 'ಆರೋಗ್ಯಕರ ಆಹಾರ ಚಾರ್ಟ್';
  @override
  String get headingHealthyRecommendation => 'ಆರೋಗ್ಯಕರ ಶಿಫಾರಸು';
  @override
  String get headingSleepTracker => 'ಸ್ಲೀಪ್ ಟ್ರ್ಯಾಕರ್';
  @override
  String get headingSetReminder => 'ಜ್ಞಾಪನೆಯನ್ನು ಹೊಂದಿಸಿ';
  // @override
  // String get headingMenstruationCycle => 'ಮುಟ್ಟಿನ ಚಕ್ರ';
  @override
  String get headingCSVDownload => 'CSV ಡೌನ್‌ಲೋಡ್';

  // Water-related phrases
  @override
  String get labelWaterTarget => "ನೀರಿನ ಗುರಿ";
  // @override
  // String get labelTodayTarget => "ಇಂದು ಟಾರ್ಗೆಟ್";
  @override
  String get labelWaterGoal => "ನೀರಿನ ಗುರಿ";
  // @override
  // String get labelWaterIntake => "ನೀರಿನ ಸೇವನೆ";
  @override
  String get labelWaterProgress => "ನೀರಿನ ಪ್ರಗತಿ";
  // @override
  // String get labelWeekly => "ಸಾಪ್ತಾಹಿಕ";
  @override
  String get labelDateWise => "ದಿನಾಂಕದ ಪ್ರಕಾರ";
  @override
  String get labelSun => "ಸೂರ್ಯ";
  @override
  String get labelMon => "ಸೋಮ";
  @override
  String get labelTue => "ಮಂಗಳವಾರ";
  @override
  String get labelWed => "ಬುಧವಾರ";
  @override
  String get labelThu => "ಗುರು";
  @override
  String get labelFri => "ಶುಕ್ರ";

  // BMI Calculator
  // @override
  // String get labelBMI => "BMI";
  @override
  String get labelEnterHeight => "ಎತ್ತರವನ್ನು ನಮೂದಿಸಿ (ಸೆಂ)";
  @override
  String get labelEnterWeight => "ತೂಕವನ್ನು ನಮೂದಿಸಿ (ಕೆಜಿ)";
  @override
  String get labelCalculateBMI => "BMI ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡಿ";

  // BMR Calculator
  @override
  String get labelMale => "ಪುರುಷ";
  @override
  String get labelFemale => "ಹೆಣ್ಣು";
  @override
  String get labelEnterAge => "ವಯಸ್ಸನ್ನು ನಮೂದಿಸಿ";
  @override
  String get labelCalculateBMR => "BMR ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡಿ";
  @override
  String get labelBMR => "ಬಿಎಂಆರ್";
  @override
  String get labelCaloriesPerDay => "ಕ್ಯಾಲೋರಿಗಳು / ದಿನ";

  // Step Tracker
  @override
  String get labelStepsTracker => "ಹಂತ ಟ್ರ್ಯಾಕರ್";
  @override
  String get labelRunningTracker => "ರನ್ನಿಂಗ್ ಟ್ರ್ಯಾಕರ್";
  @override
  String get labelAddStep => "ಹಂತವನ್ನು ಸೇರಿಸಿ";
  @override
  String get labelSelectDate => "ದಿನಾಂಕವನ್ನು ಆಯ್ಕೆಮಾಡಿ";
  @override
  String get labelJoggingTracker => "ಜಾಗಿಂಗ್ ಟ್ರ್ಯಾಕರ್";
  @override
  String get labelCaloriesBurn => "ಕ್ಯಾಲೋರಿಗಳು ಸುಟ್ಟುಹೋದವು";

  // Sleep Tracker
  @override
  String get labelSleepTarget => "ನಿದ್ರೆಯ ಗುರಿ";
  @override
  String get labelTodaySleep => "ಇಂದು ನಿದ್ರೆ";
  @override
  String get labelSleepProgress => "ನಿದ್ರೆಯ ಪ್ರಗತಿ";
  @override
  String get labelTotalSleep => "ಒಟ್ಟು ನಿದ್ರೆ";
  @override
  String get labelSleepGoal => "ನಿದ್ರೆಯ ಗುರಿ";
  @override
  String get labelSetNotification => "ಅಧಿಸೂಚನೆಯನ್ನು ಹೊಂದಿಸಿ";
  @override
  String get labelStartTime => "ಆರಂಭವಾಗುವ";
  @override
  String get labelEndTime => "ಅಂತಿಮ ಸಮಯ";
  @override
  String get labelSelect => "ಆಯ್ಕೆ ಮಾಡಿ";
  @override
  String get labelSat => "ಶನಿ";
  // @override
  // String get labelSave => "ಉಳಿಸಿ";
  @override
  String get labelStart => "ಪ್ರಾರಂಭಿಸಿ";
  @override
  String get labelEnd => "ಅಂತ್ಯ";
  @override
  String get labelType => "ಮಾದರಿ";
  @override
  String get labelIsConnected => "ಸಂಪರ್ಕ ಹೊಂದಿದೆ";

  // @override
  // String get labelMensurationCycle => "ಸೈಕಲ್ ಮಾಪನ";

  @override
  String get labelTrackAndManage =>
      "ಉತ್ತಮ ಒಳನೋಟಗಳಿಗಾಗಿ ನಿಮ್ಮ ಮಾಸಿಕ ಚಕ್ರವನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ ಮತ್ತು ನಿರ್ವಹಿಸಿ";

  @override
  String get labelMensurationStatus => "ಮಾಪನ ಸ್ಥಿತಿ";

  @override
  String get labelDaysLength => "ದಿನಗಳ ಉದ್ದ";

  @override
  String get labelDay => "ದಿನ";

  @override
  String get labelNextDate => "ಮುಂದಿನ ದಿನಾಂಕ";

  @override
  String get labelLastPeriodStartDate => "ಕೊನೆಯ ಅವಧಿ ಪ್ರಾರಂಭ ದಿನಾಂಕ";

  @override
  String get labelAverageCycleLength => "ಸರಾಸರಿ ಸೈಕಲ್ ಉದ್ದ";

  @override
  String get labelChange => "ಬದಲಾವಣೆ";

  // Common Messages
  @override
  String get messageSent => "ಸಂದೇಶ ಕಳುಹಿಸಲಾಗಿದೆ";

  @override
  String get thankYouForContactingUs => "ನಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸಿದ್ದಕ್ಕೆ ಧನ್ಯವಾದಗಳು!";

  @override
  String get alert => "ಎಚ್ಚರಿಕೆ";

  @override
  String get fillInAllFields => "ದಯವಿಟ್ಟು ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳನ್ನು ಭರ್ತಿ ಮಾಡಿ.";

  @override
  String get thankYouFeedbackSubmitted =>
      "ನಿಮ್ಮ ಪ್ರತಿಕ್ರಿಯೆಯನ್ನು ಸಲ್ಲಿಸಲಾಗಿದೆ.";

  @override
  String get resetPassword => "ಪಾಸ್ವರ್ಡ್ ಮರುಹೊಂದಿಸಿ";

  @override
  String get dishAdded => "ಭಕ್ಷ್ಯ ಸೇರಿಸಲಾಗಿದೆ!";

  @override
  String get dishAndIngredientsAddedSuccessfully =>
      "ಭಕ್ಷ್ಯ ಮತ್ತು ಪದಾರ್ಥಗಳನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಸೇರಿಸಲಾಗಿದೆ.";

  @override
  String get failed => "ವಿಫಲವಾಗಿದೆ";

  @override
  String get error => "ದೋಷ";

  @override
  String get enterBloodGlucoseLevel =>
      "ರಕ್ತದಲ್ಲಿನ ಗ್ಲೂಕೋಸ್ ಮಟ್ಟವನ್ನು mg / dL ನಲ್ಲಿ ನಮೂದಿಸಿ";

  @override
  String get enterBloodPressureLevel =>
      "mmHg ನಲ್ಲಿ ರಕ್ತದೊತ್ತಡದ ಮಟ್ಟವನ್ನು ನಮೂದಿಸಿ";

  @override
  String get enterHeartLevel =>
      "ಹೃದಯ ಬಡಿತವನ್ನು ನಿಮಿಷಕ್ಕೆ ಬಡಿತಗಳಲ್ಲಿ ನಮೂದಿಸಿ (BPM).";

  @override
  String get cancel => "ರದ್ದುಮಾಡಿ";

  @override
  String get submit => "ಸಲ್ಲಿಸು";

  @override
  String get valueCannotBeGreaterThan100 => "ಮೌಲ್ಯವು 100 ಕ್ಕಿಂತ ಹೆಚ್ಚಿರಬಾರದು.";

  @override
  String get bloodStatusSubmittedSuccessfully =>
      "ರಕ್ತದ ಸ್ಥಿತಿಯನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಸಲ್ಲಿಸಲಾಗಿದೆ.";

  @override
  String get failedToSubmitBlood => "ರಕ್ತವನ್ನು ಸಲ್ಲಿಸಲು ವಿಫಲವಾಗಿದೆ.";

  @override
  String get enterHeartLevel1to100 =>
      "ಹೃದಯ ಬಡಿತವನ್ನು ನಿಮಿಷಕ್ಕೆ ಬಡಿತಗಳಲ್ಲಿ ನಮೂದಿಸಿ (BPM).";

  @override
  String get heartLevelSubmittedSuccessfully =>
      "ಹೃದಯದ ಮಟ್ಟವನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಸಲ್ಲಿಸಲಾಗಿದೆ.";

  @override
  String get enterOxygenSaturationLevel1to100 =>
      "ಆಮ್ಲಜನಕದ ಶುದ್ಧತ್ವ ಮಟ್ಟವನ್ನು 1% -100% ನಮೂದಿಸಿ";

  @override
  String get oxygenLevelSubmittedSuccessfully =>
      "ಆಮ್ಲಜನಕದ ಮಟ್ಟವನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಸಲ್ಲಿಸಲಾಗಿದೆ.";

  @override
  String get updateData => "ಡೇಟಾವನ್ನು ನವೀಕರಿಸಿ";

  @override
  String get selectLastPeriodStartDate =>
      "ಕೊನೆಯ ಅವಧಿಯ ಪ್ರಾರಂಭ ದಿನಾಂಕವನ್ನು ಆಯ್ಕೆಮಾಡಿ";

  @override
  String get update => "ನವೀಕರಿಸಿ";

  @override
  String get failedToFetchBooks =>
      "ಪುಸ್ತಕಗಳನ್ನು ತರಲು ವಿಫಲವಾಗಿದೆ. ದಯವಿಟ್ಟು ಪುನಃ ಪ್ರಯತ್ನಿಸಿ.";

  @override
  String get errorOccurred => "ಒಂದು ತಪ್ಪು ನಡೆದಿದೆ:";

  @override
  String get invalidEndTime => "ಅಮಾನ್ಯವಾದ ಅಂತಿಮ ಸಮಯ";

  @override
  String get chooseTimeWithin1Hour =>
      "ದಯವಿಟ್ಟು ಪ್ರಾರಂಭದ ಸಮಯದಿಂದ 1 ಗಂಟೆಯೊಳಗೆ ಸಮಯವನ್ನು ಆಯ್ಕೆಮಾಡಿ.";

  @override
  String get notificationSaved => "ಅಧಿಸೂಚನೆಯನ್ನು ಉಳಿಸಲಾಗಿದೆ";

  @override
  String get notificationSetSuccessfully =>
      "ಅಧಿಸೂಚನೆಯನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಹೊಂದಿಸಲಾಗಿದೆ.";

  @override
  String get thereIsSomeError => "ಕೆಲವು ದೋಷವಿದೆ.";

  @override
  String get watchDisconnected => "ಗಡಿಯಾರ ಸಂಪರ್ಕ ಕಡಿತಗೊಂಡಿದೆ";

  @override
  String get watchDisconnectedSuccessfully =>
      "ಗಡಿಯಾರವನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಸಂಪರ್ಕ ಕಡಿತಗೊಳಿಸಲಾಗಿದೆ.";

  @override
  String get addCup => "ಕಪ್ ಸೇರಿಸಿ";

  @override
  String get numberOfCups => "ಕಪ್ಗಳ ಸಂಖ್ಯೆ";

  @override
  String get addCupCapacityInMl => "ಮಿಲಿಯಲ್ಲಿ ಕಪ್ ಸಾಮರ್ಥ್ಯವನ್ನು ಸೇರಿಸಿ";

  @override
  String get cupCapacitySubmittedSuccessfully =>
      "ಕಪ್ ಸಾಮರ್ಥ್ಯವನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಸಲ್ಲಿಸಲಾಗಿದೆ.";

  @override
  String get pleaseEnterValidValuesForAllFields =>
      "ದಯವಿಟ್ಟು ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳಿಗೆ ಮಾನ್ಯವಾದ ಮೌಲ್ಯಗಳನ್ನು ನಮೂದಿಸಿ.";

  @override
  String get enterWater => "ನೀರನ್ನು ನಮೂದಿಸಿ";

  @override
  String get waterGoalLiters => "ನೀರಿನ ಗುರಿ (ಲೀಟರ್)";

  @override
  String get waterSubmittedSuccessfully =>
      "ನೀರಿನ ಗುರಿಯನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಸಲ್ಲಿಸಲಾಗಿದೆ.";

  @override
  String get addActivityData => "ಚಟುವಟಿಕೆ ಡೇಟಾವನ್ನು ಸೇರಿಸಿ";

  @override
  String get enterValue => "ಮೌಲ್ಯವನ್ನು ನಮೂದಿಸಿ";

  @override
  String get addStepsData => "ಹಂತಗಳ ಡೇಟಾವನ್ನು ಸೇರಿಸಿ";

  @override
  String get numberOfSteps => "ಹಂತಗಳ ಸಂಖ್ಯೆ";

  @override
  String get stepsDataSubmittedSuccessfully =>
      "ಹಂತಗಳ ಡೇಟಾವನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಸಲ್ಲಿಸಲಾಗಿದೆ.";

  @override
  String get enterSleepTarget => "ನಿದ್ರೆಯ ಗುರಿಯನ್ನು ನಮೂದಿಸಿ";

  @override
  String get sleepTargetInHours => "ಗಂಟೆಗಳಲ್ಲಿ ನಿದ್ರೆ ಗುರಿ";

  @override
  String get addYourSleepDuration => "ನಿಮ್ಮ ನಿದ್ರೆಯ ಅವಧಿಯನ್ನು ಸೇರಿಸಿ";

  @override
  String get enterDurationInMinutes => "ನಿಮಿಷಗಳಲ್ಲಿ ಅವಧಿಯನ್ನು ನಮೂದಿಸಿ:";

  @override
  String get add => "ಸೇರಿಸಿ";

  @override
  String get ok => "ಸರಿ";

  @override
  String get csvFileSavedTo => "CSV ಫೈಲ್ ಅನ್ನು ಉಳಿಸಲಾಗಿದೆ";

  @override
  String get ageMustBeBetween2And100Years =>
      "ವಯಸ್ಸು 2 ರಿಂದ 100 ವರ್ಷಗಳ ನಡುವೆ ಇರಬೇಕು";

  @override
  String get next => "ಮುಂದೆ";

  @override
  String get register => "ನೋಂದಣಿ";

  @override
  String get oopsSomethingWentWrong => "ಅಯ್ಯೋ! ಏನೋ ತಪ್ಪಾಗಿದೆ";

  @override
  String get errorFetchingMeals => "ಊಟವನ್ನು ತರುವಾಗ ದೋಷ ಸಂಭವಿಸಿದೆ:";

  @override
  String get reviewAddedSuccessfully => "ವಿಮರ್ಶೆಯನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಸೇರಿಸಲಾಗಿದೆ!";

  @override
  String get failedToAddReview => "ವಿಮರ್ಶೆಯನ್ನು ಸೇರಿಸಲು ವಿಫಲವಾಗಿದೆ:";

  @override
  String get alreadyInCart => "ಈಗಾಗಲೇ ಕಾರ್ಟ್‌ನಲ್ಲಿದೆ";

  @override
  String get addedToCart => "ಕಾರ್ಟ್‌ಗೆ ಸೇರಿಸಲಾಗಿದೆ";

  @override
  String get quantityNotBetween1And2 =>
      "ಪ್ರಮಾಣವು 2 ಕ್ಕಿಂತ ಹೆಚ್ಚಿಲ್ಲ ಮತ್ತು 1 ಕ್ಕಿಂತ ಕಡಿಮೆಯಿಲ್ಲ";

  String get createcustomdish => "ಕಸ್ಟಮ್ ಭಕ್ಷ್ಯವನ್ನು ರಚಿಸಿ";
  String get quantityingram => "ಪ್ರಮಾಣ (ಗ್ರಾಂ)";
  String get labelCaloriestaken => 'ಶಕ್ತಿ';
  String get mainlabelEarlyMorning => "ಮುಂಜಾನೆ";
  String get mainlabelMidMorning => "ಮಧ್ಯ ಬೆಳಿಗ್ಗೆ";
  String get mainlabelEvening => "ಸಂಜೆ";
  String get mainlabelBedtime => "ಮಲಗುವ ಸಮಯ";
  String get mainlabelTimeSpentOn => "ವಿವಿಧ ಚಟುವಟಿಕೆಗಳಲ್ಲಿ ಸಮಯ ಕಳೆಯುತ್ತಾರೆ";
  String get mainlabelHealthCalculator => "ಆರೋಗ್ಯ ಕ್ಯಾಲ್ಕುಲೇಟರ್";
  String get mainlabelStepProgress => "ಹಂತ ಪ್ರಗತಿ";
  String get mainlabelRealTimeIntakes => "ನೈಜ ಸಮಯದ ಸೇವನೆಗಳು";
  String get mainlabelCaloriesBurnProgress => "ಸುಟ್ಟ ಕ್ಯಾಲೋರಿ ಪ್ರಗತಿ";
  String get mainlabelCaloriesBurnBreakdown =>
      "ಸುಟ್ಟ ಕ್ಯಾಲೋರಿಗಳು ಸ್ಥಗಿತಗೊಳ್ಳುತ್ತವೆ";
  String get mainlabelHeartReportsTrends => "ಹೃದಯ ವರದಿಗಳ ಪ್ರವೃತ್ತಿಗಳು";
  String get mainlabelOxygenStatus => "ಆಮ್ಲಜನಕ ಸ್ಥಿತಿ";
  String get mainlabelNoRecord => "ನನಗೆ ನೆನಪಿಲ್ಲ";
  String get mainlabelSystolicBloodPressure => "ಸಿಸ್ಟೊಲಿಕ್ ರಕ್ತದೊತ್ತಡ";
  String get mainlabelMeasuredon => "ಮೇಲೆ ಅಳೆಯಲಾಗುತ್ತದೆ";
  String get mainlabelEnterBloodPressure => "ರಕ್ತದೊತ್ತಡವನ್ನು ನಮೂದಿಸಿ";
  String get mainlabelBloodPressure => "ರಕ್ತದೊತ್ತಡ";
  String get mainlabelDiastolicBloodPressure => "ಡಯಾಸ್ಟೊಲಿಕ್ ರಕ್ತದೊತ್ತಡ";
  String get mainlabelBloodGlucose => "ರಕ್ತದ ಗ್ಲೂಕೋಸ್";
  String get mainlabelHeartStatus => "ಹೃದಯ ಸ್ಥಿತಿ";
  String get mainlabelAllExercise => "ಎಲ್ಲಾ ವ್ಯಾಯಾಮ";
  String get mainlabelCleaningOrMopping => "ಸ್ವಚ್ಛಗೊಳಿಸುವ ಅಥವಾ ಒರೆಸುವ";
  String get mainlabelGardening => "ತೋಟಗಾರಿಕೆ";
  String get mainlabelWatchingTV => "ಟಿವಿ ನೋಡುತ್ತಿದ್ದೇನೆ";
  String get mainlabelCycling => "ಸೈಕ್ಲಿಂಗ್";
  String get mainlabelRunning => "ಓಡುತ್ತಿದೆ";
  String get mainlabelWalking => "ವಾಕಿಂಗ್";
  String get mainlabelShuttle => "ಶಟಲ್";
  String get mainlabelTableTennis => "ಟೇಬಲ್ ಟೆನ್ನಿಸ್";
  String get mainlabelTennis => "ಟೆನಿಸ್";
  String get mainlabelVolleyBall => "ವಾಲಿಬಾಲ್";
  String get mainlabelDancing => "ನೃತ್ಯ";
  String get mainlabelFishing => "ಮೀನುಗಾರಿಕೆ";
  String get mainlabelShopping => "ಶಾಪಿಂಗ್";
  String get mainlabelTyping => "ಟೈಪಿಂಗ್";
  String get mainlabelSleeping => "ಸ್ಲೀಪಿಂಗ್";
  String get mainlabelStanding => "ನಿಂತಿರುವುದು";
  String get mainlabelSitting => "ಕುಳಿತುಕೊಳ್ಳುವುದು";
  String get mainlabelClickToStartActivity =>
      "ಚಟುವಟಿಕೆಯನ್ನು ಪ್ರಾರಂಭಿಸಲು ಕ್ಲಿಕ್ ಮಾಡಿ";
  String get mainlabelBMICalculator => "BMI ಕ್ಯಾಲ್ಕುಲೇಟರ್";
  String get mainlabelBMRCalculator => "BMR ಕ್ಯಾಲ್ಕುಲೇಟರ್";
  String get mainlabelDownloadActivityReportInCsv =>
      "csv ನಲ್ಲಿ ಚಟುವಟಿಕೆ ವರದಿಯನ್ನು ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ";
  String get mainlabelSelectStartDate => "ಪ್ರಾರಂಭ ದಿನಾಂಕವನ್ನು ಆಯ್ಕೆಮಾಡಿ";
  String get mainlabelSelectEndDate => "ಅಂತಿಮ ದಿನಾಂಕವನ್ನು ಆಯ್ಕೆಮಾಡಿ";
  String get mainlabelDownloadFile => "ಫೈಲ್ ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ";
  String get mainlabelDate => "ದಿನಾಂಕ";
  String get mainlabelValue => "ಮೌಲ್ಯ";
  String get mainlabelLink => "ಲಿಂಕ್";
  String get mainlabelNoNotificationFound => "ಯಾವುದೇ ಅಧಿಸೂಚನೆ ಕಂಡುಬಂದಿಲ್ಲ";
  String get mainlabelTotalNutritionTaken => "=ಒಟ್ಟು ಪೋಷಣೆ ತೆಗೆದುಕೊಳ್ಳಲಾಗಿದೆ";
  String get mainlabelSearchFood => "ಪಾಕವಿಧಾನಗಳನ್ನು ಹುಡುಕಿ";
  String get mainlabelSelectFromPersonalFood =>
      "ವೈಯಕ್ತಿಕ ಪಾಕವಿಧಾನಗಳಿಂದ ಆಯ್ಕೆಮಾಡಿ";
  String get mainlabelRecipeName => "ಪಾಕವಿಧಾನದ ಹೆಸರು";
  String get mainlabelSelectDate => "ದಿನಾಂಕವನ್ನು ಆಯ್ಕೆಮಾಡಿ";
  String get mainlabelNutrientOfAllIngredientsRaw =>
      "ಎಲ್ಲಾ ಪದಾರ್ಥಗಳ ಪೋಷಕಾಂಶಗಳು (ಕಚ್ಚಾ)";
  String get mainlabelNutrientsCompostionOfCookedWeight =>
      "ಬೇಯಿಸಿದ ತೂಕದ ಪೋಷಕಾಂಶಗಳ ಸಂಯೋಜನೆ";
  String get mainlabelWantToEditThisRecipyFollowThe =>
      "ಈ ಪಾಕವಿಧಾನವನ್ನು ಸಂಪಾದಿಸಲು ಬಯಸುವಿರಾ? ಅನುಸರಿಸಿ";
  String get mainlabelAddIngredientFrom => "ನಿಂದ ಪದಾರ್ಥವನ್ನು ಸೇರಿಸಿ";
  String get mainlabelAddFromNutrientSpecifcFood =>
      "ಪೌಷ್ಠಿಕಾಂಶದ ನಿರ್ದಿಷ್ಟ ಆಹಾರದಿಂದ ಸೇರಿಸಿ";
  String get mainlabelAddFromAllFoods => "ಎಲ್ಲಾ ಆಹಾರಗಳಿಂದ ಸೇರಿಸಿ";
  String get mainlabelNumberOfServing => "ಸೇವೆಗಳ ಸಂಖ್ಯೆ";
  String get mainlabelWeightInG => "ತೂಕ (ಗ್ರಾಂ)";
  String get mainlabelEditIngredientsWeight => "ಪದಾರ್ಥಗಳ ತೂಕವನ್ನು ಸಂಪಾದಿಸಿ";
  String get mainlabelIngredient => "ಪದಾರ್ಥ";
  String get mainlabelNewWeightInG => "ಹೊಸ ತೂಕ (ಗ್ರಾಂ)";
  String get mainlabelCancel => "ರದ್ದುಮಾಡು";
  String get mainlabelUpdate => "ನವೀಕರಿಸಿ";
  String get mainlabelCookedWeightInG => "ಬೇಯಿಸಿದ ತೂಕ (ಗ್ರಾಂ)";
  String get mainlabelEnterWeight => "ತೂಕವನ್ನು ನಮೂದಿಸಿ";
  String get mainlabelEditRecipy => "ಪಾಕವಿಧಾನವನ್ನು ಸಂಪಾದಿಸಿ";
  String get mainlabelAlert => "ಎಚ್ಚರಿಕೆ";
  String get mainlabelToSeeNutritionCompositionPleaseEnterNoOfServing =>
      "ಪೌಷ್ಠಿಕಾಂಶದ ಸಂಯೋಜನೆಯನ್ನು ನೋಡಲು, ದಯವಿಟ್ಟು ಸೇವೆಗಳ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ";
  String get mainlabelNutrirntsIn100CookedWeight =>
      "100 (ಬೇಯಿಸಿದ) ತೂಕದಲ್ಲಿ ಪೋಷಕಾಂಶಗಳು";
  String get mainlabelSetNutritionTargetInG =>
      "ಗ್ರಾಂನಲ್ಲಿ ಪೌಷ್ಟಿಕಾಂಶದ ಗುರಿಯನ್ನು ಹೊಂದಿಸಿ";
  String get mainlabelFoodAnalyse => "ಅನ್ವೇಷಿಸಿ";
  String get mainlabelExploreTop10Foods => "ಟಾಪ್ 10 ಆಹಾರಗಳನ್ನು ಅನ್ವೇಷಿಸಿ";
  String get mainlabelSearchCookedFood => "ಪಾಕವಿಧಾನಗಳಲ್ಲಿ ಪೋಷಕಾಂಶಗಳನ್ನು ಹುಡುಕಿ";
  String get mainlabelNutritionBasedOnEAR => "EAR ಆಧರಿಸಿ ಪೌಷ್ಟಿಕಾಂಶದ ಅವಶ್ಯಕತೆ";
  String get mainlabelDietDiary => "ಆಹಾರ ಡೈರಿ";
  String get mainlabelRecipes => "ಪಾಕವಿಧಾನಗಳು";
  String get mainlabelSearchByFoodName => "ಆಹಾರದ ಹೆಸರಿನ ಮೂಲಕ ಹುಡುಕಿ";
  String get mainlabelAllRecipeOf100G => "100 ಗ್ರಾಂಗಳ ಎಲ್ಲಾ ಪಾಕವಿಧಾನಗಳು";
  String get mainlabelNutritionRequirement => "ಪೋಷಣೆಯ ಅವಶ್ಯಕತೆ";
  String get mainlabelGender => "ಲಿಂಗ";
  String get mainlabelParticulars => "ವಿವರಗಳು";
  String get mainlabelBodyWeight => "ದೇಹದ ತೂಕ";
  String get mainlabelDietaryDiaryReports => "ಪೋಷಕಾಂಶಗಳ ಸೇವನೆ";
  String get mainlabelTotalNutritionTakenOn => "ತೆಗೆದುಕೊಂಡ ಒಟ್ಟು ಪೋಷಣೆ";
  String get mainlabelAttachImage => "ಚಿತ್ರವನ್ನು ಲಗತ್ತಿಸಿ";
  String get mainlabelFixedRecipy => "ಸ್ಥಿರ ಪಾಕವಿಧಾನ";
  String get mainlabelFoodInDetail => "ವಿವರವಾಗಿ ಆಹಾರ";
  String get TextAppNutrientsInMyFood => "ಆಹಾರದಲ್ಲಿ ಪೋಷಕಾಂಶಗಳನ್ನು ಹುಡುಕಿ";
  String get TextAppMyActivity => "ನನ್ನ ಚಟುವಟಿಕೆ";
  String get TextAppToday => "ಇಂದು";
  String get TextAppMyNutrientRequirements => "ನನ್ನ ಪೌಷ್ಟಿಕಾಂಶದ ಅವಶ್ಯಕತೆಗಳು";
  String get TextAppTotalNutrition => "ಒಟ್ಟು ಪೋಷಣೆ";
  String get TextAppTaken => "ತೆಗೆದುಕೊಳ್ಳಲಾಗಿದೆ";
  String get TextAppRatings => "ರೇಟಿಂಗ್‌ಗಳು";
  String get TextAppSearchComponents => "ಹುಡುಕಾಟ ಘಟಕಗಳು";
  String get TextAppTotalNutrientTaken => "ಇಂದು ನನ್ನ ಪೋಷಕಾಂಶಗಳ ಸೇವನೆ";
  String get TextAppShareApp => "ಅಪ್ಲಿಕೇಶನ್ ಹಂಚಿಕೊಳ್ಳಿ";
  String get TextAppNoNotificationsFound => "ಯಾವುದೇ ಅಧಿಸೂಚನೆಗಳು ಕಂಡುಬಂದಿಲ್ಲ";
  String get TextAppConnectWatch => "ವಾಚ್ ಅನ್ನು ಸಂಪರ್ಕಿಸಿ";
  String get TextAppYourBMIIs => "ನಿಮ್ಮ BMI ಆಗಿದೆ";
  String get TextAppBMI => "BMI";
  String get TextAppBMICategories => "BMI ವರ್ಗಗಳು";
  String get TextAppUnderweight => "ಕಡಿಮೆ ತೂಕ";
  String get TextAppNormal => "ಸಾಮಾನ್ಯ";
  String get TextAppOverweight => "ಅಧಿಕ ತೂಕ";
  String get TextAppObesity => "ಬೊಜ್ಜು";
  String get TextAppSelectDate => "ದಿನಾಂಕವನ್ನು ಆಯ್ಕೆಮಾಡಿ";
  String get TextAppOxygen => "ಆಮ್ಲಜನಕ";
  String get TextAppBlood => "ರಕ್ತ";
  String get TextAppNoRecord => "ದಾಖಲೆ ಇಲ್ಲ";
  String get TextAppAllExercise => "ಎಲ್ಲಾ ವ್ಯಾಯಾಮ";
  String get TextAppCleaningOrMopping => "ಸ್ವಚ್ಛಗೊಳಿಸುವಿಕೆ ಅಥವಾ ಮಾಪಿಂಗ್";
  String get TextAppGardening => "ತೋಟಗಾರಿಕೆ";
  String get TextAppWatchingTV => "ಟಿವಿ ನೋಡುತ್ತಿದ್ದೇನೆ";
  String get TextAppCycling => "ಸೈಕ್ಲಿಂಗ್";
  String get TextAppRunning => "ಓಡುತ್ತಿದೆ";
  String get TextAppWalking => "ವಾಕಿಂಗ್";
  String get TextAppShuttle => "ಶಟಲ್";
  String get TextAppTableTennis => "ಟೇಬಲ್ ಟೆನ್ನಿಸ್";
  String get TextAppTennis => "ಟೆನಿಸ್";
  String get TextAppVolleyBall => "ವಾಲಿಬಾಲ್";
  String get TextAppDancing => "ನೃತ್ಯ";
  String get TextAppFishing => "ಮೀನುಗಾರಿಕೆ";
  String get TextAppShopping => "ಶಾಪಿಂಗ್";
  String get TextAppTyping => "ಟೈಪಿಂಗ್";
  String get TextAppSleeping => "ಸ್ಲೀಪಿಂಗ್";
  String get TextAppStanding => "ನಿಂತಿರುವುದು";
  String get TextAppSitting => "ಕುಳಿತುಕೊಳ್ಳುವುದು";
  String get TextAppClickStartToStartActivity =>
      "ಚಟುವಟಿಕೆಯನ್ನು ಪ್ರಾರಂಭಿಸಲು ಪ್ರಾರಂಭಿಸಿ ಕ್ಲಿಕ್ ಮಾಡಿ";
  String get TextAppCaloriesBurn => "ಕ್ಯಾಲೋರಿಗಳು ಸುಟ್ಟುಹೋದವು";
  String get TextAppAddDurationManually => "ಅವಧಿಯನ್ನು ಹಸ್ತಚಾಲಿತವಾಗಿ ಸೇರಿಸಿ";
  String get TextAppStartOrMopping => "ಪ್ರಾರಂಭಿಸಿ ಅಥವಾ ಮೊಪಿಂಗ್";
  String get TextAppMale => "ಪುರುಷ";
  String get TextAppFemale => "ಹೆಣ್ಣು";
  String get TextAppWeightManager => "ನನ್ನ ದೇಹದ ತೂಕವನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ";
  String get TextAppUpdateWeight => "ತೂಕವನ್ನು ನವೀಕರಿಸಿ";
  String get TextAppSetWeightGoal => "ತೂಕದ ಗುರಿಯನ್ನು ಹೊಂದಿಸಿ";
  String get TextAppCurrentWeight => "ಪ್ರಸ್ತುತ ತೂಕ";
  String get TextAppWeightProgress => "ತೂಕದ ಪ್ರಗತಿ";
  String get TextAppPrevious30Days => "ಹಿಂದಿನ 30 ದಿನಗಳು";
  String get TextAppYourWeightGoalIsSet => "ನಿಮ್ಮ ಗುರಿಯಾಗಿದೆ";
  String get TextAppMaintain => "ನಿರ್ವಹಿಸಿ";
  String get TextAppInitialWeightOf => "ಆರಂಭಿಕ ತೂಕ";
  String get TextAppFinalWeightOf => "ಇತ್ತೀಚಿನ ತೂಕ";
  String get TextAppWeight => "ತೂಕ";
  String get TextAppYouAreNotYetAchievingYourWeightGoalKeepGoing =>
      "ನಿಮ್ಮ ತೂಕದ ಗುರಿಯನ್ನು ನೀವು ಇನ್ನೂ ಸಾಧಿಸುತ್ತಿಲ್ಲ. ಹೋಗ್ತಾ ಇರು!";
  String get TextAppYouAreAchievedYourWeightGoalKeepGoing =>
      "ನಿಮ್ಮ ತೂಕದ ಗುರಿಯನ್ನು ನೀವು ಸಾಧಿಸಿದ್ದೀರಿ. ಹೋಗ್ತಾ ಇರು!";
  String get TextAppAndYourWeightChangeIsSet =>
      "ಮತ್ತು ನಿಮ್ಮ ತೂಕ ಬದಲಾವಣೆಯನ್ನು ಹೊಂದಿಸಲಾಗಿದೆ";
  String get TextApp1NutrientsInMyFood => "ನನ್ನ ಆಹಾರದಲ್ಲಿನ ಪೋಷಕಾಂಶಗಳು";
  String get TextAppSearchNutrientsInRawFoods =>
      "ಕಚ್ಚಾ ಆಹಾರದಲ್ಲಿ ಪೋಷಕಾಂಶಗಳನ್ನು ಹುಡುಕಿ";
  String get TextAppRawIngredients => "ಕಚ್ಚಾ ಪದಾರ್ಥಗಳು";
  String get TextAppSearchRawFoodByName => "ಹೆಸರಿನಿಂದ ಕಚ್ಚಾ ಆಹಾರವನ್ನು ಹುಡುಕಿ";
  String get TextApp1MyActivity => "ನನ್ನ ಚಟುವಟಿಕೆಯ ವರದಿ";
  String get TextAppCheckOthersDates => "ಇತರ ದಿನಾಂಕಗಳನ್ನು ಪರಿಶೀಲಿಸಿ";
  String get TextAppYour24HoursChart => "ನಿಮ್ಮ 24 ಗಂಟೆಗಳ ಚಾರ್ಟ್";
  String get TextAppActivity => "ಚಟುವಟಿಕೆ";
  String get TextAppOthers => "ಇತರರು";
  String get TextAppExerciseDetails => "ವ್ಯಾಯಾಮದ ವಿವರಗಳು";
  String get TextAppActivityType => "ಚಟುವಟಿಕೆಯ ಪ್ರಕಾರ";
  String get TextAppDuration => "ಅವಧಿ";
  String get TextAppMyActivityOfCustomDates => "ಕಸ್ಟಮ್ ದಿನಾಂಕಗಳ ನನ್ನ ಚಟುವಟಿಕೆ";
  String get TextAppOurCustomerFeedback => "ನಮ್ಮ ಗ್ರಾಹಕರ ಪ್ರತಿಕ್ರಿಯೆ";
  String get TextAppOverallRatings => "ಒಟ್ಟಾರೆ ರೇಟಿಂಗ್‌ಗಳು";
  String get TextAppEnterCookedWeight => "ಬೇಯಿಸಿದ ತೂಕವನ್ನು ನಮೂದಿಸಿ";
  String get TextAppCookedWeightGram => "ಬೇಯಿಸಿದ ತೂಕ (ಗ್ರಾಂ)";
  String get TextAppNutrientIn100gCooked =>
      "100 ಗ್ರಾಂನಲ್ಲಿ ಪೋಷಕಾಂಶಗಳು (ಬೇಯಿಸಿದ)";
  String get TextAppEnterServingSize => "ಸೇವೆಯ ಗಾತ್ರವನ್ನು ನಮೂದಿಸಿ";
  String get TextAppSearchByRecipeName => "ಪಾಕವಿಧಾನದ ಹೆಸರಿನ ಮೂಲಕ ಹುಡುಕಿ";
  String get TextAppMyPersonalRecipe => "ನನ್ನ ವೈಯಕ್ತಿಕ ಪಾಕವಿಧಾನ";
  String get TextAppFixedRecipe => "ಸ್ಥಿರ ಪಾಕವಿಧಾನ";
  String get TextApp2NutrientsInMyFood => "ನನ್ನ ಆಹಾರದಲ್ಲಿ ಪೋಷಕಾಂಶಗಳು";
  String get TextAppMyDietDiary => "ನನ್ನ ಆಹಾರದ ದಿನಚರಿ";
  String get TextApp2MyActivity => "ನನ್ನ ಚಟುವಟಿಕೆ";
  String get TextAppDownloadFile => "ಫೈಲ್ ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ";
  String get TextAppStartMyNewDietDiary =>
      "ನನ್ನ ಹೊಸ ಆಹಾರದ ದಿನಚರಿಯನ್ನು ಪ್ರಾರಂಭಿಸಿ";
  String get TextAppGoogle => "ಗೂಗಲ್";
  String get TextAppFacebook => "ಫೇಸ್ಬುಕ್";
  String get TextAppLinkedin => "ಲಿಂಕ್ಡ್ಇನ್";
  String get TextAppTwitter => "ಟ್ವಿಟರ್";
  String get TextAppContactUs => "ನಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸಿ";
  String get TextAppReportBug => "ದೋಷವನ್ನು ವರದಿ ಮಾಡಿ";
  String get TextAppAttachImage => "ಚಿತ್ರವನ್ನು ಲಗತ್ತಿಸಿ";
  String get TextAppResetPassword => "ಪಾಸ್ವರ್ಡ್ ಮರುಹೊಂದಿಸಿ";
  String get TextAppNINAppCreditsPage => "NIN ಅಪ್ಲಿಕೇಶನ್ ಕ್ರೆಡಿಟ್‌ಗಳ ಪುಟ";
  String get NINTextOopsSomethingWentWrong => "ಅಯ್ಯೋ! ಏನೋ ತಪ್ಪಾಗಿದೆ";
  String get NINTextPleaseEnterAllFields =>
      "ದಯವಿಟ್ಟು ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳನ್ನು ನಮೂದಿಸಿ";
  String get NINTextSubmittedSuccessfully1 => "ಯಶಸ್ವಿಯಾಗಿ ಸಲ್ಲಿಸಲಾಗಿದೆ";
  String get NINTextSubmittedSuccessfully2 => "ಯಶಸ್ವಿಯಾಗಿ ಸಲ್ಲಿಸಲಾಗಿದೆ";
  String get NINTextFitbitAuthentication => "Fitbit ದೃಢೀಕರಣ";
  String get NINTextHours => "ಗಂಟೆಗಳು";
  String get NINTextMinutes => "ನಿಮಿಷಗಳು";
  String get NINTextEnterDurationFor => "ಅವಧಿಯನ್ನು ನಮೂದಿಸಿ";
  String get NINTextTimerRunning => "ಟೈಮರ್ ಚಾಲನೆಯಲ್ಲಿದೆ";
  String get NINTextPleaseStopTheTimerBeforeSubmitting =>
      "ಸಲ್ಲಿಸುವ ಮೊದಲು ಟೈಮರ್ ಅನ್ನು ನಿಲ್ಲಿಸಿ";
  String get NINTextTotalDuration => "ಒಟ್ಟು ಅವಧಿ";
  String get NINTextSec => "ಸೆಕೆಂಡ್";
  String get NINTextStartYourActivity => "ನಿಮ್ಮ ಚಟುವಟಿಕೆಯನ್ನು ಪ್ರಾರಂಭಿಸಿ!";
  String get NINTextPause => "ವಿರಾಮ";
  String get NINTextReset => "ಮರುಹೊಂದಿಸಿ";
  String get NINTextError => "ದೋಷ";
  String get NINTextPleaseEnterCookedWeightAndServingSize =>
      "ದಯವಿಟ್ಟು ಬೇಯಿಸಿದ ತೂಕ ಮತ್ತು ಸೇವೆಯ ಗಾತ್ರವನ್ನು ನಮೂದಿಸಿ";
  String get NINTextEditIngredient => "ಪದಾರ್ಥವನ್ನು ಸಂಪಾದಿಸಿ";
  String get NINTextAlert => "ಎಚ್ಚರಿಕೆ";
  String get NINTextEnterWeightFor => "ತೂಕವನ್ನು ನಮೂದಿಸಿ";
  String get NINTextNewWeightGram => "ಹೊಸ ತೂಕ (ಗ್ರಾಂ)";
  String get NINTextEditRecipeName => "ಪಾಕವಿಧಾನದ ಹೆಸರನ್ನು ಸಂಪಾದಿಸಿ";
  String get NINTextNewRecipeName => "ಹೊಸ ರೆಸಿಪಿ ಹೆಸರು";
  String get NINTextSubmitted => "ಸಲ್ಲಿಸಲಾಗಿದೆ";
  String get NINTextSuccess => "ಯಶಸ್ಸು";
  String get NINTextDietaryDiaryReportSavedTo =>
      "ಆಹಾರದ ಡೈರಿ ವರದಿಯನ್ನು ಉಳಿಸಲಾಗಿದೆ";
  String get NINTextErrorSavingFile => "ಫೈಲ್ ಉಳಿಸುವಲ್ಲಿ ದೋಷ";
  String get NINTextClose => "ಮುಚ್ಚಿ";
  String get NINTextIWantTo => "ನಾನು ಬಯಸುತ್ತೇನೆ";
  String get NINTextGain => "ಲಾಭ";
  String get NINTextMaintain => "ನಿರ್ವಹಿಸಿ";
  String get NINTextLose => "ಕಳೆದುಕೊಳ್ಳು";
  String get NINTextWeightChangeKg => "ತೂಕ ಬದಲಾವಣೆ (ಕೆಜಿ)";
  String get NINTextAddNewWeight => "ಹೊಸ ತೂಕವನ್ನು ಸೇರಿಸಿ";
  String get NINTextEnterWeight => "ತೂಕವನ್ನು ನಮೂದಿಸಿ";
  String get NINTextOf100Gram => "100 ಗ್ರಾಂ";
  String get NINTextProximateComposition => "ಸಮೀಪದ ಸಂಯೋಜನೆ";
  String get NINTextVitamins => "ವಿಟಮಿನ್ಸ್";
  String get NINTextMinerals => "ಖನಿಜಗಳು";
  String get NINTextTotalSaturatedFattyAcids =>
      "ಒಟ್ಟು ಸ್ಯಾಚುರೇಟೆಡ್ ಕೊಬ್ಬಿನಾಮ್ಲಗಳು";
  String get NINTextAllRecipeOf100Grams => "100 ಗ್ರಾಂಗಳ ಎಲ್ಲಾ ಪಾಕವಿಧಾನಗಳು";
  String get NINTextOurCustomerFeedback => "ನಮ್ಮ ಗ್ರಾಹಕರ ಪ್ರತಿಕ್ರಿಯೆ";
  String get NINTextOverallRatings => "ಒಟ್ಟಾರೆ ರೇಟಿಂಗ್‌ಗಳು";
  String get NINTextRateUs => "ನಮಗೆ ರೇಟ್ ಮಾಡಿ";
  String get NINTextBookDetails => "ಪುಸ್ತಕದ ವಿವರಗಳು";
  String get NINTextOne => "ಒಂದು";
  String get NINTextWeightOf => "wt ನ";
  String get NINTextSelectStartDate => "ಪ್ರಾರಂಭ ದಿನಾಂಕವನ್ನು ಆಯ್ಕೆಮಾಡಿ";
  String get NINTextSelectEndDate => "ಅಂತಿಮ ದಿನಾಂಕವನ್ನು ಆಯ್ಕೆಮಾಡಿ";
  String get NINTextNoData => "ಮಾಹಿತಿ ಇಲ್ಲ";
  String get NINTextWorkLevel => "ಕೆಲಸದ ಮಟ್ಟ";
  String get NINTextOldPassword => "ಹಳೆಯ ಪಾಸ್ವರ್ಡ್";
  String get NINTextNewPassword => "ಹೊಸ ಪಾಸ್ವರ್ಡ್";
  String get NINTextUpdateProfile => "ಪ್ರೊಫೈಲ್ ಅನ್ನು ನವೀಕರಿಸಿ";
  String get NINTextChangeImage => "ಚಿತ್ರವನ್ನು ಬದಲಾಯಿಸಿ";
  String get NINTextNoFavouriteFoodFound => "ಯಾವುದೇ ನೆಚ್ಚಿನ ಆಹಾರ ಕಂಡುಬಂದಿಲ್ಲ";
  String get NINTextCookedQuantity => "ಬೇಯಿಸಿದ ಪ್ರಮಾಣ";
  String get NINTextServingQuantity => "ಸೇವೆಯ ಪ್ರಮಾಣ";
  String get NINTextNutrientInformation => "ಪೋಷಕಾಂಶಗಳ ಮಾಹಿತಿ";
  String get NINTextIngredient => "ಪದಾರ್ಥ";
  String get NINTextMealsTakenOn => "ತೆಗೆದುಕೊಂಡ ಊಟ";
  String get NINTextPercentage => "ಶೇ";
  String get NINTextEAR => "ಕಿವಿ";
  String get NINTextValue => "ಮೌಲ್ಯ";
  String get NINTextNutrient => "ಪೋಷಕಾಂಶ";
  String get NINTextEnergyKcal => "ಶಕ್ತಿ (kcal)";
  String get NINTextProteinG => "ಪ್ರೋಟೀನ್ (ಗ್ರಾಂ)";
  String get NINTextFatG => "ಕೊಬ್ಬು (ಗ್ರಾಂ)";
  String get NINTextCarbohydratesG => "ಕಾರ್ಬೋಹೈಡ್ರೇಟ್‌ಗಳು (ಗ್ರಾಂ)";
  String get NINTextCalciumMg => "ಕ್ಯಾಲ್ಸಿಯಂ (ಮಿಗ್ರಾಂ)";
  String get NINTextFiberG => "ಫೈಬರ್ (ಗ್ರಾಂ)";
  String get NINTextIronMg => "ಕಬ್ಬಿಣ (ಮಿಗ್ರಾಂ)";
  String get NINTextZincMg => "ಸತು (ಮಿಗ್ರಾಂ)";
  String get NINTextMagnesiumMg => "ಮೆಗ್ನೀಸಿಯಮ್ (ಮಿಗ್ರಾಂ)";
  String get NINTextThiamineB1Mg => "ಥಯಾಮಿನ್ (ಬಿ 1) (ಮಿಗ್ರಾಂ)";
  String get NINTextRiboflavinB2Mg => "ರಿಬೋಫ್ಲಾವಿನ್ (B2) (ಮಿಗ್ರಾಂ)";
  String get NINTextNiacinB3Mg => "ನಿಯಾಸಿನ್ (B3) (ಮಿಗ್ರಾಂ)";
  String get NINTextFolatesB9Mcg => "ಫೋಲೇಟ್ಸ್ (B9) (mcg)";
  String get NINTextRetinolVitAMcg => "ವಿಟಮಿನ್ ಎ (ಎಂಸಿಜಿ)";
  String get VitaminCmg => "ವಿಟಮಿನ್ ಸಿ (ಮಿಗ್ರಾಂ)";
  String get Iodinemcg => "ಅಯೋಡಿನ್ (mcg)";
  String get serving => "ಸೇವೆ";
  String get Mynutritionstatus => "ನನ್ನ ಪೋಷಣೆಯ ಸ್ಥಿತಿ";

  String get ninTextMyHealthStatus => 'ನನ್ನ ಆರೋಗ್ಯ ಸ್ಥಿತಿ';
  String get ninTextNutrientsInRawFoods => 'ಕಚ್ಚಾ ಆಹಾರದಲ್ಲಿ ಪೋಷಕಾಂಶಗಳು';
  String get ninTextNutrientsInRecipes => 'ಪಾಕವಿಧಾನಗಳಲ್ಲಿ ಪೋಷಕಾಂಶಗಳು';
  String get ninTextIcmrNinMyPlateForTheDay => 'ICMR-NIN ದಿನದ ನನ್ನ ಪ್ಲೇಟ್';
  String get ninTextToday => 'ಇಂದು';
  String get ninTextTrackMyActivity => 'ನನ್ನ ಚಟುವಟಿಕೆಯನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ';
  String get ninTextMyHeartRate => 'ನನ್ನ ಹೃದಯ ಬಡಿತ';
  String get ninTextMyWaterIntake => 'ನನ್ನ ನೀರಿನ ಸೇವನೆ';
  String get ninTextSleepTracker => 'ಸ್ಲೀಪ್ ಟ್ರ್ಯಾಕರ್';
  String get ninTextLit => 'ಬೆಳಗಿದ';
  String get ninTextRecordMyBloodPressure =>
      'ನನ್ನ ರಕ್ತದೊತ್ತಡ / ರಕ್ತದ ಗ್ಲೂಕೋಸ್ / SPO2 ಅನ್ನು ರೆಕಾರ್ಡ್ ಮಾಡಿ';
  String get ninTextNutritionEducationContent => 'ಪೌಷ್ಟಿಕಾಂಶ ಶಿಕ್ಷಣದ ವಿಷಯ';
  String get ninTextMyNutrientIntake => 'ನನ್ನ ಪೋಷಕಾಂಶಗಳ ಸೇವನೆ';
  String get ninTextOn => 'ಮೇಲೆ';
  String get ninTextWithReferenceToEAR => 'EAR ಗೆ ಸಂಬಂಧಿಸಿದಂತೆ';
  String get ninTextAchieveYourHealthGoals => 'ನಿಮ್ಮ ಆರೋಗ್ಯ ಗುರಿಗಳನ್ನು ಸಾಧಿಸಿ';
  String get ninTextPercentage => 'ಶೇ';
  String get ninTextMyPreviousDietDiaries => 'ನನ್ನ ಹಿಂದಿನ ಆಹಾರದ ಡೈರಿಗಳು';
  String get ninTextRecordReviewSleep =>
      'ನಿದ್ರೆಯನ್ನು ರೆಕಾರ್ಡ್ ಮಾಡಿ / ಪರಿಶೀಲಿಸಿ';
  String get ninTextHours => 'ಗಂಟೆ';
  String get ninTextIngredient => 'ಪದಾರ್ಥ';
  String get ninTextOthersSpecify => 'ಇತರರು ಸೂಚಿಸುತ್ತಾರೆ';
  String get ninTextAddNewIngredient => 'ಹೊಸ ಪದಾರ್ಥವನ್ನು ಸೇರಿಸಿ';
  String get ninTextFoodName => 'ಆಹಾರದ ಹೆಸರು';
  String get ninTextSource => 'ಮೂಲ';
  String get ninTextEnterBrandAndProductName =>
      'ಬ್ರ್ಯಾಂಡ್ ಮತ್ತು ಉತ್ಪನ್ನದ ಹೆಸರನ್ನು ನಮೂದಿಸಿ';
  String get ninTextEnterAuthorDetails =>
      'ಲೇಖಕರ ಹೆಸರು, ವರ್ಷ, ಜರ್ನಲ್, ಪುಟವನ್ನು ನಮೂದಿಸಿ';
  String get ninTextEnterFctName => 'FCT ಹೆಸರನ್ನು ನಮೂದಿಸಿ';
  String get ninTextName => 'ಹೆಸರು';
  String get ninTextProductName => 'ಉತ್ಪನ್ನದ ಹೆಸರು';
  String get ninTextSelectStartDate => 'ಪ್ರಾರಂಭ ದಿನಾಂಕವನ್ನು ಆಯ್ಕೆಮಾಡಿ';
  String get ninTextSelectEndDate => 'ಅಂತಿಮ ದಿನಾಂಕವನ್ನು ಆಯ್ಕೆಮಾಡಿ';
  String get ninTextNoExercise => 'ವ್ಯಾಯಾಮ ಇಲ್ಲ';
  String get ninTextDevelopedWithExpertiseAndInputs =>
      'ಸೆಂಟರ್ ಫಾರ್ ಡೆವಲಪ್‌ಮೆಂಟ್ ಮತ್ತು ಅಡ್ವಾನ್ಸ್ಡ್ ಕಂಪ್ಯೂಟಿಂಗ್ (C-DAC), ಹೈದರಾಬಾದ್ ಭಾಷಾ ಲಿಂಕ್‌ನಿಂದ NIN ನಿಂದ ಪರಿಣತಿ ಮತ್ತು ಒಳಹರಿವಿನೊಂದಿಗೆ ಅಭಿವೃದ್ಧಿಪಡಿಸಲಾಗಿದೆ';
  String get ninTextMyNutrientIntakeToday => 'ಇಂದು ನನ್ನ ಪೋಷಕಾಂಶಗಳ ಸೇವನೆ';
  String get ninTextIcmrNationalInstituteOfNutritionAddress =>
      'ICMR - ತಾರ್ನಾಕಾ ಮೆಟ್ರೋ ನಿಲ್ದಾಣದ ಪಕ್ಕದಲ್ಲಿ ರಾಷ್ಟ್ರೀಯ ಪೌಷ್ಟಿಕಾಂಶ ಸಂಸ್ಥೆ, ಜಮೈ-ಉಸ್ಮಾನಿಯಾ PO, ಹೈದರಾಬಾದ್-500 007, ಭಾರತ.';

  String get ninTextKcal => 'kcal';
  String get ninTextKcalPerDay => 'kcal / ದಿನ';
  String get ninTextDelete => 'ಅಳಿಸಿ';
  String get ninTextDeleteNotification => 'ಅಧಿಸೂಚನೆಯನ್ನು ಅಳಿಸಿ';
  String get ninTextConfirmDeleteNotification =>
      'ಈ ಅಧಿಸೂಚನೆಯನ್ನು ಅಳಿಸಲು ನೀವು ಖಚಿತವಾಗಿ ಬಯಸುವಿರಾ?';
  String get ninTextTimeFor => 'ಹೇ, ಇದು\'s time for';
  String get ninTextFitbitWatch => 'ಫಿಟ್‌ಬಿಟ್ ವಾಚ್';
  String get ninTextGoogleFitApp => 'Google ಫಿಟ್ ಅಪ್ಲಿಕೇಶನ್';
  String get ninTextUnderweight => 'ಕಡಿಮೆ ತೂಕ';
  String get ninTextNormal => 'ಸಾಮಾನ್ಯ';
  String get ninTextOverweight => 'ಅಧಿಕ ತೂಕ';
  String get ninTextObesity => 'ಬೊಜ್ಜು';
  String get ninTextMale => 'ಪುರುಷ';
  String get ninTextFemale => 'ಹೆಣ್ಣು';
  String get ninTextAgeInYears => 'ವರ್ಷಗಳಲ್ಲಿ ವಯಸ್ಸು';
  String get ninTextChangeInWeight => 'ತೂಕದಲ್ಲಿ ಬದಲಾವಣೆ';
  String get ninTextSteps => 'ಹಂತಗಳು';
  String get ninTextFor => 'ಫಾರ್';
  String get ninTextMinutes => 'ನಿಮಿಷಗಳು';
  String get ninTextPause => 'ವಿರಾಮ';
  String get ninTextReset => 'ಮರುಹೊಂದಿಸಿ';
  String get ninTextStartActivity => 'ನಿಮ್ಮ ಚಟುವಟಿಕೆಯನ್ನು ಪ್ರಾರಂಭಿಸಿ';
  String get ninTextCartIsEmpty => 'ನಿಮ್ಮ ಕಾರ್ಟ್ ಖಾಲಿಯಾಗಿದೆ';
  String get ninTextMyPersonalRecipe => 'ನನ್ನ ವೈಯಕ್ತಿಕ ಪಾಕವಿಧಾನ';
  String get ninTextSearchByRecipeName => 'ಪಾಕವಿಧಾನ ಹೆಸರಿನ ಮೂಲಕ ಹುಡುಕಿ';
  String get ninTextHelpCenter => 'ಸಹಾಯ ಕೇಂದ್ರ';
  String get ninTextCommonProblems => 'ಸಾಮಾನ್ಯ ಸಮಸ್ಯೆಗಳು';
  String get ninTextFAQs => 'FAQ ಗಳು';
  String get ninTextHowActiveAreYou => 'ನೀವು ಎಷ್ಟು ಸಕ್ರಿಯರಾಗಿದ್ದೀರಿ';
  String get ninTextVitaminC => 'ವಿಟಮಿನ್ ಸಿ (ಮಿಗ್ರಾಂ)';
  String get ninTextVitaminA => 'ವಿಟಮಿನ್ ಎ (ಐಯು)';
  String get ninTextSodium => 'ಸೋಡಿಯಂ (ಮಿಗ್ರಾಂ)';
  String get ninTextJournal => 'ಜರ್ನಲ್';
  String get ninTextPage => 'ಪುಟ';
  String get ninTextAdequateIntakeCarbs =>
      '*ಕಾರ್ಬೋಹೈಡ್ರೇಟ್‌ಗಳಿಗೆ ಸಾಕಷ್ಟು ಸೇವನೆ (AI) ಶಿಫಾರಸು ಮಾಡಲಾಗಿದೆ: ವಯಸ್ಕ ಪುರುಷರು ಮತ್ತು ಮಹಿಳೆಯರಿಗೆ 130 ಗ್ರಾಂ.';
  String get ninTextAdequateIntakeFiber =>
      '** AI ಫೈಬರ್‌ಗೆ ಶಿಫಾರಸು ಮಾಡಲಾಗಿದೆ: ಮಹಿಳೆಯರಿಗೆ 25 ಗ್ರಾಂ ಮತ್ತು ಪುರುಷರಿಗೆ 38 ಗ್ರಾಂ.';
  String get your => 'ನಿಮ್ಮ';
  String get question1 => 'ನನ್ನ ವೈಯಕ್ತಿಕ ವಿವರಗಳನ್ನು ನಾನು ಸಂಪಾದಿಸಬಹುದೇ?';
  String get answer1 =>
      'ಹೌದು. ನಿಮ್ಮ ವೈಯಕ್ತಿಕ ಡೇಟಾವನ್ನು ನಿಮ್ಮ ಪ್ರೊಫೈಲ್‌ನಲ್ಲಿ ಸಂಪಾದಿಸಬಹುದು.';
  String get linkText1 =>
      'ನಿಮ್ಮ ವೈಯಕ್ತಿಕ ವಿವರಗಳನ್ನು ಸಂಪಾದಿಸಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question2 => 'ನನ್ನ ಸಂಪರ್ಕ ವಿವರಗಳನ್ನು ನಾನು ಬದಲಾಯಿಸಬಹುದೇ?';
  String get answer2 =>
      "ಹೌದು. ನಿಮ್ಮ ಪ್ರೊಫೈಲ್‌ನಲ್ಲಿರುವ 'ವೈಯಕ್ತಿಕ ಡೇಟಾ' ಆಯ್ಕೆಗೆ ಹೋಗುವ ಮೂಲಕ ನಿಮ್ಮ ಸಂಪರ್ಕ ವಿವರಗಳನ್ನು ಬದಲಾಯಿಸಬಹುದು.";
  String get linkText2 => 'ನಿಮ್ಮ ಸಂಪರ್ಕ ವಿವರಗಳನ್ನು ಸಂಪಾದಿಸಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question3 => 'ನನ್ನ ಬಳಕೆದಾರ ಪಾಸ್‌ವರ್ಡ್ ಅನ್ನು ನಾನು ಬದಲಾಯಿಸಬಹುದೇ?';
  String get answer3 =>
      "ಹೌದು. ನಿಮ್ಮ ಪ್ರೊಫೈಲ್‌ನಲ್ಲಿರುವ 'ಸೆಟ್ಟಿಂಗ್' ಆಯ್ಕೆಗೆ ಹೋಗುವ ಮೂಲಕ ನಿಮ್ಮ ಪಾಸ್‌ವರ್ಡ್ ಅನ್ನು ಬದಲಾಯಿಸಬಹುದು.";
  String get linkText3 => 'ನಿಮ್ಮ ಪಾಸ್‌ವರ್ಡ್ ಬದಲಾಯಿಸಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question4 => 'ನನ್ನ BMI ಅನ್ನು ನಾನು ಹೇಗೆ ಪರಿಶೀಲಿಸಬಹುದು?';
  String get answer4 =>
      "ಮುಖಪುಟದಲ್ಲಿ ಪ್ರದರ್ಶಿಸಲಾದ 'ಆರೋಗ್ಯ ಕ್ಯಾಲ್ಕುಲೇಟರ್' ಆಯ್ಕೆಯಲ್ಲಿ ಒದಗಿಸಲಾದ 'BMI ಕ್ಯಾಲ್ಕುಲೇಟರ್' ನಲ್ಲಿ ನಿಮ್ಮ ಎತ್ತರ ಮತ್ತು ದೇಹದ ತೂಕವನ್ನು ನಮೂದಿಸುವ ಮೂಲಕ ನಿಮ್ಮ BMI ಅನ್ನು ನೀವು ಪರಿಶೀಲಿಸಬಹುದು.";
  String get linkText4 => 'BMI ಕ್ಯಾಲ್ಕುಲೇಟರ್ ಅನ್ನು ಬಳಸಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question5 => 'ಕಳೆದ ತಿಂಗಳು ನನ್ನ ತೂಕವನ್ನು ನಾನು ಟ್ರ್ಯಾಕ್ ಮಾಡಬಹುದೇ?';
  String get answer5 =>
      "ಹೌದು. ಮುಖಪುಟದಲ್ಲಿ ಒದಗಿಸಲಾದ 'ತೂಕ ನಿರ್ವಾಹಕ' ಆಯ್ಕೆಯಲ್ಲಿ ಕಳೆದ ತಿಂಗಳು/ವರ್ಷದಲ್ಲಿ ನಿಮ್ಮ ದೇಹದ ತೂಕದಲ್ಲಿನ ಬದಲಾವಣೆಗಳ ವಿವರಗಳನ್ನು ನೀವು ವೀಕ್ಷಿಸಬಹುದು.";
  String get linkText5 => 'ನಿಮ್ಮ ತೂಕವನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question6 =>
      'ನಿರ್ದಿಷ್ಟ ದಿನದಂದು ನನ್ನ ಒಟ್ಟಾರೆ ದೈಹಿಕ ಚಟುವಟಿಕೆಯನ್ನು ನಾನು ಹೇಗೆ ಪರಿಶೀಲಿಸಬಹುದು?';
  String get answer6 =>
      "ಮುಖಪುಟದಲ್ಲಿರುವ 'ನನ್ನ ಚಟುವಟಿಕೆ' ಆಯ್ಕೆಯಿಂದ ನಿಮ್ಮ ದೈಹಿಕ ಚಟುವಟಿಕೆಯನ್ನು ನೀವು ಟ್ರ್ಯಾಕ್ ಮಾಡಬಹುದು.";
  String get linkText6 => 'ನಿಮ್ಮ ಚಟುವಟಿಕೆಯನ್ನು ವೀಕ್ಷಿಸಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question7 => 'ನೀರಿನ ಸೇವನೆಗಾಗಿ ನಾನು ಜ್ಞಾಪನೆಯನ್ನು ಹೇಗೆ ಹೊಂದಿಸಬಹುದು?';
  String get answer7 =>
      "ಮುಖಪುಟದಲ್ಲಿ ಒದಗಿಸಲಾದ 'ಸೆಟ್ ಅಧಿಸೂಚನೆ' ಆಯ್ಕೆಯಲ್ಲಿ ನೀರಿನ ಸೇವನೆಯ ಜ್ಞಾಪನೆಗಾಗಿ ನೀವು ಸಮಯವನ್ನು ಹೊಂದಿಸಬಹುದು.";
  String get linkText7 =>
      'ನೀರಿನ ಸೇವನೆಯ ಜ್ಞಾಪನೆಯನ್ನು ಹೊಂದಿಸಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question8 =>
      'ನನ್ನ ಸ್ಮಾರ್ಟ್ ವಾಚ್‌ನೊಂದಿಗೆ ನಾನು ಅಪ್ಲಿಕೇಶನ್ ಅನ್ನು ಹೇಗೆ ಸಂಯೋಜಿಸಬಹುದು?';
  String get answer8 =>
      "ಮುಖಪುಟದಲ್ಲಿ ಒದಗಿಸಲಾದ 'ಕನೆಕ್ಟ್ ವಾಚ್' ಆಯ್ಕೆಗೆ ಹೋಗುವ ಮೂಲಕ ನಿಮ್ಮ ಸ್ಮಾರ್ಟ್ ವಾಚ್ ಅನ್ನು ನೀವು ಅಪ್ಲಿಕೇಶನ್‌ನೊಂದಿಗೆ ಸಂಯೋಜಿಸಬಹುದು.";
  String get linkText8 =>
      'ನಿಮ್ಮ ಸ್ಮಾರ್ಟ್ ವಾಚ್ ಅನ್ನು ಸಂಪರ್ಕಿಸಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question9 =>
      'ಒಂದು ಸಮಯದಲ್ಲಿ ನಾನು ಎಷ್ಟು ಧರಿಸಬಹುದಾದ ವಸ್ತುಗಳನ್ನು ಅಪ್ಲಿಕೇಶನ್‌ನೊಂದಿಗೆ ಸಂಯೋಜಿಸಬಹುದು?';
  String get answer9 =>
      'ನೀವು ಅಪ್ಲಿಕೇಶನ್‌ನೊಂದಿಗೆ Fitbit ವಾಚ್ ಮತ್ತು Google Fit ಅನ್ನು ಸಂಯೋಜಿಸಬಹುದು.';
  String get linkText9 => '';

  String get question10 =>
      'ಯಾವ ಸ್ಮಾರ್ಟ್ ವಾಚ್‌ಗಳು ಅಪ್ಲಿಕೇಶನ್‌ಗೆ ಹೊಂದಿಕೆಯಾಗುತ್ತವೆ?';
  String get answer10 => 'ಫಿಟ್‌ಬಿಟ್ ವಾಚ್ ಮತ್ತು ಗೂಗಲ್ ಫಿಟ್.';
  String get linkText10 => '';

  String get question11 =>
      'ನನ್ನ ಬಳಿ ಸ್ಮಾರ್ಟ್ ವಾಚ್ ಇಲ್ಲದಿದ್ದರೆ ನನ್ನ ಚಟುವಟಿಕೆಯನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಬಹುದೇ?';
  String get answer11 =>
      'ಹೌದು, ನಿಮ್ಮ ಚಟುವಟಿಕೆಯನ್ನು ನೀವು ಟ್ರ್ಯಾಕ್ ಮಾಡಬಹುದು. ಅದಕ್ಕಾಗಿ, ನೀವು Google ಫಿಟ್ ಅಪ್ಲಿಕೇಶನ್ ಅನ್ನು ಡೌನ್‌ಲೋಡ್ ಮಾಡಬೇಕಾಗುತ್ತದೆ, Google ಖಾತೆಯೊಂದಿಗೆ ಸೈನ್ ಇನ್ ಮಾಡಬೇಕು ಮತ್ತು ಅದೇ Google ಖಾತೆಯೊಂದಿಗೆ, ನೀವು ನಮ್ಮ ವೀಕ್ಷಣೆ ವಿಭಾಗಕ್ಕೆ ಲಾಗ್ ಇನ್ ಮಾಡಬೇಕಾಗುತ್ತದೆ.';
  String get linkText11 => '';

  String get question12 => 'ನನ್ನ ನಿದ್ರೆಯನ್ನು ನಾನು ಹೇಗೆ ಟ್ರ್ಯಾಕ್ ಮಾಡಬಹುದು?';
  String get answer12 =>
      'ಮುಖಪುಟದಲ್ಲಿ ಒದಗಿಸಲಾದ ಸ್ಲೀಪ್ ಟ್ರ್ಯಾಕರ್ ಆಯ್ಕೆಗೆ ಹೋಗುವ ಮೂಲಕ ನೀವು ವಾರಕ್ಕೊಮ್ಮೆ/ಮಾಸಿಕ ಆಧಾರದ ಮೇಲೆ ನಿಮ್ಮ ನಿದ್ರೆಯನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಬಹುದು.';
  String get linkText12 => 'ನಿಮ್ಮ ನಿದ್ರೆಯನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question13 =>
      'ಅಪ್ಲಿಕೇಶನ್ ಮೂಲಕ ನಾನು ಯಾವುದೇ NIN ಪ್ರಕಟಣೆಯನ್ನು ಹೇಗೆ ಖರೀದಿಸಬಹುದು?';
  String get answer13 =>
      "ಮುಖಪುಟದಲ್ಲಿ ಒದಗಿಸಲಾದ 'ಪುಸ್ತಕ ಅಂಗಡಿ' ಆಯ್ಕೆಯಿಂದ ನೀವು NIN ಪ್ರಕಟಣೆಗಳನ್ನು ಖರೀದಿಸಬಹುದು.";
  String get linkText13 => 'ಪುಸ್ತಕ ಮಳಿಗೆಗೆ ಭೇಟಿ ನೀಡಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question14 => 'ನನ್ನ ವೈಯಕ್ತಿಕ ಆಹಾರದ ಡೈರಿಯನ್ನು ನಾನು ಹೇಗೆ ರಚಿಸಬಹುದು?';
  String get answer14 =>
      '‘ಮೈ ಡಯಟ್ ಡೈರಿ ಆಯ್ಕೆ’ಗೆ ಹೋಗುವ ಮೂಲಕ ನೀವು ಇಡೀ ದಿನ ಸೇವಿಸಿದ ಆಹಾರದ ವಿವರಗಳನ್ನು ನಮೂದಿಸಬಹುದು.';
  String get linkText14 => 'ನಿಮ್ಮ ಆಹಾರದ ಡೈರಿಯನ್ನು ರಚಿಸಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question15 =>
      'ನಿರ್ದಿಷ್ಟ ಪೌಷ್ಟಿಕಾಂಶದಲ್ಲಿ ಸಮೃದ್ಧವಾಗಿರುವ ಪಾಕವಿಧಾನವನ್ನು ನಾನು ಹೇಗೆ ಹುಡುಕಬಹುದು?';
  String get answer15 =>
      "ನೀವು ಮೊದಲು ಹೋಮ್ ಪೇಜ್‌ನಲ್ಲಿ 'ನನ್ನ ಆಹಾರದಲ್ಲಿ ಪೌಷ್ಟಿಕಾಂಶಗಳು' ಟ್ಯಾಬ್‌ನಲ್ಲಿ ನೀಡಲಾದ 'ಪಾಕವಿಧಾನಗಳಲ್ಲಿ ಪೋಷಕಾಂಶಗಳನ್ನು ಹುಡುಕಿ' ಆಯ್ಕೆಯನ್ನು ಆಯ್ಕೆ ಮಾಡಬಹುದು. ನಂತರ ಮೇಲಿನ ಬಲ ಮೂಲೆಯಲ್ಲಿರುವ ಡ್ರಾಪ್-ಡೌನ್ ಪಟ್ಟಿಯಿಂದ ಅಗತ್ಯವಿರುವ ಪೋಷಕಾಂಶವನ್ನು ಆಯ್ಕೆಮಾಡಿ.";
  String get linkText15 => 'ಪಾಕವಿಧಾನಗಳನ್ನು ಹುಡುಕಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question16 =>
      'ಹಿಂದಿನ ತಿಂಗಳು ಉಳಿಸಿದ ದಿನಕ್ಕೆ ನನ್ನ ಪೋಷಕಾಂಶಗಳ ಸೇವನೆಯನ್ನು ನಾನು ಹೇಗೆ ಪರಿಶೀಲಿಸಬಹುದು?';
  String get answer16 =>
      "'ಊಟ ಪಟ್ಟಿ' ಪುಟದಲ್ಲಿರುವ 'ಕ್ಯಾಲೆಂಡರ್ ಐಕಾನ್' ನಿಂದ ದಿನಾಂಕವನ್ನು ಆಯ್ಕೆ ಮಾಡುವ ಮೂಲಕ ನಿರ್ದಿಷ್ಟ ದಿನದಂದು ನಿಮ್ಮ ಪೋಷಕಾಂಶಗಳ ಸೇವನೆಯನ್ನು ನೀವು ವೀಕ್ಷಿಸಬಹುದು.";
  String get linkText16 =>
      'ನಿಮ್ಮ ಪೋಷಕಾಂಶಗಳ ಸೇವನೆಯನ್ನು ಪರಿಶೀಲಿಸಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question17 =>
      'ನನ್ನ ಪಾಕವಿಧಾನಗಳಲ್ಲಿ ಬಳಸುವ ಕಚ್ಚಾ ಪದಾರ್ಥಗಳಲ್ಲಿನ ಪೋಷಕಾಂಶಗಳನ್ನು ನಾನು ಹೇಗೆ ಕಂಡುಹಿಡಿಯಬಹುದು?';
  String get answer17 =>
      "ಹೋಮ್ ಪೇಜ್‌ನಲ್ಲಿರುವ 'ನ್ಯೂಟ್ರಿಯೆಂಟ್ಸ್ ಇನ್ ಮೈ ಫುಡ್' ಟ್ಯಾಬ್‌ನಲ್ಲಿ ನೀಡಲಾದ 'ಕಚ್ಚಾ ಆಹಾರಗಳಲ್ಲಿ ಪೋಷಕಾಂಶಗಳನ್ನು ಹುಡುಕಿ' ಆಯ್ಕೆಯನ್ನು ಆರಿಸುವ ಮೂಲಕ ನಿರ್ದಿಷ್ಟ ಘಟಕಾಂಶದಲ್ಲಿರುವ ಪೋಷಕಾಂಶಗಳನ್ನು ನೀವು ತಿಳಿದುಕೊಳ್ಳಬಹುದು.";
  String get linkText17 =>
      'ಕಚ್ಚಾ ಆಹಾರದಲ್ಲಿನ ಪೋಷಕಾಂಶಗಳನ್ನು ಹುಡುಕಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question18 =>
      'ಪಾಕವಿಧಾನದ ಪೌಷ್ಟಿಕಾಂಶದ ಸಂಯೋಜನೆಯನ್ನು ನಾನು ಹೇಗೆ ತಿಳಿಯಬಹುದು?';
  String get answer18 =>
      "ಹೋಮ್ ಪೇಜ್‌ನಲ್ಲಿರುವ 'ನ್ಯೂಟ್ರಿಯೆಂಟ್ಸ್ ಇನ್ ಮೈ ಫುಡ್' ಟ್ಯಾಬ್‌ನಲ್ಲಿ ನೀಡಲಾದ 'ಪಾಕವಿಧಾನಗಳಲ್ಲಿ ಪೋಷಕಾಂಶಗಳನ್ನು ಹುಡುಕಿ' ಆಯ್ಕೆಯನ್ನು ಆರಿಸುವ ಮೂಲಕ ನಿರ್ದಿಷ್ಟ ಪದಾರ್ಥದಲ್ಲಿನ ಪೋಷಕಾಂಶಗಳನ್ನು ನೀವು ತಿಳಿದುಕೊಳ್ಳಬಹುದು.";
  String get linkText18 => 'ಪೋಷಕಾಂಶಗಳ ಸಂಯೋಜನೆಯನ್ನು ತಿಳಿಯಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question19 =>
      'ಅಪ್ಲಿಕೇಶನ್‌ನಲ್ಲಿ ಲಭ್ಯವಿಲ್ಲದ ಹೊಸ ಪಾಕವಿಧಾನವನ್ನು ನಾನು ಸೇರಿಸಬಹುದೇ?';
  String get answer19 =>
      "ಹೌದು. ನಿರ್ದಿಷ್ಟ ಸ್ಥಿರ ಪಾಕವಿಧಾನದ ಕೆಳಭಾಗದಲ್ಲಿ ಒದಗಿಸಲಾದ ಲಿಂಕ್ ಅನ್ನು ಬಳಸಿಕೊಂಡು ನೀವು ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಪಾಕವಿಧಾನವನ್ನು ಮಾರ್ಪಡಿಸಬಹುದು ಅಥವಾ ಡಯಟ್ ಡೈರಿ ಪುಟದಲ್ಲಿ ಪ್ರತಿ ಊಟಕ್ಕೆ ಒದಗಿಸಲಾದ 'ಕಸ್ಟಮ್ ಡಿಶ್' ಆಯ್ಕೆಯನ್ನು ಕ್ಲಿಕ್ ಮಾಡುವ ಮೂಲಕ ಸಂಪೂರ್ಣವಾಗಿ ಹೊಸ ಪಾಕವಿಧಾನವನ್ನು ರಚಿಸಬಹುದು.";
  String get linkText19 => 'ಕಸ್ಟಮ್ ಪಾಕವಿಧಾನವನ್ನು ರಚಿಸಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question20 =>
      'ನಿರ್ದಿಷ್ಟ ಆರೋಗ್ಯ ಸ್ಥಿತಿಗಾಗಿ ನಾನು ಆಹಾರದ ಶಿಫಾರಸುಗಳನ್ನು ಪಡೆಯಬಹುದೇ?';
  String get answer20 =>
      "ಹೌದು. ಮುಖಪುಟದಲ್ಲಿರುವ 'ಸರ್ಚ್ ಕಾಂಪೊನೆಂಟ್' ಆಯ್ಕೆಯಿಂದ ನೀವು ಆರೋಗ್ಯ ಶಿಫಾರಸುಗಳನ್ನು ಅಥವಾ ಡಯಟ್ ಚಾರ್ಟ್ ಮಾರ್ಗಸೂಚಿಗಳನ್ನು ಪಡೆಯಬಹುದು.";
  String get linkText20 => 'ಆಹಾರದ ಶಿಫಾರಸುಗಳನ್ನು ಪಡೆಯಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get question21 =>
      'ನಾನು ಇಂಗ್ಲಿಷ್ ಹೊರತುಪಡಿಸಿ ಬೇರೆ ಭಾಷೆಯಲ್ಲಿ ಅಪ್ಲಿಕೇಶನ್ ಅನ್ನು ಬಳಸಬಹುದೇ?';
  String get answer21 =>
      "ಹೌದು. ನಿಮ್ಮ ಪ್ರೊಫೈಲ್‌ನಲ್ಲಿ ಒದಗಿಸಲಾದ 'ಸೆಟ್ಟಿಂಗ್' ಆಯ್ಕೆಯಿಂದ ನೀವು ಬಯಸಿದ ಭಾಷೆಯನ್ನು ಆಯ್ಕೆ ಮಾಡಬಹುದು.";
  String get linkText21 => 'ಭಾಷೆಯನ್ನು ಬದಲಾಯಿಸಲು ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ';

  String get ninTextBmiHwading => 'ಬಾಡಿ ಮಾಸ್ ಇಂಡೆಕ್ಸ್ (BMI):';
  String get ninTextBmiDiscription =>
      'BMI ಅನ್ನು ವ್ಯಕ್ತಿಯ ತೂಕವನ್ನು ಕಿಲೋಗ್ರಾಂಗಳಲ್ಲಿ ಮೀಟರ್‌ನಲ್ಲಿ ವ್ಯಕ್ತಿಯ ಎತ್ತರದ ವರ್ಗದಿಂದ ಭಾಗಿಸಿ (kg/m2) ಎಂದು ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ. BMI ಶ್ರೇಣಿಗಳು ಅತಿಯಾದ ದೇಹದ ಕೊಬ್ಬು ರೋಗ ಮತ್ತು ಸಾವಿನ ಮೇಲೆ ಬೀರುವ ಪರಿಣಾಮವನ್ನು ಆಧರಿಸಿವೆ ಮತ್ತು ಅವು ಸಮಂಜಸವಾಗಿ ಅಡಿಪೋಸಿಟಿಗೆ ಸಂಬಂಧಿಸಿವೆ. BMI ಅನ್ನು ರೋಗದ ಅಪಾಯ ಸೂಚಕವಾಗಿ ಅಭಿವೃದ್ಧಿಪಡಿಸಲಾಗಿದೆ; BMI ಹೆಚ್ಚಾದಂತೆ, ಕೆಲವು ರೋಗಗಳ ಅಪಾಯವೂ ಹೆಚ್ಚಾಗುತ್ತದೆ. ಅಧಿಕ ತೂಕ ಮತ್ತು ಸ್ಥೂಲಕಾಯತೆಗೆ ಸಂಬಂಧಿಸಿದ ಕೆಲವು ಸಾಮಾನ್ಯ ಪರಿಸ್ಥಿತಿಗಳು: ಅಕಾಲಿಕ ಮರಣ, ಹೃದಯರಕ್ತನಾಳದ ಕಾಯಿಲೆಗಳು, ಅಧಿಕ ರಕ್ತದೊತ್ತಡ, ಅಸ್ಥಿಸಂಧಿವಾತ, ಕೆಲವು ಕ್ಯಾನ್ಸರ್ಗಳು ಮತ್ತು ಮಧುಮೇಹ.';
  String get ninTextbminutritionsta => 'BMI ಪೌಷ್ಟಿಕಾಂಶದ ಸ್ಥಿತಿ';
  String get ninTextNutritionstat => 'ಪೌಷ್ಟಿಕಾಂಶದ ಸ್ಥಿತಿ';
  String get ninTextBelow => 'ಕೆಳಗೆ';
  String get ninTextPreobesity => 'ಪೂರ್ವ ಸ್ಥೂಲಕಾಯತೆ';
  String get recordMyDiet => "ನನ್ನ ಆಹಾರವನ್ನು ದಾಖಲಿಸಿ";
  String get indianFoodCompositionTitle =>
      "ಭಾರತೀಯ ಆಹಾರ ಸಂಯೋಜನೆಯ ತೋಂಡುಗಳು (2017)";

  String get indianFoodCompositionDescription =>
      "ಭಾರತೀಯ ಆಹಾರ ಸಂಯೋಜನೆಯ ತೋಂಡುಗಳು (2017): ಭಾರತೀಯ ಆಹಾರಗಳಿಗಾಗಿ ವಿಸ್ತೃತ ಪೋಷಕಾಂಶ ಡೇಟಾ.";

  String get ninTextbesity => 'ಬೊಜ್ಜು ವರ್ಗ I';
  String get ninTextbesity2 => 'ಬೊಜ್ಜು ವರ್ಗ II';
  String get ninTextbesity3 => 'ಬೊಜ್ಜು ವರ್ಗ III';
  String get moisture => "ತೇವ";

  String get ninTextBMRfull => 'ತಳದ ಚಯಾಪಚಯ ದರ (BMR)';
  String get ninTextBMRDiscription =>
      'ತಳದ ಚಯಾಪಚಯ ದರ (BMR) ಒಬ್ಬ ವ್ಯಕ್ತಿಯು ವಿಶ್ರಾಂತಿಯಲ್ಲಿರುವಾಗ ಶಕ್ತಿಯನ್ನು ವ್ಯಯಿಸುವ ದರವಾಗಿದೆ';
  String get ninTextPreviousdays => 'ಹಿಂದಿನ 30 ದಿನಗಳು';
  String get ninTextason => 'ನಂತೆ';
  String get ninTextYearly => 'ವಾರ್ಷಿಕ';
  String get ninTextabove => 'ಮೇಲೆ';
  String get ninTextAchieveyourhealthgoal => 'ನಿಮ್ಮ ಆರೋಗ್ಯ ಗುರಿಯನ್ನು ಸಾಧಿಸಿ';
  String get heavyDescription =>
      'ಈ ವರ್ಗವು ಪ್ರತಿದಿನ ಒಂದು ಗಂಟೆಗೂ ಹೆಚ್ಚು ಕಾಲ ಓಟ, ಸೈಕ್ಲಿಂಗ್ ಅಥವಾ ಭಾರ ಎತ್ತುವಿಕೆಯಂತಹ ನಿಯಮಿತ ಮತ್ತು ತೀವ್ರವಾದ ದೈಹಿಕ ಚಟುವಟಿಕೆಯನ್ನು ಒಳಗೊಂಡಿರುವ ಉದ್ಯೋಗಗಳನ್ನು ಒಳಗೊಂಡಿದೆ. ಉದಾಹರಣೆಗಳಲ್ಲಿ ಕಮ್ಮಾರರು, ಗಣಿಗಾರರು ಮತ್ತು ನಿರ್ಮಾಣ ಕೆಲಸಗಾರರು ಸೇರಿದ್ದಾರೆ.';
  String get moderateDescription =>
      'ಈ ವರ್ಗದಲ್ಲಿರುವ ವ್ಯಕ್ತಿಗಳು ಪ್ರತಿದಿನ ಸುಮಾರು 30 ನಿಮಿಷದಿಂದ ಒಂದು ಗಂಟೆಯವರೆಗೆ ವಾಕಿಂಗ್ ಅಥವಾ ಲಘು ಜಾಗಿಂಗ್‌ನಂತಹ ಕೆಲವು ಹಂತದ ದೈಹಿಕ ಚಟುವಟಿಕೆಯಲ್ಲಿ ತೊಡಗುತ್ತಾರೆ. ಕೈಯಿಂದ ಕೆಲಸ ಮಾಡುವವರು, ಕುಶಲಕರ್ಮಿಗಳು ಮತ್ತು ಕೆಲವು ರೀತಿಯ ನುರಿತ ಕೆಲಸಗಾರರಂತಹ ಉದ್ಯೋಗಗಳು ಈ ವರ್ಗಕ್ಕೆ ಸೇರುತ್ತವೆ.';
  String get sedentaryDescription =>
      'ಈ ವರ್ಗವು ದಿನವಿಡೀ ಯಾವುದೇ ದೈಹಿಕ ಚಲನೆಯನ್ನು ಹೊಂದಿರದ ಉದ್ಯೋಗಗಳನ್ನು ಒಳಗೊಂಡಿದೆ. ಈ ಉದ್ಯೋಗದಲ್ಲಿರುವ ಜನರು ತಮ್ಮ ಹೆಚ್ಚಿನ ಸಮಯವನ್ನು ಕುಳಿತುಕೊಳ್ಳುವುದು ಅಥವಾ ಮಲಗುವುದು. ಉದಾಹರಣೆಗಳಲ್ಲಿ ಕಛೇರಿ ಕೆಲಸಗಾರರು, ಶಿಕ್ಷಕರು ಮತ್ತು ಆಡಳಿತಾತ್ಮಕ ಪಾತ್ರಗಳಲ್ಲಿ ಇರುವವರು ಸೇರಿದ್ದಾರೆ.';
  String get Foodprotein => "ಪ್ರೋಟೀನ್";
  String get Foodfat => "ಕೊಬ್ಬು";
  String get Foodenergy => "ಶಕ್ತಿ";
  String get FoodtotalB2 => "ಒಟ್ಟು B2";
  String get Foodvitamins => "ವಿಟಮಿನ್ಸ್";
  String get FoodtotalFat => "ಒಟ್ಟು ಕೊಬ್ಬು";
  String get FoodproximateComposition => "ಸಮೀಪದ ಸಂಯೋಜನೆ";
  String get FoodnutrientsIn100g => "100 ಗ್ರಾಂನಲ್ಲಿ ಪೋಷಕಾಂಶಗಳು";
  String get FoodtotalCarotenoids => "ಒಟ್ಟು ಕ್ಯಾರೊಟಿನಾಯ್ಡ್ಗಳು";
  String get FoodtotalAscorbicAcid => "ಒಟ್ಟು ಆಸ್ಕೋರ್ಬಿಕ್ ಆಮ್ಲ";
  String get FoodtotalB9 => "ಒಟ್ಟು B9";
  String get FoodtotalB6 => "ಒಟ್ಟು B6";
  String get Foodcalcium => "ಕ್ಯಾಲ್ಸಿಯಂ";
  String get Foodsodium => "ಸೋಡಿಯಂ";
  String get Foodpotassium => "ಪೊಟ್ಯಾಸಿಯಮ್";
  String get Foodzinc => "ಸತು";
  String get Foodiron => "ಕಬ್ಬಿಣ";
  String get Foodminerals => "ಖನಿಜಗಳು";
  String get FoodtotalSaturatedFattyAcids =>
      "ಒಟ್ಟು ಸ್ಯಾಚುರೇಟೆಡ್ ಕೊಬ್ಬಿನಾಮ್ಲಗಳು";
  String get FoodfattyAcids => "ಕೊಬ್ಬಿನಾಮ್ಲಗಳು";
  String get FoodtotalDietaryFiber => "ಒಟ್ಟು ಆಹಾರದ ಫೈಬರ್";
  String get Foodmanganese => "ಮ್ಯಾಂಗನೀಸ್";
  String get Foodcopper => "ತಾಮ್ರ";
  String get Foodselenium => "ಸೆಲೆನಿಯಮ್";
  String get Foodmagnesium => "ಮೆಗ್ನೀಸಿಯಮ್";
  String get Foodphosphorus => "ರಂಜಕ";
  String get Foodcholesterol => "ಕೊಲೆಸ್ಟ್ರಾಲ್";
  String get Foodcarbohydrate => "ಕಾರ್ಬೋಹೈಡ್ರೇಟ್";
  String get FoodvitaminB6 => "ವಿಟಮಿನ್ ಬಿ6 (ಮಿಗ್ರಾಂ)";
  String get Punjabi => "ಪಂಜಾಬಿ";
  String get Gujarati => "ಗುಜರಾತಿ";
  String get Odia => "ಒಡಿಯಾ";
  String get Kannada => "ಕನ್ನಡ";
  String get Marathi => "ಮರಾಠಿ";
  String get Tamil => "ತಮಿಳು";
  String get Bengali => "ಬೆಂಗಾಲಿ";
  String get Telugu => "ತೆಲುಗು";
  String get English => "ಆಂಗ್ಲ";
  String get Hindi => "ಹಿಂದಿ";
  String get firstname => "ಮೊದಲ ಹೆಸರು";
  String get lastname => "ಕೊನೆಯ ಹೆಸರು";
  String get labelSodium => "ಸೋಡಿಯಂ";
  String get labelVitaminC => "ವಿಟಾಮಿನ್ ಸಿ";
  String get FinanameEnergy => "ಶಕ್ತಿ";
  String get FinanameCarbohydrate => "ಕಾರ್ಬೋಹೈಡ್ರೇಟ್";
  String get FinanameFat => "ಕಟ್ಟಿ";
  String get FinanameSodium => "ಸೋಡಿಯಂ";
  String get FinanameDietaryFibre => "ಆಹಾರ ರಚನಾ";
  String get FinanameCalcium => "ಕ್ಯಾಲ್ಸಿಯಂ";
  String get FinanameIron => "ಲೋಹ";
  String get FinanameMagnesium => "ಮ್ಯಾಗ್ನೀಸಿಯಂ";
  String get FinanameZinc => "ಜಿಂಕ್";
  String get FinanameProtein => "ಪ್ರೋಟಿನ್";
  String get FinanameThiamine => "ಥಿಯಾಮಿನ್";
  String get FinanameRiboflavin => "ರೈಬೊಫ್ಲೇವಿನ್";
  String get FinanameNiacin => "ನಿಯಾಸಿನ್";
  String get FinanameVitaminB => "ವಿಟಾಮಿನ್ B";
  String get FinanameFolate => "ಫೋಲೇಟ್";
  String get FinanameVitaminC => "ವಿಟಾಮಿನ್ C";
  String get FinanameVitaminA => "ವಿಟಾಮಿನ್ A";
  String get FinanameVitaminb6 => "ವಿಟಾಮಿನ್ B6";
  String get confirmDeleteAllNotifications =>
      "ನೀವು ಖಚಿತವಾಗಿ ಎಲ್ಲಾ ಅಧಿಸೂಚನೆಗಳನ್ನು ಅಳಿಸಲು ಬಯಸುತ್ತೀರಾ?";
  String get fillAllFields => "ದಯವಿಟ್ಟು ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳನ್ನು ತುಂಬಿ";
  String get successfullyAddedIngredient => "ಘಟಕ ಯಶಸ್ವಿಯಾಗಿ ಸೇರಿಸಲಾಗಿದೆ";
  String get confirmDeletion => "ಅಳಿಸಲು ಖಚಿತಪಡಿಸಿ";
  String get confirmDeleteIngredient =>
      "ನೀವು ಖಚಿತವಾಗಿ ಈ ಘಟಕವನ್ನು ಅಳಿಸಲು ಬಯಸುತ್ತೀರಾ?";
  String get fileDownloaded =>
      "ಫೈಲ್ ಯಶಸ್ವಿಯಾಗಿ ಡೌನ್‌ಲೋಡ್ ಮಾಡಲಾಗಿದೆ ಮತ್ತು ಫೈಲ್ ಸ್ಥಳ";
  String get confirmDeleteFood =>
      "ನೀವು ಖಚಿತವಾಗಿ ಈ ಆಹಾರವನ್ನು ಅಳಿಸಲು ಬಯಸುತ್ತೀರಾ?";
  String get estimatedAverageRequirement =>
      'ಅಂದಾಜಿತ ಸರಾಸರಿ ಅವಶ್ಯಕತೆ (EAR): ಆರೋಗ್ಯದಲ್ಲಿರುವ 50% ವ್ಯಕ್ತಿಗಳ ಅವರ್ಜಿತ ದಿನದ ಮಟ್ಟ';
  String get editQuantity => "ಪ್ರಮಾಣ ಸಂಪಾದಿಸಿ";
  String get confirmDelete => "ನೀವು ಖಚಿತವಾಗಿ ಅಳಿಸಲು ಬಯಸುತ್ತೀರಾ?";
  String get exerciseDeleted => "ವ್ಯಾಯಾಮ ಯಶಸ್ವಿಯಾಗಿ ಅಳಿಸಲಾಗಿದೆ.";
  String get confirmDeleteExercise =>
      "ನೀವು ಖಚಿತವಾಗಿ ಈ ವ್ಯಾಯಾಮವನ್ನು ಅಳಿಸಲು ಬಯಸುತ್ತೀರಾ?";
  String get EssentialNutritionalGuidelines =>
      "ಭಾರತೀಯರ ಆಹಾರ ಅವಶ್ಯಕತೆಗಳಿಗೆ ತಕ್ಕಂತೆ ಅಗತ್ಯವಾದ ಪೋಷಣಾ ಮಾರ್ಗದರ್ಶಿಗಳು.";
  String get NutrientRequirementsRDA2020 =>
      "ಭಾರತೀಯರಿಗಾಗಿ ಪೋಷಕಾಂಶ ಅವಶ್ಯಕತೆಗಳು ಮತ್ತು ಶಿಫಾರಸು ಮಾಡಲಾದ ಆಹಾರ ಭತ್ಯೆ (RDA 2020).";
  String get RecommendationsBalancedDiets =>
      "ಭಾರತದಲ್ಲಿ ಸಮತೋಲನದ ಆಹಾರ ಮತ್ತು ಆರೋಗ್ಯಕರ ಆಹಾರ ಅಭ್ಯಾಸಗಳನ್ನು ಉತ್ತೇಜಿಸಲು ಶಿಫಾರಸುಗಳು.";
  String get DietaryGuidelinesForIndians => "ಭಾರತೀಯರಿಗಾಗಿ ಆಹಾರ ಮಾರ್ಗಸೂಚಿಗಳು.";
  String get Nutritionstat => "ಪೋಷಣಾ ಗಣತಾಂಕಗಳು";
  String get referenceMen65kg => "ತೂಕದ ಪ್ರತಿನಿಧಿ ಪುರುಷರು (65 kg)";
  String get referenceWomen55kg => "ತೂಕದ ಪ್ರತಿನಿಧಿ ಮಹಿಳೆಯರು (55 kg)";
  String get valueForMen => "1506";
  String get valueForWomen => "1184";
  String get referenceMenWomenDescription =>
      "ಸೂಚನಾ ಪುರುಷರು ಮತ್ತು ಮಹಿಳೆಯರು 19-39 ವರ್ಷ ವಯಸ್ಸಿನ ಆರೋಗ್ಯಕರ ವಯಸ್ಕರು, ಸಾಮಾನ್ಯ BMI ಹೊಂದಿರುವವರು ಮತ್ತು ಮಿತವಾಗಿ ಸಕ್ರಿಯರಾಗಿರುವವರು (ICMR-NIN). ನೋಡಿ";
  String get personalizedDietDiaryDescription =>
      "ವೈಯಕ್ತಿಕ ಆಹಾರ ದಿನಚರಿ ನಿಮ್ಮ ಪೋಷಕಾಂಶವನ್ನು ಪ್ರಸ್ತುತದಿಂದ ಕಳೆದ ತಿಂಗಳವರೆಗೆ ಟ್ರ್ಯಾಕ್ ಮಾಡುತ್ತದೆ";
}
