// LanguageGu.dart
import 'languages.dart';

class LanguageGu extends Languages {
  @override
  String get appName => "NIN2.0";
  String get totalEnergyConsumption => "કુલ ઊર્જા વપરાશ";
  String get totalEnergyExpenditure => "કુલ ઊર્જા ખર્ચ";
  String get inputActivityDataPrompt =>
      "તમારા ઊર્જા ખર્ચ અને સંતુલન જોવા માટે, કૃપા કરીને 24-કલાકની પ્રવૃત્તિ ડેટા દાખલ કરો.";
  String get myEnergyBalanceYesterday => "મારો ઊર્જા સંતુલન (ગઇકાલે)";
  String get caloriesBurnFromWatch => "ઘડિયાળથી બળેલી કૅલરી";
  String get activities => "પ્રવૃત્તિઓ";
  String get searchActivityHere => "અહિ પ્રવૃત્તિ શોધો";
  String get orSelectActivityFromBelow => "અથવા નીચે થી પ્રવૃત્તિ પસંદ કરો";
  String get tryLater => "પછી પ્રયાસ કરો";
  @override
  String get labelWelcome => "સ્વાગત છે";

  @override
  String get labelSelectLanguage => "ભાષા પસંદ કરો";
  String get energybalance => "ઊર્જા સંતુલન";
  String get indicatorhealth =>
      "('+' ઊર્જા વધારાને દર્શાવે છે; '-' ઊર્જા ઘટતાને દર્શાવે છે)";

  @override
  String get labelInfo => "આ બહુ-ભાષાઓની ડેમો એપ્લિકેશન છે";

  @override
  // TODO: implement labelChangeLanguage
  String get labelChangeLanguage => "ભાષા બદલો";
  @override
  String get labelWelcomeBack => "ફરી સ્વાગત છે,";

  @override
  String get labelUnderweight => "તમારું વજન ઓછું છે";

  @override
  String get labelNormalWeight => "તમારું વજન સામાન્ય છે";

  @override
  String get labelOverweight => "તમારું વજન વધારે છે";

  @override
  String get labelObese => "તમે મેદસ્વી છો";

  @override
  String get labelViewMore => "વધુ જોવો";

  @override
  String get labelTodaySteps => "આજના પગલાં";

  @override
  String get labelCheck => "તપાસો";

  @override
  String get labelHealthData =>
      "મારું બ્લડ પ્રેશર / બ્લડ ગ્લુકોઝ / SPO2 રેકોર્ડ કરો";

  @override
  String get labelActivityStatus => "પ્રવૃત્તિ સ્થિતિ";

  @override
  String get labelHeartRate => "હૃદય દર";

  @override
  String get labelHeartRateValue => "78 BPM";

  @override
  String get labelMinutesAgo => "મિનિટ પહેલા";

  @override
  String get labelWaterIntake => "મારું પાણીનું સેવન";

  @override
  String get labelLiters => "લિટર";

  @override
  String get labelZeroLiters => "0 લિટર";

  @override
  String get labelRealTimeGoal => "વાસ્તવિક સમય, ધ્યેય";

  @override
  String get labelCalories => "કેલરી બળી ગઈ";

  @override
  String get labelCaloriesEarned => "કેલરી મેળવી";

  @override
  String get labelFoodPlan => "ખોરાક યોજના";

  @override
  String get labelWorkoutProgress => "વર્કઆઉટ પ્રગતિ";

  @override
  String get labelWeekly => "સાપ્તાહિક";

  @override
  String get labelMonthly => "માસિક";

  @override
  String get labelLatestWorkout => "નવીનતમ વર્કઆઉટ";

  @override
  String get labelSeeMore => "વધુ જુઓ";
  String get labelBreakfast => "નાસ્તો";
  String get labelLunch => "લંચ";
  String get labelDinner => "રાત્રિભોજન";
  String get labelSnacks => "નાસ્તો";
  String get labelTaken => "લીધેલ";
  String get labelTarget => "લક્ષ્ય";

  //profile

  String get labelProfile => "પ્રોફાઇલ";
  String get labelEdit => "સંપાદિત કરો";
  String get labelUser => "વપરાશકર્તા";
  String get labelProgram => "ચરબી કાર્યક્રમ ગુમાવો";
  String get labelHeight => "ઊંચાઈ";
  String get labelWeight => "વજન";
  String get labelAge => "ઉંમર";
  String get labelAccount => "એકાઉન્ટ";
  String get labelPersonalData => "વ્યક્તિગત માહિતી";
  String get labelAchievement => "સિદ્ધિ";
  String get labelActivityHistory => "પ્રવૃત્તિ ઇતિહાસ";
//String get labelWorkoutProgress => "વર્કઆઉટ પ્રોગ્રેસ";
  String get labelNotification => "સૂચના";
  String get labelPopupNotification => "પોપ-અપ સૂચના";
  String get labelMensurationCycle => "ચક્ર માપન";
  String get labelOther => "અન્ય";
  String get labelContactUs => "અમારો સંપર્ક કરો";
  String get labelPrivacyPolicy => "ગોપનીયતા નીતિ";
  String get labelSetting => "સેટિંગ";
  String get labelFeedback => "પ્રતિભાવ";
  String get labelConfirmLogout => "લોગઆઉટની પુષ્ટિ કરો";
  String get labelConfirmLogoutMessage =>
      "શું તમે ખરેખર લૉગ આઉટ કરવા માંગો છો?";
  String get labelLogout => "લૉગ આઉટ";
  //select tab
  String get labelOptions => "વિકલ્પો";
  String get labelFoodTable => "ખોરાક ઉમેરો";
  String get labelTop10Food => "ટોચના 10 ખોરાક";
  String get labelActivityTrack => "પ્રવૃત્તિ ટ્રેકર";
  String get labelsteptracker => "સ્ટેપ ટ્રેકર";

  String get labelTodayTarget => "પાણીનું લક્ષ્ય";
  String get labelJoggingTrack => "જોગિંગ ટ્રેક";
  String get labelMensurationTrack => "મેન્સ્યુરેશન ટ્રેક";
//String get labelFoodTable => "ફૂડ ટેબલ";
  String get labelPassword => "પાસવર્ડ બદલો";
  String get labelDarkMode => "ડાર્ક મોડ અજમાવો";
  String get labelconectWatch => "ઘડિયાળ કનેક્ટ કરો";
  @override
  String get labelSleep => "ઊંઘ";
  @override
  String get labelBookStore => "બુક સ્ટોર";
  @override
  String get labelSearchBooks => "પુસ્તકો શોધો";
  @override
  String get labelPrice => "કિંમત";
  @override
  String get labelAddToCart => "સૂચી માં સામેલ કરો";
  @override
  String get labelAuthor => "લેખક";
  @override
  String get labelYear => "વર્ષ";
  @override
  String get labelQuantityAvailable => "ઉપલબ્ધ જથ્થો";
  @override
  String get labelCart => "સૂચી માં સામેલ કરો";
  @override
  String get labelMyOrders => "મારા ઓર્ડર";
  @override
  String get labelAllOrders => "બધા ઓર્ડર";
  @override
  String get labelOrderDetail => "ઓર્ડર વિગત";
  @override
  String get labelOrderId => "ઓર્ડર આઈડી";
  @override
  String get labelOrdersInMyOrders => "મારા ઓર્ડરમાં ઓર્ડર";
  @override
  String get labelItemsInMyOrders => "મારા ઓર્ડરમાં વસ્તુઓ";
  @override
  String get labelTotal => "કુલ";
  @override
  String get labelTotalPrice => "કુલ કિંમત";
  @override
  String get labelCheckout => "ચેકઆઉટ";

  // Meal List
  @override
  String get labelMealList => "મારો આહાર";
  @override
  String get labelAnalyze => "વિશ્લેષણ કરો";
  @override
  String get labelAddDish => "વાનગી ઉમેરો";
  @override
  String get labelTop10Foods => "ટોચના 10 ખોરાક";
  @override
  String get labelRecentMeal => "તાજેતરનું ભોજન";
  @override
  String get labelAnalyzeIngredientsTaken => "ખોરાકના સેવનનું વિશ્લેષણ કરો";

  // Nutrition Summary
  @override
  String get labelCarbs => "કાર્બોહાઇડ્રેટ";
  // @override
  // String get labelCalories => "કેલરી";
  @override
  String get labelFibers => "કુલ ફાઇબર";
  @override
  String get labelFats => "ચરબી";
  @override
  String get labelProteins => "પ્રોટીન";
  @override
  String get labelCalcium => "કેલ્શિયમ";

  @override
  String get labelNiacinB3 => "નિયાસિન (B3)";

  @override
  String get labelThiamineB1 => "થાઇમીન (B1)";

  @override
  String get labelIron => "લોખંડ";

  @override
  String get labelZinc => "ઝીંક";

  @override
  String get labelFolatesB9 => "ફોલેટ (B9)";

  @override
  String get labelRiboflavinB2 => "રિબોફ્લેવિન (B2)";

  @override
  String get labelRetinolVitA => "રેટિનોલ (વિટામિન એ)";

  @override
  String get labelMagnesium => "મેગ્નેશિયમ";

  @override
  String get labelTodaysNutritionSummary => "આજના પોષણનો સારાંશ";
  @override
  String get labelChangeGoal => "ધ્યેય બદલો";
  @override
  String get labelIngredientsTaken => "ઘટકો લેવામાં આવે છે";
  @override
  String get labelIngredientsLeft => "ઘટકો બાકી";

  // Food Table
  // @override
  // String get labelFoodTable => "ફૂડ ટેબલ";
  // @override
  // String get labelBreakfast => "નાસ્તો";
  // @override
  // String get labelLunch => "લંચ";
  // @override
  // String get labelDinner => "રાત્રિભોજન";
  // @override
  // String get labelSnacks => "નાસ્તો";
  @override
  String get labelTop10FoodsSleep => "ટોચના 10 ખોરાક";
  @override
  String get labelFavouriteDishes => "મનપસંદ વાનગીઓ";

  // User Profile
  @override
  String get labelHelp => "મદદ";
  // @override
  // String get labelLogout => "લૉગ આઉટ";
  // @override
  // String get labelWeight => "વજન";
  @override
  String get labelEmail => "ઈમેલ";
  // @override
  // String get labelHeight => "ઊંચાઈ";
  @override
  String get labelLinkedInProfileLink => "LinkedIn પ્રોફાઇલ લિંક";
  @override
  String get labelGoogleProfileLink => "Google પ્રોફાઇલ લિંક";
  @override
  String get labelFacebookProfileLink => "ફેસબુક પ્રોફાઇલ લિંક";
  @override
  String get labelTwitterProfileLink => "ટ્વિટર પ્રોફાઇલ લિંક";
  @override
  String get labelName => "નામ";
  @override
  String get labelPhoneNumber => "ફોન નં.";
  @override
  String get labelDateOfBirth => "ડી.ઓ.બી";
  @override
  String get labelBMI => "BMI";
  // @override
  // String get labelAge => "ઉંમર";

  // Contact Us
  @override
  String get labelMessage => "સંદેશ";
  @override
  String get labelSubmit => "સબમિટ કરો";
  @override
  String get labelCompanyContacts => "કંપની સંપર્કો";
  @override
  String get labelAddress => "સરનામું";
  @override
  String get labelDirectorsEmail => "ડિરેક્ટરનો ઈમેલ";
  @override
  String get labelFax => "ફેક્સ";

  // Settings
  @override
  String get labelResetPassword => "પાસવર્ડ રીસેટ કરો";
  // @override
  // String get labelFeedback => "પ્રતિભાવ";
  @override
  String get labelPleaseProvideFeedback => "કૃપા કરીને તમારો પ્રતિસાદ આપો";
  @override
  String get labelEnterYourFeedbackHere => "તમારો પ્રતિસાદ અહીં દાખલ કરો";
  @override
  String get labelSubmitFeedback => "પ્રતિસાદ સબમિટ કરો";

  // Credits
  // @override
  // String get labelContactUs => "અમારો સંપર્ક કરો";
  @override
  String get labelDevelopmentTeam => "વિકાસ ટીમ";
  @override
  String get labelAcknowledgments => "સ્વીકૃતિઓ";
  @override
  String get labelPartnerships => "ભાગીદારી";

  // Mobile
  @override
  String get labelSearchComponents => "ઘટકો શોધો";
  @override
  String get labelSearchComponentsHere => "ઘટકો અહીં શોધો";
  @override
  String get lablelDishName => 'વાનગીનું નામ';
  @override
  String get labelCredits => 'શ્રેય';
  @override
  String get labelShareAppButton => "શેર કરો";
  @override
  String get labelShareApp =>
      "બારકોડ સ્કેનર એપ વડે QR કોડ સ્કેન કરો અને એપ ડાઉનલોડ કરો";
  // New translations
  @override
  String get labelConnectedWatch => "કનેક્ટેડ ઘડિયાળ છે";
  @override
  String get labelDisconnect => "ડિસ્કનેક્ટ કરો";
  @override
  String get labelFitbit => "ફિટબિટ";
  @override
  String get labelGoogleFit => "Google Fit";
  @override
  String get labelAppleWatch => "એપલ ઘડિયાળ";
  @override
  String get labelSamsungSmartWatch => "સેમસંગ સ્માર્ટ વોચ";
  @override
  String get labelBookDetails => "પુસ્તક વિગતો";
  @override
  String get labelDeliveryDate => "સોંપણી તારીખ";
  @override
  String get labelOrderDate => "ઓર્ડર તારીખ";
  @override
  String get labelAnalyseIngredientsTaken => "ખોરાકના સેવનનું વિશ્લેષણ કરો";
  @override
  String get labelAddDishIngredients => "વાનગી ઘટકો ઉમેરો";
  @override
  String get labelIngredientName => "ઘટકનું નામ";
  @override
  String get labelEnterIngredientName => "ઘટકનું નામ દાખલ કરો";
  @override
  String get labelIngredientQuantity => "ઘટક જથ્થો";
  @override
  String get labelEnterIngredientQuantity => "ઘટક જથ્થો દાખલ કરો";
  @override
  String get labelAdd => "ઉમેરો";
  @override
  String get labelSave => "સાચવો";
  @override
  String get labelwatch => "ઘડિયાળ";

  //
  @override
  String get labelBloodOxygenHeart =>
      'મહત્વપૂર્ણ સંકેતોને માપો અને એકંદર આરોગ્યને ટ્રૅક કરો.';
  @override
  String get labelTop10FoodS =>
      'તંદુરસ્ત જીવનશૈલી જાળવવા માટે ભલામણ કરેલ ખોરાક શોધો.';
  @override
  String get labelWaterTrack =>
      'દૈનિક ફિટનેસ હાઇડ્રેશન લક્ષ્યો સેટ કરો અને પ્રાપ્ત કરો.';
  @override
  String get labelPersonalDetails =>
      'વ્યક્તિગત માહિતીને સુરક્ષિત રીતે મેનેજ કરો અને અપડેટ કરો.';
  @override
  String get labelFeedbackS => 'તમારા વિચારો અને સૂચનો અમારી સાથે શેર કરો.';
  @override
  String get labelContactUsS =>
      'ગ્રાહક સમર્થન સુધી પહોંચો અને અમારી સાથે સંપર્કમાં રહો.';
  @override
  String get labelBMICalculator =>
      'સ્વાસ્થ્યની જાણકારી માટે તમારા બોડી માસ ઇન્ડેક્સની ગણતરી કરો.';
  @override
  String get labelBMRCalculator =>
      'ફિટનેસ પ્લાનિંગ માટે તમારા બેઝલ મેટાબોલિક રેટની ગણતરી કરો.';
  @override
  String get labelRunningJoggingSteps =>
      'તંદુરસ્ત જીવનશૈલી માટે તમારા દોડવાના અને જોગિંગના પગલાંને ટ્રૅક કરો.';
  @override
  String get labelHealthyDietChart =>
      'તંદુરસ્ત આહારની ઝાંખી માટે વ્યાપક ચાર્ટને ઍક્સેસ કરો.';
  @override
  String get labelHealthyRecommendation => 'વ્યક્તિગત આરોગ્ય ભલામણો મેળવો.';
  @override
  String get labelSleepTracker =>
      'તમારી ઊંઘની પેટર્ન ટ્રૅક કરો અને ઊંઘની ગુણવત્તા બહેતર બનાવો.';
  @override
  String get labelSetReminder =>
      'આરોગ્ય અને ફિટનેસ પ્રવૃત્તિઓ માટે રીમાઇન્ડર્સ સેટ કરો.';
  // @override
  // String get labelMenstruationCycle =>
  //     'બહેતર આંતરદૃષ્ટિ માટે તમારા માસિક ચક્રને ટ્રૅક કરો અને મેનેજ કરો.';
  @override
  String get labelCSVDownload =>
      'સરળ વિશ્લેષણ માટે તમારો ડેટા CSV ફોર્મેટમાં ડાઉનલોડ કરો.';

  // New Headings
  @override
  String get headingBloodOxygenHeart => 'લોહી | પ્રાણવાયુ';
  @override
  String get headingTop10Food => 'ટોચના 10 ખોરાક';
  @override
  String get headingWaterTrack => 'પાણી ટ્રેકર';
  @override
  String get headingPersonalDetails => 'અંગત વિગતો';
  @override
  String get headingFeedback => 'પ્રતિસાદ';
  @override
  String get headingContactUs => 'અમારો સંપર્ક કરો';
  @override
  String get headingBMICalculator => 'BMI કેલ્ક્યુલેટર';
  @override
  String get headingBMRCalculator => 'BMR કેલ્ક્યુલેટર';
  @override
  String get headingRunningJoggingSteps => 'દોડવું / જોગિંગ / પગલાં';
  @override
  String get headingHealthyDietChart => 'સ્વસ્થ આહાર ચાર્ટ';
  @override
  String get headingHealthyRecommendation => 'તંદુરસ્ત ભલામણ';
  @override
  String get headingSleepTracker => 'સ્લીપ ટ્રેકર';
  @override
  String get headingSetReminder => 'રીમાઇન્ડર સેટ કરો';
  // @override
  // String get headingMenstruationCycle => 'માસિક ચક્ર';
  @override
  String get headingCSVDownload => 'CSV ડાઉનલોડ';

  // Water-related phrases
  @override
  String get labelWaterTarget => "પાણીનું લક્ષ્ય";
  // @override
  // String get labelTodayTarget => "આજે લક્ષ્ય";
  @override
  String get labelWaterGoal => "પાણી ધ્યેય";
  // @override
  // String get labelWaterIntake => "પાણીનું સેવન";
  @override
  String get labelWaterProgress => "પાણીની પ્રગતિ";
  // @override
  // String get labelWeekly => "સાપ્તાહિક";
  @override
  String get labelDateWise => "તારીખ મુજબ";
  @override
  String get labelSun => "સૂર્ય";
  @override
  String get labelMon => "સોમ";
  @override
  String get labelTue => "મંગળ";
  @override
  String get labelWed => "બુધ";
  @override
  String get labelThu => "ગુરૂ";
  @override
  String get labelFri => "શુક્ર";

  // BMI Calculator
  // @override
  // String get labelBMI => "BMI";
  @override
  String get labelEnterHeight => "ઊંચાઈ દાખલ કરો (સે.મી.)";
  @override
  String get labelEnterWeight => "વજન દાખલ કરો (કિલો)";
  @override
  String get labelCalculateBMI => "BMI ની ગણતરી કરો";

  // BMR Calculator
  @override
  String get labelMale => "પુરુષ";
  @override
  String get labelFemale => "સ્ત્રી";
  @override
  String get labelEnterAge => "ઉંમર દાખલ કરો";
  @override
  String get labelCalculateBMR => "BMR ની ગણતરી કરો";
  @override
  String get labelBMR => "BMR";
  @override
  String get labelCaloriesPerDay => "કેલરી / દિવસ";

  // Step Tracker
  @override
  String get labelStepsTracker => "સ્ટેપ ટ્રેકર";
  @override
  String get labelRunningTracker => "ચાલી રહેલ ટ્રેકર";
  @override
  String get labelAddStep => "પગલું ઉમેરો";
  @override
  String get labelSelectDate => "તારીખ પસંદ કરો";
  @override
  String get labelJoggingTracker => "જોગિંગ ટ્રેકર";
  @override
  String get labelCaloriesBurn => "કેલરી બળી ગઈ";

  // Sleep Tracker
  @override
  String get labelSleepTarget => "ઊંઘ લક્ષ્ય";
  @override
  String get labelTodaySleep => "આજે ઊંઘ";
  @override
  String get labelSleepProgress => "ઊંઘની પ્રગતિ";
  @override
  String get labelTotalSleep => "કુલ ઊંઘ";
  @override
  String get labelSleepGoal => "ઊંઘ ધ્યેય";
  @override
  String get labelSetNotification => "સૂચના સેટ કરો";
  @override
  String get labelStartTime => "પ્રારંભ સમય";
  @override
  String get labelEndTime => "સમાપ્તિ સમય";
  @override
  String get labelSelect => "પસંદ કરો";
  @override
  String get labelSat => "શનિ";
  // @override
  // String get labelSave => "સાચવો";
  @override
  String get labelStart => "શરૂઆત";
  @override
  String get labelEnd => "અંત";
  @override
  String get labelType => "પ્રકાર";
  @override
  String get labelIsConnected => "જોડાયેલ છે";

  // @override
  // String get labelMensurationCycle => "ચક્ર માપન";

  @override
  String get labelTrackAndManage =>
      "બહેતર આંતરદૃષ્ટિ માટે તમારા માસિક ચક્રને ટ્રૅક કરો અને મેનેજ કરો";

  @override
  String get labelMensurationStatus => "માપન સ્થિતિ";

  @override
  String get labelDaysLength => "દિવસોની લંબાઈ";

  @override
  String get labelDay => "દિવસ";

  @override
  String get labelNextDate => "આગામી તા";

  @override
  String get labelLastPeriodStartDate => "છેલ્લી અવધિની શરૂઆતની તારીખ";

  @override
  String get labelAverageCycleLength => "ચક્રની સરેરાશ લંબાઈ";

  @override
  String get labelChange => "બદલો";

  // Common Messages
  @override
  String get messageSent => "સંદેશ મોકલ્યો";

  @override
  String get thankYouForContactingUs => "અમારો સંપર્ક કરવા બદલ આભાર!";

  @override
  String get alert => "ચેતવણી";

  @override
  String get fillInAllFields => "કૃપા કરીને તમામ ફીલ્ડ ભરો.";

  @override
  String get thankYouFeedbackSubmitted =>
      "તમારો પ્રતિસાદ સબમિટ કરવામાં આવ્યો છે.";

  @override
  String get resetPassword => "પાસવર્ડ રીસેટ કરો";

  @override
  String get dishAdded => "વાનગી ઉમેરી!";

  @override
  String get dishAndIngredientsAddedSuccessfully =>
      "વાનગી અને ઘટકો સફળતાપૂર્વક ઉમેર્યા.";

  @override
  String get failed => "નિષ્ફળ";

  @override
  String get error => "ભૂલ";

  @override
  String get enterBloodGlucoseLevel =>
      "લોહીમાં શર્કરાનું સ્તર mg/dL માં દાખલ કરો";

  @override
  String get enterBloodPressureLevel => "mmHg માં બ્લડ પ્રેશરનું સ્તર દાખલ કરો";

  @override
  String get enterHeartLevel =>
      "કૃપા કરીને ધબકારા પ્રતિ મિનિટ (BPM) માં હૃદય દર દાખલ કરો.";

  @override
  String get cancel => "રદ કરો";

  @override
  String get submit => "સબમિટ કરો";

  @override
  String get valueCannotBeGreaterThan100 => "મૂલ્ય 100 થી વધુ ન હોઈ શકે.";

  @override
  String get bloodStatusSubmittedSuccessfully =>
      "રક્તનું સ્ટેટસ સફળતાપૂર્વક સબમિટ કર્યું.";

  @override
  String get failedToSubmitBlood => "બ્લડ સબમિટ કરવામાં નિષ્ફળ.";

  @override
  String get enterHeartLevel1to100 =>
      "કૃપા કરીને ધબકારા પ્રતિ મિનિટ (BPM) માં હૃદય દર દાખલ કરો.";

  @override
  String get heartLevelSubmittedSuccessfully =>
      "હાર્ટ લેવલ સફળતાપૂર્વક સબમિટ કર્યું.";

  @override
  String get enterOxygenSaturationLevel1to100 =>
      "ઓક્સિજન સંતૃપ્તિ સ્તર 1%-100% દાખલ કરો";

  @override
  String get oxygenLevelSubmittedSuccessfully =>
      "ઓક્સિજન સ્તર સફળતાપૂર્વક સબમિટ કર્યું.";

  @override
  String get updateData => "ડેટા અપડેટ કરો";

  @override
  String get selectLastPeriodStartDate =>
      "છેલ્લી અવધિની શરૂઆતની તારીખ પસંદ કરો";

  @override
  String get update => "અપડેટ કરો";

  @override
  String get failedToFetchBooks =>
      "પુસ્તકો મેળવવામાં નિષ્ફળ. મહેરબાની કરીને ફરીથી પ્રયતન કરો.";

  @override
  String get errorOccurred => "એક ભૂલ આવી:";

  @override
  String get invalidEndTime => "અમાન્ય સમાપ્તિ સમય";

  @override
  String get chooseTimeWithin1Hour =>
      "કૃપા કરીને પ્રારંભ સમયના 1 કલાકની અંદર સમય પસંદ કરો.";

  @override
  String get notificationSaved => "સૂચના સાચવી";

  @override
  String get notificationSetSuccessfully => "સૂચના સફળતાપૂર્વક સેટ થઈ.";

  @override
  String get thereIsSomeError => "કેટલીક ભૂલ છે.";

  @override
  String get watchDisconnected => "ઘડિયાળ ડિસ્કનેક્ટ થઈ";

  @override
  String get watchDisconnectedSuccessfully =>
      "ઘડિયાળ સફળતાપૂર્વક ડિસ્કનેક્ટ થઈ ગઈ છે.";

  @override
  String get addCup => "કપ ઉમેરો";

  @override
  String get numberOfCups => "કપની સંખ્યા";

  @override
  String get addCupCapacityInMl => "ml માં કપ ક્ષમતા ઉમેરો";

  @override
  String get cupCapacitySubmittedSuccessfully =>
      "કપ ક્ષમતા સફળતાપૂર્વક સબમિટ કરી.";

  @override
  String get pleaseEnterValidValuesForAllFields =>
      "કૃપા કરીને તમામ ક્ષેત્રો માટે માન્ય મૂલ્યો દાખલ કરો.";

  @override
  String get enterWater => "પાણી દાખલ કરો";

  @override
  String get waterGoalLiters => "પાણીનો ધ્યેય (લિટર)";

  @override
  String get waterSubmittedSuccessfully =>
      "પાણીનો ધ્યેય સફળતાપૂર્વક સબમિટ થયો.";

  @override
  String get addActivityData => "પ્રવૃત્તિ ડેટા ઉમેરો";

  @override
  String get enterValue => "મૂલ્ય દાખલ કરો";

  @override
  String get addStepsData => "પગલાં ડેટા ઉમેરો";

  @override
  String get numberOfSteps => "પગલાંઓની સંખ્યા";

  @override
  String get stepsDataSubmittedSuccessfully =>
      "પગલાંનો ડેટા સફળતાપૂર્વક સબમિટ કર્યો.";

  @override
  String get enterSleepTarget => "ઊંઘનું લક્ષ્ય દાખલ કરો";

  @override
  String get sleepTargetInHours => "કલાકોમાં ઊંઘનું લક્ષ્ય";

  @override
  String get addYourSleepDuration => "તમારી ઊંઘનો સમયગાળો ઉમેરો";

  @override
  String get enterDurationInMinutes => "મિનિટમાં અવધિ દાખલ કરો:";

  @override
  String get add => "ઉમેરો";

  @override
  String get ok => "બરાબર";

  @override
  String get csvFileSavedTo => "CSV ફાઇલમાં સાચવવામાં આવી";

  @override
  String get ageMustBeBetween2And100Years =>
      "ઉંમર 2 થી 100 વર્ષની વચ્ચે હોવી જોઈએ";

  @override
  String get next => "આગળ";

  @override
  String get register => "નોંધણી કરો";

  @override
  String get oopsSomethingWentWrong => "અરે! કંઈક ખોટું થયું";

  @override
  String get errorFetchingMeals => "ભોજન મેળવતી વખતે એક ભૂલ આવી:";

  @override
  String get reviewAddedSuccessfully => "સમીક્ષા સફળતાપૂર્વક ઉમેરાઈ!";

  @override
  String get failedToAddReview => "સમીક્ષા ઉમેરવામાં નિષ્ફળ:";

  @override
  String get alreadyInCart => "પહેલેથી જ કાર્ટમાં છે";

  @override
  String get addedToCart => "કાર્ટમાં ઉમેર્યું";

  @override
  String get quantityNotBetween1And2 => "જથ્થો 2 કરતાં વધુ અને 1 કરતાં ઓછો નથી";

  String get createcustomdish => "કસ્ટમ ડીશ બનાવો";
  String get quantityingram => "જથ્થો (ગ્રામ)";
  String get labelCaloriestaken => 'ઉર્જા';
  String get mainlabelEarlyMorning => "વહેલી સવારે";
  String get mainlabelMidMorning => "મધ્ય સવાર";
  String get mainlabelEvening => "સાંજ";
  String get mainlabelBedtime => "સૂવાનો સમય";
  String get mainlabelTimeSpentOn => "વિવિધ પ્રવૃત્તિઓમાં સમય પસાર થાય છે";
  String get mainlabelHealthCalculator => "આરોગ્ય કેલ્ક્યુલેટર";
  String get mainlabelStepProgress => "પગલું પ્રગતિ";
  String get mainlabelRealTimeIntakes => "વાસ્તવિક સમયનો વપરાશ";
  String get mainlabelCaloriesBurnProgress => "કેલરી બર્ન પ્રગતિ";
  String get mainlabelCaloriesBurnBreakdown => "પર કેલરી બર્ન બ્રેકડાઉન";
  String get mainlabelHeartReportsTrends => "હૃદય વલણોની જાણ કરે છે";
  String get mainlabelOxygenStatus => "ઓક્સિજન સ્થિતિ";
  String get mainlabelNoRecord => "મને યાદ નથી";
  String get mainlabelSystolicBloodPressure => "સિસ્ટોલિક બ્લડ પ્રેશર";
  String get mainlabelMeasuredon => "પર માપવામાં આવે છે";
  String get mainlabelEnterBloodPressure => "બ્લડ પ્રેશર દાખલ કરો";
  String get mainlabelBloodPressure => "લોહિનુ દબાણ";
  String get mainlabelDiastolicBloodPressure => "ડાયસ્ટોલિક બ્લડ પ્રેશર";
  String get mainlabelBloodGlucose => "બ્લડ ગ્લુકોઝ";
  String get mainlabelHeartStatus => "હૃદય સ્થિતિ";
  String get mainlabelAllExercise => "બધી કસરત";
  String get mainlabelCleaningOrMopping => "સફાઈ અથવા મોપિંગ";
  String get mainlabelGardening => "બાગકામ";
  String get mainlabelWatchingTV => "ટીવી જોઉં છું";
  String get mainlabelCycling => "સાયકલિંગ";
  String get mainlabelRunning => "ચાલી રહી છે";
  String get mainlabelWalking => "વૉકિંગ";
  String get mainlabelShuttle => "શટલ";
  String get mainlabelTableTennis => "ટેબલ ટેનિસ";
  String get mainlabelTennis => "ટેનિસ";
  String get mainlabelVolleyBall => "વોલી બોલ";
  String get mainlabelDancing => "નૃત્ય";
  String get mainlabelFishing => "માછીમારી";
  String get mainlabelShopping => "શોપિંગ";
  String get mainlabelTyping => "ટાઈપિંગ";
  String get mainlabelSleeping => "ઊંઘમાં";
  String get mainlabelStanding => "સ્ટેન્ડિંગ";
  String get mainlabelSitting => "બેઠા";
  String get mainlabelClickToStartActivity =>
      "પ્રવૃત્તિ શરૂ કરવા માટે ક્લિક કરો";
  String get mainlabelBMICalculator => "BMI કેલ્ક્યુલેટર";
  String get mainlabelBMRCalculator => "BMR કેલ્ક્યુલેટર";
  String get mainlabelDownloadActivityReportInCsv =>
      "csv માં પ્રવૃત્તિ રિપોર્ટ ડાઉનલોડ કરો";
  String get mainlabelSelectStartDate => "પ્રારંભ તારીખ પસંદ કરો";
  String get mainlabelSelectEndDate => "સમાપ્તિ તારીખ પસંદ કરો";
  String get mainlabelDownloadFile => "ફાઈલ ડાઉનલોડ";
  String get mainlabelDate => "તારીખ";
  String get mainlabelValue => "મૂલ્ય";
  String get mainlabelLink => "લિંક";
  String get mainlabelNoNotificationFound => "કોઈ સૂચના મળી નથી";
  String get mainlabelTotalNutritionTaken => "= લેવામાં આવેલ કુલ પોષણ";
  String get mainlabelSearchFood => "વાનગીઓ શોધો";
  String get mainlabelSelectFromPersonalFood =>
      "વ્યક્તિગત વાનગીઓમાંથી પસંદ કરો";
  String get mainlabelRecipeName => "રેસીપી નામ";
  String get mainlabelSelectDate => "તારીખ પસંદ કરો";
  String get mainlabelNutrientOfAllIngredientsRaw =>
      "તમામ ઘટકોના પોષક તત્વો (કાચા)";
  String get mainlabelNutrientsCompostionOfCookedWeight =>
      "માટે રાંધેલા વજનની પોષક રચના";
  String get mainlabelWantToEditThisRecipyFollowThe =>
      "આ રેસીપી સંપાદિત કરવા માંગો છો? અનુસરો";
  String get mainlabelAddIngredientFrom => "માંથી ઘટક ઉમેરો";
  String get mainlabelAddFromNutrientSpecifcFood =>
      "પોષક ચોક્કસ ખોરાકમાંથી ઉમેરો";
  String get mainlabelAddFromAllFoods => "બધા ખોરાકમાંથી ઉમેરો";
  String get mainlabelNumberOfServing => "સર્વિંગ્સની સંખ્યા";
  String get mainlabelWeightInG => "વજન (જી)";
  String get mainlabelEditIngredientsWeight => "ઘટકોનું વજન સંપાદિત કરો";
  String get mainlabelIngredient => "ઘટક";
  String get mainlabelNewWeightInG => "નવું વજન (g)";
  String get mainlabelCancel => "રદ કરો";
  String get mainlabelUpdate => "અપડેટ";
  String get mainlabelCookedWeightInG => "રાંધેલું વજન (જી)";
  String get mainlabelEnterWeight => "વજન દાખલ કરો";
  String get mainlabelEditRecipy => "રેસીપી સંપાદિત કરો";
  String get mainlabelAlert => "ચેતવણી";
  String get mainlabelToSeeNutritionCompositionPleaseEnterNoOfServing =>
      "પોષણની રચના જોવા માટે, કૃપા કરીને સર્વિંગ્સની સંખ્યા દાખલ કરો";
  String get mainlabelNutrirntsIn100CookedWeight =>
      "100 (રાંધેલા) વજનમાં પોષક તત્વો";
  String get mainlabelSetNutritionTargetInG =>
      "પોષણનું લક્ષ્ય ગ્રામમાં સેટ કરો";
  String get mainlabelFoodAnalyse => "અન્વેષણ કરો";
  String get mainlabelExploreTop10Foods => "ટોચના 10 ખોરાકનું અન્વેષણ કરો";
  String get mainlabelSearchCookedFood => "વાનગીઓમાં પોષક તત્વો શોધો";
  String get mainlabelNutritionBasedOnEAR =>
      "EAR પર આધારિત પોષક તત્ત્વોની જરૂરિયાત";
  String get mainlabelDietDiary => "આહાર ડાયરી";
  String get mainlabelRecipes => "વાનગીઓ";
  String get mainlabelSearchByFoodName => "ખોરાકના નામ દ્વારા શોધો";
  String get mainlabelAllRecipeOf100G => "100 ગ્રામની બધી રેસીપી";
  String get mainlabelNutritionRequirement => "પોષણની જરૂરિયાત";
  String get mainlabelGender => "લિંગ";
  String get mainlabelParticulars => "વિગતો";
  String get mainlabelBodyWeight => "શરીર નુ વજન";
  String get mainlabelDietaryDiaryReports => "પોષક તત્વોનું સેવન";
  String get mainlabelTotalNutritionTakenOn => "લેવામાં આવેલ કુલ પોષણ";
  String get mainlabelAttachImage => "છબી જોડો";
  String get mainlabelFixedRecipy => "સ્થિર રેસીપી";
  String get mainlabelFoodInDetail => "વિગતવાર ખોરાક";
  String get TextAppNutrientsInMyFood => "ખોરાકમાં પોષક તત્વો શોધો";
  String get TextAppMyActivity => "મારી પ્રવૃત્તિ";
  String get TextAppToday => "આજે";
  String get TextAppMyNutrientRequirements => "મારી પોષક જરૂરિયાતો";
  String get TextAppTotalNutrition => "કુલ પોષણ";
  String get TextAppTaken => "લીધેલ";
  String get TextAppRatings => "રેટિંગ્સ";
  String get TextAppSearchComponents => "ઘટકો શોધો";
  String get TextAppTotalNutrientTaken => "આજે મારા પોષક તત્વોનું સેવન";
  String get TextAppShareApp => "એપ શેર કરો";
  String get TextAppNoNotificationsFound => "કોઈ સૂચનાઓ મળી નથી";
  String get TextAppConnectWatch => "વોચ કનેક્ટ કરો";
  String get TextAppYourBMIIs => "તમારું BMI છે";
  String get TextAppBMI => "BMI";
  String get TextAppBMICategories => "BMI શ્રેણીઓ";
  String get TextAppUnderweight => "ઓછું વજન";
  String get TextAppNormal => "સામાન્ય";
  String get TextAppOverweight => "વધારે વજન";
  String get TextAppObesity => "સ્થૂળતા";
  String get TextAppSelectDate => "તારીખ પસંદ કરો";
  String get TextAppOxygen => "પ્રાણવાયુ";
  String get TextAppBlood => "લોહી";
  String get TextAppNoRecord => "કોઈ રેકોર્ડ નથી";
  String get TextAppAllExercise => "બધી કસરત";
  String get TextAppCleaningOrMopping => "સફાઈ અથવા મોપિંગ";
  String get TextAppGardening => "બાગકામ";
  String get TextAppWatchingTV => "ટીવી જોઉં છું";
  String get TextAppCycling => "સાયકલિંગ";
  String get TextAppRunning => "ચાલી રહી છે";
  String get TextAppWalking => "વૉકિંગ";
  String get TextAppShuttle => "શટલ";
  String get TextAppTableTennis => "ટેબલ ટેનિસ";
  String get TextAppTennis => "ટેનિસ";
  String get TextAppVolleyBall => "વોલી બોલ";
  String get TextAppDancing => "નૃત્ય";
  String get TextAppFishing => "માછીમારી";
  String get TextAppShopping => "શોપિંગ";
  String get TextAppTyping => "ટાઈપિંગ";
  String get TextAppSleeping => "ઊંઘમાં";
  String get TextAppStanding => "સ્ટેન્ડિંગ";
  String get TextAppSitting => "બેઠા";
  String get TextAppClickStartToStartActivity =>
      "પ્રવૃત્તિ શરૂ કરવા માટે પ્રારંભ પર ક્લિક કરો";
  String get TextAppCaloriesBurn => "કેલરી બળી ગઈ";
  String get TextAppAddDurationManually => "સમયગાળો જાતે ઉમેરો";
  String get TextAppStartOrMopping => "પ્રારંભ અથવા મોપિંગ";
  String get TextAppMale => "પુરુષ";
  String get TextAppFemale => "સ્ત્રી";
  String get TextAppWeightManager => "મારા શરીરના વજનને ટ્રૅક કરો";
  String get TextAppUpdateWeight => "અપડેટ વજન";
  String get TextAppSetWeightGoal => "વજનનું લક્ષ્ય નક્કી કરો";
  String get TextAppCurrentWeight => "અત્યારનું વજન";
  String get TextAppWeightProgress => "વજન પ્રગતિ";
  String get TextAppPrevious30Days => "પાછલા 30 દિવસ";
  String get TextAppYourWeightGoalIsSet => "તમારો ધ્યેય છે";
  String get TextAppMaintain => "જાળવી";
  String get TextAppInitialWeightOf => "પ્રારંભિક વજન";
  String get TextAppFinalWeightOf => "નવીનતમ વજન";
  String get TextAppWeight => "વજન";
  String get TextAppYouAreNotYetAchievingYourWeightGoalKeepGoing =>
      "તમે હજી સુધી તમારું વજન લક્ષ્ય હાંસલ કરી રહ્યાં નથી. ચાલુ રાખો!";
  String get TextAppYouAreAchievedYourWeightGoalKeepGoing =>
      "તમે તમારું વજન લક્ષ્ય પ્રાપ્ત કર્યું છે. ચાલુ રાખો!";
  String get TextAppAndYourWeightChangeIsSet => "અને તમારું વજન ફેરફાર સેટ છે";
  String get TextApp1NutrientsInMyFood => "મારા ખોરાકમાં પોષક તત્વો";
  String get TextAppSearchNutrientsInRawFoods =>
      "કાચા ખોરાકમાં પોષક તત્વો શોધો";
  String get TextAppRawIngredients => "કાચા ઘટકો";
  String get TextAppSearchRawFoodByName => "નામ દ્વારા કાચો ખોરાક શોધો";
  String get TextApp1MyActivity => "મારી પ્રવૃત્તિ અહેવાલ";
  String get TextAppCheckOthersDates => "અન્ય તારીખો તપાસો";
  String get TextAppYour24HoursChart => "તમારો 24 કલાકનો ચાર્ટ";
  String get TextAppActivity => "પ્રવૃત્તિ";
  String get TextAppOthers => "અન્ય";
  String get TextAppExerciseDetails => "વ્યાયામ વિગતો";
  String get TextAppActivityType => "પ્રવૃત્તિ પ્રકાર";
  String get TextAppDuration => "અવધિ";
  String get TextAppMyActivityOfCustomDates => "કસ્ટમ તારીખોની મારી પ્રવૃત્તિ";
  String get TextAppOurCustomerFeedback => "અમારા ગ્રાહક પ્રતિસાદ";
  String get TextAppOverallRatings => "એકંદરે રેટિંગ્સ";
  String get TextAppEnterCookedWeight => "રાંધેલ વજન દાખલ કરો";
  String get TextAppCookedWeightGram => "રાંધેલું વજન (ગ્રામ)";
  String get TextAppNutrientIn100gCooked => "100 ગ્રામ (રાંધેલા) માં પોષક";
  String get TextAppEnterServingSize => "સેવાનું કદ દાખલ કરો";
  String get TextAppSearchByRecipeName => "રેસીપી નામ દ્વારા શોધો";
  String get TextAppMyPersonalRecipe => "મારી અંગત રેસીપી";
  String get TextAppFixedRecipe => "સ્થિર રેસીપી";
  String get TextApp2NutrientsInMyFood => "મારા ખોરાકમાં પોષક તત્વો";
  String get TextAppMyDietDiary => "મારી ડાયટ ડાયરી";
  String get TextApp2MyActivity => "મારી પ્રવૃત્તિ";
  String get TextAppDownloadFile => "ફાઈલ ડાઉનલોડ";
  String get TextAppStartMyNewDietDiary => "મારી નવી ડાયટ ડાયરી શરૂ કરો";
  String get TextAppGoogle => "Google";
  String get TextAppFacebook => "ફેસબુક";
  String get TextAppLinkedin => "લિંક્ડિન";
  String get TextAppTwitter => "Twitter";
  String get TextAppContactUs => "અમારો સંપર્ક કરો";
  String get TextAppReportBug => "બગની જાણ કરો";
  String get TextAppAttachImage => "છબી જોડો";
  String get TextAppResetPassword => "પાસવર્ડ રીસેટ કરો";
  String get TextAppNINAppCreditsPage => "NIN એપ્લિકેશન ક્રેડિટ પૃષ્ઠ";
  String get NINTextOopsSomethingWentWrong => "અરે! કંઈક ખોટું થયું";
  String get NINTextPleaseEnterAllFields => "કૃપા કરીને તમામ ફીલ્ડ દાખલ કરો";
  String get NINTextSubmittedSuccessfully1 => "સફળતાપૂર્વક સબમિટ કર્યું";
  String get NINTextSubmittedSuccessfully2 => "સફળતાપૂર્વક સબમિટ કર્યું";
  String get NINTextFitbitAuthentication => "Fitbit પ્રમાણીકરણ";
  String get NINTextHours => "કલાક";
  String get NINTextMinutes => "મિનિટ";
  String get NINTextEnterDurationFor => "માટે અવધિ દાખલ કરો";
  String get NINTextTimerRunning => "ટાઈમર ચાલી રહ્યું છે";
  String get NINTextPleaseStopTheTimerBeforeSubmitting =>
      "સબમિટ કરતા પહેલા કૃપા કરીને ટાઈમર બંધ કરો";
  String get NINTextTotalDuration => "કુલ સમયગાળો";
  String get NINTextSec => "સેકન્ડ";
  String get NINTextStartYourActivity => "તમારી પ્રવૃત્તિ શરૂ કરો!";
  String get NINTextPause => "વિરામ";
  String get NINTextReset => "રીસેટ કરો";
  String get NINTextError => "ભૂલ";
  String get NINTextPleaseEnterCookedWeightAndServingSize =>
      "કૃપા કરીને રાંધેલા વજન અને સર્વિંગ સાઈઝ દાખલ કરો";
  String get NINTextEditIngredient => "ઘટક સંપાદિત કરો";
  String get NINTextAlert => "ચેતવણી";
  String get NINTextEnterWeightFor => "માટે વજન દાખલ કરો";
  String get NINTextNewWeightGram => "નવું વજન (g)";
  String get NINTextEditRecipeName => "રેસીપીનું નામ સંપાદિત કરો";
  String get NINTextNewRecipeName => "નવું રેસીપી નામ";
  String get NINTextSubmitted => "સબમિટ";
  String get NINTextSuccess => "સફળતા";
  String get NINTextDietaryDiaryReportSavedTo =>
      "ડાયેટરી ડાયરીનો રિપોર્ટ સાચવવામાં આવ્યો";
  String get NINTextErrorSavingFile => "ફાઇલ સાચવવામાં ભૂલ";
  String get NINTextClose => "બંધ";
  String get NINTextIWantTo => "હું ઇચ્છું છું";
  String get NINTextGain => "ગેઇન";
  String get NINTextMaintain => "જાળવી";
  String get NINTextLose => "હારવું";
  String get NINTextWeightChangeKg => "વજનમાં ફેરફાર (કિલો)";
  String get NINTextAddNewWeight => "નવું વજન ઉમેરો";
  String get NINTextEnterWeight => "વજન દાખલ કરો";
  String get NINTextOf100Gram => "100 ગ્રામ";
  String get NINTextProximateComposition => "નિકટવર્તી રચના";
  String get NINTextVitamins => "વિટામિન્સ";
  String get NINTextMinerals => "ખનીજ";
  String get NINTextTotalSaturatedFattyAcids => "કુલ સંતૃપ્ત ફેટી એસિડ્સ";
  String get NINTextAllRecipeOf100Grams => "100 ગ્રામની બધી રેસીપી";
  String get NINTextOurCustomerFeedback => "અમારા ગ્રાહક પ્રતિસાદ";
  String get NINTextOverallRatings => "એકંદરે રેટિંગ્સ";
  String get NINTextRateUs => "અમને રેટ કરો";
  String get NINTextBookDetails => "પુસ્તક વિગતો";
  String get NINTextOne => "એક";
  String get NINTextWeightOf => "wt ના";
  String get NINTextSelectStartDate => "પ્રારંભ તારીખ પસંદ કરો";
  String get NINTextSelectEndDate => "સમાપ્તિ તારીખ પસંદ કરો";
  String get NINTextNoData => "કોઈ ડેટા નથી";
  String get NINTextWorkLevel => "કાર્ય સ્તર";
  String get NINTextOldPassword => "જુનો પાસવર્ડ";
  String get NINTextNewPassword => "નવો પાસવર્ડ";
  String get NINTextUpdateProfile => "પ્રોફાઇલ અપડેટ કરો";
  String get NINTextChangeImage => "છબી બદલો";
  String get NINTextNoFavouriteFoodFound => "મનપસંદ ખોરાક મળ્યો નથી";
  String get NINTextCookedQuantity => "રાંધેલ જથ્થો";
  String get NINTextServingQuantity => "સેવા આપતા જથ્થો";
  String get NINTextNutrientInformation => "પોષક માહિતી";
  String get NINTextIngredient => "ઘટક";
  String get NINTextMealsTakenOn => "ભોજન લીધું";
  String get NINTextPercentage => "ટકાવારી";
  String get NINTextEAR => "કાન";
  String get NINTextValue => "મૂલ્ય";
  String get NINTextNutrient => "પોષક";
  String get NINTextEnergyKcal => "ઊર્જા (kcal)";
  String get NINTextProteinG => "પ્રોટીન (જી)";
  String get NINTextFatG => "ચરબી (જી)";
  String get NINTextCarbohydratesG => "કાર્બોહાઇડ્રેટ્સ (જી)";
  String get NINTextCalciumMg => "કેલ્શિયમ (એમજી)";
  String get NINTextFiberG => "ફાઇબર (જી)";
  String get NINTextIronMg => "આયર્ન (એમજી)";
  String get NINTextZincMg => "ઝીંક (એમજી)";
  String get NINTextMagnesiumMg => "મેગ્નેશિયમ (એમજી)";
  String get NINTextThiamineB1Mg => "થાઈમીન (B1) (mg)";
  String get NINTextRiboflavinB2Mg => "રિબોફ્લેવિન (B2) (mg)";
  String get NINTextNiacinB3Mg => "નિયાસિન (B3) (mg)";
  String get NINTextFolatesB9Mcg => "ફોલેટ્સ (B9) (mcg)";
  String get NINTextRetinolVitAMcg => "વિટામિન એ (એમસીજી)";
  String get VitaminCmg => "વિટામિન સી (એમજી)";
  String get Iodinemcg => "આયોડિન (એમસીજી)";
  String get serving => "સેવા આપવી";
  String get Mynutritionstatus => "મારા પોષણની સ્થિતિ";

  String get ninTextMyHealthStatus => 'માય હેલ્થ સ્ટેટસ';
  String get ninTextNutrientsInRawFoods => 'કાચા ખોરાકમાં પોષક તત્વો';
  String get ninTextNutrientsInRecipes => 'વાનગીઓમાં પોષક તત્વો';
  String get ninTextIcmrNinMyPlateForTheDay => 'ICMR-NIN દિવસ માટે મારી પ્લેટ';
  String get ninTextToday => 'આજે';
  String get ninTextTrackMyActivity => 'મારી પ્રવૃત્તિને ટ્રૅક કરો';
  String get ninTextMyHeartRate => 'મારા હૃદયના ધબકારા';
  String get ninTextMyWaterIntake => 'મારું પાણીનું સેવન';
  String get ninTextSleepTracker => 'સ્લીપ ટ્રેકર';
  String get ninTextLit => 'લિટ';
  String get ninTextRecordMyBloodPressure =>
      'મારું બ્લડ પ્રેશર / બ્લડ ગ્લુકોઝ / SPO2 રેકોર્ડ કરો';
  String get ninTextNutritionEducationContent => 'પોષણ શિક્ષણ સામગ્રી';
  String get ninTextMyNutrientIntake => 'મારા પોષક ઇન્ટેક';
  String get ninTextOn => 'પર';
  String get ninTextWithReferenceToEAR => 'EAR ના સંદર્ભમાં';
  String get ninTextAchieveYourHealthGoals =>
      'તમારા સ્વાસ્થ્ય લક્ષ્યો હાંસલ કરો';
  String get ninTextPercentage => 'ટકાવારી';
  String get ninTextMyPreviousDietDiaries => 'મારી પાછલી ડાયટ ડાયરી';
  String get ninTextRecordReviewSleep => 'નોંધ / સમીક્ષા ઊંઘ';
  String get ninTextHours => 'કલાક';
  String get ninTextIngredient => 'ઘટક';
  String get ninTextOthersSpecify => 'અન્ય સ્પષ્ટ કરે છે';
  String get ninTextAddNewIngredient => 'નવું ઘટક ઉમેરો';
  String get ninTextFoodName => 'ખોરાકનું નામ';
  String get ninTextSource => 'સ્ત્રોત';
  String get ninTextEnterBrandAndProductName =>
      'બ્રાન્ડ અને ઉત્પાદન નામ દાખલ કરો';
  String get ninTextEnterAuthorDetails =>
      'લેખકનું નામ, વર્ષ, જર્નલ, પૃષ્ઠ દાખલ કરો';
  String get ninTextEnterFctName => 'FCT નું નામ દાખલ કરો';
  String get ninTextName => 'નામ';
  String get ninTextProductName => 'ઉત્પાદન નામ';
  String get ninTextSelectStartDate => 'પ્રારંભ તારીખ પસંદ કરો';
  String get ninTextSelectEndDate => 'સમાપ્તિ તારીખ પસંદ કરો';
  String get ninTextNoExercise => 'કોઈ કસરત નથી';
  String get ninTextDevelopedWithExpertiseAndInputs =>
      'સેન્ટર ફોર ડેવલપમેન્ટ એન્ડ એડવાન્સ કોમ્પ્યુટીંગ (C-DAC), હૈદરાબાદ લેંગ્વેજ લિંક દ્વારા NIN ની કુશળતા અને ઇનપુટ્સ સાથે વિકસિત';
  String get ninTextMyNutrientIntakeToday => 'આજે મારા પોષક તત્વોનું સેવન';
  String get ninTextIcmrNationalInstituteOfNutritionAddress =>
      'ICMR - તરનાકા મેટ્રો સ્ટેશનની બાજુમાં નેશનલ ઇન્સ્ટિટ્યૂટ ઑફ ન્યુટ્રિશન, જમાઈ-ઓસ્માનિયા પીઓ, હૈદરાબાદ-500 007, ભારત.';

  String get ninTextKcal => 'kcal';
  String get ninTextKcalPerDay => 'kcal/દિવસ';
  String get ninTextDelete => 'કાઢી નાખો';
  String get ninTextDeleteNotification => 'સૂચના કાઢી નાખો';
  String get ninTextConfirmDeleteNotification =>
      'શું તમે ખરેખર આ સૂચના કાઢી નાખવા માંગો છો?';
  String get ninTextTimeFor => 'અરે, તે\'s time for';
  String get ninTextFitbitWatch => 'Fitbit ઘડિયાળ';
  String get ninTextGoogleFitApp => 'Google Fit એપ્લિકેશન';
  String get ninTextUnderweight => 'ઓછું વજન';
  String get ninTextNormal => 'સામાન્ય';
  String get ninTextOverweight => 'વધારે વજન';
  String get ninTextObesity => 'સ્થૂળતા';
  String get ninTextMale => 'પુરુષ';
  String get ninTextFemale => 'સ્ત્રી';
  String get ninTextAgeInYears => 'વર્ષોમાં ઉંમર';
  String get ninTextChangeInWeight => 'વજનમાં ફેરફાર';
  String get ninTextSteps => 'પગલાં';
  String get ninTextFor => 'માટે';
  String get ninTextMinutes => 'મિનિટ';
  String get ninTextPause => 'વિરામ';
  String get ninTextReset => 'રીસેટ કરો';
  String get ninTextStartActivity => 'તમારી પ્રવૃત્તિ શરૂ કરો';
  String get ninTextCartIsEmpty => 'તમારું ટોપલું ખાલી છે';
  String get ninTextMyPersonalRecipe => 'મારી અંગત રેસીપી';
  String get ninTextSearchByRecipeName => 'રેસીપી નામ દ્વારા શોધો';
  String get ninTextHelpCenter => 'મદદ કેન્દ્ર';
  String get ninTextCommonProblems => 'સામાન્ય સમસ્યાઓ';
  String get ninTextFAQs => 'FAQs';
  String get ninTextHowActiveAreYou => 'તમે કેટલા સક્રિય છો';
  String get ninTextVitaminC => 'વિટામિન સી (એમજી)';
  String get ninTextVitaminA => 'વિટામિન A (IU)';
  String get ninTextSodium => 'સોડિયમ (એમજી)';
  String get ninTextJournal => 'જર્નલ';
  String get ninTextPage => 'પાનું';
  String get ninTextAdequateIntakeCarbs =>
      '*કાર્બોહાઇડ્રેટ્સ માટે પૂરતા પ્રમાણમાં સેવન (AI) ભલામણ કરેલ: પુખ્ત પુરુષો અને સ્ત્રીઓ માટે 130 ગ્રામ.';
  String get ninTextAdequateIntakeFiber =>
      '**એઆઈ ફાઈબર માટે ભલામણ કરેલ: સ્ત્રીઓ માટે 25 ગ્રામ અને પુરુષો માટે 38 ગ્રામ.';
  String get your => 'તમારા';
  String get question1 => 'શું હું મારી અંગત વિગતોમાં ફેરફાર કરી શકું?';
  String get answer1 =>
      'હા. તમારો વ્યક્તિગત ડેટા તમારી પ્રોફાઇલમાં સંપાદિત કરી શકાય છે.';
  String get linkText1 => 'તમારી અંગત વિગતો સંપાદિત કરવા માટે અહીં ક્લિક કરો';

  String get question2 => 'શું હું મારી સંપર્ક વિગતો બદલી શકું?';
  String get answer2 =>
      'હા. તમારી પ્રોફાઇલમાં ‘પર્સનલ ડેટા’ વિકલ્પ પર જઈને તમારી સંપર્ક વિગતો બદલી શકાય છે.';
  String get linkText2 => 'તમારી સંપર્ક વિગતો સંપાદિત કરવા માટે અહીં ક્લિક કરો';

  String get question3 => 'શું હું મારો વપરાશકર્તા પાસવર્ડ બદલી શકું?';
  String get answer3 =>
      'હા. તમારી પ્રોફાઇલમાં ‘સેટિંગ’ વિકલ્પ પર જઈને તમારો પાસવર્ડ બદલી શકાય છે.';
  String get linkText3 => 'તમારો પાસવર્ડ બદલવા માટે અહીં ક્લિક કરો';

  String get question4 => 'હું મારો BMI કેવી રીતે તપાસી શકું?';
  String get answer4 =>
      'હોમ પેજમાં પ્રદર્શિત ‘હેલ્થ કેલ્ક્યુલેટર’ વિકલ્પમાં આપેલા ‘BMI કેલ્ક્યુલેટર’માં તમારી ઊંચાઈ અને શરીરનું વજન દાખલ કરીને તમે તમારો BMI ચકાસી શકો છો.';
  String get linkText4 => 'BMI કેલ્ક્યુલેટરનો ઉપયોગ કરવા માટે અહીં ક્લિક કરો';

  String get question5 => 'શું હું છેલ્લા મહિના માટે મારું વજન ટ્રૅક કરી શકું?';
  String get answer5 =>
      'હા. તમે હોમ પેજમાં આપેલા ‘વેઈટ મેનેજર’ વિકલ્પમાં છેલ્લા મહિના/વર્ષમાં તમારા શરીરના વજનમાં થયેલા ફેરફારોની વિગતો જોઈ શકો છો.';
  String get linkText5 => 'તમારું વજન ટ્રૅક કરવા માટે અહીં ક્લિક કરો';

  String get question6 =>
      'હું કોઈ ચોક્કસ દિવસે મારી એકંદર શારીરિક પ્રવૃત્તિ કેવી રીતે તપાસી શકું?';
  String get answer6 =>
      'તમે હોમ પેજમાં ‘મારી પ્રવૃત્તિ’ વિકલ્પમાંથી તમારી શારીરિક પ્રવૃત્તિને ટ્રૅક કરી શકો છો.';
  String get linkText6 => 'તમારી પ્રવૃત્તિ જોવા માટે અહીં ક્લિક કરો';

  String get question7 =>
      'હું પાણીના સેવન માટે રીમાઇન્ડર કેવી રીતે સેટ કરી શકું?';
  String get answer7 =>
      "તમે હોમ પેજમાં આપેલા 'સેટ નોટિફિકેશન' વિકલ્પમાં પાણીના સેવનના રિમાઇન્ડર માટે સમય સેટ કરી શકો છો.";
  String get linkText7 => 'પાણી લેવાનું રીમાઇન્ડર સેટ કરવા માટે અહીં ક્લિક કરો';

  String get question8 =>
      'હું એપ્લિકેશનને મારી સ્માર્ટ ઘડિયાળ સાથે કેવી રીતે એકીકૃત કરી શકું?';
  String get answer8 =>
      'હોમ પેજમાં આપેલા ‘કનેક્ટ વોચ’ વિકલ્પ પર જઈને તમે તમારી સ્માર્ટ ઘડિયાળને એપ સાથે એકીકૃત કરી શકો છો.';
  String get linkText8 =>
      'તમારી સ્માર્ટ ઘડિયાળને કનેક્ટ કરવા માટે અહીં ક્લિક કરો';

  String get question9 => 'હું એક સમયે કેટલા વેરેબલ એપ સાથે એકીકૃત કરી શકું?';
  String get answer9 =>
      'તમે એપ્લિકેશન સાથે Fitbit ઘડિયાળ અને Google Fit ને એકીકૃત કરી શકો છો.';
  String get linkText9 => '';

  String get question10 => 'કઈ સ્માર્ટ ઘડિયાળો એપ સાથે સુસંગત છે?';
  String get answer10 => 'Fitbit ઘડિયાળ અને Google Fit.';
  String get linkText10 => '';

  String get question11 =>
      'જો મારી પાસે સ્માર્ટ ઘડિયાળ ન હોય તો શું હું મારી પ્રવૃત્તિને ટ્રૅક કરી શકું?';
  String get answer11 =>
      'હા, તમે તમારી પ્રવૃત્તિને ટ્રૅક કરી શકો છો. તેના માટે, તમારે Google Fit એપ્લિકેશન ડાઉનલોડ કરવાની, Google એકાઉન્ટ વડે સાઇન ઇન કરવાની અને તે જ Google એકાઉન્ટથી, તમારે અમારા ઘડિયાળ વિભાગમાં લૉગ ઇન કરવાની જરૂર છે.';
  String get linkText11 => '';

  String get question12 => 'હું મારી ઊંઘને ​​કેવી રીતે ટ્રેક કરી શકું?';
  String get answer12 =>
      'હોમ પેજમાં આપેલા સ્લીપ ટ્રેકર વિકલ્પ પર જઈને તમે સાપ્તાહિક/માસિક ધોરણે તમારી ઊંઘને ​​ટ્રૅક કરી શકો છો.';
  String get linkText12 => 'તમારી ઊંઘ ટ્રૅક કરવા માટે અહીં ક્લિક કરો';

  String get question13 =>
      'હું એપ્લિકેશન દ્વારા કોઈપણ NIN પ્રકાશન કેવી રીતે ખરીદી શકું?';
  String get answer13 =>
      'તમે હોમ પેજમાં આપેલા ‘બુક સ્ટોર’ વિકલ્પમાંથી NIN પ્રકાશનો ખરીદી શકો છો.';
  String get linkText13 => 'બુક સ્ટોરની મુલાકાત લેવા માટે અહીં ક્લિક કરો';

  String get question14 =>
      'હું મારી વ્યક્તિગત આહાર ડાયરી કેવી રીતે બનાવી શકું?';
  String get answer14 =>
      'તમે ‘માય ડાયેટ ડાયરી ઓપ્શન’ પર જઈને આખા દિવસમાં ખાધેલા ખોરાકની વિગતો દાખલ કરી શકો છો.';
  String get linkText14 => 'તમારી ડાયેટ ડાયરી બનાવવા માટે અહીં ક્લિક કરો';

  String get question15 =>
      'હું એવી રેસીપી કેવી રીતે શોધી શકું જે ચોક્કસ પોષક તત્વોથી સમૃદ્ધ હોય?';
  String get answer15 =>
      'તમે સૌપ્રથમ હોમ પેજમાં ‘મારા ખોરાકમાં પોષક તત્વો’ ટેબમાં આપેલ ‘રેસીપીમાં પોષક તત્ત્વો શોધો’ વિકલ્પ પસંદ કરી શકો છો. પછી ઉપરના જમણા ખૂણે ડ્રોપ-ડાઉન સૂચિમાંથી જરૂરી પોષક તત્વો પસંદ કરો.';
  String get linkText15 => 'રેસિપી શોધવા માટે અહીં ક્લિક કરો';

  String get question16 =>
      'પાછલા મહિને સાચવેલ એક દિવસ માટે હું મારા પોષક તત્વોનું સેવન કેવી રીતે તપાસી શકું?';
  String get answer16 =>
      "તમે 'ભોજન સૂચિ' પૃષ્ઠમાં 'કૅલેન્ડર આઇકન'માંથી તારીખ પસંદ કરીને ચોક્કસ દિવસે તમારા પોષક તત્વોનું સેવન જોઈ શકો છો.";
  String get linkText16 =>
      'તમારા પોષક તત્વોનું સેવન તપાસવા માટે અહીં ક્લિક કરો';

  String get question17 =>
      'મારી વાનગીઓમાં વપરાતા કાચા ઘટકોમાંના પોષક તત્વો હું કેવી રીતે શોધી શકું?';
  String get answer17 =>
      "તમે હોમ પેજમાં 'મારા ખોરાકમાં પોષક તત્વો' ટેબમાં આપેલા 'કાચા ખોરાકમાં પોષક તત્ત્વો શોધો' વિકલ્પ પસંદ કરીને ચોક્કસ ઘટકમાંના પોષક તત્ત્વોને જાણી શકો છો.";
  String get linkText17 => 'કાચા ખોરાકમાં પોષક તત્વો શોધવા માટે અહીં ક્લિક કરો';

  String get question18 => 'હું રેસીપીની પોષક રચના કેવી રીતે જાણી શકું?';
  String get answer18 =>
      "તમે હોમ પેજમાં 'મારા ખોરાકમાં પોષક તત્વો' ટેબમાં આપેલા 'રેસીપીમાં પોષક તત્ત્વો શોધો' વિકલ્પ પસંદ કરીને ચોક્કસ ઘટકમાંના પોષક તત્વોને જાણી શકો છો.";
  String get linkText18 => 'પોષક તત્વોની રચના જાણવા માટે અહીં ક્લિક કરો';

  String get question19 =>
      'શું હું નવી રેસીપીનો સમાવેશ કરી શકું છું જે એપ્લિકેશનમાં ઉપલબ્ધ નથી?';
  String get answer19 =>
      "હા. તમે ચોક્કસ નિશ્ચિત રેસીપીના તળિયે આપેલી લિંકનો ઉપયોગ કરીને હાલની રેસીપીમાં ફેરફાર કરી શકો છો અથવા ડાયેટ ડાયરીના પેજમાં દરેક ભોજન માટે આપવામાં આવેલ 'કસ્ટમ ડીશ બનાવો' વિકલ્પ પર ક્લિક કરીને સંપૂર્ણપણે નવી રેસીપી બનાવી શકો છો.";
  String get linkText19 => 'કસ્ટમ રેસીપી બનાવવા માટે અહીં ક્લિક કરો';

  String get question20 =>
      'શું હું ચોક્કસ સ્વાસ્થ્ય સ્થિતિ માટે આહારની ભલામણો મેળવી શકું?';
  String get answer20 =>
      'હા. તમે હોમ પેજમાં ‘સર્ચ કમ્પોનન્ટ’ વિકલ્પમાંથી આરોગ્ય ભલામણો અથવા આહાર ચાર્ટ માર્ગદર્શિકા મેળવી શકો છો.';
  String get linkText20 => 'આહારની ભલામણો મેળવવા માટે અહીં ક્લિક કરો';

  String get question21 =>
      'શું હું એપનો ઉપયોગ અંગ્રેજી સિવાયની ભાષામાં કરી શકું?';
  String get answer21 =>
      "હા. તમે તમારી પ્રોફાઇલમાં આપેલા 'સેટિંગ' વિકલ્પમાંથી ઇચ્છિત ભાષા પસંદ કરી શકો છો.";
  String get linkText21 => 'ભાષા બદલવા માટે અહીં ક્લિક કરો';

  String get ninTextBmiHwading => 'બોડી માસ ઇન્ડેક્સ (BMI):';
  String get ninTextBmiDiscription =>
      'BMI એ વ્યક્તિના વજનને કિલોગ્રામમાં વ્યક્તિની ઊંચાઈના વર્ગ દ્વારા મીટર (kg/m2) માં ભાગ્યા તરીકે વ્યાખ્યાયિત કરવામાં આવે છે. BMI શ્રેણીઓ શરીરની અતિશય ચરબીના રોગ અને મૃત્યુ પર પડેલી અસર પર આધારિત છે અને વ્યાજબી રીતે એડિપોઝીટી સાથે સંબંધિત છે. BMI રોગના જોખમ સૂચક તરીકે વિકસાવવામાં આવ્યો હતો; જેમ જેમ BMI વધે છે, તેમ કેટલાક રોગોનું જોખમ પણ વધે છે. વધારે વજન અને સ્થૂળતા સંબંધિત કેટલીક સામાન્ય પરિસ્થિતિઓમાં આનો સમાવેશ થાય છે: અકાળ મૃત્યુ, કાર્ડિયોવેસ્ક્યુલર રોગો, હાઈ બ્લડ પ્રેશર, અસ્થિવા, કેટલાક કેન્સર અને ડાયાબિટીસ.';
  String get ninTextbminutritionsta => 'BMI પોષણ સ્થિતિ';
  String get ninTextNutritionstat => 'પોષણની સ્થિતિ';
  String get ninTextBelow => 'નીચે';
  String get ninTextPreobesity => 'પૂર્વ-સ્થૂળતા';

  String get ninTextbesity => 'સ્થૂળતા વર્ગ I';
  String get ninTextbesity2 => 'સ્થૂળતા વર્ગ II';
  String get ninTextbesity3 => 'સ્થૂળતા વર્ગ III';
  String get ninTextBMRfull => 'બેસલ મેટાબોલિક રેટ (BMR)';
  String get ninTextBMRDiscription =>
      'બેસલ મેટાબોલિક રેટ (BMR) એ દર છે કે જેના પર વ્યક્તિ આરામ કરતી વખતે ઊર્જાનો વ્યય કરે છે';
  String get ninTextPreviousdays => 'પાછલા 30 દિવસ';
  String get ninTextason => 'પર તરીકે';
  String get ninTextYearly => 'વાર્ષિક';
  String get moisture => "ભેજ";
  String get indianFoodCompositionTitle => "ભારતીય ખોરાક રચના ટેબલ્સ (૨૦૧૭)";

  String get indianFoodCompositionDescription =>
      "ભારતીય ખોરાક રચના ટેબલ્સ (૨૦૧૭): ભારતીય ખોરાક માટે વ્યાપક પોષણ માહિતી.";

  String get ninTextabove => 'ઉપર';
  String get ninTextAchieveyourhealthgoal =>
      'તમારું સ્વાસ્થ્ય લક્ષ્ય હાંસલ કરો';
  String get recordMyDiet => "મારો આહાર નોંધો";

  String get heavyDescription =>
      'આ કેટેગરીમાં દરરોજ એક કલાકથી વધુ સમય માટે દોડવું, સાયકલ ચલાવવું અથવા ભારે લિફ્ટિંગ જેવી નિયમિત અને તીવ્ર શારીરિક પ્રવૃત્તિનો સમાવેશ થાય છે. ઉદાહરણોમાં લુહાર, ખાણિયો અને બાંધકામ કામદારોનો સમાવેશ થાય છે.';
  String get moderateDescription =>
      'આ શ્રેણીની વ્યક્તિઓ દરરોજ લગભગ 30 મિનિટથી એક કલાક સુધી ચાલવા અથવા હળવા જોગિંગ જેવી કેટલીક શારીરિક પ્રવૃત્તિમાં વ્યસ્ત રહે છે. મેન્યુઅલ મજૂર, કારીગરો અને અમુક પ્રકારના કુશળ કામદારો જેવા વ્યવસાયો આ શ્રેણીમાં આવે છે.';
  String get sedentaryDescription =>
      'આ કેટેગરીમાં એવા વ્યવસાયોનો સમાવેશ થાય છે જેમાં દિવસભર શારીરિક હલનચલન ન હોય. આ નોકરીઓમાં લોકો તેમનો મોટાભાગનો સમય બેસીને અથવા સૂવામાં વિતાવે છે. ઉદાહરણોમાં ઓફિસ વર્કર્સ, શિક્ષકો અને વહીવટી ભૂમિકામાં રહેલા લોકોનો સમાવેશ થાય છે.';
  String get Foodprotein => "પ્રોટીન";
  String get Foodfat => "ચરબી";
  String get Foodenergy => "ઉર્જા";
  String get FoodtotalB2 => "કુલ B2";
  String get Foodvitamins => "વિટામિન્સ";
  String get FoodtotalFat => "કુલ ચરબી";
  String get FoodproximateComposition => "નિકટવર્તી રચના";
  String get FoodnutrientsIn100g => "100 ગ્રામમાં પોષક તત્વો";
  String get FoodtotalCarotenoids => "કુલ કેરોટીનોઇડ્સ";
  String get FoodtotalAscorbicAcid => "કુલ એસ્કોર્બિક એસિડ";
  String get FoodtotalB9 => "કુલ B9";
  String get FoodtotalB6 => "કુલ B6";
  String get Foodcalcium => "કેલ્શિયમ";
  String get Foodsodium => "સોડિયમ";
  String get Foodpotassium => "પોટેશિયમ";
  String get Foodzinc => "ઝીંક";
  String get Foodiron => "લોખંડ";
  String get Foodminerals => "ખનીજ";
  String get FoodtotalSaturatedFattyAcids => "કુલ સંતૃપ્ત ફેટી એસિડ્સ";
  String get FoodfattyAcids => "ફેટી એસિડ્સ";
  String get FoodtotalDietaryFiber => "કુલ ડાયેટરી ફાઇબર";
  String get Foodmanganese => "મેંગેનીઝ";
  String get Foodcopper => "કોપર";
  String get Foodselenium => "સેલેનિયમ";
  String get Foodmagnesium => "મેગ્નેશિયમ";
  String get Foodphosphorus => "ફોસ્ફરસ";
  String get Foodcholesterol => "કોલેસ્ટ્રોલ";
  String get Foodcarbohydrate => "કાર્બોહાઇડ્રેટ";
  String get FoodvitaminB6 => "વિટામિન B6 (mg)";
  String get Punjabi => "પંજાબી";
  String get Gujarati => "ગુજરાતી";
  String get Odia => "ઓડિયા";
  String get Kannada => "કન્નડ";
  String get Marathi => "મરાઠી";
  String get Tamil => "તમિલ";
  String get Bengali => "બંગાળી";
  String get Telugu => "તેલુગુ";
  String get English => "અંગ્રેજી";
  String get Hindi => "હિન્દી";
  String get firstname => "પ્રથમ નામ";
  String get lastname => "છેલુ નામ";
  String get labelSodium => "સોડિયમ";
  String get labelVitaminC => "વિટામિન C";
  String get FinanameEnergy => "ઊર્જા";
  String get FinanameCarbohydrate => "કાર્બોહાઇડ્રેટ";
  String get FinanameFat => "ચરબી";
  String get FinanameSodium => "સોડિયમ";
  String get FinanameDietaryFibre => "આહાર ફાઇબર";
  String get FinanameCalcium => "કેલ્શિયમ";
  String get FinanameIron => "લોહ";
  String get FinanameMagnesium => "મેગ્નેશિયમ";
  String get FinanameZinc => "ઝીંક";
  String get FinanameProtein => "પ્રોટીન";
  String get FinanameThiamine => "થાયમિન";
  String get FinanameRiboflavin => "રાઇબોફ્લેવિન";
  String get FinanameNiacin => "નાયાસિન";
  String get FinanameVitaminB => "વિટામિન B";
  String get FinanameFolate => "ફોલેટ";
  String get FinanameVitaminC => "વિટામિન C";
  String get FinanameVitaminA => "વિટામિન A";
  String get FinanameVitaminb6 => "વિટામિન B6";
  String get confirmDeleteAllNotifications =>
      "શું તમે ખરેખર બધી સૂચનાઓ કાઢી નાખવા માંગો છો?";
  String get fillAllFields => "કૃપા કરીને તમામ ફિલ્ડ્સ ભરો";
  String get successfullyAddedIngredient => "ઘટક સફળતાપૂર્વક ઉમેરાયો";
  String get confirmDeletion => "કાઢી નાખવા માટે ખાતરી કરો";
  String get confirmDeleteIngredient =>
      "શું તમે ખરેખર આ ઘટક કાઢી નાખવા માંગો છો?";
  String get fileDownloaded => "ફાઇલ સફળતાપૂર્વક ડાઉનલોડ કરી અને ફાઇલનું સ્થાન";
  String get confirmDeleteFood => "શું તમે ખરેખર આ ખોરાક કાઢી નાખવા માંગો છો?";
  String get estimatedAverageRequirement =>
      'અંદાજિત સરેરાશ આવશ્યકતા (EAR): 50% સ્વસ્થ વ્યક્તિઓની જરૂરિયાતો પૂરી કરવા માટે અંદાજિત દરરોજ લેવલ';
  String get editQuantity => "જથ્થો સંપાદિત કરો";
  String get confirmDelete => "શું તમે ખરેખર કાઢી નાખવા માંગો છો?";
  String get exerciseDeleted => "વ્યાયામ સફળતાપૂર્વક કાઢી નાખ્યો.";
  String get confirmDeleteExercise =>
      "શું તમે ખરેખર આ વ્યાયામ કાઢી નાખવા માંગો છો?";
  String get EssentialNutritionalGuidelines =>
      "ભારતીયોના આહારની જરૂરિયાતો માટે અનુકૂળ અતિઆવશ્યક પોષણ માર્ગદર્શિકાઓ.";
  String get NutrientRequirementsRDA2020 =>
      "ભારતીયો માટે પોષક તત્ત્વોની જરૂરિયાતો અને ભલામણ કરેલા આહાર ભથ્થા (RDA 2020).";
  String get RecommendationsBalancedDiets =>
      "ભારતમાં સંતુલિત આહાર અને સ્વસ્થ ખાવાના માવજત માટે ભલામણો.";
  String get DietaryGuidelinesForIndians => "ભારતીયો માટે આહાર માર્ગદર્શિકા.";
  String get Nutritionstat => "પોષણ આંકડાકીય";
  String get referenceMen65kg => "સંદર્ભ પુરુષો (65 કિગ્રા)";
  String get referenceWomen55kg => "સંદર્ભ સ્ત્રીઓ (55 કિગ્રા)";
  String get valueForMen => "1506";
  String get valueForWomen => "1184";
  String get referenceMenWomenDescription =>
      "સંદર્ભ પુરુષો અને મહિલાઓ સ્વસ્થ પુખ્ત એવા હોય છે જે 19-39 વર્ષના હોય છે, જેમનું બીએમઆઈ સામાન્ય હોય છે અને જેઓ મધ્યમ રીતે સક્રિય હોય છે (ICMR-NIN). જુઓ";
  String get personalizedDietDiaryDescription =>
      "વ્યક્તિગત ડાયેટ ડાયરી તમારી પોષક તત્વોનું ગ્રહણ વર્તમાનથી ગયા મહિના સુધી ટ્રેક કરે છે";
}
