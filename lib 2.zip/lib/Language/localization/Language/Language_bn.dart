// LanguageBn.dart
import 'languages.dart';

class LanguageBn extends Languages {
  String get inputActivityDataPrompt =>
      "আপনার শক্তি ব্যয় এবং ভারসাম্য দেখতে, অনুগ্রহ করে ২৪-ঘণ্টার কার্যকলাপের তথ্য দিন।";
  String get myEnergyBalanceYesterday => "আমার শক্তি ভারসাম্য (গতকাল)";
  String get caloriesBurnFromWatch => "ঘড়ি থেকে পোড়ানো ক্যালোরি";
  String get activities => "কার্যকলাপ";
  String get searchActivityHere => "এখানে কার্যকলাপ খুঁজুন";
  String get orSelectActivityFromBelow =>
      "অথবা নিচ থেকে কার্যকলাপ নির্বাচন করুন";
  String get recordMyDiet => "আমার ডায়েট রেকর্ড করুন";
  String get moisture => "আর্দ্রতা";
  String get indianFoodCompositionTitle => "ভারতীয় খাদ্য রচনা টেবিল (২০১৭)";

  String get indianFoodCompositionDescription =>
      "ভারতীয় খাদ্য রচনা টেবিল (২০১৭): ভারতীয় খাবারের জন্য ব্যাপক পুষ্টি সম্পর্কিত তথ্য।";

  @override
  String get appName => "NIN2.0";
  String get energybalance => "শক্তি ভারসাম্য";
  String get indicatorhealth =>
      "('+' শক্তির অতিরিক্ততা নির্দেশ করে; '-' শক্তির ঘাটতি নির্দেশ করে)";
  String get tryLater => "পরে চেষ্টা করুন";
  @override
  String get labelWelcome => "স্বাগত";
  String get totalEnergyConsumption => "মোট শক্তি ব্যয়";
  String get totalEnergyExpenditure => "মোট শক্তি ব্যয়ের";

  @override
  String get labelSelectLanguage => "ভাষা নির্বাচন কর";

  @override
  String get labelInfo => "এটি বহু-ভাষা ডেমো অ্যাপ্লিকেশন";

  @override
  // TODO: implement labelChangeLanguage
  String get labelChangeLanguage => "ভাষা পরিবর্তন করুন";
  @override
  String get labelWelcomeBack => "ফিরে আসার জন্য স্বাগতম,";

  @override
  String get labelUnderweight => "আপনার ওজন কম";

  @override
  String get labelNormalWeight => "আপনার ওজন স্বাভাবিক";

  @override
  String get labelOverweight => "আপনার ওজন বেশি";

  @override
  String get labelObese => "আপনি মোটা";

  @override
  String get labelViewMore => "আরো দেখুন";

  @override
  String get labelTodaySteps => "আজকের পদক্ষেপ";

  @override
  String get labelCheck => "চেক করুন";

  @override
  String get labelHealthData =>
      "আমার রক্তচাপ / রক্তের গ্লুকোজ / SPO2 রেকর্ড করুন";

  @override
  String get labelActivityStatus => "কার্যকলাপ অবস্থা";

  @override
  String get labelHeartRate => "হৃদ কম্পন";

  @override
  String get labelHeartRateValue => "78 BPM";

  @override
  String get labelMinutesAgo => "মিনিট আগে";

  @override
  String get labelWaterIntake => "আমার জল গ্রহণ";

  @override
  String get labelLiters => "লিটার";

  @override
  String get labelZeroLiters => "0 লিটার";

  @override
  String get labelRealTimeGoal => "বাস্তব সময়, লক্ষ্য";

  @override
  String get labelCalories => "ক্যালোরি পোড়া";

  @override
  String get labelCaloriesEarned => "ক্যালোরি অর্জিত";

  @override
  String get labelFoodPlan => "খাদ্য পরিকল্পনা";

  @override
  String get labelWorkoutProgress => "ওয়ার্কআউট অগ্রগতি";

  @override
  String get labelWeekly => "সাপ্তাহিক";

  @override
  String get labelMonthly => "মাসিক";

  @override
  String get labelLatestWorkout => "সর্বশেষ ওয়ার্কআউট";

  @override
  String get labelSeeMore => "আরো দেখুন";
  String get labelBreakfast => "সকালের নাস্তা";
  String get labelLunch => "মধ্যাহ্নভোজ";
  String get labelDinner => "রাতের খাবার";
  String get labelSnacks => "স্ন্যাকস";
  String get labelTaken => "নেওয়া হয়েছে";
  String get labelTarget => "টার্গেট";

  //profile

  String get labelProfile => "প্রোফাইল";
  String get labelEdit => "সম্পাদনা করুন";
  String get labelUser => "ব্যবহারকারী";
  String get labelProgram => "একটি চর্বি প্রোগ্রাম হারান";
  String get labelHeight => "উচ্চতা";
  String get labelWeight => "ওজন";
  String get labelAge => "বয়স";
  String get labelAccount => "হিসাব";
  String get labelPersonalData => "ব্যক্তিগত তথ্য";
  String get labelAchievement => "অর্জন";
  String get labelActivityHistory => "কার্যকলাপ ইতিহাস";
//String get labelWorkoutProgress => "ওয়ার্কআউট অগ্রগতি";
  String get labelNotification => "বিজ্ঞপ্তি";
  String get labelPopupNotification => "পপআপ বিজ্ঞপ্তি";
  String get labelMensurationCycle => "চক্র পরিমাপ";
  String get labelOther => "অন্যান্য";
  String get labelContactUs => "যোগাযোগ করুন";
  String get labelPrivacyPolicy => "গোপনীয়তা নীতি";
  String get labelSetting => "বিন্যাস";
  String get labelFeedback => "প্রতিক্রিয়া";
  String get labelConfirmLogout => "লগআউট নিশ্চিত করুন";
  String get labelConfirmLogoutMessage => "আপনি লগ আউট করতে চান?";
  String get labelLogout => "প্রস্থান";
  //select tab
  String get labelOptions => "অপশন";
  String get labelFoodTable => "খাবার যোগ করুন";
  String get labelTop10Food => "সেরা 10 খাবার";
  String get labelActivityTrack => "কার্যকলাপ ট্র্যাকার";
  String get labelsteptracker => "স্টেপ ট্র্যাকার";

  String get labelTodayTarget => "জল লক্ষ্য";
  String get labelJoggingTrack => "ব্যায়াম ট্র্যাক";
  String get labelMensurationTrack => "মাসিক ট্র্যাক";
//String get labelFoodTable => "খাবার টেবিল";
  String get labelPassword => "পাসওয়ার্ড পরিবর্তন করুন";
  String get labelDarkMode => "ডার্ক মোড ব্যবহার করে দেখুন";
  String get labelconectWatch => "ঘড়ি সংযুক্ত করুন";
  @override
  String get labelSleep => "ঘুম";
  @override
  String get labelBookStore => "বইয়ের দোকান";
  @override
  String get labelSearchBooks => "বই অনুসন্ধান করুন";
  @override
  String get labelPrice => "দাম";
  @override
  String get labelAddToCart => "কার্টে যোগ করুন";
  @override
  String get labelAuthor => "লেখক";
  @override
  String get labelYear => "বছর";
  @override
  String get labelQuantityAvailable => "পরিমান সরবরাহযোগ্য";
  @override
  String get labelCart => "কার্টে যোগ করুন";
  @override
  String get labelMyOrders => "আমার আদেশ";
  @override
  String get labelAllOrders => "সমস্ত আদেশ";
  @override
  String get labelOrderDetail => "আদেশ বিবরণী";
  @override
  String get labelOrderId => "অর্ডার আইডি";
  @override
  String get labelOrdersInMyOrders => "আমার আদেশে আদেশ";
  @override
  String get labelItemsInMyOrders => "আমার অর্ডার আইটেম";
  @override
  String get labelTotal => "মোট";
  @override
  String get labelTotalPrice => "মোট দাম";
  @override
  String get labelCheckout => "চেকআউট";

  // Meal List
  @override
  String get labelMealList => "আমার খাদ্য";
  @override
  String get labelAnalyze => "বিশ্লেষণ করুন";
  @override
  String get labelAddDish => "থালা যোগ করুন";
  @override
  String get labelTop10Foods => "সেরা 10টি খাবার";
  @override
  String get labelRecentMeal => "সাম্প্রতিক খাবার";
  @override
  String get labelAnalyzeIngredientsTaken => "খাদ্য গ্রহণ বিশ্লেষণ করুন";

  // Nutrition Summary
  @override
  String get labelCarbs => "কার্বোহাইড্রেট";
  // @override
  // String get labelCalories => "ক্যালোরি";
  @override
  String get labelFibers => "মোট ফাইবার";
  @override
  String get labelFats => "মোটা";
  @override
  String get labelProteins => "প্রোটিন";
  @override
  String get labelCalcium => "ক্যালসিয়াম";

  @override
  String get labelNiacinB3 => "নিয়াসিন (B3)";

  @override
  String get labelThiamineB1 => "থায়ামিন (B1)";

  @override
  String get labelIron => "আয়রন";

  @override
  String get labelZinc => "দস্তা";

  @override
  String get labelFolatesB9 => "ফোলেট (B9)";

  @override
  String get labelRiboflavinB2 => "রিবোফ্লাভিন (B2)";

  @override
  String get labelRetinolVitA => "রেটিনল (ভিটামিন এ)";

  @override
  String get labelMagnesium => "ম্যাগনেসিয়াম";

  @override
  String get labelTodaysNutritionSummary => "আজকের পুষ্টির সারাংশ";
  @override
  String get labelChangeGoal => "লক্ষ্য পরিবর্তন করুন";
  @override
  String get labelIngredientsTaken => "উপকরণ নেওয়া হয়েছে";
  @override
  String get labelIngredientsLeft => "উপকরণ বাকি";

  // Food Table
  // @override
  // String get labelFoodTable => "খাবার টেবিল";
  // @override
  // String get labelBreakfast => "সকালের নাস্তা";
  // @override
  // String get labelLunch => "মধ্যাহ্নভোজ";
  // @override
  // String get labelDinner => "রাতের খাবার";
  // @override
  // String get labelSnacks => "স্ন্যাকস";
  @override
  String get labelTop10FoodsSleep => "সেরা 10টি খাবার";
  @override
  String get labelFavouriteDishes => "প্রিয় খাবার";

  // User Profile
  @override
  String get labelHelp => "সাহায্য";
  // @override
  // String get labelLogout => "প্রস্থান";
  // @override
  // String get labelWeight => "ওজন";
  @override
  String get labelEmail => "ইমেইল";
  // @override
  // String get labelHeight => "উচ্চতা";
  @override
  String get labelLinkedInProfileLink => "লিঙ্কডইন প্রোফাইল লিঙ্ক";
  @override
  String get labelGoogleProfileLink => "গুগল প্রোফাইল লিঙ্ক";
  @override
  String get labelFacebookProfileLink => "ফেসবুক প্রোফাইল লিঙ্ক";
  @override
  String get labelTwitterProfileLink => "টুইটার প্রোফাইল লিঙ্ক";
  @override
  String get labelName => "নাম";
  @override
  String get labelPhoneNumber => "ফোন নম্বর.";
  @override
  String get labelDateOfBirth => "D.O.B";
  @override
  String get labelBMI => "বিএমআই";
  // @override
  // String get labelAge => "বয়স";

  // Contact Us
  @override
  String get labelMessage => "বার্তা";
  @override
  String get labelSubmit => "জমা দিন";
  @override
  String get labelCompanyContacts => "কোম্পানির পরিচিতি";
  @override
  String get labelAddress => "ঠিকানা";
  @override
  String get labelDirectorsEmail => "পরিচালকের ইমেইল";
  @override
  String get labelFax => "ফ্যাক্স";

  // Settings
  @override
  String get labelResetPassword => "পাসওয়ার্ড রিসেট করুন";
  // @override
  // String get labelFeedback => "প্রতিক্রিয়া";
  @override
  String get labelPleaseProvideFeedback => "আপনার মতামত প্রদান করুন";
  @override
  String get labelEnterYourFeedbackHere => "এখানে আপনার প্রতিক্রিয়া লিখুন";
  @override
  String get labelSubmitFeedback => "প্রতিক্রিয়া জমা দিন";

  // Credits
  // @override
  // String get labelContactUs => "যোগাযোগ করুন";
  @override
  String get labelDevelopmentTeam => "উন্নয়ন দল";
  @override
  String get labelAcknowledgments => "স্বীকৃতি";
  @override
  String get labelPartnerships => "অংশীদারিত্ব";

  // Mobile
  @override
  String get labelSearchComponents => "উপাদান অনুসন্ধান করুন";
  @override
  String get labelSearchComponentsHere => "এখানে উপাদান অনুসন্ধান করুন";
  @override
  String get lablelDishName => 'খাবারের নাম';
  @override
  String get labelCredits => 'ক্রেডিট';
  @override
  String get labelShareAppButton => "শেয়ার করুন";
  @override
  String get labelShareApp =>
      "একটি বারকোড স্ক্যানার অ্যাপ দিয়ে QR কোড স্ক্যান করুন এবং অ্যাপ ডাউনলোড করুন";
  // New translations
  @override
  String get labelConnectedWatch => "সংযুক্ত ঘড়ি হয়";
  @override
  String get labelDisconnect => "সংযোগ বিচ্ছিন্ন করুন";
  @override
  String get labelFitbit => "ফিটবিট";
  @override
  String get labelGoogleFit => "গুগল ফিট";
  @override
  String get labelAppleWatch => "আপেল ঘড়ি";
  @override
  String get labelSamsungSmartWatch => "স্যামসাং স্মার্ট ঘড়ি";
  @override
  String get labelBookDetails => "বই বিবরণ";
  @override
  String get labelDeliveryDate => "প্রসবের তারিখ";
  @override
  String get labelOrderDate => "অর্ডারের তারিখ";
  @override
  String get labelAnalyseIngredientsTaken => "খাদ্য গ্রহণ বিশ্লেষণ করুন";
  @override
  String get labelAddDishIngredients => "থালা উপাদান যোগ করুন";
  @override
  String get labelIngredientName => "উপাদানের নাম";
  @override
  String get labelEnterIngredientName => "একটি উপাদানের নাম লিখুন";
  @override
  String get labelIngredientQuantity => "উপাদান পরিমাণ";
  @override
  String get labelEnterIngredientQuantity => "উপাদান পরিমাণ লিখুন";
  @override
  String get labelAdd => "যোগ করুন";
  @override
  String get labelSave => "সংরক্ষণ";
  @override
  String get labelwatch => "ঘড়ি";

  //
  @override
  String get labelBloodOxygenHeart =>
      'গুরুত্বপূর্ণ লক্ষণ পরিমাপ এবং সামগ্রিক স্বাস্থ্য ট্র্যাক.';
  @override
  String get labelTop10FoodS =>
      'একটি স্বাস্থ্যকর জীবনধারা বজায় রাখার জন্য প্রস্তাবিত খাবারগুলি আবিষ্কার করুন।';
  @override
  String get labelWaterTrack =>
      'দৈনিক ফিটনেস হাইড্রেশন লক্ষ্য সেট করুন এবং অর্জন করুন।';
  @override
  String get labelPersonalDetails =>
      'নিরাপদে ব্যক্তিগত তথ্য পরিচালনা এবং আপডেট করুন।';
  @override
  String get labelFeedbackS =>
      'আমাদের সাথে আপনার চিন্তা এবং পরামর্শ শেয়ার করুন.';
  @override
  String get labelContactUsS =>
      'গ্রাহক সমর্থনে পৌঁছান এবং আমাদের সাথে যোগাযোগ করুন।';
  @override
  String get labelBMICalculator =>
      'স্বাস্থ্য অন্তর্দৃষ্টি জন্য আপনার শরীরের ভর সূচক গণনা.';
  @override
  String get labelBMRCalculator =>
      'ফিটনেস পরিকল্পনার জন্য আপনার বেসাল মেটাবলিক রেট গণনা করুন।';
  @override
  String get labelRunningJoggingSteps =>
      'একটি স্বাস্থ্যকর জীবনধারার জন্য আপনার দৌড় এবং জগিং পদক্ষেপগুলি ট্র্যাক করুন।';
  @override
  String get labelHealthyDietChart =>
      'একটি স্বাস্থ্যকর খাদ্য ওভারভিউ জন্য একটি ব্যাপক চার্ট অ্যাক্সেস.';
  @override
  String get labelHealthyRecommendation =>
      'ব্যক্তিগতকৃত স্বাস্থ্য সুপারিশ পান.';
  @override
  String get labelSleepTracker =>
      'আপনার ঘুমের ধরণগুলি ট্র্যাক করুন এবং ঘুমের গুণমান উন্নত করুন।';
  @override
  String get labelSetReminder =>
      'স্বাস্থ্য এবং ফিটনেস কার্যক্রমের জন্য অনুস্মারক সেট করুন।';
  // @override
  // String get labelMenstruationCycle =>
  //     'আরও ভাল অন্তর্দৃষ্টির জন্য আপনার মাসিক চক্র ট্র্যাক করুন এবং পরিচালনা করুন।';
  @override
  String get labelCSVDownload =>
      'সহজ বিশ্লেষণের জন্য CSV ফরম্যাটে আপনার ডেটা ডাউনলোড করুন।';

  // New Headings
  @override
  String get headingBloodOxygenHeart => 'রক্ত | অক্সিজেন';
  @override
  String get headingTop10Food => 'সেরা 10 খাবার';
  @override
  String get headingWaterTrack => 'জল ট্র্যাকার';
  @override
  String get headingPersonalDetails => 'ব্যক্তিগত বিবরণ';
  @override
  String get headingFeedback => 'প্রতিক্রিয়া';
  @override
  String get headingContactUs => 'যোগাযোগ করুন';
  @override
  String get headingBMICalculator => 'BMI ক্যালকুলেটর';
  @override
  String get headingBMRCalculator => 'বিএমআর ক্যালকুলেটর';
  @override
  String get headingRunningJoggingSteps => 'দৌড়ানো / জগিং / পদক্ষেপ';
  @override
  String get headingHealthyDietChart => 'স্বাস্থ্যকর ডায়েট চার্ট';
  @override
  String get headingHealthyRecommendation => 'স্বাস্থ্যকর সুপারিশ';
  @override
  String get headingSleepTracker => 'স্লিপ ট্র্যাকার';
  @override
  String get headingSetReminder => 'রিমাইন্ডার সেট করুন';
  // @override
  // String get headingMenstruationCycle => 'মাসিক চক্র';
  @override
  String get headingCSVDownload => 'CSV ডাউনলোড';

  // Water-related phrases
  @override
  String get labelWaterTarget => "জল লক্ষ্য";
  // @override
  // String get labelTodayTarget => "আজকের টার্গেট";
  @override
  String get labelWaterGoal => "জল লক্ষ্য";
  // @override
  // String get labelWaterIntake => "জল খাওয়ার";
  @override
  String get labelWaterProgress => "জল অগ্রগতি";
  // @override
  // String get labelWeekly => "সাপ্তাহিক";
  @override
  String get labelDateWise => "তারিখ অনুযায়ী";
  @override
  String get labelSun => "সূর্য";
  @override
  String get labelMon => "সোম";
  @override
  String get labelTue => "মঙ্গল";
  @override
  String get labelWed => "বুধ";
  @override
  String get labelThu => "বৃহ";
  @override
  String get labelFri => "শুক্র";

  // BMI Calculator
  // @override
  // String get labelBMI => "বিএমআই";
  @override
  String get labelEnterHeight => "উচ্চতা লিখুন (সেমি)";
  @override
  String get labelEnterWeight => "ওজন লিখুন (কেজি)";
  @override
  String get labelCalculateBMI => "বিএমআই গণনা করুন";

  // BMR Calculator
  @override
  String get labelMale => "পুরুষ";
  @override
  String get labelFemale => "মহিলা";
  @override
  String get labelEnterAge => "বয়স লিখুন";
  @override
  String get labelCalculateBMR => "BMR গণনা করুন";
  @override
  String get labelBMR => "বিএমআর";
  @override
  String get labelCaloriesPerDay => "ক্যালোরি / দিন";

  // Step Tracker
  @override
  String get labelStepsTracker => "স্টেপ ট্র্যাকার";
  @override
  String get labelRunningTracker => "চলমান ট্র্যাকার";
  @override
  String get labelAddStep => "ধাপ যোগ করুন";
  @override
  String get labelSelectDate => "তারিখ নির্বাচন করুন";
  @override
  String get labelJoggingTracker => "জগিং ট্র্যাকার";
  @override
  String get labelCaloriesBurn => "ক্যালোরি পোড়া";

  // Sleep Tracker
  @override
  String get labelSleepTarget => "ঘুমের লক্ষ্য";
  @override
  String get labelTodaySleep => "আজ ঘুম";
  @override
  String get labelSleepProgress => "ঘুমের অগ্রগতি";
  @override
  String get labelTotalSleep => "মোট ঘুম";
  @override
  String get labelSleepGoal => "ঘুমের লক্ষ্য";
  @override
  String get labelSetNotification => "বিজ্ঞপ্তি সেট করুন";
  @override
  String get labelStartTime => "সময় শুরু";
  @override
  String get labelEndTime => "শেষ সময়";
  @override
  String get labelSelect => "নির্বাচন করুন";
  @override
  String get labelSat => "শনি";
  // @override
  // String get labelSave => "সংরক্ষণ";
  @override
  String get labelStart => "শুরু করুন";
  @override
  String get labelEnd => "শেষ";
  @override
  String get labelType => "টাইপ";
  @override
  String get labelIsConnected => "সংযুক্ত";

  // @override
  // String get labelMensurationCycle => "চক্র পরিমাপ";

  @override
  String get labelTrackAndManage =>
      "আরও ভাল অন্তর্দৃষ্টির জন্য আপনার মাসিক চক্র ট্র্যাক করুন এবং পরিচালনা করুন";

  @override
  String get labelMensurationStatus => "পরিমাপ অবস্থা";

  @override
  String get labelDaysLength => "দিনের দৈর্ঘ্য";

  @override
  String get labelDay => "দিন";

  @override
  String get labelNextDate => "পরের তারিখ";

  @override
  String get labelLastPeriodStartDate => "শেষ সময়ের শুরুর তারিখ";

  @override
  String get labelAverageCycleLength => "গড় চক্রের দৈর্ঘ্য";

  @override
  String get labelChange => "পরিবর্তন";

  // Common Messages
  @override
  String get messageSent => "বার্তা পাঠানো";

  @override
  String get thankYouForContactingUs =>
      "আমাদের সাথে যোগাযোগ করার জন্য আপনাকে ধন্যবাদ!";

  @override
  String get alert => "সতর্কতা";

  @override
  String get fillInAllFields => "সবগুলো ঘর পূরন করুন.";

  @override
  String get thankYouFeedbackSubmitted => "আপনার মতামত জমা দেওয়া হয়েছে।";

  @override
  String get resetPassword => "পাসওয়ার্ড রিসেট করুন";

  @override
  String get dishAdded => "ডিশ যোগ করা হয়েছে!";

  @override
  String get dishAndIngredientsAddedSuccessfully =>
      "সফলভাবে থালা এবং উপাদান যোগ করা হয়েছে.";

  @override
  String get failed => "ব্যর্থ";

  @override
  String get error => "ত্রুটি";

  @override
  String get enterBloodGlucoseLevel => "mg/dL রক্তে গ্লুকোজের মাত্রা লিখুন";

  @override
  String get enterBloodPressureLevel => "mmHg এ রক্তচাপের মাত্রা লিখুন";

  @override
  String get enterHeartLevel =>
      "অনুগ্রহ করে বিট প্রতি মিনিটে হার্ট রেট লিখুন (BPM)।";

  @override
  String get cancel => "বাতিল করুন";

  @override
  String get submit => "জমা দিন";

  @override
  String get valueCannotBeGreaterThan100 => "মান 100 এর বেশি হতে পারে না।";

  @override
  String get bloodStatusSubmittedSuccessfully =>
      "রক্তের স্থিতি সফলভাবে জমা দেওয়া হয়েছে।";

  @override
  String get failedToSubmitBlood => "রক্ত জমা দিতে ব্যর্থ।";

  @override
  String get enterHeartLevel1to100 =>
      "অনুগ্রহ করে বিট প্রতি মিনিটে হার্ট রেট লিখুন (BPM)।";

  @override
  String get heartLevelSubmittedSuccessfully =>
      "হার্ট লেভেল সফলভাবে জমা দেওয়া হয়েছে।";

  @override
  String get enterOxygenSaturationLevel1to100 =>
      "অক্সিজেন স্যাচুরেশন লেভেল 1%-100% লিখুন";

  @override
  String get oxygenLevelSubmittedSuccessfully =>
      "অক্সিজেন স্তর সফলভাবে জমা দেওয়া হয়েছে।";

  @override
  String get updateData => "ডেটা আপডেট করুন";

  @override
  String get selectLastPeriodStartDate =>
      "শেষ সময়ের শুরুর তারিখ নির্বাচন করুন";

  @override
  String get update => "হালনাগাদ";

  @override
  String get failedToFetchBooks =>
      "বই আনতে ব্যর্থ হয়েছে. অনুগ্রহপূর্বক আবার চেষ্টা করুন.";

  @override
  String get errorOccurred => "একটি ত্রুটি ঘটেছে:";

  @override
  String get invalidEndTime => "অবৈধ শেষ সময়";

  @override
  String get chooseTimeWithin1Hour =>
      "অনুগ্রহ করে শুরুর সময়ের 1 ঘন্টার মধ্যে একটি সময় বেছে নিন।";

  @override
  String get notificationSaved => "বিজ্ঞপ্তি সংরক্ষিত";

  @override
  String get notificationSetSuccessfully => "বিজ্ঞপ্তি সফলভাবে সেট করা হয়েছে।";

  @override
  String get thereIsSomeError => "কিছু ত্রুটি আছে.";

  @override
  String get watchDisconnected => "ঘড়ি সংযোগ বিচ্ছিন্ন";

  @override
  String get watchDisconnectedSuccessfully =>
      "ঘড়ি সফলভাবে সংযোগ বিচ্ছিন্ন করা হয়েছে.";

  @override
  String get addCup => "কাপ যোগ করুন";

  @override
  String get numberOfCups => "কাপ সংখ্যা";

  @override
  String get addCupCapacityInMl => "মিলি কাপ ক্ষমতা যোগ করুন";

  @override
  String get cupCapacitySubmittedSuccessfully =>
      "কাপ ক্ষমতা সফলভাবে জমা দেওয়া হয়েছে.";

  @override
  String get pleaseEnterValidValuesForAllFields =>
      "সমস্ত ক্ষেত্রের জন্য বৈধ মান লিখুন.";

  @override
  String get enterWater => "জল প্রবেশ করান";

  @override
  String get waterGoalLiters => "জল লক্ষ্য (লিটার)";

  @override
  String get waterSubmittedSuccessfully =>
      "জলের লক্ষ্য সফলভাবে জমা দেওয়া হয়েছে।";

  @override
  String get addActivityData => "কার্যকলাপ তথ্য যোগ করুন";

  @override
  String get enterValue => "মান লিখুন";

  @override
  String get addStepsData => "ধাপ ডেটা যোগ করুন";

  @override
  String get numberOfSteps => "ধাপের সংখ্যা";

  @override
  String get stepsDataSubmittedSuccessfully =>
      "ধাপের ডেটা সফলভাবে জমা দেওয়া হয়েছে।";

  @override
  String get enterSleepTarget => "ঘুমের লক্ষ্য লিখুন";

  @override
  String get sleepTargetInHours => "ঘন্টার মধ্যে ঘুমের লক্ষ্য";

  @override
  String get addYourSleepDuration => "আপনার ঘুমের সময়কাল যোগ করুন";

  @override
  String get enterDurationInMinutes => "মিনিটের মধ্যে সময়কাল লিখুন:";

  @override
  String get add => "যোগ করুন";

  @override
  String get ok => "ঠিক আছে";

  @override
  String get csvFileSavedTo => "CSV ফাইল সংরক্ষণ করা হয়েছে";

  @override
  String get ageMustBeBetween2And100Years =>
      "বয়স 2 থেকে 100 বছরের মধ্যে হতে হবে";

  @override
  String get next => "পরবর্তী";

  @override
  String get register => "নিবন্ধন";

  @override
  String get oopsSomethingWentWrong => "উফ! কিছু ভুল হয়েছে";

  @override
  String get errorFetchingMeals => "খাবার আনার সময় একটি ত্রুটি ঘটেছে:";

  @override
  String get reviewAddedSuccessfully => "পর্যালোচনা সফলভাবে যোগ করা হয়েছে!";

  @override
  String get failedToAddReview => "পর্যালোচনা যোগ করতে ব্যর্থ:";

  @override
  String get alreadyInCart => "ইতিমধ্যেই কার্টে আছে";

  @override
  String get addedToCart => "কার্টে যোগ করা হয়েছে";

  @override
  String get quantityNotBetween1And2 => "পরিমাণ 2 এর বেশি এবং 1 এর কম নয়";

  String get createcustomdish => "কাস্টম ডিশ তৈরি করুন";
  String get quantityingram => "পরিমাণ (গ্রাম)";
  String get labelCaloriestaken => 'শক্তি';
  String get mainlabelEarlyMorning => "ভোরবেলা";
  String get mainlabelMidMorning => "মধ্য সকাল";
  String get mainlabelEvening => "সন্ধ্যা";
  String get mainlabelBedtime => "শয়নকাল";
  String get mainlabelTimeSpentOn => "বিভিন্ন কাজে সময় কাটে";
  String get mainlabelHealthCalculator => "স্বাস্থ্য ক্যালকুলেটর";
  String get mainlabelStepProgress => "ধাপে ধাপে অগ্রগতি";
  String get mainlabelRealTimeIntakes => "বাস্তব সময় গ্রহণ";
  String get mainlabelCaloriesBurnProgress => "ক্যালোরি বার্ন অগ্রগতি";
  String get mainlabelCaloriesBurnBreakdown => "ক্যালোরি বার্ন ব্রেকডাউন অন";
  String get mainlabelHeartReportsTrends => "হার্ট রিপোর্ট প্রবণতা";
  String get mainlabelOxygenStatus => "অক্সিজেনের অবস্থা";
  String get mainlabelNoRecord => "মনে নেই";
  String get mainlabelSystolicBloodPressure => "সিস্টোলিক রক্তচাপ";
  String get mainlabelMeasuredon => "উপর মাপা";
  String get mainlabelEnterBloodPressure => "রক্তচাপ লিখুন";
  String get mainlabelBloodPressure => "রক্তচাপ";
  String get mainlabelDiastolicBloodPressure => "ডায়াস্টোলিক রক্তচাপ";
  String get mainlabelBloodGlucose => "রক্তে গ্লুকোজ";
  String get mainlabelHeartStatus => "হার্ট স্ট্যাটাস";
  String get mainlabelAllExercise => "সব ব্যায়াম";
  String get mainlabelCleaningOrMopping => "পরিষ্কার বা মোপিং";
  String get mainlabelGardening => "বাগান করা";
  String get mainlabelWatchingTV => "টিভি দেখছি";
  String get mainlabelCycling => "সাইক্লিং";
  String get mainlabelRunning => "চলছে";
  String get mainlabelWalking => "হাঁটা";
  String get mainlabelShuttle => "শাটল";
  String get mainlabelTableTennis => "টেবিল টেনিস";
  String get mainlabelTennis => "টেনিস";
  String get mainlabelVolleyBall => "ভলি বল";
  String get mainlabelDancing => "নাচ";
  String get mainlabelFishing => "মাছ ধরা";
  String get mainlabelShopping => "কেনাকাটা";
  String get mainlabelTyping => "টাইপিং";
  String get mainlabelSleeping => "ঘুমন্ত";
  String get mainlabelStanding => "দাঁড়ানো";
  String get mainlabelSitting => "বসা";
  String get mainlabelClickToStartActivity => "কার্যকলাপ শুরু করতে ক্লিক করুন";
  String get mainlabelBMICalculator => "BMI ক্যালকুলেটর";
  String get mainlabelBMRCalculator => "বিএমআর ক্যালকুলেটর";
  String get mainlabelDownloadActivityReportInCsv =>
      "csv এ কার্যকলাপ প্রতিবেদন ডাউনলোড করুন";
  String get mainlabelSelectStartDate => "শুরুর তারিখ নির্বাচন করুন";
  String get mainlabelSelectEndDate => "শেষ তারিখ নির্বাচন করুন";
  String get mainlabelDownloadFile => "ডাউনলোড ফাইল";
  String get mainlabelDate => "তারিখ";
  String get mainlabelValue => "মান";
  String get mainlabelLink => "লিঙ্ক";
  String get mainlabelNoNotificationFound => "কোনো বিজ্ঞপ্তি পাওয়া যায়নি";
  String get mainlabelTotalNutritionTaken => "= মোট পুষ্টি গ্রহণ";
  String get mainlabelSearchFood => "রেসিপি অনুসন্ধান করুন";
  String get mainlabelSelectFromPersonalFood =>
      "ব্যক্তিগত রেসিপি থেকে নির্বাচন করুন";
  String get mainlabelRecipeName => "রেসিপির নাম";
  String get mainlabelSelectDate => "তারিখ নির্বাচন করুন";
  String get mainlabelNutrientOfAllIngredientsRaw =>
      "সমস্ত উপাদানের পুষ্টি (কাঁচা)";
  String get mainlabelNutrientsCompostionOfCookedWeight =>
      "জন্য রান্না করা ওজন পুষ্টির গঠন";
  String get mainlabelWantToEditThisRecipyFollowThe =>
      "এই রেসিপি সম্পাদনা করতে চান? অনুসরণ করা";
  String get mainlabelAddIngredientFrom => "থেকে উপাদান যোগ করুন";
  String get mainlabelAddFromNutrientSpecifcFood =>
      "পুষ্টি নির্দিষ্ট খাদ্য থেকে যোগ করুন";
  String get mainlabelAddFromAllFoods => "সব খাবার থেকে যোগ করুন";
  String get mainlabelNumberOfServing => "পরিবেশনের সংখ্যা";
  String get mainlabelWeightInG => "ওজন (গ্রাম)";
  String get mainlabelEditIngredientsWeight => "উপাদান ওজন সম্পাদনা করুন";
  String get mainlabelIngredient => "উপাদান";
  String get mainlabelNewWeightInG => "নতুন ওজন (g)";
  String get mainlabelCancel => "বাতিল";
  String get mainlabelUpdate => "হালনাগাদ";
  String get mainlabelCookedWeightInG => "রান্না করা ওজন (গ্রাম)";
  String get mainlabelEnterWeight => "ওজন লিখুন";
  String get mainlabelEditRecipy => "রেসিপি সম্পাদনা করুন";
  String get mainlabelAlert => "সতর্ক";
  String get mainlabelToSeeNutritionCompositionPleaseEnterNoOfServing =>
      "পুষ্টির গঠন দেখতে, পরিবেশনের সংখ্যা লিখুন";
  String get mainlabelNutrirntsIn100CookedWeight =>
      "100 (রান্না করা) ওজনে পুষ্টি";
  String get mainlabelSetNutritionTargetInG =>
      "গ্রামে পুষ্টির লক্ষ্য নির্ধারণ করুন";
  String get mainlabelFoodAnalyse => "অন্বেষণ";
  String get mainlabelExploreTop10Foods => "সেরা 10টি খাবার অন্বেষণ করুন";
  String get mainlabelSearchCookedFood => "রেসিপিগুলিতে পুষ্টি সন্ধান করুন";
  String get mainlabelNutritionBasedOnEAR =>
      "কানের উপর ভিত্তি করে পুষ্টির প্রয়োজনীয়তা";
  String get mainlabelDietDiary => "খাদ্য ডায়েরি";
  String get mainlabelRecipes => "রেসিপি";
  String get mainlabelSearchByFoodName => "খাবারের নাম দিয়ে অনুসন্ধান করুন";
  String get mainlabelAllRecipeOf100G => "100 গ্রাম সব রেসিপি";
  String get mainlabelNutritionRequirement => "পুষ্টির প্রয়োজনীয়তা";
  String get mainlabelGender => "লিঙ্গ";
  String get mainlabelParticulars => "বিবরণ";
  String get mainlabelBodyWeight => "শরীরের ওজন";
  String get mainlabelDietaryDiaryReports => "পুষ্টি গ্রহণ";
  String get mainlabelTotalNutritionTakenOn => "গ্রহণ করা মোট পুষ্টি";
  String get mainlabelAttachImage => "ছবি সংযুক্ত করুন";
  String get mainlabelFixedRecipy => "স্থির রেসিপি";
  String get mainlabelFoodInDetail => "বিস্তারিত খাদ্য";
  String get TextAppNutrientsInMyFood => "খাবারে পুষ্টি সন্ধান করুন";
  String get TextAppMyActivity => "আমার কার্যকলাপ";
  String get TextAppToday => "আজ";
  String get TextAppMyNutrientRequirements => "আমার পুষ্টির চাহিদা";
  String get TextAppTotalNutrition => "মোট পুষ্টি";
  String get TextAppTaken => "নেওয়া হয়েছে";
  String get TextAppRatings => "রেটিং";
  String get TextAppSearchComponents => "উপাদান অনুসন্ধান করুন";
  String get TextAppTotalNutrientTaken => "আজ আমার পুষ্টি গ্রহণ";
  String get TextAppShareApp => "অ্যাপ্লিকেশন ভাগ করা";
  String get TextAppNoNotificationsFound => "কোন বিজ্ঞপ্তি পাওয়া যায়নি";
  String get TextAppConnectWatch => "ঘড়ি কানেক্ট করুন";
  String get TextAppYourBMIIs => "আপনার BMI হল";
  String get TextAppBMI => "বিএমআই";
  String get TextAppBMICategories => "বিএমআই বিভাগ";
  String get TextAppUnderweight => "কম ওজন";
  String get TextAppNormal => "স্বাভাবিক";
  String get TextAppOverweight => "অতিরিক্ত ওজন";
  String get TextAppObesity => "স্থূলতা";
  String get TextAppSelectDate => "তারিখ নির্বাচন করুন";
  String get TextAppOxygen => "অক্সিজেন";
  String get TextAppBlood => "রক্ত";
  String get TextAppNoRecord => "কোন রেকর্ড নেই";
  String get TextAppAllExercise => "সমস্ত ব্যায়াম";
  String get TextAppCleaningOrMopping => "ক্লিনিং বা মোপিং";
  String get TextAppGardening => "বাগান করা";
  String get TextAppWatchingTV => "টিভি দেখছি";
  String get TextAppCycling => "সাইক্লিং";
  String get TextAppRunning => "চলছে";
  String get TextAppWalking => "হাঁটা";
  String get TextAppShuttle => "শাটল";
  String get TextAppTableTennis => "টেবিল টেনিস";
  String get TextAppTennis => "টেনিস";
  String get TextAppVolleyBall => "ভলি বল";
  String get TextAppDancing => "নাচ";
  String get TextAppFishing => "মাছ ধরা";
  String get TextAppShopping => "কেনাকাটা";
  String get TextAppTyping => "টাইপিং";
  String get TextAppSleeping => "ঘুমন্ত";
  String get TextAppStanding => "দাঁড়ানো";
  String get TextAppSitting => "বসা";
  String get TextAppClickStartToStartActivity =>
      "কার্যকলাপ শুরু করতে শুরু ক্লিক করুন";
  String get TextAppCaloriesBurn => "ক্যালোরি পোড়া";
  String get TextAppAddDurationManually => "ম্যানুয়ালি সময়কাল যোগ করুন";
  String get TextAppStartOrMopping => "স্টার্ট বা মোপিং";
  String get TextAppMale => "পুরুষ";
  String get TextAppFemale => "মহিলা";
  String get TextAppWeightManager => "আমার শরীরের ওজন ট্র্যাক";
  String get TextAppUpdateWeight => "ওজন আপডেট করুন";
  String get TextAppSetWeightGoal => "ওজন লক্ষ্য সেট করুন";
  String get TextAppCurrentWeight => "বর্তমান ওজন";
  String get TextAppWeightProgress => "ওজন অগ্রগতি";
  String get TextAppPrevious30Days => "আগের 30 দিন";
  String get TextAppYourWeightGoalIsSet => "আপনার লক্ষ্য হল";
  String get TextAppMaintain => "রক্ষণাবেক্ষণ";
  String get TextAppInitialWeightOf => "প্রাথমিক ওজন";
  String get TextAppFinalWeightOf => "সর্বশেষ ওজন";
  String get TextAppWeight => "ওজন";
  String get TextAppYouAreNotYetAchievingYourWeightGoalKeepGoing =>
      "আপনি এখনও আপনার ওজন লক্ষ্য অর্জন করছেন না. চোলতে থাকা!";
  String get TextAppYouAreAchievedYourWeightGoalKeepGoing =>
      "আপনি আপনার ওজন লক্ষ্য অর্জন করা হয়. চোলতে থাকা!";
  String get TextAppAndYourWeightChangeIsSet =>
      "এবং আপনার ওজন পরিবর্তন সেট করা হয়";
  String get TextApp1NutrientsInMyFood => "আমার খাবারে পুষ্টি";
  String get TextAppSearchNutrientsInRawFoods =>
      "কাঁচা খাবারে পুষ্টি সন্ধান করুন";
  String get TextAppRawIngredients => "কাঁচা উপাদান";
  String get TextAppSearchRawFoodByName =>
      "নাম অনুসারে কাঁচা খাবার অনুসন্ধান করুন";
  String get TextApp1MyActivity => "আমার কার্যকলাপ রিপোর্ট";
  String get TextAppCheckOthersDates => "অন্যদের তারিখ চেক করুন";
  String get TextAppYour24HoursChart => "আপনার 24 ঘন্টা চার্ট";
  String get TextAppActivity => "কার্যকলাপ";
  String get TextAppOthers => "অন্যান্য";
  String get TextAppExerciseDetails => "ব্যায়াম বিবরণ";
  String get TextAppActivityType => "কার্যকলাপ টাইপ";
  String get TextAppDuration => "সময়কাল";
  String get TextAppMyActivityOfCustomDates => "কাস্টম তারিখের আমার কার্যকলাপ";
  String get TextAppOurCustomerFeedback => "আমাদের গ্রাহক প্রতিক্রিয়া";
  String get TextAppOverallRatings => "সামগ্রিক রেটিং";
  String get TextAppEnterCookedWeight => "রান্না করা ওজন লিখুন";
  String get TextAppCookedWeightGram => "রান্না করা ওজন (গ্রাম)";
  String get TextAppNutrientIn100gCooked =>
      "100 গ্রাম পুষ্টি উপাদান (রান্না করা)";
  String get TextAppEnterServingSize => "পরিবেশন আকার লিখুন";
  String get TextAppSearchByRecipeName => "রেসিপি নাম দ্বারা অনুসন্ধান করুন";
  String get TextAppMyPersonalRecipe => "আমার ব্যক্তিগত রেসিপি";
  String get TextAppFixedRecipe => "স্থির রেসিপি";
  String get TextApp2NutrientsInMyFood => "আমার খাবারে পুষ্টি";
  String get TextAppMyDietDiary => "আমার খাদ্য ডায়েরি";
  String get TextApp2MyActivity => "আমার কার্যকলাপ";
  String get TextAppDownloadFile => "ডাউনলোড ফাইল";
  String get TextAppStartMyNewDietDiary => "আমার নতুন খাদ্য ডায়েরি শুরু করুন";
  String get TextAppGoogle => "গুগল";
  String get TextAppFacebook => "ফেসবুক";
  String get TextAppLinkedin => "লিঙ্কডইন";
  String get TextAppTwitter => "টুইটার";
  String get TextAppContactUs => "যোগাযোগ করুন";
  String get TextAppReportBug => "বাগ রিপোর্ট";
  String get TextAppAttachImage => "ছবি সংযুক্ত করুন";
  String get TextAppResetPassword => "পাসওয়ার্ড রিসেট করুন";
  String get TextAppNINAppCreditsPage => "NIN অ্যাপ ক্রেডিট পৃষ্ঠা";
  String get NINTextOopsSomethingWentWrong => "উফ! কিছু ভুল হয়েছে";
  String get NINTextPleaseEnterAllFields => "সব ক্ষেত্র লিখুন";
  String get NINTextSubmittedSuccessfully1 => "সফলভাবে দাখিল হল";
  String get NINTextSubmittedSuccessfully2 => "সফলভাবে দাখিল হল";
  String get NINTextFitbitAuthentication => "Fitbit প্রমাণীকরণ";
  String get NINTextHours => "ঘন্টার";
  String get NINTextMinutes => "মিনিট";
  String get NINTextEnterDurationFor => "জন্য সময়কাল লিখুন";
  String get NINTextTimerRunning => "টাইমার চলছে";
  String get NINTextPleaseStopTheTimerBeforeSubmitting =>
      "জমা দেওয়ার আগে টাইমার বন্ধ করুন";
  String get NINTextTotalDuration => "মোট সময়কাল";
  String get NINTextSec => "সেকেন্ড";
  String get NINTextStartYourActivity => "আপনার কার্যকলাপ শুরু করুন!";
  String get NINTextPause => "বিরতি";
  String get NINTextReset => "রিসেট";
  String get NINTextError => "ত্রুটি";
  String get NINTextPleaseEnterCookedWeightAndServingSize =>
      "রান্না করা ওজন এবং পরিবেশন আকার লিখুন দয়া করে";
  String get NINTextEditIngredient => "উপাদান সম্পাদনা";
  String get NINTextAlert => "সতর্কতা";
  String get NINTextEnterWeightFor => "জন্য ওজন লিখুন";
  String get NINTextNewWeightGram => "নতুন ওজন (g)";
  String get NINTextEditRecipeName => "রেসিপির নাম সম্পাদনা করুন";
  String get NINTextNewRecipeName => "নতুন রেসিপির নাম";
  String get NINTextSubmitted => "জমা";
  String get NINTextSuccess => "সফলতা";
  String get NINTextDietaryDiaryReportSavedTo =>
      "ডায়েটরি ডায়েরি রিপোর্ট সংরক্ষিত";
  String get NINTextErrorSavingFile => "ফাইল সংরক্ষণে ত্রুটি৷";
  String get NINTextClose => "বন্ধ";
  String get NINTextIWantTo => "আমি চাই";
  String get NINTextGain => "লাভ করা";
  String get NINTextMaintain => "রক্ষণাবেক্ষণ";
  String get NINTextLose => "হারান";
  String get NINTextWeightChangeKg => "ওজন পরিবর্তন (কেজি)";
  String get NINTextAddNewWeight => "নতুন ওজন যোগ করুন";
  String get NINTextEnterWeight => "ওজন লিখুন";
  String get NINTextOf100Gram => "100 গ্রাম";
  String get NINTextProximateComposition => "আনুমানিক রচনা";
  String get NINTextVitamins => "ভিটামিন";
  String get NINTextMinerals => "খনিজ পদার্থ";
  String get NINTextTotalSaturatedFattyAcids =>
      "মোট স্যাচুরেটেড ফ্যাটি অ্যাসিড";
  String get NINTextAllRecipeOf100Grams => "100 গ্রাম এর সমস্ত রেসিপি";
  String get NINTextOurCustomerFeedback => "আমাদের গ্রাহক প্রতিক্রিয়া";
  String get NINTextOverallRatings => "সামগ্রিক রেটিং";
  String get NINTextRateUs => "আমাদের ব্যাপারে আপনার মতামত দিন";
  String get NINTextBookDetails => "বই বিবরণ";
  String get NINTextOne => "এক";
  String get NINTextWeightOf => "wt এর";
  String get NINTextSelectStartDate => "শুরুর তারিখ নির্বাচন করুন";
  String get NINTextSelectEndDate => "শেষ তারিখ নির্বাচন করুন";
  String get NINTextNoData => "কোন তথ্য নেই";
  String get NINTextWorkLevel => "কাজের স্তর";
  String get NINTextOldPassword => "পুরানো পাসওয়ার্ড";
  String get NINTextNewPassword => "নতুন পাসওয়ার্ড";
  String get NINTextUpdateProfile => "প্রফাইল হালনাগাদ";
  String get NINTextChangeImage => "ছবি পরিবর্তন করুন";
  String get NINTextNoFavouriteFoodFound => "পছন্দের খাবার পাওয়া যায়নি";
  String get NINTextCookedQuantity => "রান্নার পরিমাণ";
  String get NINTextServingQuantity => "পরিবেশন পরিমাণ";
  String get NINTextNutrientInformation => "পুষ্টি তথ্য";
  String get NINTextIngredient => "উপাদান";
  String get NINTextMealsTakenOn => "খাবার নেওয়া হয়েছে";
  String get NINTextPercentage => "শতাংশ";
  String get NINTextEAR => "কান";
  String get NINTextValue => "মান";
  String get NINTextNutrient => "পুষ্টি";
  String get NINTextEnergyKcal => "শক্তি (kcal)";
  String get NINTextProteinG => "প্রোটিন (ছ)";
  String get NINTextFatG => "চর্বি (ছ)";
  String get NINTextCarbohydratesG => "কার্বোহাইড্রেট (ছ)";
  String get NINTextCalciumMg => "ক্যালসিয়াম (মিগ্রা)";
  String get NINTextFiberG => "ফাইবার (ছ)";
  String get NINTextIronMg => "আয়রন (মিগ্রা)";
  String get NINTextZincMg => "দস্তা (মিগ্রা)";
  String get NINTextMagnesiumMg => "ম্যাগনেসিয়াম (মিগ্রা)";
  String get NINTextThiamineB1Mg => "থায়ামিন (B1) (mg)";
  String get NINTextRiboflavinB2Mg => "রিবোফ্লাভিন (B2) (mg)";
  String get NINTextNiacinB3Mg => "নিয়াসিন (বি৩) (মিগ্রা)";
  String get NINTextFolatesB9Mcg => "ফোলেটস (B9) (mcg)";
  String get NINTextRetinolVitAMcg => "ভিটামিন এ (এমসিজি)";
  String get VitaminCmg => "ভিটামিন সি (মিগ্রা)";
  String get Iodinemcg => "আয়োডিন (এমসিজি)";
  String get serving => "ভজনা";
  String get Mynutritionstatus => "আমার পুষ্টির অবস্থা";

  String get ninTextMyHealthStatus => 'আমার স্বাস্থ্য অবস্থা';
  String get ninTextNutrientsInRawFoods => 'কাঁচা খাবারে পুষ্টি';
  String get ninTextNutrientsInRecipes => 'রেসিপি মধ্যে পুষ্টি';
  String get ninTextIcmrNinMyPlateForTheDay => 'ICMR-NIN দিনের জন্য আমার প্লেট';
  String get ninTextToday => 'আজ';
  String get ninTextTrackMyActivity => 'আমার কার্যকলাপ ট্র্যাক';
  String get ninTextMyHeartRate => 'আমার হৃদস্পন্দন';
  String get ninTextMyWaterIntake => 'আমার জল গ্রহণ';
  String get ninTextSleepTracker => 'স্লিপ ট্র্যাকার';
  String get ninTextLit => 'লিট';
  String get ninTextRecordMyBloodPressure =>
      'আমার রক্তচাপ / রক্তের গ্লুকোজ / SPO2 রেকর্ড করুন';
  String get ninTextNutritionEducationContent => 'পুষ্টি শিক্ষা বিষয়বস্তু';
  String get ninTextMyNutrientIntake => 'আমার পুষ্টি গ্রহণ';
  String get ninTextOn => 'চালু';
  String get ninTextWithReferenceToEAR => 'EAR এর রেফারেন্স সহ';
  String get ninTextAchieveYourHealthGoals => 'আপনার স্বাস্থ্য লক্ষ্য অর্জন';
  String get ninTextPercentage => 'শতাংশ';
  String get ninTextMyPreviousDietDiaries => 'আমার আগের খাদ্য ডায়েরি';
  String get ninTextRecordReviewSleep => 'রেকর্ড / পর্যালোচনা ঘুম';
  String get ninTextHours => 'ঘন্টা';
  String get ninTextIngredient => 'উপাদান';
  String get ninTextOthersSpecify => 'অন্যান্য (উল্লেখ করুন';
  String get ninTextAddNewIngredient => 'নতুন উপাদান যোগ করুন';
  String get ninTextFoodName => 'খাবারের নাম';
  String get ninTextSource => 'উৎস';
  String get ninTextEnterBrandAndProductName =>
      'ব্র্যান্ড এবং পণ্যের নাম লিখুন';
  String get ninTextEnterAuthorDetails =>
      'লেখকের নাম, বছর, জার্নাল, পৃষ্ঠা লিখুন';
  String get ninTextEnterFctName => 'FCT এর নাম লিখুন';
  String get ninTextName => 'নাম';
  String get ninTextProductName => 'পণ্যের নাম';
  String get ninTextSelectStartDate => 'শুরুর তারিখ নির্বাচন করুন';
  String get ninTextSelectEndDate => 'শেষ তারিখ নির্বাচন করুন';
  String get ninTextNoExercise => 'কোন ব্যায়াম';
  String get ninTextDevelopedWithExpertiseAndInputs =>
      'সেন্টার ফর ডেভেলপমেন্ট অ্যান্ড অ্যাডভান্সড কম্পিউটিং (সি-ড্যাক), হায়দ্রাবাদ ল্যাঙ্গুয়েজ লিংক দ্বারা এনআইএন থেকে দক্ষতা এবং ইনপুট নিয়ে তৈরি';
  String get ninTextMyNutrientIntakeToday => 'আজ আমার পুষ্টি গ্রহণ';
  String get ninTextIcmrNationalInstituteOfNutritionAddress =>
      'ICMR - তরনাকা মেট্রো স্টেশনের পাশে ন্যাশনাল ইনস্টিটিউট অফ নিউট্রিশন, জামাই-ওসমানিয়া PO, হায়দ্রাবাদ-500 007, ভারত।';

  String get ninTextKcal => 'kcal';
  String get ninTextKcalPerDay => 'kcal/দিন';
  String get ninTextDelete => 'মুছে ফেলা';
  String get ninTextDeleteNotification => 'বিজ্ঞপ্তি মুছুন';
  String get ninTextConfirmDeleteNotification =>
      'আপনি কি এই বিজ্ঞপ্তিটি মুছতে চান?';
  String get ninTextTimeFor => 'আরে, এটা\'s time for';
  String get ninTextFitbitWatch => 'ফিটবিট ঘড়ি';
  String get ninTextGoogleFitApp => 'Google Fit অ্যাপ';
  String get ninTextUnderweight => 'কম ওজন';
  String get ninTextNormal => 'স্বাভাবিক';
  String get ninTextOverweight => 'অতিরিক্ত ওজন';
  String get ninTextObesity => 'স্থূলতা';
  String get ninTextMale => 'পুরুষ';
  String get ninTextFemale => 'মহিলা';
  String get ninTextAgeInYears => 'বয়স বছরে';
  String get ninTextChangeInWeight => 'ওজনে পরিবর্তন';
  String get ninTextSteps => 'ধাপ';
  String get ninTextFor => 'জন্য';
  String get ninTextMinutes => 'মিনিট';
  String get ninTextPause => 'বিরতি';
  String get ninTextReset => 'রিসেট';
  String get ninTextStartActivity => 'আপনার কার্যকলাপ শুরু করুন';
  String get ninTextCartIsEmpty => 'তোমার থলে তো খালি';
  String get ninTextMyPersonalRecipe => 'আমার ব্যক্তিগত রেসিপি';
  String get ninTextSearchByRecipeName => 'রেসিপি নাম দ্বারা অনুসন্ধান করুন';
  String get ninTextHelpCenter => 'সাহায্য কেন্দ্র';
  String get ninTextCommonProblems => 'সাধারন সমস্যা';
  String get ninTextFAQs => 'FAQs';
  String get ninTextHowActiveAreYou => 'আপনি কতটা সক্রিয়';
  String get ninTextVitaminC => 'ভিটামিন সি (মিগ্রা)';
  String get ninTextVitaminA => 'ভিটামিন এ (IU)';
  String get ninTextSodium => 'সোডিয়াম (মিগ্রা)';
  String get ninTextJournal => 'জার্নাল';
  String get ninTextPage => 'পাতা';
  String get ninTextAdequateIntakeCarbs =>
      '*পর্যাপ্ত পরিমাণে গ্রহণ (AI) কার্বোহাইড্রেটের জন্য প্রস্তাবিত: প্রাপ্তবয়স্ক পুরুষ এবং মহিলাদের জন্য 130 গ্রাম।';
  String get ninTextAdequateIntakeFiber =>
      '**এআই ফাইবারের জন্য প্রস্তাবিত: মহিলাদের জন্য 25 গ্রাম এবং পুরুষদের জন্য 38 গ্রাম।';
  String get your => 'তোমার';
  String get question1 => 'আমি কি আমার ব্যক্তিগত বিবরণ সম্পাদনা করতে পারি?';
  String get answer1 =>
      'হ্যাঁ. আপনার ব্যক্তিগত তথ্য আপনার প্রোফাইলে সম্পাদনা করা যেতে পারে.';
  String get linkText1 =>
      'আপনার ব্যক্তিগত বিবরণ সম্পাদনা করতে এখানে ক্লিক করুন';

  String get question2 => 'আমি কি আমার যোগাযোগের বিবরণ পরিবর্তন করতে পারি?';
  String get answer2 =>
      "হ্যাঁ. আপনার প্রোফাইলের 'ব্যক্তিগত ডেটা' বিকল্পে গিয়ে আপনার যোগাযোগের বিবরণ পরিবর্তন করা যেতে পারে।";
  String get linkText2 =>
      'আপনার যোগাযোগের বিবরণ সম্পাদনা করতে এখানে ক্লিক করুন';

  String get question3 =>
      'আমি কি আমার ব্যবহারকারীর পাসওয়ার্ড পরিবর্তন করতে পারি?';
  String get answer3 =>
      "হ্যাঁ. আপনার প্রোফাইলের 'সেটিং' বিকল্পে গিয়ে আপনার পাসওয়ার্ড পরিবর্তন করা যেতে পারে।";
  String get linkText3 => 'আপনার পাসওয়ার্ড পরিবর্তন করতে এখানে ক্লিক করুন';

  String get question4 => 'আমি কিভাবে আমার BMI চেক করতে পারি?';
  String get answer4 =>
      "হোম পেজে প্রদর্শিত 'স্বাস্থ্য ক্যালকুলেটর' বিকল্পে দেওয়া 'BMI ক্যালকুলেটর'-এ আপনার উচ্চতা এবং শরীরের ওজন লিখে আপনি আপনার BMI পরীক্ষা করতে পারেন।";
  String get linkText4 => 'BMI ক্যালকুলেটর ব্যবহার করতে এখানে ক্লিক করুন';

  String get question5 => 'আমি কি গত মাসের জন্য আমার ওজন ট্র্যাক করতে পারি?';
  String get answer5 =>
      'হ্যাঁ. হোম পেজে দেওয়া ‘ওয়েট ম্যানেজার’ বিকল্পে আপনি গত মাস/বছরে আপনার শরীরের ওজনের পরিবর্তনের বিবরণ দেখতে পারেন।';
  String get linkText5 => 'আপনার ওজন ট্র্যাক করতে এখানে ক্লিক করুন';

  String get question6 =>
      'আমি কিভাবে একটি নির্দিষ্ট দিনে আমার সামগ্রিক শারীরিক কার্যকলাপ পরীক্ষা করতে পারি?';
  String get answer6 =>
      "আপনি হোম পেজে 'আমার কার্যকলাপ' বিকল্প থেকে আপনার শারীরিক কার্যকলাপ ট্র্যাক করতে পারেন।";
  String get linkText6 => 'আপনার কার্যকলাপ দেখতে এখানে ক্লিক করুন';

  String get question7 =>
      'আমি কিভাবে জল খাওয়ার জন্য একটি অনুস্মারক সেট করতে পারি?';
  String get answer7 =>
      "আপনি হোম পেজে দেওয়া 'সেট নোটিফিকেশন' বিকল্পে জল খাওয়ার অনুস্মারকের জন্য একটি সময় সেট করতে পারেন।";
  String get linkText7 => 'একটি জল খাওয়ার অনুস্মারক সেট করতে এখানে ক্লিক করুন';

  String get question8 =>
      'আমি কীভাবে আমার স্মার্ট ঘড়ির সাথে অ্যাপটিকে সংহত করতে পারি?';
  String get answer8 =>
      "আপনি হোম পেজে দেওয়া 'কানেক্ট ওয়াচ' বিকল্পে গিয়ে অ্যাপের সাথে আপনার স্মার্ট ঘড়িকে একীভূত করতে পারেন।";
  String get linkText8 => 'আপনার স্মার্ট ঘড়ি সংযোগ করতে এখানে ক্লিক করুন';

  String get question9 =>
      'আমি একবারে অ্যাপের সাথে কতগুলি পরিধানযোগ্য জিনিস একত্রিত করতে পারি?';
  String get answer9 =>
      'আপনি অ্যাপের সাথে Fitbit ঘড়ি এবং Google Fit সংহত করতে পারেন।';
  String get linkText9 => '';

  String get question10 => 'কোন স্মার্ট ঘড়ি অ্যাপের সাথে সামঞ্জস্যপূর্ণ?';
  String get answer10 => 'ফিটবিট ঘড়ি এবং গুগল ফিট।';
  String get linkText10 => '';

  String get question11 =>
      'আমার কাছে স্মার্ট ঘড়ি না থাকলে আমি কি আমার কার্যকলাপ ট্র্যাক করতে পারি?';
  String get answer11 =>
      'হ্যাঁ, আপনি আপনার কার্যকলাপ ট্র্যাক করতে পারেন. এর জন্য, আপনাকে Google Fit অ্যাপটি ডাউনলোড করতে হবে, একটি Google অ্যাকাউন্ট দিয়ে সাইন ইন করতে হবে এবং একই Google অ্যাকাউন্ট দিয়ে আপনাকে আমাদের ঘড়ি বিভাগে লগ ইন করতে হবে।';
  String get linkText11 => '';

  String get question12 => 'আমি কিভাবে আমার ঘুম ট্র্যাক করতে পারি?';
  String get answer12 =>
      'হোম পেজে দেওয়া স্লিপ ট্র্যাকার বিকল্পে গিয়ে আপনি সাপ্তাহিক/মাসিক ভিত্তিতে আপনার ঘুম ট্র্যাক করতে পারেন।';
  String get linkText12 => 'আপনার ঘুম ট্র্যাক করতে এখানে ক্লিক করুন';

  String get question13 =>
      'আমি কীভাবে অ্যাপের মাধ্যমে যেকোনো NIN প্রকাশনা কিনতে পারি?';
  String get answer13 =>
      "আপনি হোম পেজে দেওয়া 'বুক স্টোর' বিকল্প থেকে NIN প্রকাশনা কিনতে পারেন।";
  String get linkText13 => 'বইয়ের দোকানে যেতে এখানে ক্লিক করুন';

  String get question14 =>
      'আমি কিভাবে আমার ব্যক্তিগত খাদ্য ডায়েরি তৈরি করতে পারি?';
  String get answer14 =>
      "আপনি 'মাই ডায়েট ডায়েরি বিকল্প'-এ গিয়ে সারাদিন খাওয়া খাবারের বিবরণ লিখতে পারেন।";
  String get linkText14 => 'আপনার খাদ্য ডায়েরি তৈরি করতে এখানে ক্লিক করুন';

  String get question15 =>
      'আমি কীভাবে এমন একটি রেসিপি অনুসন্ধান করতে পারি যা একটি নির্দিষ্ট পুষ্টিতে সমৃদ্ধ?';
  String get answer15 =>
      'আপনি প্রথমে হোম পেজে ‘আমার খাবারে পুষ্টি’ ট্যাবে দেওয়া ‘রেসিপিতে পুষ্টির সন্ধান করুন’ বিকল্পটি নির্বাচন করতে পারেন। তারপর উপরের ডান কোণে ড্রপ-ডাউন তালিকা থেকে প্রয়োজনীয় পুষ্টি নির্বাচন করুন।';
  String get linkText15 => 'রেসিপি অনুসন্ধান করতে এখানে ক্লিক করুন';

  String get question16 =>
      'আগের মাসে সংরক্ষিত একটি দিনের জন্য আমি কীভাবে আমার পুষ্টির পরিমাণ পরীক্ষা করতে পারি?';
  String get answer16 =>
      "আপনি 'খাবার তালিকা' পৃষ্ঠায় 'ক্যালেন্ডার আইকন' থেকে একটি তারিখ নির্বাচন করে একটি নির্দিষ্ট দিনে আপনার পুষ্টির পরিমাণ দেখতে পারেন।";
  String get linkText16 => 'আপনার পুষ্টি গ্রহণ পরীক্ষা করতে এখানে ক্লিক করুন';

  String get question17 =>
      'আমার রেসিপিগুলিতে ব্যবহৃত কাঁচা উপাদানগুলির পুষ্টি আমি কীভাবে খুঁজে পেতে পারি?';
  String get answer17 =>
      'হোম পেজে থাকা ‘আমার খাবারে পুষ্টি’ ট্যাবে দেওয়া ‘কাঁচা খাবারে পুষ্টির সন্ধান করুন’ বিকল্পটি নির্বাচন করে আপনি একটি নির্দিষ্ট উপাদানের পুষ্টিগুণ জানতে পারবেন।';
  String get linkText17 =>
      'কাঁচা খাবারে পুষ্টি অনুসন্ধান করতে এখানে ক্লিক করুন';
  String get EssentialNutritionalGuidelines =>
      "ভারতীয়দের খাদ্য প্রয়োজনের জন্য উপযুক্ত মৌলিক পুষ্টি নির্দেশিকা।";
  String get NutrientRequirementsRDA2020 =>
      "ভারতীয়দের জন্য পুষ্টি প্রয়োজনীয়তা এবং প্রস্তাবিত খাদ্য ভাতা (RDA 2020)।";
  String get RecommendationsBalancedDiets =>
      "ভারতে সুষম খাদ্য এবং স্বাস্থ্যকর খাওয়ার অভ্যাস প্রচারের জন্য সুপারিশ।";
  String get DietaryGuidelinesForIndians => "ভারতীয়দের জন্য খাদ্য নির্দেশিকা।";
  String get Nutritionstat => "পুষ্টি পরিসংখ্যান";
  String get referenceMen65kg => "মানুষের রেফারেন্স (65 কেজি)";
  String get referenceWomen55kg => "মহিলাদের রেফারেন্স (55 কেজি)";
  String get valueForMen => "1506";
  String get valueForWomen => "1184";

  String get question18 => 'আমি কীভাবে একটি রেসিপির পুষ্টির গঠন জানতে পারি?';
  String get answer18 =>
      "আপনি হোম পেজে 'আমার খাবারে পুষ্টি' ট্যাবে দেওয়া 'রেসিপিতে পুষ্টির সন্ধান করুন' বিকল্পটি নির্বাচন করে একটি নির্দিষ্ট উপাদানের পুষ্টি জানতে পারেন।";
  String get linkText18 => 'পুষ্টির গঠন জানতে এখানে ক্লিক করুন';

  String get question19 =>
      'আমি কি একটি নতুন রেসিপি অন্তর্ভুক্ত করতে পারি যা অ্যাপে উপলব্ধ নয়?';
  String get answer19 =>
      "হ্যাঁ. আপনি হয় নির্দিষ্ট নির্দিষ্ট রেসিপির নীচে দেওয়া লিঙ্কটি ব্যবহার করে একটি বিদ্যমান রেসিপি পরিবর্তন করতে পারেন বা ডায়েট ডায়েরি পৃষ্ঠায় প্রতিটি খাবারের জন্য দেওয়া 'কাস্টম ডিশ তৈরি করুন' বিকল্পে ক্লিক করে একটি সম্পূর্ণ নতুন রেসিপি তৈরি করতে পারেন।";
  String get linkText19 => 'একটি কাস্টম রেসিপি তৈরি করতে এখানে ক্লিক করুন';

  String get question20 =>
      'আমি কি একটি নির্দিষ্ট স্বাস্থ্য অবস্থার জন্য খাদ্যের সুপারিশ পেতে পারি?';
  String get answer20 =>
      "হ্যাঁ. আপনি হোম পেজে 'সার্চ কম্পোনেন্ট' বিকল্প থেকে স্বাস্থ্য সুপারিশ বা ডায়েট চার্ট নির্দেশিকা পেতে পারেন।";
  String get linkText20 => 'খাদ্যতালিকাগত সুপারিশ পেতে এখানে ক্লিক করুন';

  String get question21 =>
      'আমি কি ইংরেজি ছাড়া অন্য কোনো ভাষায় অ্যাপ ব্যবহার করতে পারি?';
  String get answer21 =>
      "হ্যাঁ. আপনি আপনার প্রোফাইলে দেওয়া 'সেটিং' বিকল্প থেকে পছন্দসই ভাষা নির্বাচন করতে পারেন।";
  String get linkText21 => 'ভাষা পরিবর্তন করতে এখানে ক্লিক করুন';

  String get ninTextBmiHwading => 'বডি মাস ইনডেক্স (BMI):';
  String get ninTextBmiDiscription =>
      'BMI কে একজন ব্যক্তির ওজন কেলোগ্রামে ব্যক্তির উচ্চতার বর্গ মিটার (kg/m2) দ্বারা ভাগ করা হয়। শরীরের অত্যধিক চর্বি রোগ এবং মৃত্যুর উপর যে প্রভাব ফেলে তার উপর ভিত্তি করে বিএমআই রেঞ্জ তৈরি করা হয় এবং যৌক্তিকভাবে অ্যাডিপোসিটির সাথে সম্পর্কিত। বিএমআই রোগের ঝুঁকি নির্দেশক হিসাবে বিকশিত হয়েছিল; BMI যেমন বাড়ে, তেমনি কিছু রোগের ঝুঁকিও বাড়ে। অতিরিক্ত ওজন এবং স্থূলতার সাথে সম্পর্কিত কিছু সাধারণ অবস্থার মধ্যে রয়েছে: অকাল মৃত্যু, কার্ডিওভাসকুলার রোগ, উচ্চ রক্তচাপ, অস্টিওআর্থারাইটিস, কিছু ক্যান্সার এবং ডায়াবেটিস।';
  String get ninTextbminutritionsta => 'BMI পুষ্টির অবস্থা';
  String get ninTextNutritionstat => 'পুষ্টির অবস্থা';
  String get ninTextBelow => 'নিচে';
  String get ninTextPreobesity => 'প্রাক-স্থূলতা';

  String get ninTextbesity => 'স্থূলতা ক্লাস I';
  String get ninTextbesity2 => 'স্থূলতা ক্লাস II';
  String get ninTextbesity3 => 'স্থূলতা ক্লাস II';
  String get ninTextBMRfull => 'বেসাল মেটাবলিক রেট (BMR)';
  String get ninTextBMRDiscription =>
      'বেসাল মেটাবলিক রেট (BMR) হল সেই হার যা একজন ব্যক্তি বিশ্রামের সময় শক্তি ব্যয় করে';
  String get ninTextPreviousdays => 'আগের 30 দিন';
  String get ninTextason => 'একটি ছেলে';
  String get ninTextYearly => 'বার্ষিক';
  String get ninTextabove => 'উপরে';
  String get ninTextAchieveyourhealthgoal => 'আপনার স্বাস্থ্য লক্ষ্য অর্জন';
  String get heavyDescription =>
      'এই বিভাগে প্রতিদিন এক ঘন্টার বেশি সময় ধরে নিয়মিত এবং তীব্র শারীরিক ক্রিয়াকলাপ যেমন দৌড়ানো, সাইকেল চালানো বা ভারী উত্তোলন জড়িত পেশাগুলিকে অন্তর্ভুক্ত করে। উদাহরণের মধ্যে রয়েছে কামার, খনি শ্রমিক এবং নির্মাণ শ্রমিক।';
  String get moderateDescription =>
      'এই বিভাগের ব্যক্তিরা প্রতিদিন প্রায় 30 মিনিট থেকে এক ঘন্টা ধরে হাঁটা বা হালকা জগিংয়ের মতো কিছু স্তরের শারীরিক কার্যকলাপে নিযুক্ত হন। কায়িক শ্রমিক, কারিগর এবং কিছু ধরণের দক্ষ শ্রমিকের মতো পেশাগুলি এই বিভাগে পড়ে।';
  String get sedentaryDescription =>
      'এই বিভাগের মধ্যে এমন পেশাগুলি অন্তর্ভুক্ত রয়েছে যেখানে সারাদিনে সামান্য থেকে কোনও শারীরিক নড়াচড়া নেই৷ এই চাকরির লোকেরা তাদের বেশিরভাগ সময় বসে বা শুয়ে কাটায়। উদাহরণগুলির মধ্যে অফিসের কর্মী, শিক্ষক এবং প্রশাসনিক ভূমিকা রয়েছে।';
  String get Foodprotein => "প্রোটিন";
  String get Foodfat => "মোটা";
  String get Foodenergy => "শক্তি";
  String get FoodtotalB2 => "মোট B2";
  String get Foodvitamins => "ভিটামিন";
  String get FoodtotalFat => "মোট চর্বি";
  String get FoodproximateComposition => "আনুমানিক রচনা";
  String get FoodnutrientsIn100g => "100 গ্রাম মধ্যে পুষ্টি";
  String get FoodtotalCarotenoids => "মোট ক্যারোটিনয়েড";
  String get FoodtotalAscorbicAcid => "মোট অ্যাসকরবিক অ্যাসিড";
  String get FoodtotalB9 => "মোট B9";
  String get FoodtotalB6 => "মোট B6";
  String get Foodcalcium => "ক্যালসিয়াম";
  String get Foodsodium => "সোডিয়াম";
  String get Foodpotassium => "পটাসিয়াম";
  String get Foodzinc => "দস্তা";
  String get Foodiron => "আয়রন";
  String get Foodminerals => "খনিজ পদার্থ";
  String get FoodtotalSaturatedFattyAcids => "মোট স্যাচুরেটেড ফ্যাটি অ্যাসিড";
  String get FoodfattyAcids => "ফ্যাটি এসিড";
  String get FoodtotalDietaryFiber => "মোট ডায়েটারি ফাইবার";
  String get Foodmanganese => "ম্যাঙ্গানিজ";
  String get Foodcopper => "তামা";
  String get Foodselenium => "সেলেনিয়াম";
  String get Foodmagnesium => "ম্যাগনেসিয়াম";
  String get Foodphosphorus => "ফসফরাস";
  String get Foodcholesterol => "কোলেস্টেরল";
  String get Foodcarbohydrate => "কার্বোহাইড্রেট";
  String get FoodvitaminB6 => "ভিটামিন বি৬ (মিলিগ্রাম)";
  String get Punjabi => "পাঞ্জাবি";
  String get Gujarati => "গুজরাটি";
  String get Odia => "ওড়িয়া";
  String get Kannada => "কান্নাড়";
  String get Marathi => "মারাঠি";
  String get Tamil => "তামিল";
  String get Bengali => "বাংলা";
  String get Telugu => "তেলেগু";
  String get English => "ইংরেজি";
  String get Hindi => "হিন্দি";
  String get firstname => "প্রথম নাম";
  String get lastname => "শেষ নাম";
  String get labelSodium => "সোডিয়াম";
  String get labelVitaminC => "ভিটামিন সি";
  String get FinanameEnergy => "শক্তি";
  String get FinanameCarbohydrate => "কার্বোহাইড্রেট";
  String get FinanameFat => "চর্বি";
  String get FinanameSodium => "সোডিয়াম";
  String get FinanameDietaryFibre => "খাদ্য আঁশ";
  String get FinanameCalcium => "ক্যালসিয়াম";
  String get FinanameIron => "লোহা";
  String get FinanameMagnesium => "ম্যাগনেসিয়াম";
  String get FinanameZinc => "দস্তা";
  String get FinanameProtein => "প্রোটিন";
  String get FinanameThiamine => "থিয়ামিন";
  String get FinanameRiboflavin => "রাইবোফ্লাভিন";
  String get FinanameNiacin => "নায়াসিন";
  String get FinanameVitaminB => "ভিটামিন বি";
  String get FinanameFolate => "ফোলেট";
  String get FinanameVitaminC => "ভিটামিন সি";
  String get FinanameVitaminA => "ভিটামিন এ";
  String get FinanameVitaminb6 => "ভিটামিন বি৬";
  String get referenceMenWomenDescription =>
      "রেফারেন্স পুরুষ এবং মহিলা হিসাবে 19-39 বছর বয়সী সুস্থ প্রাপ্তবয়স্কদের বোঝায়, যাদের বিএমআই স্বাভাবিক এবং যারা মাঝারি সক্রিয় (ICMR-NIN)। দেখুন";
  String get personalizedDietDiaryDescription =>
      "ব্যক্তিগতকৃত ডায়েট ডায়েরি আপনার পুষ্টির গ্রহণকে বর্তমান থেকে গত মাস পর্যন্ত ট্র্যাক করে";

  String get confirmDeleteAllNotifications =>
      "আপনি কি নিশ্চিত যে আপনি সমস্ত বিজ্ঞপ্তি মুছে ফেলতে চান?";
  String get fillAllFields => "সমস্ত ঘর পূরণ করুন";
  String get successfullyAddedIngredient => "উপাদান সফলভাবে যোগ করা হয়েছে";
  String get confirmDeletion => "মুছে ফেলার নিশ্চয়তা দিন";
  String get confirmDeleteIngredient =>
      "আপনি কি নিশ্চিত যে আপনি এই উপাদানটি মুছে ফেলতে চান?";
  String get fileDownloaded => "ফাইল সফলভাবে ডাউনলোড হয়েছে এবং ফাইলের অবস্থান";
  String get confirmDeleteFood =>
      "আপনি কি নিশ্চিত যে আপনি খাবারটি মুছে ফেলতে চান?";
  String get estimatedAverageRequirement =>
      'আনুমানিক গড় প্রয়োজনীয়তা (EAR): স্বাস্থ্যকর ব্যক্তিদের ৫০% এর প্রয়োজনীয়তা পূরণের জন্য প্রতিদিনের গড় স্তর';
  String get editQuantity => "পরিমাণ সম্পাদনা করুন";
  String get confirmDelete => "আপনি কি নিশ্চিত যে আপনি মুছে ফেলতে চান?";
  String get exerciseDeleted => "ব্যায়াম সফলভাবে মুছে ফেলা হয়েছে।";
  String get confirmDeleteExercise =>
      "আপনি কি নিশ্চিত যে আপনি এই ব্যায়ামটি মুছে ফেলতে চান?";
}
