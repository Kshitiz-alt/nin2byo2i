// LanguageOr.dart
import 'languages.dart';

class LanguageOr extends Languages {
  @override
  String get appName => "NIN2.0";
  String get recordMyDiet => "ମୋର ଆହାର ରେକର୍ଡ କରନ୍ତୁ";

  @override
  String get labelWelcome => "ସ୍ Welcome ାଗତ";
  String get inputActivityDataPrompt =>
      "ଆପଣଙ୍କର ଶକ୍ତି ଖର୍ଚ୍ଚ ଏବଂ ସମତୁଳନ ଦେଖିବା ପାଇଁ, ଦୟାକରି 24-ଘଣ୍ଟା କାର୍ଯ୍ୟକଳାପ ତଥ୍ୟ ପ୍ରବେଶ କରନ୍ତୁ।";
  String get myEnergyBalanceYesterday => "ମୋର ଶକ୍ତି ସମତୁଳନ (ଗୋଟେକାଳି)";
  String get caloriesBurnFromWatch => "ଘଡ଼ିରୁ ଜଳିଥିବା କ୍ୟାଲୋରି";
  String get tryLater => "ପରେ ଚେଷ୍ଟା କରନ୍ତୁ";
  @override
  String get labelSelectLanguage => "ଭାଷା ଚୟନ କରନ୍ତୁ |";
  String get activities => "କାର୍ଯ୍ୟକଳାପ";
  String get searchActivityHere => "ଏଠାରେ କାର୍ଯ୍ୟକଳାପ ଖୋଜନ୍ତୁ";
  String get orSelectActivityFromBelow => "ନାହିଁଲେ ତଳୁ କାର୍ଯ୍ୟକଳାପ ଚୟନ କରନ୍ତୁ";
  String get moisture => "ଅର୍ଦ୍ରତା";
  String get indianFoodCompositionTitle => "ଭାରତୀୟ ଖାଦ୍ୟ ଗଠନ ତାଲିକା (୨୦୧୭)";

  String get indianFoodCompositionDescription =>
      "ଭାରତୀୟ ଖାଦ୍ୟ ଗଠନ ତାଲିକା (୨୦୧୭): ଭାରତୀୟ ଖାଦ୍ୟ ପାଇଁ ବ୍ୟାପକ ପୋଷକ ତଥ୍ୟ।";

  @override
  String get labelInfo => "ଏହା ହେଉଛି ବହୁ-ଭାଷା ଡେମୋ ପ୍ରୟୋଗ |";
  String get totalEnergyConsumption => "ସମୁଦୟ ଶକ୍ତି ଖପାଇବା";
  String get totalEnergyExpenditure => "ସମୁଦୟ ଶକ୍ତି ବୟାର୍ଥ";
  String get energybalance => "ଶକ୍ତି ସମତ୍ୱ";
  String get indicatorhealth =>
      "('+' ଶକ୍ତି ଅଧିଶେଷରେ ଚିହ୍ନିତ କରେ; '-' ଶକ୍ତି ଘାଟକରେ ଚିହ୍ନିତ କରେ)";

  @override
  // TODO: implement labelChangeLanguage
  String get labelChangeLanguage => "ଭାଷା ପରିବର୍ତ୍ତନ କରନ୍ତୁ |";
  @override
  String get labelWelcomeBack => "ପୁଣି ଥରେ ସ୍ୱାଗତ,";

  @override
  String get labelUnderweight => "ତୁମର ଓଜନ କମ୍ |";

  @override
  String get labelNormalWeight => "ତୁମେ ସାଧାରଣ ଓଜନ |";

  @override
  String get labelOverweight => "ତୁମେ ଅଧିକ ଓଜନିଆ |";

  @override
  String get labelObese => "ତୁମେ ମେଦବହୁଳ |";

  @override
  String get labelViewMore => "ଅଧିକ ଦେଖନ୍ତୁ |";

  @override
  String get labelTodaySteps => "ଆଜିର ପଦକ୍ଷେପ |";

  @override
  String get labelCheck => "ଯାଞ୍ଚ କରନ୍ତୁ |";

  @override
  String get labelHealthData =>
      "ମୋର ରକ୍ତଚାପ / ରକ୍ତ ଗ୍ଲୁକୋଜ / SPO2 ରେକର୍ଡ କରନ୍ତୁ |";

  @override
  String get labelActivityStatus => "କାର୍ଯ୍ୟକଳାପ ସ୍ଥିତି";

  @override
  String get labelHeartRate => "ହୃଦଘାତ";

  @override
  String get labelHeartRateValue => "78 BPM |";

  @override
  String get labelMinutesAgo => "ମିନିଟ୍ ପୂର୍ବରୁ";

  @override
  String get labelWaterIntake => "ମୋର ଜଳ ଗ୍ରହଣ";

  @override
  String get labelLiters => "ଲିଟର";

  @override
  String get labelZeroLiters => "0 ଲିଟର |";

  @override
  String get labelRealTimeGoal => "ପ୍ରକୃତ ସମୟ, ଲକ୍ଷ୍ୟ |";

  @override
  String get labelCalories => "କ୍ୟାଲୋରୀ ପୋଡିଗଲା |";

  @override
  String get labelCaloriesEarned => "କ୍ୟାଲୋରୀ ଅର୍ଜନ |";

  @override
  String get labelFoodPlan => "ଖାଦ୍ୟ ଯୋଜନା";

  @override
  String get labelWorkoutProgress => "ବ୍ୟାୟାମ ଅଗ୍ରଗତି |";

  @override
  String get labelWeekly => "ସାପ୍ତାହିକ";

  @override
  String get labelMonthly => "ମାସିକ";

  @override
  String get labelLatestWorkout => "ସର୍ବଶେଷ ବ୍ୟାୟାମ";

  @override
  String get labelSeeMore => "ଅଧିକ ଦେଖନ୍ତୁ |";
  String get labelBreakfast => "ଜଳଖିଆ";
  String get labelLunch => "ମଧ୍ୟାହ୍ନ ଭୋଜନ";
  String get labelDinner => "ରାତ୍ରୀ ଭୋଜନ";
  String get labelSnacks => "ସ୍ନାକ୍ସ";
  String get labelTaken => "ନିଆଯାଇଛି";
  String get labelTarget => "ଲକ୍ଷ୍ୟ";

  //profile

  String get labelProfile => "ପ୍ରୋଫାଇଲ୍";
  String get labelEdit => "ସଂପାଦନା କରନ୍ତୁ |";
  String get labelUser => "ଉପଯୋଗକର୍ତ୍ତା |";
  String get labelProgram => "ଏକ ଚର୍ବି ପ୍ରୋଗ୍ରାମ୍ ହରାନ୍ତୁ |";
  String get labelHeight => "ଉଚ୍ଚତା";
  String get labelWeight => "ଓଜନ";
  String get labelAge => "ବୟସ";
  String get labelAccount => "ଖାତା";
  String get labelPersonalData => "ବ୍ୟକ୍ତିଗତ ତଥ୍ୟ";
  String get labelAchievement => "ସଫଳତା";
  String get labelActivityHistory => "କାର୍ଯ୍ୟକଳାପ ଇତିହାସ";
//String get labelWorkoutProgress => "ବ୍ୟାୟାମ ପ୍ରଗତି |";
  String get labelNotification => "ବିଜ୍ଞପ୍ତି";
  String get labelPopupNotification => "ପପ୍-ଅପ୍ ବିଜ୍ଞପ୍ତି |";
  String get labelMensurationCycle => "ଚକ୍ର ମାପ";
  String get labelOther => "ଅନ୍ୟମାନେ |";
  String get labelContactUs => "ଆମ ସହିତ ଯୋଗାଯୋଗ କରନ୍ତୁ |";
  String get labelPrivacyPolicy => "ଗୋପନୀୟତା ନୀତି";
  String get labelSetting => "ସେଟିଂ";
  String get labelFeedback => "ମତାମତ";
  String get labelConfirmLogout => "ଲଗଆଉଟ୍ ନିଶ୍ଚିତ କରନ୍ତୁ |";
  String get labelConfirmLogoutMessage =>
      "ଆପଣ ନିଶ୍ଚିତ କି ଆପଣ ଲଗ୍ ଆଉଟ୍ କରିବାକୁ ଚାହୁଁଛନ୍ତି?";
  String get labelLogout => "ପ୍ରସ୍ଥାନ କର";
  //select tab
  String get labelOptions => "ବିକଳ୍ପଗୁଡ଼ିକ";
  String get labelFoodTable => "ଖାଦ୍ୟ ମିଶାନ୍ତୁ |";
  String get labelTop10Food => "ଶ୍ରେଷ୍ଠ ୧୦ଟି ଖାଦ୍ୟ |";
  String get labelActivityTrack => "କାର୍ଯ୍ୟକଳାପ ଟ୍ରାକର୍ |";
  String get labelsteptracker => "ଷ୍ଟେପ୍ ଟ୍ରାକର୍ |";

  String get labelTodayTarget => "ଜଳ ଲକ୍ଷ୍ୟ |";
  String get labelJoggingTrack => "ଜଗିଂ ଟ୍ରାକ୍ |";
  String get labelMensurationTrack => "ମାନସ ଟ୍ରାକ |";
//String get labelFoodTable => "ଖାଦ୍ୟ ସାରଣୀ |";
  String get labelPassword => "ପାସୱାର୍ଡ ପରିବର୍ତ୍ତନ କରନ୍ତୁ";
  String get labelDarkMode => "ଅନ୍ଧାର ମୋଡ୍ ଚେଷ୍ଟା କରନ୍ତୁ |";
  String get labelconectWatch => "ଘଣ୍ଟା ସଂଯୋଗ କରନ୍ତୁ |";
  @override
  String get labelSleep => "ଶୋଇବା |";
  @override
  String get labelBookStore => "ବୁକ୍ ଷ୍ଟୋର୍‌ |";
  @override
  String get labelSearchBooks => "ବହି ଖୋଜ |";
  @override
  String get labelPrice => "ମୂଲ୍ୟ";
  @override
  String get labelAddToCart => "କାର୍ଟରେ ଯୋଗ କର";
  @override
  String get labelAuthor => "ଲେଖକ";
  @override
  String get labelYear => "ବର୍ଷ";
  @override
  String get labelQuantityAvailable => "ପରିମାଣ ଉପଲବ୍ଧ |";
  @override
  String get labelCart => "କାର୍ଟରେ ଯୋଗ କର";
  @override
  String get labelMyOrders => "ମୋର ଆଦେଶ";
  @override
  String get labelAllOrders => "ସମସ୍ତ ଅର୍ଡର |";
  @override
  String get labelOrderDetail => "ସବିଶେଷ ବିବରଣୀ ଅର୍ଡର କରନ୍ତୁ |";
  @override
  String get labelOrderId => "ଆଇଡି ଅର୍ଡର କରନ୍ତୁ |";
  @override
  String get labelOrdersInMyOrders => "ମୋ ଆଦେଶରେ ଅର୍ଡର |";
  @override
  String get labelItemsInMyOrders => "ମୋ କ୍ରମରେ ଆଇଟମ୍ |";
  @override
  String get labelTotal => "ସମୁଦାୟ";
  @override
  String get labelTotalPrice => "ମୋଟ ମୂଲ୍ୟ";
  @override
  String get labelCheckout => "ଚେକଆଉଟ୍ |";

  // Meal List
  @override
  String get labelMealList => "ମୋର ଡାଏଟ୍";
  @override
  String get labelAnalyze => "ବିଶ୍ଳେଷଣ କର |";
  @override
  String get labelAddDish => "ଥାଳି ମିଶାନ୍ତୁ |";
  @override
  String get labelTop10Foods => "ଶ୍ରେଷ୍ଠ ୧୦ଟି ଖାଦ୍ୟ |";
  @override
  String get labelRecentMeal => "ସାମ୍ପ୍ରତିକ ଭୋଜନ";
  @override
  String get labelAnalyzeIngredientsTaken => "ଖାଦ୍ୟ ଗ୍ରହଣକୁ ବିଶ୍ଳେଷଣ କରନ୍ତୁ |";

  // Nutrition Summary
  @override
  String get labelCarbs => "କାର୍ବୋହାଇଡ୍ରେଟ୍ |";
  // @override
  // String get labelCalories => "କ୍ୟାଲୋରୀ |";
  @override
  String get labelFibers => "ମୋଟ ଫାଇବର |";
  @override
  String get labelFats => "ମୋଟା";
  @override
  String get labelProteins => "ପ୍ରୋଟିନ୍ |";
  @override
  String get labelCalcium => "କ୍ୟାଲସିୟମ୍";

  @override
  String get labelNiacinB3 => "ନିୟାସିନ୍ (B3)";

  @override
  String get labelThiamineB1 => "ଥିଏମାଇନ୍ (B1)";

  @override
  String get labelIron => "ଲ Iron ହ |";

  @override
  String get labelZinc => "ଜିଙ୍କ୍ |";

  @override
  String get labelFolatesB9 => "ଫୋଲେଟ୍ (B9)";

  @override
  String get labelRiboflavinB2 => "ରିବୋଫ୍ଲାଭିନ୍ (B2)";

  @override
  String get labelRetinolVitA => "ରେଟିନୋଲ୍ (ଭିଟାମିନ୍ ଏ)";

  @override
  String get labelMagnesium => "ମ୍ୟାଗ୍ନେସିୟମ୍ |";

  @override
  String get labelTodaysNutritionSummary => "ଆଜିର ପୁଷ୍ଟିକର ସାରାଂଶ |";
  @override
  String get labelChangeGoal => "ଲକ୍ଷ୍ୟ ପରିବର୍ତ୍ତନ କରନ୍ତୁ |";
  @override
  String get labelIngredientsTaken => "ନିଆଯାଇଥିବା ସାମଗ୍ରୀ";
  @override
  String get labelIngredientsLeft => "ଉପାଦାନଗୁଡିକ ବାକି ଅଛି |";

  // Food Table
  // @override
  // String get labelFoodTable => "ଖାଦ୍ୟ ସାରଣୀ |";
  // @override
  // String get labelBreakfast => "ଜଳଖିଆ";
  // @override
  // String get labelLunch => "ମଧ୍ୟାହ୍ନ ଭୋଜନ";
  // @override
  // String get labelDinner => "ରାତ୍ରୀ ଭୋଜନ";
  // @override
  // String get labelSnacks => "ସ୍ନାକ୍ସ";
  @override
  String get labelTop10FoodsSleep => "ଶ୍ରେଷ୍ଠ ୧୦ଟି ଖାଦ୍ୟ |";
  @override
  String get labelFavouriteDishes => "ପ୍ରିୟ ଖାଦ୍ୟ";

  // User Profile
  @override
  String get labelHelp => "ସାହାଯ୍ୟ";
  // @override
  // String get labelLogout => "ପ୍ରସ୍ଥାନ କର";
  // @override
  // String get labelWeight => "ଓଜନ";
  @override
  String get labelEmail => "ଇମେଲ୍ କରନ୍ତୁ |";
  // @override
  // String get labelHeight => "ଉଚ୍ଚତା";
  @override
  String get labelLinkedInProfileLink => "ଲିଙ୍କଡଇନ୍ ପ୍ରୋଫାଇଲ୍ ଲିଙ୍କ୍ |";
  @override
  String get labelGoogleProfileLink => "ଗୁଗୁଲ୍ ପ୍ରୋଫାଇଲ୍ ଲିଙ୍କ୍ |";
  @override
  String get labelFacebookProfileLink => "ଫେସବୁକ୍ ପ୍ରୋଫାଇଲ୍ ଲିଙ୍କ୍ |";
  @override
  String get labelTwitterProfileLink => "ଟ୍ୱିଟର ପ୍ରୋଫାଇଲ୍ ଲିଙ୍କ୍ |";
  @override
  String get labelName => "ନାମ";
  @override
  String get labelPhoneNumber => "ଫୋନ୍ ନମ୍ବର";
  @override
  String get labelDateOfBirth => "D.O.B।";
  @override
  String get labelBMI => "BMI";
  // @override
  // String get labelAge => "ବୟସ";

  // Contact Us
  @override
  String get labelMessage => "ବାର୍ତ୍ତା |";
  @override
  String get labelSubmit => "ଦାଖଲ କରନ୍ତୁ |";
  @override
  String get labelCompanyContacts => "କମ୍ପାନୀ ଯୋଗାଯୋଗ |";
  @override
  String get labelAddress => "ଠିକଣା";
  @override
  String get labelDirectorsEmail => "ନିର୍ଦ୍ଦେଶକଙ୍କ ଇମେଲ୍ |";
  @override
  String get labelFax => "FAX";

  // Settings
  @override
  String get labelResetPassword => "ପାସୱାର୍ଡ ପୁନ Res ସେଟ୍ କରନ୍ତୁ |";
  // @override
  // String get labelFeedback => "ମତାମତ";
  @override
  String get labelPleaseProvideFeedback =>
      "ଦୟାକରି ଆପଣଙ୍କର ମତାମତ ପ୍ରଦାନ କରନ୍ତୁ |";
  @override
  String get labelEnterYourFeedbackHere =>
      "ଏଠାରେ ଆପଣଙ୍କର ମତାମତ ପ୍ରବେଶ କରନ୍ତୁ |";
  @override
  String get labelSubmitFeedback => "ମତାମତ ଦାଖଲ କରନ୍ତୁ |";

  // Credits
  // @override
  // String get labelContactUs => "ଆମ ସହିତ ଯୋଗାଯୋଗ କରନ୍ତୁ |";
  @override
  String get labelDevelopmentTeam => "ବିକାଶ ଦଳ";
  @override
  String get labelAcknowledgments => "ସ୍ୱୀକୃତି";
  @override
  String get labelPartnerships => "ସହଭାଗୀତା |";

  // Mobile
  @override
  String get labelSearchComponents => "ଉପାଦାନଗୁଡିକ ସନ୍ଧାନ କରନ୍ତୁ |";
  @override
  String get labelSearchComponentsHere => "ଏଠାରେ ଉପାଦାନଗୁଡିକ ସନ୍ଧାନ କରନ୍ତୁ |";
  @override
  String get lablelDishName => 'ଡିସ୍ ନାମ |';
  @override
  String get labelCredits => 'କ୍ରେଡିଟ୍';
  @override
  String get labelShareAppButton => "ଅଂଶୀଦାର କରନ୍ତୁ |";
  @override
  String get labelShareApp =>
      "ବାରକୋଡ୍ ସ୍କାନର୍ ଆପ୍ ସହିତ QR କୋଡ୍ ସ୍କାନ୍ କରନ୍ତୁ ଏବଂ ଆପ୍ ଡାଉନଲୋଡ୍ କରନ୍ତୁ |";
  // New translations
  @override
  String get labelConnectedWatch => "ସଂଯୋଜିତ ଘଣ୍ଟା ହେଉଛି |";
  @override
  String get labelDisconnect => "ବିଚ୍ଛିନ୍ନ କରନ୍ତୁ |";
  @override
  String get labelFitbit => "ଫିଟବିଟ୍ |";
  @override
  String get labelGoogleFit => "ଗୁଗୁଲ୍ ଫିଟ୍ |";
  @override
  String get labelAppleWatch => "ଆପଲ୍ ୱାଚ୍ |";
  @override
  String get labelSamsungSmartWatch => "ସାମସଙ୍ଗ ସ୍ମାର୍ଟ ୱାଚ୍ |";
  @override
  String get labelBookDetails => "ପୁସ୍ତକ ବିବରଣୀ";
  @override
  String get labelDeliveryDate => "ପ୍ରସବ ତାରିଖ୍";
  @override
  String get labelOrderDate => "ଅର୍ଡର ତାରିଖ |";
  @override
  String get labelAnalyseIngredientsTaken => "ଖାଦ୍ୟ ଗ୍ରହଣକୁ ବିଶ୍ଳେଷଣ କରନ୍ତୁ |";
  @override
  String get labelAddDishIngredients => "ଡିସ୍ ଉପାଦାନଗୁଡିକ ମିଶାନ୍ତୁ |";
  @override
  String get labelIngredientName => "ଉପାଦାନ ନାମ";
  @override
  String get labelEnterIngredientName => "ଏକ ଉପାଦାନ ନାମ ପ୍ରବେଶ କରନ୍ତୁ |";
  @override
  String get labelIngredientQuantity => "ଉପାଦାନ ପରିମାଣ |";
  @override
  String get labelEnterIngredientQuantity => "ଉପାଦାନ ପରିମାଣ ପ୍ରବେଶ କରନ୍ତୁ |";
  @override
  String get labelAdd => "ଯୋଡନ୍ତୁ |";
  @override
  String get labelSave => "ସଞ୍ଚୟ କରନ୍ତୁ |";
  @override
  String get labelwatch => "ଦେଖନ୍ତୁ |";

  //
  @override
  String get labelBloodOxygenHeart =>
      'ଗୁରୁତ୍ୱପୂର୍ଣ୍ଣ ଚିହ୍ନଗୁଡିକ ମାପନ୍ତୁ ଏବଂ ସାମଗ୍ରିକ ସ୍ୱାସ୍ଥ୍ୟକୁ ଟ୍ରାକ୍ କରନ୍ତୁ |';
  @override
  String get labelTop10FoodS =>
      'ଏକ ସୁସ୍ଥ ଜୀବନଶ lifestyle ଳୀ ବଜାୟ ରଖିବା ପାଇଁ ପରାମର୍ଶିତ ଖାଦ୍ୟ ଆବିଷ୍କାର କରନ୍ତୁ |';
  @override
  String get labelWaterTrack =>
      'ଦ daily ନିକ ଫିଟନେସ୍ ହାଇଡ୍ରେସନ୍ ଲକ୍ଷ୍ୟ ସ୍ଥିର କରନ୍ତୁ ଏବଂ ହାସଲ କରନ୍ତୁ |';
  @override
  String get labelPersonalDetails =>
      'ବ୍ୟକ୍ତିଗତ ସୂଚନାକୁ ସୁରକ୍ଷିତ ଭାବରେ ପରିଚାଳନା ଏବଂ ଅଦ୍ୟତନ କରନ୍ତୁ |';
  @override
  String get labelFeedbackS =>
      'ଆପଣଙ୍କର ଚିନ୍ତାଧାରା ଏବଂ ପରାମର୍ଶଗୁଡିକ ଆମ ସହିତ ଅଂଶୀଦାର କରନ୍ତୁ |';
  @override
  String get labelContactUsS =>
      'ଗ୍ରାହକଙ୍କ ସମର୍ଥନ ପହଞ୍ଚନ୍ତୁ ଏବଂ ଆମ ସହିତ ଯୋଗାଯୋଗ କରନ୍ତୁ |';
  @override
  String get labelBMICalculator =>
      'ସ୍ ins ାସ୍ଥ୍ୟ ଜ୍ଞାନ ପାଇଁ ଆପଣଙ୍କ ଶରୀର ମାସ ସୂଚକାଙ୍କ ଗଣନା କରନ୍ତୁ |';
  @override
  String get labelBMRCalculator =>
      'ଫିଟନେସ୍ ଯୋଜନା ପାଇଁ ତୁମର ବେସାଲ୍ ମେଟାବୋଲିକ୍ ରେଟ୍ ଗଣନା କର |';
  @override
  String get labelRunningJoggingSteps =>
      'ଏକ ସୁସ୍ଥ ଜୀବନଶ lifestyle ଳୀ ପାଇଁ ଆପଣଙ୍କର ଚାଲିବା ଏବଂ ଜଗିଂ ଷ୍ଟେପ୍ ଟ୍ରାକ୍ କରନ୍ତୁ |';
  @override
  String get labelHealthyDietChart =>
      'ଏକ ସୁସ୍ଥ ଖାଦ୍ୟ ସମୀକ୍ଷା ପାଇଁ ଏକ ବିସ୍ତୃତ ଚାର୍ଟ ଆକ୍ସେସ୍ କରନ୍ତୁ |';
  @override
  String get labelHealthyRecommendation =>
      'ବ୍ୟକ୍ତିଗତ ସ୍ୱାସ୍ଥ୍ୟ ସୁପାରିଶ ଗ୍ରହଣ କରନ୍ତୁ |';
  @override
  String get labelSleepTracker =>
      'ତୁମର ଶୋଇବା ଶ s ଳୀକୁ ଟ୍ରାକ୍ କର ଏବଂ ଶୋଇବା ଗୁଣରେ ଉନ୍ନତି କର |';
  @override
  String get labelSetReminder =>
      'ସ୍ୱାସ୍ଥ୍ୟ ଏବଂ ଫିଟନେସ୍ କାର୍ଯ୍ୟକଳାପ ପାଇଁ ସ୍ମାରକପତ୍ର ସେଟ୍ କରନ୍ତୁ |';
  // @override
  // String get labelMenstruationCycle =>
  //     'ଉତ୍ତମ ଜ୍ଞାନ ପାଇଁ ଆପଣଙ୍କର ମାସିକ cycle ତୁଚକ୍ରକୁ ଟ୍ରାକ୍ ଏବଂ ପରିଚାଳନା କରନ୍ତୁ |';
  @override
  String get labelCSVDownload =>
      'ସହଜ ବିଶ୍ଳେଷଣ ପାଇଁ CSV ଫର୍ମାଟରେ ଆପଣଙ୍କର ତଥ୍ୟ ଡାଉନଲୋଡ୍ କରନ୍ତୁ |';

  // New Headings
  @override
  String get headingBloodOxygenHeart => 'ରକ୍ତ | ଅମ୍ଳଜାନ |';
  @override
  String get headingTop10Food => 'ଶ୍ରେଷ୍ଠ ୧୦ଟି ଖାଦ୍ୟ |';
  @override
  String get headingWaterTrack => 'ୱାଟର ଟ୍ରାକର୍ |';
  @override
  String get headingPersonalDetails => 'ବ୍ୟକ୍ତିଗତ ବିବରଣୀ';
  @override
  String get headingFeedback => 'ମତାମତ';
  @override
  String get headingContactUs => 'ଆମ ସହିତ ଯୋଗାଯୋଗ କରନ୍ତୁ |';
  @override
  String get headingBMICalculator => 'BMI କାଲକୁଲେଟର |';
  @override
  String get headingBMRCalculator => 'BMR କାଲକୁଲେଟର |';
  @override
  String get headingRunningJoggingSteps => 'ଚାଲିବା / ଜଗିଂ / ଷ୍ଟେପ୍ |';
  @override
  String get headingHealthyDietChart => 'ସୁସ୍ଥ ଡାଏଟ୍ ଚାର୍ଟ |';
  @override
  String get headingHealthyRecommendation => 'ସୁସ୍ଥ ସୁପାରିଶ |';
  @override
  String get headingSleepTracker => 'ଶୋଇବା ଟ୍ରାକର୍ |';
  @override
  String get headingSetReminder => 'ସ୍ମାରକପତ୍ର ସେଟ୍ କରନ୍ତୁ |';
  // @override
  // String get headingMenstruationCycle => 'ମାସିକ cycle ତୁସ୍ରାବ |';
  @override
  String get headingCSVDownload => 'CSV ଡାଉନଲୋଡ୍ |';

  // Water-related phrases
  @override
  String get labelWaterTarget => "ଜଳ ଲକ୍ଷ୍ୟ |";
  // @override
  // String get labelTodayTarget => "ଆଜି ଟାର୍ଗେଟ୍ |";
  @override
  String get labelWaterGoal => "ଜଳ ଲକ୍ଷ୍ୟ |";
  // @override
  // String get labelWaterIntake => "ଜଳ ଗ୍ରହଣ";
  @override
  String get labelWaterProgress => "ଜଳ ପ୍ରଗତି |";
  // @override
  // String get labelWeekly => "ସାପ୍ତାହିକ";
  @override
  String get labelDateWise => "ଜ୍ଞାନୀ ତାରିଖ |";
  @override
  String get labelSun => "ସୂର୍ଯ୍ୟ |";
  @override
  String get labelMon => "ସୋମ";
  @override
  String get labelTue => "ମଙ୍ଗଳ";
  @override
  String get labelWed => "ବୁଧ";
  @override
  String get labelThu => "ଶୁକ୍ର";
  @override
  String get labelFri => "ଶୁକ୍ର";

  // BMI Calculator
  // @override
  // String get labelBMI => "BMI";
  @override
  String get labelEnterHeight => "ଉଚ୍ଚତା (ସେମି) ପ୍ରବେଶ କରନ୍ତୁ |";
  @override
  String get labelEnterWeight => "ଓଜନ (କିଲୋଗ୍ରାମ) ପ୍ରବେଶ କରନ୍ତୁ |";
  @override
  String get labelCalculateBMI => "BMI ଗଣନା କରନ୍ତୁ |";

  // BMR Calculator
  @override
  String get labelMale => "ପୁରୁଷ";
  @override
  String get labelFemale => "ମହିଳା";
  @override
  String get labelEnterAge => "ବୟସ ପ୍ରବେଶ କରନ୍ତୁ |";
  @override
  String get labelCalculateBMR => "BMR ଗଣନା କରନ୍ତୁ |";
  @override
  String get labelBMR => "BMR";
  @override
  String get labelCaloriesPerDay => "କ୍ୟାଲୋରୀ / ଦିନ";

  // Step Tracker
  @override
  String get labelStepsTracker => "ଷ୍ଟେପ୍ ଟ୍ରାକର୍ |";
  @override
  String get labelRunningTracker => "ଚାଲୁଥିବା ଟ୍ରାକର୍ |";
  @override
  String get labelAddStep => "ଷ୍ଟେପ୍ ଯୋଡନ୍ତୁ |";
  @override
  String get labelSelectDate => "ତାରିଖ ଚୟନ କରନ୍ତୁ |";
  @override
  String get labelJoggingTracker => "ଜଗିଂ ଟ୍ରାକର୍ |";
  @override
  String get labelCaloriesBurn => "କ୍ୟାଲୋରୀ ପୋଡିଗଲା |";

  // Sleep Tracker
  @override
  String get labelSleepTarget => "ଶୋଇବା ଲକ୍ଷ୍ୟ |";
  @override
  String get labelTodaySleep => "ଆଜି ଶୋଇବା |";
  @override
  String get labelSleepProgress => "ଶୋଇବା ପ୍ରଗତି |";
  @override
  String get labelTotalSleep => "ସମୁଦାୟ ନିଦ |";
  @override
  String get labelSleepGoal => "ଶୋଇବା ଲକ୍ଷ୍ୟ |";
  @override
  String get labelSetNotification => "ବିଜ୍ଞପ୍ତି ସେଟ୍ କରନ୍ତୁ |";
  @override
  String get labelStartTime => "ଆରମ୍ଭ ସମୟ";
  @override
  String get labelEndTime => "ଶେଷ ସମୟ";
  @override
  String get labelSelect => "ଚୟନ କରନ୍ତୁ |";
  @override
  String get labelSat => "ଶନି";
  // @override
  // String get labelSave => "ସଞ୍ଚୟ କରନ୍ତୁ |";
  @override
  String get labelStart => "ଆରମ୍ଭ କରନ୍ତୁ |";
  @override
  String get labelEnd => "ଶେଷ";
  @override
  String get labelType => "ଟାଇପ୍ କରନ୍ତୁ |";
  @override
  String get labelIsConnected => "ସଂଯୁକ୍ତ ଅଟେ |";

  // @override
  // String get labelMensurationCycle => "ଚକ୍ର ମାପ";

  @override
  String get labelTrackAndManage =>
      "ଉତ୍ତମ ଅନ୍ତର୍ଦୃଷ୍ଟି ପାଇଁ ତୁମର ମାନସ ଚକ୍ରକୁ ଟ୍ରାକ୍ ଏବଂ ପରିଚାଳନା କର |";

  @override
  String get labelMensurationStatus => "ମାପ ସ୍ଥିତି";

  @override
  String get labelDaysLength => "ଦିନର ଲମ୍ବ |";

  @override
  String get labelDay => "ଦିନ";

  @override
  String get labelNextDate => "ପରବର୍ତ୍ତୀ ତାରିଖ";

  @override
  String get labelLastPeriodStartDate => "ଶେଷ ଅବଧି ଆରମ୍ଭ ତାରିଖ |";

  @override
  String get labelAverageCycleLength => "ହାରାହାରି ଚକ୍ର ଦ length ର୍ଘ୍ୟ |";

  @override
  String get labelChange => "ପରିବର୍ତ୍ତନ କରନ୍ତୁ |";

  // Common Messages
  @override
  String get messageSent => "ବାର୍ତ୍ତା ପଠାଯାଇଛି |";

  @override
  String get thankYouForContactingUs => "ଆମ ସହିତ ଯୋଗାଯୋଗ କରିଥିବାରୁ ଧନ୍ୟବାଦ!";

  @override
  String get alert => "ସତର୍କତା";

  @override
  String get fillInAllFields => "ଦୟାକରି ସମସ୍ତ କ୍ଷେତ୍ର ପୁରଣ କରନ୍ତୁ |";

  @override
  String get thankYouFeedbackSubmitted => "ଆପଣଙ୍କର ମତାମତ ଦାଖଲ କରାଯାଇଛି |";

  @override
  String get resetPassword => "ପାସୱାର୍ଡ ପୁନ Res ସେଟ୍ କରନ୍ତୁ |";

  @override
  String get dishAdded => "ଡିସ୍ ଯୋଡିଲା!";

  @override
  String get dishAndIngredientsAddedSuccessfully =>
      "ସଫଳତାର ସହିତ ଡିସ୍ ଏବଂ ଉପାଦାନଗୁଡିକ ଯୋଗ କରାଗଲା |";

  @override
  String get failed => "ବିଫଳ";

  @override
  String get error => "ତ୍ରୁଟି |";

  @override
  String get enterBloodGlucoseLevel =>
      "Mg / dL ରେ ରକ୍ତ ଗ୍ଲୁକୋଜ ସ୍ତର ପ୍ରବେଶ କରନ୍ତୁ |";

  @override
  String get enterBloodPressureLevel => "MmHg ରେ ରକ୍ତଚାପ ସ୍ତର ପ୍ରବେଶ କରନ୍ତୁ |";

  @override
  String get enterHeartLevel =>
      "ଦୟାକରି ପ୍ରତି ମିନିଟରେ ବିଟ୍ ରେ ହୃଦସ୍ପନ୍ଦନ ପ୍ରବେଶ କରନ୍ତୁ (BPM) |";

  @override
  String get cancel => "ବାତିଲ୍ କରନ୍ତୁ |";

  @override
  String get submit => "ଦାଖଲ କରନ୍ତୁ |";

  @override
  String get valueCannotBeGreaterThan100 =>
      "ମୂଲ୍ୟ 100 ରୁ ଅଧିକ ହୋଇପାରିବ ନାହିଁ |";

  @override
  String get bloodStatusSubmittedSuccessfully =>
      "ରକ୍ତ ସ୍ଥିତି ସଫଳତାର ସହିତ ଦାଖଲ ହେଲା |";

  @override
  String get failedToSubmitBlood => "ରକ୍ତ ଦାଖଲ କରିବାରେ ବିଫଳ |";

  @override
  String get enterHeartLevel1to100 =>
      "ଦୟାକରି ପ୍ରତି ମିନିଟରେ ବିଟ୍ ରେ ହୃଦସ୍ପନ୍ଦନ ପ୍ରବେଶ କରନ୍ତୁ (BPM) |";

  @override
  String get heartLevelSubmittedSuccessfully =>
      "ହୃଦୟ ସ୍ତର ସଫଳତାର ସହିତ ଦାଖଲ ହେଲା |";

  @override
  String get enterOxygenSaturationLevel1to100 =>
      "ଅମ୍ଳଜାନ ସାଚୁରେଚର ସ୍ତର 1% -100% ପ୍ରବେଶ କରନ୍ତୁ |";

  @override
  String get oxygenLevelSubmittedSuccessfully =>
      "ଅମ୍ଳଜାନ ସ୍ତର ସଫଳତାର ସହିତ ଦାଖଲ ହେଲା |";

  @override
  String get updateData => "ଡାଟା ଅଦ୍ୟତନ କରନ୍ତୁ |";

  @override
  String get selectLastPeriodStartDate => "ଶେଷ ଅବଧି ଆରମ୍ଭ ତାରିଖ ଚୟନ କରନ୍ତୁ |";

  @override
  String get update => "ଅଦ୍ୟତନ କରନ୍ତୁ |";

  @override
  String get failedToFetchBooks =>
      "ବହି ଆଣିବାରେ ବିଫଳ | ଦୟାକରି ପୁଣିଥରେ ଚେଷ୍ଟା କରନ୍ତୁ।";

  @override
  String get errorOccurred => "ଗୋଟାଏ ଭୂଲ୍ ହେଇଛି:";

  @override
  String get invalidEndTime => "ଅବ val ଧ ଶେଷ ସମୟ |";

  @override
  String get chooseTimeWithin1Hour =>
      "ଦୟାକରି ଆରମ୍ଭ ସମୟର 1 ଘଣ୍ଟା ମଧ୍ୟରେ ଏକ ସମୟ ବାଛନ୍ତୁ |";

  @override
  String get notificationSaved => "ବିଜ୍ଞପ୍ତି ସଞ୍ଚୟ ହୋଇଛି |";

  @override
  String get notificationSetSuccessfully =>
      "ବିଜ୍ଞପ୍ତି ସଫଳତାର ସହିତ ସେଟ୍ ହୋଇଛି |";

  @override
  String get thereIsSomeError => "କିଛି ତ୍ରୁଟି ଅଛି |";

  @override
  String get watchDisconnected => "ସଂଯୋଗ ବିଚ୍ଛିନ୍ନ ଦେଖନ୍ତୁ |";

  @override
  String get watchDisconnectedSuccessfully =>
      "ଘଣ୍ଟା ସଫଳତାର ସହିତ ବିଚ୍ଛିନ୍ନ ହୋଇଛି |";

  @override
  String get addCup => "କପ୍ ମିଶାନ୍ତୁ |";

  @override
  String get numberOfCups => "କପ୍ ସଂଖ୍ୟା |";

  @override
  String get addCupCapacityInMl => "ମିଲ୍ ରେ କପ୍ କ୍ଷମତା ମିଶାନ୍ତୁ |";

  @override
  String get cupCapacitySubmittedSuccessfully =>
      "କପ୍ କ୍ଷମତା ସଫଳତାର ସହିତ ଦାଖଲ |";

  @override
  String get pleaseEnterValidValuesForAllFields =>
      "ସମସ୍ତ କ୍ଷେତ୍ର ପାଇଁ ଦୟାକରି ବ valid ଧ ମୂଲ୍ୟ ପ୍ରବେଶ କରନ୍ତୁ |";

  @override
  String get enterWater => "ପାଣି ପ୍ରବେଶ କର |";

  @override
  String get waterGoalLiters => "ଜଳ ଲକ୍ଷ୍ୟ (ଲିଟର)";

  @override
  String get waterSubmittedSuccessfully => "ଜଳ ଲକ୍ଷ୍ୟ ସଫଳତାର ସହିତ ଦାଖଲ ହେଲା |";

  @override
  String get addActivityData => "କାର୍ଯ୍ୟକଳାପ ତଥ୍ୟ ଯୋଡନ୍ତୁ |";

  @override
  String get enterValue => "ମୂଲ୍ୟ ପ୍ରବେଶ କରନ୍ତୁ |";

  @override
  String get addStepsData => "ଷ୍ଟେପ୍ ଡାଟା ଯୋଡନ୍ତୁ |";

  @override
  String get numberOfSteps => "ପଦାଙ୍କ ସଂଖ୍ୟା";

  @override
  String get stepsDataSubmittedSuccessfully => "ପଦାଙ୍କ ତଥ୍ୟ ସଫଳତାର ସହିତ ଦାଖଲ |";

  @override
  String get enterSleepTarget => "ଶୋଇବା ଲକ୍ଷ୍ୟ ପ୍ରବେଶ କରନ୍ତୁ |";

  @override
  String get sleepTargetInHours => "ଘଣ୍ଟା ମଧ୍ୟରେ ଶୋଇବା ଲକ୍ଷ୍ୟ |";

  @override
  String get addYourSleepDuration => "ତୁମର ଶୋଇବା ଅବଧି ଯୋଡ |";

  @override
  String get enterDurationInMinutes => "ମିନିଟ୍ରେ ଅବଧି ପ୍ରବେଶ କରନ୍ତୁ:";

  @override
  String get add => "ଯୋଡନ୍ତୁ |";

  @override
  String get ok => "ଠିକ୍ ଅଛି";

  @override
  String get csvFileSavedTo => "CSV ଫାଇଲ୍ ସେଭ୍ ହୋଇଛି |";

  @override
  String get ageMustBeBetween2And100Years =>
      "ବୟସ 2 ରୁ 100 ବର୍ଷ ମଧ୍ୟରେ ହେବା ଜରୁରୀ |";

  @override
  String get next => "ପରବର୍ତ୍ତୀ";

  @override
  String get register => "ପଞ୍ଜିକରଣ କର |";

  @override
  String get oopsSomethingWentWrong => "ଓହୋ! କିଛି ଭୁଲ ହୋଇ ଗଲା";

  @override
  String get errorFetchingMeals => "ଭୋଜନ ଆଣିବା ସମୟରେ ଏକ ତ୍ରୁଟି ଘଟିଲା:";

  @override
  String get reviewAddedSuccessfully => "ସମୀକ୍ଷା ସଫଳତାର ସହିତ ଯୋଡା ଯାଇଛି!";

  @override
  String get failedToAddReview => "ସମୀକ୍ଷା ଯୋଗ କରିବାରେ ବିଫଳ:";

  @override
  String get alreadyInCart => "ପୂର୍ବରୁ କାର୍ଟରେ |";

  @override
  String get addedToCart => "କାର୍ଟରେ ଯୋଡା ଯାଇଛି |";

  @override
  String get quantityNotBetween1And2 =>
      "ପରିମାଣ 2 ରୁ ଅଧିକ ନୁହେଁ ଏବଂ 1 ରୁ କମ୍ ନୁହେଁ |";

  String get createcustomdish => "କଷ୍ଟମ୍ ଡିସ୍ ତିଆରି କରନ୍ତୁ |";
  String get quantityingram => "ପରିମାଣ (ଗ୍ରାମ)";
  String get labelCaloriestaken => 'ଶକ୍ତି';
  String get mainlabelEarlyMorning => "ପ୍ରଭାତ";
  String get mainlabelMidMorning => "ମଧ୍ୟରାତ୍ରି |";
  String get mainlabelEvening => "ସନ୍ଧ୍ୟା |";
  String get mainlabelBedtime => "ଶୋଇବା ସମୟ |";
  String get mainlabelTimeSpentOn => "ବିଭିନ୍ନ କାର୍ଯ୍ୟକଳାପରେ ସମୟ ଅତିବାହିତ |";
  String get mainlabelHealthCalculator => "ସ୍ୱାସ୍ଥ୍ୟ କାଲକୁଲେଟର";
  String get mainlabelStepProgress => "ପଦକ୍ଷେପ ଅଗ୍ରଗତି |";
  String get mainlabelRealTimeIntakes => "ପ୍ରକୃତ ସମୟ ଗ୍ରହଣ";
  String get mainlabelCaloriesBurnProgress => "କ୍ୟାଲୋରୀ ପ୍ରଗତି ଅଗ୍ରଗତି କଲା |";
  String get mainlabelCaloriesBurnBreakdown => "କ୍ୟାଲୋରୀ ପୋଡି ଯାଇଛି |";
  String get mainlabelHeartReportsTrends => "ହୃଦୟ ରିପୋର୍ଟ କରେ |";
  String get mainlabelOxygenStatus => "ଅମ୍ଳଜାନ ସ୍ଥିତି |";
  String get mainlabelNoRecord => "ମୋର ମନେ ନାହିଁ";
  String get mainlabelSystolicBloodPressure => "ସିଷ୍ଟୋଲିକ୍ ରକ୍ତଚାପ |";
  String get mainlabelMeasuredon => "ମାପ କରାଯାଇଛି";
  String get mainlabelEnterBloodPressure => "ରକ୍ତଚାପ ପ୍ରବେଶ କରନ୍ତୁ |";
  String get mainlabelBloodPressure => "ରକ୍ତ ଚାପ";
  String get mainlabelDiastolicBloodPressure => "ଡାଇଷ୍ଟୋଲିକ୍ ରକ୍ତଚାପ |";
  String get mainlabelBloodGlucose => "ରକ୍ତ ଗ୍ଲୁକୋଜ |";
  String get mainlabelHeartStatus => "ହୃଦୟ ସ୍ଥିତି";
  String get mainlabelAllExercise => "ସମସ୍ତ ବ୍ୟାୟାମ |";
  String get mainlabelCleaningOrMopping => "ସଫା କରିବା କିମ୍ବା ମପିଙ୍ଗ୍ |";
  String get mainlabelGardening => "ବଗିଚା";
  String get mainlabelWatchingTV => "ଟିଭି ଦେଖୁଛି";
  String get mainlabelCycling => "ସାଇକେଲ ଚଲାଇବା |";
  String get mainlabelRunning => "ଚାଲୁଛି |";
  String get mainlabelWalking => "ଚାଲିବା";
  String get mainlabelShuttle => "ଶଟଲ୍";
  String get mainlabelTableTennis => "ଟେବୁଲ୍ ଟେନିସ୍ |";
  String get mainlabelTennis => "ଟେନିସ୍ |";
  String get mainlabelVolleyBall => "ଭଲି ବଲ୍ |";
  String get mainlabelDancing => "ନୃତ୍ୟ";
  String get mainlabelFishing => "ମତ୍ସ୍ୟଚାଷ";
  String get mainlabelShopping => "ସପିଂ";
  String get mainlabelTyping => "ଟାଇପିଂ";
  String get mainlabelSleeping => "ଶୋଇବା";
  String get mainlabelStanding => "ଠିଆ";
  String get mainlabelSitting => "ବସିବା";
  String get mainlabelClickToStartActivity =>
      "କାର୍ଯ୍ୟକଳାପ ଆରମ୍ଭ କରିବାକୁ କ୍ଲିକ୍ କରନ୍ତୁ |";
  String get mainlabelBMICalculator => "BMI କାଲକୁଲେଟର |";
  String get mainlabelBMRCalculator => "BMR କାଲକୁଲେଟର |";
  String get mainlabelDownloadActivityReportInCsv =>
      "csv ରେ କାର୍ଯ୍ୟକଳାପ ରିପୋର୍ଟ ଡାଉନଲୋଡ୍ କରନ୍ତୁ |";
  String get mainlabelSelectStartDate => "ଆରମ୍ଭ ତାରିଖ ଚୟନ କରନ୍ତୁ |";
  String get mainlabelSelectEndDate => "ଶେଷ ତାରିଖ ଚୟନ କରନ୍ତୁ |";
  String get mainlabelDownloadFile => "ଫାଇଲ୍ ଡାଉନଲୋଡ୍ କରନ୍ତୁ |";
  String get mainlabelDate => "ତାରିଖ";
  String get mainlabelValue => "ମୂଲ୍ୟ";
  String get mainlabelLink => "ଲିଙ୍କ୍";
  String get mainlabelNoNotificationFound =>
      "କ No ଣସି ବିଜ୍ଞପ୍ତି ମିଳିଲା ନାହିଁ |";
  String get mainlabelTotalNutritionTaken => "= ସମୁଦାୟ ପୁଷ୍ଟିକର ନିଆଯାଇଛି |";
  String get mainlabelSearchFood => "ରେସିପି ଖୋଜ |";
  String get mainlabelSelectFromPersonalFood =>
      "ବ୍ୟକ୍ତିଗତ ରେସିପିରୁ ଚୟନ କରନ୍ତୁ |";
  String get mainlabelRecipeName => "ରେସିପି ନାମ";
  String get mainlabelSelectDate => "ତାରିଖ ଚୟନ କରନ୍ତୁ |";
  String get mainlabelNutrientOfAllIngredientsRaw =>
      "ସମସ୍ତ ଉପାଦାନର ପୁଷ୍ଟିକର (କଞ୍ଚା)";
  String get mainlabelNutrientsCompostionOfCookedWeight =>
      "ରନ୍ଧା ଓଜନର ପୁଷ୍ଟିକର ରଚନା |";
  String get mainlabelWantToEditThisRecipyFollowThe =>
      "ଏହି ରେସିପି ସଂପାଦନ କରିବାକୁ ଚାହୁଁଛନ୍ତି କି? ଅନୁସରଣ କରନ୍ତୁ";
  String get mainlabelAddIngredientFrom => "ଏଥିରୁ ଉପାଦାନ ଯୋଗ କରନ୍ତୁ |";
  String get mainlabelAddFromNutrientSpecifcFood =>
      "ପୁଷ୍ଟିକର ଖାଦ୍ୟରୁ ଯୋଗ କରନ୍ତୁ |";
  String get mainlabelAddFromAllFoods => "ସମସ୍ତ ଖାଦ୍ୟରୁ ମିଶାନ୍ତୁ |";
  String get mainlabelNumberOfServing => "ସେବା ସଂଖ୍ୟା |";
  String get mainlabelWeightInG => "ଓଜନ (g)";
  String get mainlabelEditIngredientsWeight =>
      "ଉପାଦାନଗୁଡ଼ିକର ଓଜନ ସଂପାଦନ କରନ୍ତୁ |";
  String get mainlabelIngredient => "ଉପାଦାନ";
  String get mainlabelNewWeightInG => "ନୂତନ ଓଜନ (g)";
  String get mainlabelCancel => "ବାତିଲ୍ କରନ୍ତୁ |";
  String get mainlabelUpdate => "ଅଦ୍ୟତନ କରନ୍ତୁ |";
  String get mainlabelCookedWeightInG => "ରନ୍ଧା ହୋଇଥିବା ଓଜନ (g)";
  String get mainlabelEnterWeight => "ଓଜନ ପ୍ରବେଶ କରନ୍ତୁ |";
  String get mainlabelEditRecipy => "ରେସିପି ସଂପାଦନ କରନ୍ତୁ |";
  String get mainlabelAlert => "ସତର୍କ";
  String get mainlabelToSeeNutritionCompositionPleaseEnterNoOfServing =>
      "ପୁଷ୍ଟିକର ରଚନା ଦେଖିବାକୁ, ଦୟାକରି ସର୍ଭିସ୍ ସଂଖ୍ୟା ପ୍ରବେଶ କରନ୍ତୁ |";
  String get mainlabelNutrirntsIn100CookedWeight =>
      "100 (ରନ୍ଧା) ଓଜନରେ ପୋଷକ ତତ୍ତ୍ୱ |";
  String get mainlabelSetNutritionTargetInG =>
      "ଗ୍ରାମରେ ପୁଷ୍ଟିକର ଲକ୍ଷ୍ୟ ସ୍ଥିର କରନ୍ତୁ |";
  String get mainlabelFoodAnalyse => "ଏକ୍ସପ୍ଲୋର୍ କରନ୍ତୁ |";
  String get mainlabelExploreTop10Foods =>
      "ଶ୍ରେଷ୍ଠ ୧୦ଟି ଖାଦ୍ୟ ଅନୁସନ୍ଧାନ କରନ୍ତୁ |";
  String get mainlabelSearchCookedFood => "ରେସିପିରେ ପୁଷ୍ଟିକର ସନ୍ଧାନ କରନ୍ତୁ |";
  String get mainlabelNutritionBasedOnEAR =>
      "EAR ଉପରେ ଆଧାରିତ ପୁଷ୍ଟିକର ଆବଶ୍ୟକତା |";
  String get mainlabelDietDiary => "ଡାଏଟ୍ ଡାଏରୀ |";
  String get mainlabelRecipes => "ରେସିପି |";
  String get mainlabelSearchByFoodName => "ଖାଦ୍ୟ ନାମ ଦ୍ୱାରା ସନ୍ଧାନ କରନ୍ତୁ |";
  String get mainlabelAllRecipeOf100G => "100 ଗ୍ରାମର ସମସ୍ତ ରେସିପି |";
  String get mainlabelNutritionRequirement => "ପୁଷ୍ଟିକର ଆବଶ୍ୟକତା |";
  String get mainlabelGender => "ଲିଙ୍ଗ";
  String get mainlabelParticulars => "ବିଶେଷତା |";
  String get mainlabelBodyWeight => "ଶରୀରର ଓଜନ";
  String get mainlabelDietaryDiaryReports => "ପୁଷ୍ଟିକର ଖାଦ୍ୟ";
  String get mainlabelTotalNutritionTakenOn =>
      "ସମୁଦାୟ ପୁଷ୍ଟିକର ଖାଦ୍ୟ ଗ୍ରହଣ କରାଯାଇଛି |";
  String get mainlabelAttachImage => "ପ୍ରତିଛବି ସଂଲଗ୍ନ କରନ୍ତୁ |";
  String get mainlabelFixedRecipy => "ସ୍ଥିର ରେସିପି |";
  String get mainlabelFoodInDetail => "ଖାଦ୍ୟ ବିସ୍ତୃତ ଭାବରେ |";
  String get TextAppNutrientsInMyFood => "ଖାଦ୍ୟରେ ପୋଷକ ତତ୍ତ୍ୱ ଖୋଜ |";
  String get TextAppMyActivity => "ମୋର କାର୍ଯ୍ୟକଳାପ";
  String get TextAppToday => "ଆଜି";
  String get TextAppMyNutrientRequirements => "ମୋର ପୁଷ୍ଟିକର ଆବଶ୍ୟକତା |";
  String get TextAppTotalNutrition => "ସମୁଦାୟ ପୁଷ୍ଟିକର ଖାଦ୍ୟ |";
  String get TextAppTaken => "ନିଆଯାଇଛି";
  String get TextAppRatings => "ମୂଲ୍ୟାୟନ";
  String get TextAppSearchComponents => "ଉପାଦାନଗୁଡିକ ସନ୍ଧାନ କରନ୍ତୁ |";
  String get TextAppTotalNutrientTaken => "ଆଜି ମୋର ପୁଷ୍ଟିକର ଖାଦ୍ୟ |";
  String get TextAppShareApp => "ଆପ୍ ଅଂଶୀଦାର କରନ୍ତୁ |";
  String get TextAppNoNotificationsFound => "କ No ଣସି ବିଜ୍ଞପ୍ତି ମିଳିଲା ନାହିଁ |";
  String get TextAppConnectWatch => "ୱାଚ୍ ସଂଯୋଗ କରନ୍ତୁ |";
  String get TextAppYourBMIIs => "ତୁମର BMI ହେଉଛି |";
  String get TextAppBMI => "BMI";
  String get TextAppBMICategories => "BMI ବର୍ଗଗୁଡିକ |";
  String get TextAppUnderweight => "ଓଜନ କମ |";
  String get TextAppNormal => "ସାଧାରଣ";
  String get TextAppOverweight => "ଅଧିକ ଓଜନ";
  String get TextAppObesity => "ମୋଟାପଣ |";
  String get TextAppSelectDate => "ତାରିଖ ଚୟନ କରନ୍ତୁ |";
  String get TextAppOxygen => "ଅମ୍ଳଜାନ |";
  String get TextAppBlood => "ରକ୍ତ";
  String get TextAppNoRecord => "କ Record ଣସି ରେକର୍ଡ ନାହିଁ |";
  String get TextAppAllExercise => "ସମସ୍ତ ବ୍ୟାୟାମ |";
  String get TextAppCleaningOrMopping => "ସଫା କରିବା କିମ୍ବା ମପିଙ୍ଗ୍ |";
  String get TextAppGardening => "ବଗିଚା";
  String get TextAppWatchingTV => "ଟିଭି ଦେଖୁଛି";
  String get TextAppCycling => "ସାଇକେଲ ଚଲାଇବା |";
  String get TextAppRunning => "ଚାଲୁଛି |";
  String get TextAppWalking => "ଚାଲିବା";
  String get TextAppShuttle => "ଶଟଲ୍";
  String get TextAppTableTennis => "ଟେବୁଲ୍ ଟେନିସ୍ |";
  String get TextAppTennis => "ଟେନିସ୍ |";
  String get TextAppVolleyBall => "ଭଲି ବଲ୍ |";
  String get TextAppDancing => "ନୃତ୍ୟ";
  String get TextAppFishing => "ମତ୍ସ୍ୟଚାଷ";
  String get TextAppShopping => "ସପିଂ";
  String get TextAppTyping => "ଟାଇପିଂ";
  String get TextAppSleeping => "ଶୋଇବା";
  String get TextAppStanding => "ଠିଆ";
  String get TextAppSitting => "ବସିବା";
  String get TextAppClickStartToStartActivity =>
      "କାର୍ଯ୍ୟକଳାପ ଆରମ୍ଭ କରିବାକୁ ଆରମ୍ଭ କ୍ଲିକ୍ କରନ୍ତୁ |";
  String get TextAppCaloriesBurn => "କ୍ୟାଲୋରୀ ପୋଡିଗଲା |";
  String get TextAppAddDurationManually => "ହସ୍ତକୃତ ଭାବରେ ଅବଧି ଯୋଡନ୍ତୁ |";
  String get TextAppStartOrMopping => "ଆରମ୍ଭ କିମ୍ବା ମପିଙ୍ଗ୍ |";
  String get TextAppMale => "ପୁରୁଷ";
  String get TextAppFemale => "ମହିଳା";
  String get TextAppWeightManager => "ମୋ ଶରୀରର ଓଜନ ଟ୍ରାକ୍ କରନ୍ତୁ |";
  String get TextAppUpdateWeight => "ଓଜନ ଅଦ୍ୟତନ କରନ୍ତୁ |";
  String get TextAppSetWeightGoal => "ଓଜନ ଲକ୍ଷ୍ୟ ସ୍ଥିର କରନ୍ତୁ |";
  String get TextAppCurrentWeight => "ସାମ୍ପ୍ରତିକ ଓଜନ |";
  String get TextAppWeightProgress => "ଓଜନ ପ୍ରଗତି |";
  String get TextAppPrevious30Days => "ପୂର୍ବ 30 ଦିନ";
  String get TextAppYourWeightGoalIsSet => "ତୁମର ଲକ୍ଷ୍ୟ ହେଉଛି";
  String get TextAppMaintain => "ରକ୍ଷଣାବେକ୍ଷଣ କର |";
  String get TextAppInitialWeightOf => "ପ୍ରାରମ୍ଭିକ ଓଜନ";
  String get TextAppFinalWeightOf => "ସର୍ବଶେଷ ଓଜନ";
  String get TextAppWeight => "ଓଜନ";
  String get TextAppYouAreNotYetAchievingYourWeightGoalKeepGoing =>
      "ଆପଣ ଏପର୍ଯ୍ୟନ୍ତ ଆପଣଙ୍କର ଓଜନ ଲକ୍ଷ୍ୟ ହାସଲ କରୁନାହାଁନ୍ତି | ଜାରି ରଖ!";
  String get TextAppYouAreAchievedYourWeightGoalKeepGoing =>
      "ତୁମେ ତୁମର ଓଜନ ଲକ୍ଷ୍ୟ ହାସଲ କରିଛ | ଜାରି ରଖ!";
  String get TextAppAndYourWeightChangeIsSet =>
      "ଏବଂ ତୁମର ଓଜନ ପରିବର୍ତ୍ତନ ସ୍ଥିର ହୋଇଛି |";
  String get TextApp1NutrientsInMyFood => "ମୋ ଖାଦ୍ୟରେ ପୁଷ୍ଟିକର ଖାଦ୍ୟ |";
  String get TextAppSearchNutrientsInRawFoods =>
      "କଞ୍ଚା ଖାଦ୍ୟରେ ପୁଷ୍ଟିକର ଖାଦ୍ୟ ଖୋଜ |";
  String get TextAppRawIngredients => "କଞ୍ଚା ଉପାଦାନ |";
  String get TextAppSearchRawFoodByName => "ନାମରେ କଞ୍ଚା ଖାଦ୍ୟ ଖୋଜ |";
  String get TextApp1MyActivity => "ମୋର କାର୍ଯ୍ୟକଳାପ ରିପୋର୍ଟ";
  String get TextAppCheckOthersDates => "ଅନ୍ୟମାନଙ୍କର ତାରିଖ ଯାଞ୍ଚ କରନ୍ତୁ |";
  String get TextAppYour24HoursChart => "ତୁମର 24 ଘଣ୍ଟା ଚାର୍ଟ |";
  String get TextAppActivity => "କାର୍ଯ୍ୟକଳାପ";
  String get TextAppOthers => "ଅନ୍ୟମାନେ |";
  String get TextAppExerciseDetails => "ବ୍ୟାୟାମ ବିବରଣୀ";
  String get TextAppActivityType => "କାର୍ଯ୍ୟକଳାପ ପ୍ରକାର";
  String get TextAppDuration => "ଅବଧି";
  String get TextAppMyActivityOfCustomDates =>
      "କଷ୍ଟମ୍ ତାରିଖଗୁଡିକର ମୋର କାର୍ଯ୍ୟକଳାପ |";
  String get TextAppOurCustomerFeedback => "ଆମର ଗ୍ରାହକଙ୍କ ମତାମତ |";
  String get TextAppOverallRatings => "ସାମଗ୍ରିକ ମୂଲ୍ୟାୟନ";
  String get TextAppEnterCookedWeight => "ରନ୍ଧା ହୋଇଥିବା ଓଜନ ପ୍ରବେଶ କରନ୍ତୁ |";
  String get TextAppCookedWeightGram => "ରନ୍ଧା ହୋଇଥିବା ଓଜନ (ଗ୍ରାମ)";
  String get TextAppNutrientIn100gCooked => "100g ରେ ପୁଷ୍ଟିକର (ରନ୍ଧା)";
  String get TextAppEnterServingSize => "ପରିବେଷଣ ଆକାର ପ୍ରବେଶ କରନ୍ତୁ |";
  String get TextAppSearchByRecipeName => "ରେସିପି ନାମ ଦ୍ୱାରା ସନ୍ଧାନ କରନ୍ତୁ |";
  String get TextAppMyPersonalRecipe => "ମୋର ବ୍ୟକ୍ତିଗତ ରେସିପି |";
  String get TextAppFixedRecipe => "ସ୍ଥିର ରେସିପି |";
  String get TextApp2NutrientsInMyFood => "ମୋ ଖାଦ୍ୟରେ ପୁଷ୍ଟିକର ଖାଦ୍ୟ |";
  String get TextAppMyDietDiary => "ମୋର ଡାଏଟ୍ ଡାଏରୀ |";
  String get TextApp2MyActivity => "ମୋର କାର୍ଯ୍ୟକଳାପ";
  String get TextAppDownloadFile => "ଫାଇଲ୍ ଡାଉନଲୋଡ୍ କରନ୍ତୁ |";
  String get TextAppStartMyNewDietDiary =>
      "ମୋର ନୂତନ ଡାଏଟ୍ ଡାଏରୀ ଆରମ୍ଭ କରନ୍ତୁ |";
  String get TextAppGoogle => "ଗୁଗୁଲ୍";
  String get TextAppFacebook => "ଫେସବୁକ୍";
  String get TextAppLinkedin => "ଲିଙ୍କ୍ଡେନ୍ |";
  String get TextAppTwitter => "ଟ୍ୱିଟର";
  String get TextAppContactUs => "ଆମ ସହିତ ଯୋଗାଯୋଗ କରନ୍ତୁ |";
  String get TextAppReportBug => "ତ୍ରୁଟି ରିପୋର୍ଟ କରନ୍ତୁ |";
  String get TextAppAttachImage => "ପ୍ରତିଛବି ସଂଲଗ୍ନ କରନ୍ତୁ |";
  String get TextAppResetPassword => "ପାସୱାର୍ଡ ପୁନ Res ସେଟ୍ କରନ୍ତୁ |";
  String get TextAppNINAppCreditsPage => "NIN ଆପ୍ କ୍ରେଡିଟ୍ ପୃଷ୍ଠା |";
  String get NINTextOopsSomethingWentWrong => "ଓହୋ! କିଛି ଭୁଲ ହୋଇ ଗଲା";
  String get NINTextPleaseEnterAllFields =>
      "ଦୟାକରି ସମସ୍ତ କ୍ଷେତ୍ର ପ୍ରବେଶ କରନ୍ତୁ |";
  String get NINTextSubmittedSuccessfully1 => "ସଫଳତାର ସହିତ ଦାଖଲ |";
  String get NINTextSubmittedSuccessfully2 => "ସଫଳତାର ସହିତ ଦାଖଲ |";
  String get NINTextFitbitAuthentication => "ଫିଟବିଟ୍ ପ୍ରାମାଣିକିକରଣ |";
  String get NINTextHours => "ଘଣ୍ଟା";
  String get NINTextMinutes => "ମିନିଟ୍ |";
  String get NINTextEnterDurationFor => "ପାଇଁ ଅବଧି ପ୍ରବେଶ କରନ୍ତୁ |";
  String get NINTextTimerRunning => "ଟାଇମର୍ ଚାଲୁଛି |";
  String get NINTextPleaseStopTheTimerBeforeSubmitting =>
      "ଦାଖଲ କରିବା ପୂର୍ବରୁ ଦୟାକରି ଟାଇମର୍ ବନ୍ଦ କରନ୍ତୁ |";
  String get NINTextTotalDuration => "ସମୁଦାୟ ଅବଧି";
  String get NINTextSec => "ସେକେଣ୍ଡ";
  String get NINTextStartYourActivity => "ତୁମର କାର୍ଯ୍ୟକଳାପ ଆରମ୍ଭ କର!";
  String get NINTextPause => "ବିରାମ";
  String get NINTextReset => "ପୁନ et ସେଟ୍ କରନ୍ତୁ |";
  String get NINTextError => "ତ୍ରୁଟି |";
  String get NINTextPleaseEnterCookedWeightAndServingSize =>
      "ଦୟାକରି ରନ୍ଧା ହୋଇଥିବା ଓଜନ ଏବଂ ପରିବେଷଣ ଆକାର ପ୍ରବେଶ କରନ୍ତୁ |";
  String get NINTextEditIngredient => "ଉପାଦାନ ସଂପାଦନ କରନ୍ତୁ |";
  String get NINTextAlert => "ସତର୍କତା";
  String get NINTextEnterWeightFor => "ପାଇଁ ଓଜନ ପ୍ରବେଶ କରନ୍ତୁ |";
  String get NINTextNewWeightGram => "ନୂତନ ଓଜନ (g)";
  String get NINTextEditRecipeName => "ରେସିପି ନାମ ସଂପାଦନ କରନ୍ତୁ |";
  String get NINTextNewRecipeName => "ନୂତନ ପ୍ରାପ୍ତ ନାମ |";
  String get NINTextSubmitted => "ଦାଖଲ";
  String get NINTextSuccess => "ସଫଳତା |";
  String get NINTextDietaryDiaryReportSavedTo =>
      "ଡାଏଟାରୀ ଡାଏରୀ ରିପୋର୍ଟକୁ ସେଭ୍ କରାଯାଇଛି |";
  String get NINTextErrorSavingFile => "ଫାଇଲ୍ ସଞ୍ଚୟ କରିବାରେ ତ୍ରୁଟି |";
  String get NINTextClose => "ବନ୍ଦ";
  String get NINTextIWantTo => "ମୁଁ ଚାହେଁ";
  String get NINTextGain => "ଲାଭ";
  String get NINTextMaintain => "ରକ୍ଷଣାବେକ୍ଷଣ କର |";
  String get NINTextLose => "ହାରିଯାଅ |";
  String get NINTextWeightChangeKg => "ଓଜନ ପରିବର୍ତ୍ତନ (କେଜି)";
  String get NINTextAddNewWeight => "ନୂତନ ଓଜନ ଯୋଗ କରନ୍ତୁ |";
  String get NINTextEnterWeight => "ଓଜନ ପ୍ରବେଶ କରନ୍ତୁ |";
  String get NINTextOf100Gram => "100 ଗ୍ରାମ";
  String get NINTextProximateComposition => "ଆନୁମାନିକ ରଚନା |";
  String get NINTextVitamins => "ଭିଟାମିନ୍ |";
  String get NINTextMinerals => "ଖଣିଜ ପଦାର୍ଥ |";
  String get NINTextTotalSaturatedFattyAcids =>
      "ସମୁଦାୟ ସନ୍ତୁଳିତ ଫ୍ୟାଟି ଏସିଡ୍ |";
  String get NINTextAllRecipeOf100Grams => "100 ଗ୍ରାମର ସମସ୍ତ ରେସିପି |";
  String get NINTextOurCustomerFeedback => "ଆମର ଗ୍ରାହକଙ୍କ ମତାମତ |";
  String get NINTextOverallRatings => "ସାମଗ୍ରିକ ମୂଲ୍ୟାୟନ";
  String get NINTextRateUs => "ଆମକୁ ମୂଲ୍ୟାଙ୍କନ କର |";
  String get NINTextBookDetails => "ପୁସ୍ତକ ବିବରଣୀ";
  String get NINTextOne => "ଗୋଟିଏ |";
  String get NINTextWeightOf => "wt। ର";
  String get NINTextSelectStartDate => "ଆରମ୍ଭ ତାରିଖ ଚୟନ କରନ୍ତୁ |";
  String get NINTextSelectEndDate => "ଶେଷ ତାରିଖ ଚୟନ କରନ୍ତୁ |";
  String get NINTextNoData => "କ data ଣସି ତଥ୍ୟ ନାହିଁ |";
  String get NINTextWorkLevel => "କାର୍ଯ୍ୟ ସ୍ତର";
  String get NINTextOldPassword => "ପୁରୁଣା ପ୍ରବେଶ ସବ୍ଦ";
  String get NINTextNewPassword => "ନୁତନ ପାସ୍ୱାର୍ଡ";
  String get NINTextUpdateProfile => "ପ୍ରୋଫାଇଲ୍ ଅଦ୍ୟତନ କରନ୍ତୁ |";
  String get NINTextChangeImage => "ପ୍ରତିଛବି ପରିବର୍ତ୍ତନ କରନ୍ତୁ |";
  String get NINTextNoFavouriteFoodFound =>
      "କ favorite ଣସି ପ୍ରିୟ ଖାଦ୍ୟ ମିଳିଲା ନାହିଁ |";
  String get NINTextCookedQuantity => "ରନ୍ଧା ପରିମାଣ |";
  String get NINTextServingQuantity => "ପରିବେଷଣ ପରିମାଣ |";
  String get NINTextNutrientInformation => "ପୁଷ୍ଟିକର ସୂଚନା";
  String get NINTextIngredient => "ଉପାଦାନ";
  String get NINTextMealsTakenOn => "ଭୋଜନ ନିଆଗଲା |";
  String get NINTextPercentage => "ଶତକଡା";
  String get NINTextEAR => "EAR";
  String get NINTextValue => "ମୂଲ୍ୟ";
  String get NINTextNutrient => "ପୁଷ୍ଟିକର";
  String get NINTextEnergyKcal => "ଶକ୍ତି (kcal)";
  String get NINTextProteinG => "ପ୍ରୋଟିନ୍ (g)";
  String get NINTextFatG => "ଚର୍ବି (g)";
  String get NINTextCarbohydratesG => "କାର୍ବୋହାଇଡ୍ରେଟ୍ସ (g)";
  String get NINTextCalciumMg => "କ୍ୟାଲସିୟମ୍ (ମିଗ୍ରା)";
  String get NINTextFiberG => "ଫାଇବର (g)";
  String get NINTextIronMg => "ଲ Iron ହ (ମିଗ୍ରା)";
  String get NINTextZincMg => "ଜିଙ୍କ (ମିଗ୍ରା)";
  String get NINTextMagnesiumMg => "ମ୍ୟାଗ୍ନେସିୟମ୍ (ମିଗ୍ରା)";
  String get NINTextThiamineB1Mg => "ଥିଏମାଇନ୍ (ବି 1) (ମିଗ୍ରା)";
  String get NINTextRiboflavinB2Mg => "ରାଇବୋଫ୍ଲାଭିନ (B2) (ମିଗ୍ରା)";
  String get NINTextNiacinB3Mg => "ନିୟାସିନ୍ (B3) (ମିଗ୍ରା)";
  String get NINTextFolatesB9Mcg => "ଫୋଲେଟ୍ସ (B9) (mcg)";
  String get NINTextRetinolVitAMcg => "ଭିଟ୍ ଏ (mcg)";
  String get VitaminCmg => "ଭିଟାମିନ୍ ସି (ମିଗ୍ରା)";
  String get Iodinemcg => "ଆୟୋଡିନ୍ (mcg)";
  String get serving => "ସେବା କରିବା |";
  String get Mynutritionstatus => "ମୋର ପୁଷ୍ଟିକର ସ୍ଥିତି |";

  String get ninTextMyHealthStatus => 'ମୋର ସ୍ୱାସ୍ଥ୍ୟ ସ୍ଥିତି';
  String get ninTextNutrientsInRawFoods => 'କଞ୍ଚା ଖାଦ୍ୟରେ ପୁଷ୍ଟିକର ଖାଦ୍ୟ |';
  String get ninTextNutrientsInRecipes => 'ରେସିପିରେ ପୁଷ୍ଟିକର ଖାଦ୍ୟ |';
  String get ninTextIcmrNinMyPlateForTheDay => 'ICMR-NIN ଦିନ ପାଇଁ ମୋର ପ୍ଲେଟ୍ |';
  String get ninTextToday => 'ଆଜି';
  String get ninTextTrackMyActivity => 'ମୋର କାର୍ଯ୍ୟକଳାପକୁ ଟ୍ରାକ୍ କରନ୍ତୁ |';
  String get ninTextMyHeartRate => 'ମୋର ହୃଦୟର ଗତି';
  String get ninTextMyWaterIntake => 'ମୋର ଜଳ ଗ୍ରହଣ';
  String get ninTextSleepTracker => 'ଶୋଇବା ଟ୍ରାକର୍ |';
  String get ninTextLit => 'ଲିଟ୍';
  String get ninTextRecordMyBloodPressure =>
      'ମୋର ରକ୍ତଚାପ / ରକ୍ତ ଗ୍ଲୁକୋଜ / SPO2 ରେକର୍ଡ କରନ୍ତୁ |';
  String get ninTextNutritionEducationContent => 'ପୁଷ୍ଟିକର ଶିକ୍ଷା ବିଷୟବସ୍ତୁ |';
  String get ninTextMyNutrientIntake => 'ମୋର ପୁଷ୍ଟିକର ଖାଦ୍ୟ';
  String get ninTextOn => 'ଉପରେ';
  String get ninTextWithReferenceToEAR => 'EAR ରେଫରେନ୍ସ ସହିତ |';
  String get ninTextAchieveYourHealthGoals =>
      'ଆପଣଙ୍କର ସ୍ୱାସ୍ଥ୍ୟ ଲକ୍ଷ୍ୟ ହାସଲ କରନ୍ତୁ |';
  String get ninTextPercentage => 'ଶତକଡା';
  String get ninTextMyPreviousDietDiaries => 'ମୋର ପୂର୍ବ ଡାଏଟ୍ ଡାଏରୀ |';
  String get ninTextRecordReviewSleep => 'ନିଦ ରେକର୍ଡ / ସମୀକ୍ଷା କରନ୍ତୁ |';
  String get ninTextHours => 'ଘଣ୍ଟା';
  String get ninTextIngredient => 'ଉପାଦାନ';
  String get ninTextOthersSpecify => 'ଅନ୍ୟମାନେ ନିର୍ଦ୍ଦିଷ୍ଟ କରନ୍ତି |';
  String get ninTextAddNewIngredient => 'ନୂତନ ଉପାଦାନ ଯୋଗ କରନ୍ତୁ |';
  String get ninTextFoodName => 'ଖାଦ୍ୟ ନାମ';
  String get ninTextSource => 'ଉତ୍ସ';
  String get ninTextEnterBrandAndProductName =>
      'ବ୍ରାଣ୍ଡ ଏବଂ ଉତ୍ପାଦ ନାମ ପ୍ରବେଶ କରନ୍ତୁ |';
  String get ninTextEnterAuthorDetails =>
      'ଲେଖକଙ୍କ ନାମ, ବର୍ଷ, ପତ୍ରିକା, ପୃଷ୍ଠା ପ୍ରବେଶ କରନ୍ତୁ |';
  String get ninTextEnterFctName => 'FCT ର ନାମ ପ୍ରବେଶ କରନ୍ତୁ |';
  String get ninTextName => 'ନାମ';
  String get ninTextProductName => 'ଉତ୍ପାଦର ନାମ';
  String get ninTextSelectStartDate => 'ଆରମ୍ଭ ତାରିଖ ଚୟନ କରନ୍ତୁ |';
  String get ninTextSelectEndDate => 'ଶେଷ ତାରିଖ ଚୟନ କରନ୍ତୁ |';
  String get ninTextNoExercise => 'କ exc ଣସି ବ୍ୟାୟାମ ନାହିଁ |';
  String get ninTextDevelopedWithExpertiseAndInputs =>
      'ସେଣ୍ଟର ଫର ଡେଭଲପମେଣ୍ଟ ଆଣ୍ଡ ଆଡଭାନ୍ସଡ କମ୍ପ୍ୟୁଟିଙ୍ଗ (C-DAC), ହାଇଦ୍ରାବାଦ ଭାଷା ଲିଙ୍କ ଦ୍ୱାରା NIN ରୁ ଅଭିଜ୍ and ତା ଏବଂ ନିବେଶ ସହିତ ବିକଶିତ |';
  String get ninTextMyNutrientIntakeToday => 'ଆଜି ମୋର ପୁଷ୍ଟିକର ଖାଦ୍ୟ |';
  String get ninTextIcmrNationalInstituteOfNutritionAddress =>
      'ICMR - ତାରାକା ମେଟ୍ରୋ ଷ୍ଟେସନ ପାଖରେ ନ୍ୟାସନାଲ୍ ଇନଷ୍ଟିଚ୍ୟୁଟ୍ ଅଫ୍ ପୁଷ୍ଟିକର, ଜାମାଇ-ଓସମାନିଆ PO, ହାଇଦ୍ରାବାଦ -500 007, ଭାରତ |';

  String get ninTextKcal => 'kcal';
  String get ninTextKcalPerDay => 'kcal / ଦିନ';
  String get ninTextDelete => 'ବିଲୋପ କରନ୍ତୁ |';
  String get ninTextDeleteNotification => 'ବିଜ୍ଞପ୍ତି ବିଲୋପ କରନ୍ତୁ |';
  String get ninTextConfirmDeleteNotification =>
      'ଆପଣ ନିଶ୍ଚିତ କି ଆପଣ ଏହି ବିଜ୍ଞପ୍ତିକୁ ବିଲୋପ କରିବାକୁ ଚାହୁଁଛନ୍ତି କି?';
  String get ninTextTimeFor => 'ହେ, ଏହା \'s time for';
  String get ninTextFitbitWatch => 'ଫିଟବିଟ୍ ଘଣ୍ଟା |';
  String get ninTextGoogleFitApp => 'ଗୁଗୁଲ୍ ଫିଟ୍ ଆପ୍ |';
  String get ninTextUnderweight => 'ଓଜନ କମ |';
  String get ninTextNormal => 'ସାଧାରଣ';
  String get ninTextOverweight => 'ଅଧିକ ଓଜନ';
  String get ninTextObesity => 'ମୋଟାପଣ |';
  String get ninTextMale => 'ପୁରୁଷ';
  String get ninTextFemale => 'ମହିଳା';
  String get ninTextAgeInYears => 'ବର୍ଷଗୁଡ଼ିକରେ ବୟସ |';
  String get ninTextChangeInWeight => 'ଓଜନରେ ପରିବର୍ତ୍ତନ |';
  String get ninTextSteps => 'ପଦକ୍ଷେପ';
  String get ninTextFor => 'ପାଇଁ';
  String get ninTextMinutes => 'ମିନିଟ୍ |';
  String get ninTextPause => 'ବିରାମ';
  String get ninTextReset => 'ପୁନ et ସେଟ୍ କରନ୍ତୁ |';
  String get ninTextStartActivity => 'ତୁମର କାର୍ଯ୍ୟକଳାପ ଆରମ୍ଭ କର |';
  String get ninTextCartIsEmpty => 'ତୁମର କାର୍ଟ ଖାଲି ଅଛି |';
  String get ninTextMyPersonalRecipe => 'ମୋର ବ୍ୟକ୍ତିଗତ ରେସିପି |';
  String get ninTextSearchByRecipeName => 'ରେସିପି ନାମ ଦ୍ୱାରା ସନ୍ଧାନ କରନ୍ତୁ |';
  String get ninTextHelpCenter => 'ସହାୟତା କେନ୍ଦ୍ର';
  String get ninTextCommonProblems => 'ସାଧାରଣ ସମସ୍ୟା |';
  String get ninTextFAQs => 'ପ୍ରଶ୍ନଗୁଡିକ';
  String get ninTextHowActiveAreYou => 'ଆପଣ କେତେ ସକ୍ରିୟ ଅଛନ୍ତି |';
  String get ninTextVitaminC => 'ଭିଟାମିନ୍ ସି (ମିଗ୍ରା)';
  String get ninTextVitaminA => 'ଭିଟାମିନ୍ ଏ (IU)';
  String get ninTextSodium => 'ସୋଡିୟମ୍ (ମିଗ୍ରା)';
  String get ninTextJournal => 'ପତ୍ରିକା';
  String get ninTextPage => 'ପୃଷ୍ଠା';
  String get ninTextAdequateIntakeCarbs =>
      '* କାର୍ବୋହାଇଡ୍ରେଟ୍ ପାଇଁ ପର୍ଯ୍ୟାପ୍ତ ପରିମାଣର ଭୋଜନ (AI): ବୟସ୍କ ପୁରୁଷ ଏବଂ ମହିଳାଙ୍କ ପାଇଁ 130 ଗ୍ରାମ |';
  String get ninTextAdequateIntakeFiber =>
      '** ଫାଇବର ପାଇଁ AI ସୁପାରିଶ: ମହିଳାମାନଙ୍କ ପାଇଁ 25 g ଏବଂ ପୁରୁଷମାନଙ୍କ ପାଇଁ 38 g |';
  String get your => 'ତୁମର';
  String get question1 => 'ମୁଁ ମୋର ବ୍ୟକ୍ତିଗତ ବିବରଣୀ ସଂପାଦନ କରିପାରିବି କି?';
  String get answer1 =>
      'ହଁ ତୁମର ବ୍ୟକ୍ତିଗତ ତଥ୍ୟ ତୁମର ପ୍ରୋଫାଇଲରେ ଏଡିଟ୍ ହୋଇପାରିବ |';
  String get linkText1 =>
      'ଆପଣଙ୍କର ବ୍ୟକ୍ତିଗତ ବିବରଣୀ ସଂପାଦନ କରିବାକୁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question2 => 'ମୁଁ ମୋର ଯୋଗାଯୋଗ ବିବରଣୀ ପରିବର୍ତ୍ତନ କରିପାରିବି କି?';
  String get answer2 =>
      'ହଁ ତୁମର ପ୍ରୋଫାଇଲରେ ଥିବା ‘ବ୍ୟକ୍ତିଗତ ତଥ୍ୟ’ ବିକଳ୍ପକୁ ଯାଇ ତୁମର ଯୋଗାଯୋଗ ବିବରଣୀ ପରିବର୍ତ୍ତନ କରାଯାଇପାରିବ |';
  String get linkText2 =>
      'ଆପଣଙ୍କର ଯୋଗାଯୋଗ ବିବରଣୀ ସଂପାଦନ କରିବାକୁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question3 =>
      'ମୁଁ ମୋର ବ୍ୟବହାରକାରୀ ପାସୱାର୍ଡ ପରିବର୍ତ୍ତନ କରିପାରିବି କି?';
  String get answer3 =>
      'ହଁ ତୁମର ପ୍ରୋଫାଇଲରେ ଥିବା ‘ସେଟିଂ’ ଅପ୍ସନ୍ କୁ ଯାଇ ତୁମର ପାସୱାର୍ଡ ପରିବର୍ତ୍ତନ କରାଯାଇପାରିବ |';
  String get linkText3 =>
      'ଆପଣଙ୍କର ପାସୱାର୍ଡ ପରିବର୍ତ୍ତନ କରିବାକୁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question4 => 'ମୁଁ କିପରି ମୋର BMI ଯାଞ୍ଚ କରିପାରିବି?';
  String get answer4 =>
      'ମୂଳପୃଷ୍ଠାରେ ପ୍ରଦର୍ଶିତ ‘ସ୍ୱାସ୍ଥ୍ୟ କାଲକୁଲେଟର’ ବିକଳ୍ପରେ ପ୍ରଦତ୍ତ ‘BMI କାଲକୁଲେଟର’ରେ ତୁମର ଉଚ୍ଚତା ଏବଂ ଶରୀରର ଓଜନ ପ୍ରବେଶ କରି ତୁମର BMI ଯାଞ୍ଚ କରିପାରିବ |';
  String get linkText4 => 'BMI କାଲକୁଲେଟର ବ୍ୟବହାର କରିବାକୁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question5 => 'ମୁଁ ଗତ ଏକ ମାସ ପାଇଁ ମୋର ଓଜନ ଟ୍ରାକ୍ କରିପାରିବି କି?';
  String get answer5 =>
      'ହଁ ମୂଳପୃଷ୍ଠାରେ ପ୍ରଦତ୍ତ ‘ଓଜନ ପରିଚାଳକ’ ବିକଳ୍ପରେ ଆପଣ ଗତ ମାସ / ବର୍ଷ ପାଇଁ ଆପଣଙ୍କ ଶରୀରର ଓଜନ ପରିବର୍ତ୍ତନଗୁଡ଼ିକର ବିବରଣୀ ଦେଖିପାରିବେ |';
  String get linkText5 => 'ଆପଣଙ୍କର ଓଜନ ଟ୍ରାକ୍ କରିବାକୁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question6 =>
      'ଏକ ନିର୍ଦ୍ଦିଷ୍ଟ ଦିନରେ ମୁଁ କିପରି ମୋର ସାମଗ୍ରିକ ଶାରୀରିକ କାର୍ଯ୍ୟକଳାପ ଯାଞ୍ଚ କରିପାରିବି?';
  String get answer6 =>
      'ମୂଳ ପୃଷ୍ଠାରେ ଥିବା ‘ମୋ କାର୍ଯ୍ୟକଳାପ’ ବିକଳ୍ପରୁ ତୁମେ ତୁମର ଶାରୀରିକ କାର୍ଯ୍ୟକଳାପକୁ ଟ୍ରାକ୍ କରିପାରିବ |';
  String get linkText6 => 'ଆପଣଙ୍କର କାର୍ଯ୍ୟକଳାପ ଦେଖିବାକୁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question7 =>
      'ଜଳ ଗ୍ରହଣ ପାଇଁ ମୁଁ କିପରି ଏକ ସ୍ମାରକପତ୍ର ସେଟ୍ କରିପାରିବି?';
  String get answer7 =>
      'ମୂଳପୃଷ୍ଠାରେ ପ୍ରଦତ୍ତ ‘ସେଟ୍ ବିଜ୍ଞପ୍ତି’ ବିକଳ୍ପରେ ଆପଣ ଜଳ ଗ୍ରହଣ ସ୍ମାରକ ପାଇଁ ଏକ ସମୟ ସେଟ୍ କରିପାରିବେ |';
  String get linkText7 => 'ଜଳ ଗ୍ରହଣ ସ୍ମାରକ ସେଟ୍ କରିବାକୁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question8 =>
      'ମୁଁ କିପରି ମୋର ସ୍ମାର୍ଟ ୱାଚ୍ ସହିତ ଆପ୍ ସଂଯୋଗ କରିପାରିବି?';
  String get answer8 =>
      'ମୂଳ ପୃଷ୍ଠାରେ ପ୍ରଦତ୍ତ ‘ସଂଯୋଗ ଘଣ୍ଟା’ ବିକଳ୍ପକୁ ଯାଇ ଆପଣ ଆପଣଙ୍କର ସ୍ମାର୍ଟ ଘଣ୍ଟାକୁ ଆପ୍ ସହିତ ସଂଯୋଗ କରିପାରିବେ |';
  String get linkText8 =>
      'ଆପଣଙ୍କର ସ୍ମାର୍ଟ ଘଣ୍ଟାକୁ ସଂଯୋଗ କରିବାକୁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question9 => 'ମୁଁ ଏକ ସମୟରେ କେତେ ପୋଷାକ ବ୍ୟବହାର କରିପାରିବି?';
  String get answer9 =>
      'ଆପଣ ଆପ୍ ସହିତ ଫିଟ୍ବିଟ୍ ୱାଚ୍ ଏବଂ ଗୁଗୁଲ୍ ଫିଟ୍ କୁ ଏକତ୍ର କରିପାରିବେ |';
  String get linkText9 => '';

  String get question10 => 'କେଉଁ ସ୍ମାର୍ଟ ଘଣ୍ଟା ଆପ୍ ସହିତ ସୁସଙ୍ଗତ?';
  String get answer10 => 'ଫିଟବିଟ୍ ୱାଚ୍ ଏବଂ ଗୁଗୁଲ୍ ଫିଟ୍ |';
  String get linkText10 => '';

  String get question11 =>
      'ଯଦି ମୋର ସ୍ମାର୍ଟ ଘଣ୍ଟା ନାହିଁ ତେବେ ମୁଁ ମୋର କାର୍ଯ୍ୟକଳାପକୁ ଟ୍ରାକ୍ କରିପାରିବି କି?';
  String get answer11 =>
      'ହଁ, ଆପଣ ଆପଣଙ୍କର କାର୍ଯ୍ୟକଳାପକୁ ଟ୍ରାକ୍ କରିପାରିବେ | ଏଥିପାଇଁ ଆପଣଙ୍କୁ ଗୁଗୁଲ୍ ଫିଟ୍ ଆପ୍ ଡାଉନଲୋଡ୍ କରିବାକୁ ପଡିବ, ଏକ ଗୁଗୁଲ୍ ଆକାଉଣ୍ଟ୍ ସହିତ ସାଇନ୍ ଇନ୍ କରନ୍ତୁ ଏବଂ ସମାନ ଗୁଗୁଲ୍ ଆକାଉଣ୍ଟ୍ ସହିତ ଆପଣଙ୍କୁ ଆମର ୱାଚ୍ ବିଭାଗରେ ଲଗ୍ କରିବାକୁ ପଡିବ |';
  String get linkText11 => '';

  String get question12 => 'ମୁଁ କିପରି ମୋର ନିଦକୁ ଟ୍ରାକ୍ କରିପାରିବି?';
  String get answer12 =>
      'ମୂଳପୃଷ୍ଠାରେ ପ୍ରଦତ୍ତ ଶୋଇବା ଟ୍ରାକର୍ ବିକଳ୍ପକୁ ଯାଇ ଆପଣ ଏକ ସାପ୍ତାହିକ / ମାସିକ ଭିତ୍ତିରେ ଆପଣଙ୍କର ନିଦକୁ ଟ୍ରାକ୍ କରିପାରିବେ |';
  String get linkText12 => 'ତୁମର ନିଦକୁ ଟ୍ରାକ୍ କରିବା ପାଇଁ ଏଠାରେ କ୍ଲିକ୍ କର |';

  String get question13 =>
      'ମୁଁ କିପରି ଆପ୍ ମାଧ୍ୟମରେ କ any ଣସି NIN ପ୍ରକାଶନ କିଣି ପାରିବି?';
  String get answer13 =>
      'ମୂଳପୃଷ୍ଠାରେ ପ୍ରଦତ୍ତ ‘ବୁକ୍ ଷ୍ଟୋର୍’ ବିକଳ୍ପରୁ ଆପଣ NIN ପ୍ରକାଶନ କ୍ରୟ କରିପାରିବେ |';
  String get linkText13 =>
      'ପୁସ୍ତକ ଦୋକାନ ପରିଦର୍ଶନ କରିବାକୁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question14 =>
      'ମୁଁ କିପରି ମୋର ବ୍ୟକ୍ତିଗତ ଡାଏଟ୍ ଡାଏରୀ ତିଆରି କରିପାରିବି?';
  String get answer14 =>
      'ଆପଣ ‘ମୋର ଡାଏଟ୍ ଡାଏରୀ ବିକଳ୍ପ’କୁ ଯାଇ ଦିନସାରା ଖାଉଥିବା ଖାଦ୍ୟର ବିବରଣୀ ପ୍ରବେଶ କରିପାରିବେ |';
  String get linkText14 =>
      'ଆପଣଙ୍କର ଡାଏଟ୍ ଡାଏରୀ ସୃଷ୍ଟି କରିବାକୁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question15 =>
      'ମୁଁ କିପରି ଏକ ରେସିପି ଖୋଜିବି ଯାହା ଏକ ନିର୍ଦ୍ଦିଷ୍ଟ ପୁଷ୍ଟିକର ଅଟେ |';
  String get answer15 =>
      'ଆପଣ ମୂଳପୃଷ୍ଠାରେ ଥିବା ‘ମୋ ଖାଦ୍ୟରେ ଥିବା ପୋଷକ ତତ୍ତ୍ୱ’ ଟ୍ୟାବରେ ଦିଆଯାଇଥିବା ‘ରେସିପିରେ ପୁଷ୍ଟିକର ସନ୍ଧାନ’ ବିକଳ୍ପ ଚୟନ କରିପାରିବେ | ତା’ପରେ ଉପର ଡାହାଣ କୋଣରେ ଥିବା ଡ୍ରପ୍ ଡାଉନ୍ ତାଲିକାରୁ ଆବଶ୍ୟକ ପୁଷ୍ଟିକର ଚୟନ କରନ୍ତୁ |';
  String get linkText15 => 'ରେସିପି ଖୋଜିବା ପାଇଁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question16 =>
      'ପୂର୍ବ ଦିନ ସଞ୍ଚୟ ହୋଇଥିବା ଦିନ ପାଇଁ ମୁଁ କିପରି ମୋର ପୁଷ୍ଟିକର ଖାଦ୍ୟ ଯାଞ୍ଚ କରିପାରିବି?';
  String get answer16 =>
      '‘ଭୋଜନ ତାଲିକା’ ପୃଷ୍ଠାରେ ‘କ୍ୟାଲେଣ୍ଡର ଆଇକନ୍’ ରୁ ​​ଏକ ତାରିଖ ଚୟନ କରି ଆପଣ ଏକ ନିର୍ଦ୍ଦିଷ୍ଟ ଦିନରେ ଆପଣଙ୍କର ପୁଷ୍ଟିକର ଖାଦ୍ୟ ଦେଖିପାରିବେ |';
  String get linkText16 =>
      'ଆପଣଙ୍କର ପୁଷ୍ଟିକର ଖାଦ୍ୟ ଯାଞ୍ଚ କରିବାକୁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question17 =>
      'ମୋର ରେସିପିରେ ବ୍ୟବହୃତ କଞ୍ଚା ଉପାଦାନରେ ଥିବା ପୁଷ୍ଟିକର ଖାଦ୍ୟ ମୁଁ କିପରି ଜାଣିବି?';
  String get answer17 =>
      'ମୂଳ ପୃଷ୍ଠାରେ ଥିବା ‘ମୋ ଖାଦ୍ୟରେ ଥିବା ପୁଷ୍ଟିକର ଖାଦ୍ୟ’ ଟ୍ୟାବରେ ଦିଆଯାଇଥିବା ‘କଞ୍ଚା ଖାଦ୍ୟରେ ପୁଷ୍ଟିକର ସନ୍ଧାନ’ ବିକଳ୍ପ ଚୟନ କରି ଆପଣ ଏକ ନିର୍ଦ୍ଦିଷ୍ଟ ଉପାଦାନରେ ଥିବା ପୋଷକ ତତ୍ତ୍ୱ ଜାଣିପାରିବେ |';
  String get linkText17 =>
      'କଞ୍ଚା ଖାଦ୍ୟରେ ପୋଷକ ତତ୍ତ୍ୱ ଖୋଜିବା ପାଇଁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question18 => 'ମୁଁ କିପରି ଏକ ରେସିପିର ପୁଷ୍ଟିକର ରଚନା ଜାଣିପାରିବି?';
  String get answer18 =>
      'ମୂଳ ପୃଷ୍ଠାରେ ଥିବା ‘ମୋ ଖାଦ୍ୟରେ ଥିବା ପୋଷକ ତତ୍ତ୍ୱ’ ଟ୍ୟାବରେ ଦିଆଯାଇଥିବା ‘ରେସିପିରେ ସନ୍ଧାନ ପୁଷ୍ଟିକର’ ବିକଳ୍ପ ଚୟନ କରି ଆପଣ ଏକ ନିର୍ଦ୍ଦିଷ୍ଟ ଉପାଦାନରେ ଥିବା ପୋଷକ ତତ୍ତ୍ୱ ଜାଣିପାରିବେ |';
  String get linkText18 => 'ପୁଷ୍ଟିକର ରଚନା ଜାଣିବା ପାଇଁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question19 =>
      'ମୁଁ ଏକ ନୂତନ ରେସିପି ଅନ୍ତର୍ଭୂକ୍ତ କରିପାରିବି ଯାହା ଆପରେ ଉପଲବ୍ଧ ନୁହେଁ?';
  String get answer19 =>
      'ହଁ ନିର୍ଦ୍ଦିଷ୍ଟ ସ୍ଥିର ରେସିପି ତଳେ ଦିଆଯାଇଥିବା ଲିଙ୍କ୍ ବ୍ୟବହାର କରି ଆପଣ ଏକ ବିଦ୍ୟମାନ ରେସିପି ପରିବର୍ତ୍ତନ କରିପାରିବେ କିମ୍ବା ଡାଏଟ୍ ଡାଏରୀ ପୃଷ୍ଠାରେ ପ୍ରତ୍ୟେକ ଖାଦ୍ୟ ପାଇଁ ପ୍ରଦାନ କରାଯାଇଥିବା ‘କଷ୍ଟମ୍ ଡିସ୍ ସୃଷ୍ଟି’ ବିକଳ୍ପ ଉପରେ କ୍ଲିକ୍ କରି ଏକ ସମ୍ପୂର୍ଣ୍ଣ ନୂତନ ରେସିପି ତିଆରି କରିପାରିବେ |';
  String get linkText19 =>
      'ଏକ କଷ୍ଟମ୍ ରେସିପି ତିଆରି କରିବାକୁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question20 =>
      'ଏକ ନିର୍ଦ୍ଦିଷ୍ଟ ସ୍ୱାସ୍ଥ୍ୟ ଅବସ୍ଥା ପାଇଁ ମୁଁ ଖାଦ୍ୟପେୟ ସୁପାରିଶ ପାଇ ପାରିବି କି?';
  String get answer20 =>
      'ହଁ ମୂଳପୃଷ୍ଠାରେ ଥିବା ‘ସନ୍ଧାନ ଉପାଦାନ’ ବିକଳ୍ପରୁ ଆପଣ ସ୍ୱାସ୍ଥ୍ୟ ସୁପାରିଶ କିମ୍ବା ଡାଏଟ୍ ଚାର୍ଟ ନିର୍ଦ୍ଦେଶାବଳୀ ପାଇପାରିବେ |';
  String get linkText20 => 'ଖାଦ୍ୟପେୟ ସୁପାରିଶ ପାଇବାକୁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get question21 =>
      'ମୁଁ ଇଂରାଜୀ ବ୍ୟତୀତ ଅନ୍ୟ ଭାଷାରେ ଆପ୍ ବ୍ୟବହାର କରିପାରିବି କି?';
  String get answer21 =>
      'ହଁ ତୁମର ପ୍ରୋଫାଇଲରେ ପ୍ରଦତ୍ତ ‘ସେଟିଂ’ ବିକଳ୍ପରୁ ଆପଣ ଚାହୁଁଥିବା ଭାଷା ଚୟନ କରିପାରିବେ |';
  String get linkText21 => 'ଭାଷା ପରିବର୍ତ୍ତନ କରିବାକୁ ଏଠାରେ କ୍ଲିକ୍ କରନ୍ତୁ |';

  String get ninTextBmiHwading => 'ବଡି ମାସ ଇଣ୍ଡେକ୍ସ (BMI):';
  String get ninTextBmiDiscription =>
      'BMI ବ୍ୟକ୍ତିର ଓଜନ ଭାବରେ କିଲୋଗ୍ରାମରେ ବ୍ୟକ୍ତିର ଉଚ୍ଚତାର ବର୍ଗ ଦ୍ meters ାରା ମିଟର (କିଲୋଗ୍ରାମ / ମି 2) ଭାବରେ ବିଭକ୍ତ | BMI ରେଞ୍ଜଗୁଡିକ ଶରୀରର ଅତ୍ୟଧିକ ଚର୍ବିର ରୋଗ ଏବଂ ମୃତ୍ୟୁ ଉପରେ ପ୍ରଭାବ ଉପରେ ଆଧାରିତ ଏବଂ ଆଡିପୋଜିଟି ସହିତ ଯଥାର୍ଥ ଭାବରେ ଜଡିତ | BMI ରୋଗର ବିପଦ ସୂଚକ ଭାବରେ ବିକଶିତ ହେଲା; ଯେହେତୁ BMI ବୃଦ୍ଧି ହୁଏ, ସେହିପରି କିଛି ରୋଗ ପାଇଁ ବିପଦ ମଧ୍ୟ ବ .େ | ଅଧିକ ଓଜନ ଏବଂ ମେଦବହୁଳତା ସହିତ ଜଡିତ କେତେକ ସାଧାରଣ ଅବସ୍ଥା ଅନ୍ତର୍ଭୁକ୍ତ: ଅକାଳ ମୃତ୍ୟୁ, ହୃଦ୍ ରୋଗ, ଉଚ୍ଚ ରକ୍ତଚାପ, ଅଷ୍ଟିଓଆର୍ଥ୍ରାଇଟିସ୍, କିଛି କର୍କଟ ଏବଂ ମଧୁମେହ |';
  String get ninTextbminutritionsta => 'BMI ପୁଷ୍ଟିକର ସ୍ଥିତି |';
  String get ninTextNutritionstat => 'ପୁଷ୍ଟିକର ସ୍ଥିତି |';
  String get ninTextBelow => 'ନିମ୍ନରେ |';
  String get ninTextPreobesity => 'ପୂର୍ବ ମେଦବହୁଳତା |';

  String get ninTextbesity => 'ମୋଟାପଣ ଶ୍ରେଣୀ I';
  String get ninTextbesity2 => 'ମେଦବହୁଳ ଶ୍ରେଣୀ II';
  String get ninTextbesity3 => 'ମେଦବହୁଳ ଶ୍ରେଣୀ II';
  String get ninTextBMRfull => 'ବେସାଲ୍ ମେଟାବୋଲିକ୍ ରେଟ୍ (BMR)';
  String get ninTextBMRDiscription =>
      'ବେସାଲ୍ ମେଟାବୋଲିକ୍ ରେଟ୍ (BMR) ହେଉଛି ସେହି ହାର ଯେଉଁଥିରେ ଜଣେ ବ୍ୟକ୍ତି ବିଶ୍ରାମ ସମୟରେ ଶକ୍ତି ଖର୍ଚ୍ଚ କରନ୍ତି |';
  String get ninTextPreviousdays => 'ପୂର୍ବ 30 ଦିନ';
  String get ninTextason => 'ଯେପରି';
  String get ninTextYearly => 'ବାର୍ଷିକ |';
  String get ninTextabove => 'ଉପରେ';
  String get ninTextAchieveyourhealthgoal =>
      'ଆପଣଙ୍କର ସ୍ୱାସ୍ଥ୍ୟ ଲକ୍ଷ୍ୟ ହାସଲ କରନ୍ତୁ |';
  String get heavyDescription =>
      'ଏହି ବର୍ଗରେ ନିୟମିତ ଏବଂ ତୀବ୍ର ଶାରୀରିକ କାର୍ଯ୍ୟକଳାପ ସହିତ ଜଡିତ ବୃତ୍ତି ଅନ୍ତର୍ଭୁକ୍ତ, ଯେପରିକି ଦ running ଡ଼ିବା, ସାଇକେଲ ଚଲାଇବା, କିମ୍ବା ଭାରୀ ଉଠାଇବା, ପ୍ରତିଦିନ ଏକ ଘଣ୍ଟାରୁ ଅଧିକ ସମୟ | ଉଦାହରଣରେ କଳାବତୀ, ଖଣି ମାଲିକ ଏବଂ ନିର୍ମାଣ ଶ୍ରମିକ ଅନ୍ତର୍ଭୁକ୍ତ |';
  String get moderateDescription =>
      'ଏହି ବର୍ଗର ବ୍ୟକ୍ତିମାନେ ଦ physical ନିକ ପ୍ରାୟ 30 ମିନିଟରୁ ଏକ ଘଣ୍ଟା ପର୍ଯ୍ୟନ୍ତ ଚାଲିବା କିମ୍ବା ହାଲୁକା ଜଗିଂ ଭଳି କିଛି ଶାରୀରିକ କାର୍ଯ୍ୟକଳାପରେ ନିୟୋଜିତ ହୁଅନ୍ତି | ମାନୁଆଲ ଶ୍ରମିକ, କାରିଗର ଏବଂ କେତେକ ପ୍ରକାରର କୁଶଳୀ ଶ୍ରମିକ ପରି ବୃତ୍ତି ଏହି ବର୍ଗରେ ଅନ୍ତର୍ଭୁକ୍ତ |';
  String get sedentaryDescription =>
      'ଏହି ବର୍ଗରେ ଦିନସାରା କ physical ଣସି ଶାରୀରିକ ଗତିବିଧି ନଥିବା ବୃତ୍ତି ଅନ୍ତର୍ଭୁକ୍ତ | ଏହି ଚାକିରିରେ ଥିବା ଲୋକମାନେ ଅଧିକାଂଶ ସମୟ ବସିବା କିମ୍ବା ଶୋଇବାରେ ବିତାଇଥା’ନ୍ତି | ଉଦାହରଣଗୁଡିକରେ ଅଫିସ୍ କର୍ମଚାରୀ, ଶିକ୍ଷକ ଏବଂ ପ୍ରଶାସନିକ ଭୂମିକାରେ ଥିବା ବ୍ୟକ୍ତି ଅନ୍ତର୍ଭୁକ୍ତ |';
  String get Foodprotein => "ପ୍ରୋଟିନ୍ |";
  String get Foodfat => "ମୋଟା";
  String get Foodenergy => "ଶକ୍ତି";
  String get FoodtotalB2 => "ମୋଟ B2";
  String get Foodvitamins => "ଭିଟାମିନ୍ |";
  String get FoodtotalFat => "ମୋଟ ଚର୍ବି |";
  String get FoodproximateComposition => "ଆନୁମାନିକ ରଚନା |";
  String get FoodnutrientsIn100g => "100 ଗ୍ରାମରେ ପୁଷ୍ଟିକର ଖାଦ୍ୟ |";
  String get FoodtotalCarotenoids => "ସମୁଦାୟ କାରୋଟିନଏଡ୍ |";
  String get FoodtotalAscorbicAcid => "ସମୁଦାୟ ଆସ୍କୋରବିକ୍ ଏସିଡ୍ |";
  String get FoodtotalB9 => "ମୋଟ B9";
  String get FoodtotalB6 => "ମୋଟ B6";
  String get Foodcalcium => "କ୍ୟାଲସିୟମ୍";
  String get Foodsodium => "ସୋଡିୟମ୍";
  String get Foodpotassium => "ପୋଟାସିୟମ୍ |";
  String get Foodzinc => "ଜିଙ୍କ୍ |";
  String get Foodiron => "ଲ Iron ହ |";
  String get Foodminerals => "ଖଣିଜ ପଦାର୍ଥ |";
  String get FoodtotalSaturatedFattyAcids => "ସମୁଦାୟ ସନ୍ତୁଳିତ ଫ୍ୟାଟି ଏସିଡ୍ |";
  String get FoodfattyAcids => "ଫ୍ୟାଟି ଏସିଡ୍ |";
  String get FoodtotalDietaryFiber => "ମୋଟ ଡାଏଟାରୀ ଫାଇବର |";
  String get Foodmanganese => "ମାଙ୍ଗାନିଜ୍";
  String get Foodcopper => "ତମ୍ବା |";
  String get Foodselenium => "ସେଲେନିୟମ୍";
  String get Foodmagnesium => "ମ୍ୟାଗ୍ନେସିୟମ୍ |";
  String get Foodphosphorus => "ଫସଫରସ୍ |";
  String get Foodcholesterol => "କୋଲେଷ୍ଟ୍ରଲ |";
  String get Foodcarbohydrate => "କାର୍ବୋହାଇଡ୍ରେଟ୍ |";
  String get FoodvitaminB6 => "ଭିଟାମିନ୍ B6 (ମିଗ୍ରା)";
  String get Punjabi => "ପଞ୍ଜାବୀ |";
  String get Gujarati => "ଗୁଜରାଟୀ";
  String get Odia => "ଓଡିଆ";
  String get Kannada => "କନ୍ନଡ |";
  String get Marathi => "ମରାଠୀ";
  String get Tamil => "ତାମିଲ୍ |";
  String get Bengali => "ବଙ୍ଗାଳୀ";
  String get Telugu => "ତେଲୁଗୁ";
  String get English => "ଇଂରାଜୀ |";
  String get EssentialNutritionalGuidelines =>
      "ଭାରତୀୟମାନଙ୍କର ଖାଦ୍ୟ ଆବଶ୍ୟକତା ପାଇଁ ଉପଯୋଗୀ ଅତ୍ୟାବଶ୍ୟକ ପୋଷକ ନିର୍ଦ୍ଦେଶନାମା।";
  String get NutrientRequirementsRDA2020 =>
      "ଭାରତୀୟମାନଙ୍କ ପାଇଁ ପୋଷକ ଆବଶ୍ୟକତା ଏବଂ ସୁପାରିଶ କରାଯାଇଥିବା ଆହାର ଭତ୍ତା (RDA 2020)।";
  String get RecommendationsBalancedDiets =>
      "ଭାରତରେ ସମତୁଳିତ ଆହାର ଏବଂ ସ୍ୱାସ୍ଥ୍ୟକର ଖାଦ୍ୟ ଅଭ୍ୟାସକୁ ପ୍ରୋତ୍ସାହିତ କରିବା ପାଇଁ ସୁପାରିଶଗୁଡ଼ିକ।";
  String get DietaryGuidelinesForIndians =>
      "ଭାରତୀୟମାନଙ୍କ ପାଇଁ ଆହାର ନିର୍ଦ୍ଦେଶନାମା।";
  String get Nutritionstat => "ପୋଷକ ସାଂଖ୍ୟିକୀ";
  String get referenceMen65kg => "ସନ୍ଦର୍ଭ ପୁରୁଷମାନେ (65 କିଲୋଗ୍ରାମ)";
  String get referenceWomen55kg => "ସନ୍ଦର୍ଭ ମହିଳାମାନେ (55 କିଲୋଗ୍ରାମ)";
  String get valueForMen => "1506";
  String get valueForWomen => "1184";
  String get referenceMenWomenDescription =>
      "ସନ୍ଦର୍ଭ ପୁରୁଷ ଏବଂ ମହିଳାମାନେ ସ୍ୱାସ୍ଥ୍ୟ ସମ୍ପୂର୍ଣ୍ଣ ପ୍ରାପ୍ତବୟସ୍କମାନେ ଯେଉଁମାନେ 19-39 ବର୍ଷ ଆୟୁ ଥାଏ, ସାଧାରଣ BMI ରଖନ୍ତି ଏବଂ ମଧ୍ୟମ ଭାବରେ ସକ୍ରିୟ ଅନୁଭବନ୍ତି (ICMR-NIN). ଦେଖନ୍ତୁ";
  String get personalizedDietDiaryDescription =>
      "ବ୍ୟକ୍ତିଗତ ଖାଦ୍ୟ ଡାଇରୀ ଆପଣଙ୍କର ବର୍ତ୍ତମାନରୁ ପିଛଲା ମାସ ପର୍ଯ୍ୟନ୍ତ ପୋଷକତାତ୍ତ୍ୱିକ ଆହାରକୁ ଟ୍ରାକ୍ କରେ";

  String get Hindi => "ହିନ୍ଦୀ";
  String get firstname => "ପ୍ରଥମ ନାମ";
  String get lastname => "ଶେଷ ନାମ";
  String get labelSodium => "ସୋଡିଅମ";
  String get labelVitaminC => "ଭିଟାମିନ ସି";
  String get FinanameEnergy => "ଉର୍ଜ୍ୟ";
  String get FinanameCarbohydrate => "କାର୍ବୋହାଇଡ୍ରେଟ";
  String get FinanameFat => "ଚରବି";
  String get FinanameSodium => "ସୋଡିଅମ";
  String get FinanameDietaryFibre => "ଆହାରିକ ଫାଇବର୍";
  String get FinanameCalcium => "କ୍ୟାଲସିଅମ୍";
  String get FinanameIron => "ଲୋହ";
  String get FinanameMagnesium => "ମ୍ୟାଗ୍ନେସିଯ଼ମ୍";
  String get FinanameZinc => "ଜିଙ୍କ";
  String get FinanameProtein => "ପ୍ରୋଟିନ୍";
  String get FinanameThiamine => "ଥାଇଆମିନ୍";
  String get FinanameRiboflavin => "ରାଇବୋଫ୍ଲାଭିନ୍";
  String get FinanameNiacin => "ନାୟାସିନ୍";
  String get FinanameVitaminB => "ଭିଟାମିନ୍ B";
  String get FinanameFolate => "ଫୋଲେଟ୍";
  String get FinanameVitaminC => "ଭିଟାମିନ୍ C";
  String get FinanameVitaminA => "ଭିଟାମିନ୍ A";
  String get FinanameVitaminb6 => "ଭିଟାମିନ୍ B6";
  String get confirmDeleteAllNotifications => "ସମସ୍ତ ସୂଚନା ମିଟାଇବା ନିଶ୍ଚିତ?";
  String get fillAllFields => "ସମସ୍ତ କ୍ଷେତ୍ର ସଂପୂର୍ଣ କରନ୍ତୁ";
  String get successfullyAddedIngredient => "ଉପକରଣ ଯଥାକାଳରେ ଯୋଗ କରାଯାଇଛି";
  String get confirmDeletion => "ଡିଲିଟ୍‌ କରିବା ନିଶ୍ଚିତ";
  String get confirmDeleteIngredient =>
      "ଆପଣ ନିଶ୍ଚିତ୍ ଭାବେ ଏହି ଉପକରଣ ମିଟାଇବା ଚାହୁଁଛନ୍ତି?";
  String get fileDownloaded => "ଫାଇଲ ସଫଳତାରେ ଡାଉନଲୋଡ ହୋଇଛି ଏବଂ ଫାଇଲର ସ୍ଥାନ";
  String get confirmDeleteFood => "ଆପଣ ଖୁଣ୍ଟି ଖାଦ୍ୟ ମିଟାଇବା ନିଶ୍ଚିତ?";
  String get estimatedAverageRequirement =>
      'ଅନୁମାନିତ ସରାଧିକ ଆବଶ୍ୟକତା (EAR): 50% ସ୍ୱସ୍ଥ ବ୍ୟକ୍ତିଙ୍କ ଦିନବଳେ ଯାହା  ଆବଶ୍ୟକତା ପୂର୍ଣ୍ଣ ହେବ';
  String get editQuantity => "ପ୍ରମାଣ ସମ୍ପାଦିତ କରନ୍ତୁ";
  String get confirmDelete => "ଆପଣ ଖୁଣ୍ଟି କରିବା ନିଶ୍ଚିତ?";
  String get exerciseDeleted => "ବ୍ୟାଯାମ ଯଥାକାଳରେ ମିଟାଇ ଗଲା";
  String get confirmDeleteExercise =>
      "ଆପଣ ନିଶ୍ଚିତ ଭାବେ ଏହି ବ୍ୟାଯାମ ମିଟାଇବା ଚାହୁଁଛନ୍ତି?";
}
