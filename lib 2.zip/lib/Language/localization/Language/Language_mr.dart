import 'package:nin2byo2i/Language/localization/Language/languages.dart';

class LanguageMr extends Languages {
  @override
  String get appName => "NIN2.0";
  String get recordMyDiet => "माझा आहार नोंदवा";

  @override
  String get labelWelcome => "स्वागत आहे";
  String get activities => "क्रियाकलाप";
  String get searchActivityHere => "इथे क्रियाकलाप शोधा";
  String get orSelectActivityFromBelow => "किंवा खालील क्रियाकलाप निवडा";
  String get tryLaterMr => "नंतर प्रयत्न करा"; // Marathi
  String get moisture => "आर्द्रता";
  String get indianFoodCompositionTitle => "भारतीय अन्न संरचना तक्ते (२०१७)";

  String get indianFoodCompositionDescription =>
      "भारतीय अन्न संरचना तक्ते (२०१७): भारतीय अन्नासाठी व्यापक पोषण संबंधी माहिती.";

  @override
  String get labelSelectLanguage => "भाषा निवडा";
  String get inputActivityDataPrompt =>
      "आपला ऊर्जा खर्च आणि समतोल पाहण्यासाठी, कृपया २४ तासांच्या क्रियाकलापांचा डेटा प्रविष्ट करा.";
  String get myEnergyBalanceYesterday => "माझा ऊर्जा समतोल (काल)";
  String get caloriesBurnFromWatch => "घड्याळामधून जाळलेल्या कॅलरीज";
  String get tryLater => "नंतर प्रयत्न करा";
  @override
  String get labelInfo => "हा बहु-भाषा डेमो अनुप्रयोग आहे";
  String get totalEnergyConsumption => "एकूण ऊर्जा वापर";
  String get totalEnergyExpenditure => "एकूण ऊर्जा खर्च";
  String get energybalance => "ऊर्जा संतुलन";
  String get indicatorhealth =>
      "('+' ऊर्जा अधिशेष निश्चित करते; '-' ऊर्जा घातक निश्चित करते)";

  @override
  // TODO: implement labelChangeLanguage
  String get labelChangeLanguage => "भाषा बदला";
  @override
  String get labelWelcomeBack => "परत स्वागत आहे,";

  @override
  String get labelUnderweight => "तुमचे वजन कमी आहे";

  @override
  String get labelNormalWeight => "तुमचे वजन सामान्य आहे";

  @override
  String get labelOverweight => "तुमचे वजन जास्त आहे";

  @override
  String get labelObese => "तुम्ही लठ्ठ आहात";

  @override
  String get labelViewMore => "अधिक प i हा";

  @override
  String get labelTodaySteps => "आजची पायरी";

  @override
  String get labelCheck => "तपासा";

  @override
  String get labelHealthData =>
      "माझा रक्तदाब / रक्त ग्लुकोज / SPO2 रेकॉर्ड करा";

  @override
  String get labelActivityStatus => "क्रियाकलाप स्थिती";

  @override
  String get labelHeartRate => "हृदयाची गती";

  @override
  String get labelHeartRateValue => "78 बीपीएम";

  @override
  String get labelMinutesAgo => "मिनिटांपूर्वी";

  @override
  String get labelWaterIntake => "माझे पाणी सेवन";

  @override
  String get labelLiters => "लिटर";

  @override
  String get labelZeroLiters => "0 लिटर";

  @override
  String get labelRealTimeGoal => "वास्तविक वेळ, ध्येय";

  @override
  String get labelCalories => "कॅलरीज जळतात";

  @override
  String get labelCaloriesEarned => "कॅलरीज मिळवल्या";

  @override
  String get labelFoodPlan => "अन्न योजना";

  @override
  String get labelWorkoutProgress => "कसरत प्रगती";

  @override
  String get labelWeekly => "साप्ताहिक";

  @override
  String get labelMonthly => "मासिक";

  @override
  String get labelLatestWorkout => "नवीनतम कसरत";

  @override
  String get labelSeeMore => "अजून पहा";
  String get labelBreakfast => "नाश्ता";
  String get labelLunch => "दुपारचे जेवण";
  String get labelDinner => "रात्रीचे जेवण";
  String get labelSnacks => "खाद्यपदार्थ";
  String get labelTaken => "घेतले";
  String get labelTarget => "लक्ष्य";

  //profile

  String get labelProfile => "प्रोफाइल";
  String get labelEdit => "सुधारणे";
  String get labelUser => "वापरकर्ता";
  String get labelProgram => "एक चरबी कार्यक्रम गमावू";
  String get labelHeight => "उंची";
  String get labelWeight => "वजन";
  String get labelAge => "वय";
  String get labelAccount => "खाते";
  String get labelPersonalData => "वैयक्तिक माहिती";
  String get labelAchievement => "साध्य";
  String get labelActivityHistory => "क्रियाकलाप इतिहास";
//String get labelWorkoutProgress => "कसरत प्रगती";
  String get labelNotification => "सूचना";
  String get labelPopupNotification => "पॉप-अप सूचना";
  String get labelMensurationCycle => "सायकल मोजमाप";
  String get labelOther => "इतर";
  String get labelContactUs => "आमच्याशी संपर्क साधा";
  String get labelPrivacyPolicy => "गोपनीयता धोरण";
  String get labelSetting => "सेटिंग";
  String get labelFeedback => "अभिप्राय";
  String get labelConfirmLogout => "लॉगआउटची पुष्टी करा";
  String get labelConfirmLogoutMessage =>
      "तुमची खात्री आहे की तुम्ही लॉग आउट करू इच्छिता?";
  String get labelLogout => "बाहेर पडणे";
  //select tab
  String get labelOptions => "पर्याय";
  String get labelFoodTable => "अन्न जोडा";
  String get labelTop10Food => "शीर्ष 10 अन्न";
  String get labelActivityTrack => "क्रियाकलाप ट्रॅकर";
  String get labelsteptracker => "स्टेप ट्रॅकर";

  String get labelTodayTarget => "पाणी लक्ष्य";
  String get labelJoggingTrack => "जॉगिंग ट्रॅक";
  String get labelMensurationTrack => "मासिक पाळी";
//String get labelFoodTable => "अन्न टेबल";
  String get labelPassword => "पासवर्ड बदला";
  String get labelDarkMode => "गडद मोड वापरून पहा";
  String get labelconectWatch => "घड्याळ कनेक्ट करा";
  @override
  String get labelSleep => "झोप";
  @override
  String get labelBookStore => "पुस्तकांचे दुकान";
  @override
  String get labelSearchBooks => "पुस्तके शोधा";
  @override
  String get labelPrice => "किंमत";
  @override
  String get labelAddToCart => "कार्टमध्ये जोडा";
  @override
  String get labelAuthor => "लेखक";
  @override
  String get labelYear => "वर्ष";
  @override
  String get labelQuantityAvailable => "प्रमाण उपलब्ध";
  @override
  String get labelCart => "कार्टमध्ये जोडा";
  @override
  String get labelMyOrders => "माझे आदेश";
  @override
  String get labelAllOrders => "सर्व ऑर्डर";
  @override
  String get labelOrderDetail => "ऑर्डर तपशील";
  @override
  String get labelOrderId => "ऑर्डर आयडी";
  @override
  String get labelOrdersInMyOrders => "माझ्या आदेशात ऑर्डर";
  @override
  String get labelItemsInMyOrders => "माझ्या ऑर्डरमधील आयटम";
  @override
  String get labelTotal => "एकूण";
  @override
  String get labelTotalPrice => "एकूण किंमत";
  @override
  String get labelCheckout => "तपासा";

  // Meal List
  @override
  String get labelMealList => "माझा आहार";
  @override
  String get labelAnalyze => "विश्लेषण करा";
  @override
  String get labelAddDish => "डिश घाला";
  @override
  String get labelTop10Foods => "शीर्ष 10 पदार्थ";
  @override
  String get labelRecentMeal => "अलीकडचे जेवण";
  @override
  String get labelAnalyzeIngredientsTaken => "अन्न सेवनाचे विश्लेषण करा";

  // Nutrition Summary
  @override
  String get labelCarbs => "कार्बोहायड्रेट";
  // @override
  // String get labelCalories => "कॅलरीज";
  @override
  String get labelFibers => "एकूण फायबर";
  @override
  String get labelFats => "चरबी";
  @override
  String get labelProteins => "प्रथिने";
  @override
  String get labelCalcium => "कॅल्शियम";

  @override
  String get labelNiacinB3 => "नियासिन (B3)";

  @override
  String get labelThiamineB1 => "थायमिन (B1)";

  @override
  String get labelIron => "लोखंड";

  @override
  String get labelZinc => "जस्त";

  @override
  String get labelFolatesB9 => "फोलेट (B9)";

  @override
  String get labelRiboflavinB2 => "रिबोफ्लेविन (B2)";

  @override
  String get labelRetinolVitA => "रेटिनॉल (व्हिटॅमिन ए)";

  @override
  String get labelMagnesium => "मॅग्नेशियम";

  @override
  String get labelTodaysNutritionSummary => "आजचा पोषण सारांश";
  @override
  String get labelChangeGoal => "ध्येय बदला";
  @override
  String get labelIngredientsTaken => "साहित्य घेतले";
  @override
  String get labelIngredientsLeft => "साहित्य बाकी";

  // Food Table
  // @override
  // String get labelFoodTable => "अन्न टेबल";
  // @override
  // String get labelBreakfast => "नाश्ता";
  // @override
  // String get labelLunch => "दुपारचे जेवण";
  // @override
  // String get labelDinner => "रात्रीचे जेवण";
  // @override
  // String get labelSnacks => "खाद्यपदार्थ";
  @override
  String get labelTop10FoodsSleep => "शीर्ष 10 पदार्थ";
  @override
  String get labelFavouriteDishes => "आवडते पदार्थ";

  // User Profile
  @override
  String get labelHelp => "मदत करा";
  // @override
  // String get labelLogout => "बाहेर पडणे";
  // @override
  // String get labelWeight => "वजन";
  @override
  String get labelEmail => "ईमेल";
  // @override
  // String get labelHeight => "उंची";
  @override
  String get labelLinkedInProfileLink => "लिंक्डइन प्रोफाइल लिंक";
  @override
  String get labelGoogleProfileLink => "Google प्रोफाइल लिंक";
  @override
  String get labelFacebookProfileLink => "फेसबुक प्रोफाइल लिंक";
  @override
  String get labelTwitterProfileLink => "ट्विटर प्रोफाइल लिंक";
  @override
  String get labelName => "नाव";
  @override
  String get labelPhoneNumber => "दूरध्वनी क्रमांक.";
  @override
  String get labelDateOfBirth => "D.O.B";
  @override
  String get labelBMI => "BMI";
  // @override
  // String get labelAge => "वय";

  // Contact Us
  @override
  String get labelMessage => "संदेश";
  @override
  String get labelSubmit => "प्रस्तुत करणे";
  @override
  String get labelCompanyContacts => "कंपनी संपर्क";
  @override
  String get labelAddress => "पत्ता";
  @override
  String get labelDirectorsEmail => "दिग्दर्शकाचा ईमेल";
  @override
  String get labelFax => "फॅक्स";

  // Settings
  @override
  String get labelResetPassword => "पासवर्ड रीसेट करा";
  // @override
  // String get labelFeedback => "अभिप्राय";
  @override
  String get labelPleaseProvideFeedback => "कृपया तुमचा अभिप्राय द्या";
  @override
  String get labelEnterYourFeedbackHere => "तुमचा अभिप्राय येथे प्रविष्ट करा";
  @override
  String get labelSubmitFeedback => "अभिप्राय सबमिट करा";

  // Credits
  // @override
  // String get labelContactUs => "आमच्याशी संपर्क साधा";
  @override
  String get labelDevelopmentTeam => "विकास संघ";
  @override
  String get labelAcknowledgments => "पावती";
  @override
  String get labelPartnerships => "भागीदारी";

  // Mobile
  @override
  String get labelSearchComponents => "घटक शोधा";
  @override
  String get labelSearchComponentsHere => "येथे घटक शोधा";
  @override
  String get lablelDishName => 'डिश नाव';
  @override
  String get labelCredits => 'श्रेय';
  @override
  String get labelShareAppButton => "शेअर करा";
  @override
  String get labelShareApp =>
      "बारकोड स्कॅनर ॲपसह QR कोड स्कॅन करा आणि ॲप डाउनलोड करा";
  // New translations
  @override
  String get labelConnectedWatch => "कनेक्ट केलेले घड्याळ आहे";
  @override
  String get labelDisconnect => "डिस्कनेक्ट करा";
  @override
  String get labelFitbit => "फिटबिट";
  @override
  String get labelGoogleFit => "Google फिट";
  @override
  String get labelAppleWatch => "ऍपल घड्याळ";
  @override
  String get labelSamsungSmartWatch => "सॅमसंग स्मार्ट घड्याळ";
  @override
  String get labelBookDetails => "पुस्तक तपशील";
  @override
  String get labelDeliveryDate => "वितरण तारीख";
  @override
  String get labelOrderDate => "मागणीची तारीख";
  @override
  String get labelAnalyseIngredientsTaken => "अन्न सेवनाचे विश्लेषण करा";
  @override
  String get labelAddDishIngredients => "डिश साहित्य जोडा";
  @override
  String get labelIngredientName => "घटकाचे नाव";
  @override
  String get labelEnterIngredientName => "घटकाचे नाव एंटर करा";
  @override
  String get labelIngredientQuantity => "घटक प्रमाण";
  @override
  String get labelEnterIngredientQuantity => "घटक प्रमाण प्रविष्ट करा";
  @override
  String get labelAdd => "ॲड";
  @override
  String get labelSave => "जतन करा";
  @override
  String get labelwatch => "घड्याळ";

  //
  @override
  String get labelBloodOxygenHeart =>
      'महत्त्वपूर्ण चिन्हे मोजा आणि एकूण आरोग्याचा मागोवा घ्या.';
  @override
  String get labelTop10FoodS =>
      'निरोगी जीवनशैली राखण्यासाठी शिफारस केलेले पदार्थ शोधा.';
  @override
  String get labelWaterTrack =>
      'दैनंदिन फिटनेस हायड्रेशन लक्ष्ये सेट करा आणि साध्य करा.';
  @override
  String get labelPersonalDetails =>
      'वैयक्तिक माहिती सुरक्षितपणे व्यवस्थापित करा आणि अपडेट करा.';
  @override
  String get labelFeedbackS => 'तुमचे विचार आणि सूचना आमच्यासोबत शेअर करा.';
  @override
  String get labelContactUsS =>
      'ग्राहक समर्थनापर्यंत पोहोचा आणि आमच्याशी संपर्क साधा.';
  @override
  String get labelBMICalculator =>
      'आरोग्यविषयक अंतर्दृष्टीसाठी तुमच्या बॉडी मास इंडेक्सची गणना करा.';
  @override
  String get labelBMRCalculator =>
      'फिटनेस नियोजनासाठी तुमचा बेसल मेटाबॉलिक रेट मोजा.';
  @override
  String get labelRunningJoggingSteps =>
      'निरोगी जीवनशैलीसाठी तुमच्या धावण्याच्या आणि जॉगिंगच्या पायऱ्यांचा मागोवा घ्या.';
  @override
  String get labelHealthyDietChart =>
      'निरोगी आहाराच्या विहंगावलोकनासाठी सर्वसमावेशक चार्टमध्ये प्रवेश करा.';
  @override
  String get labelHealthyRecommendation =>
      'वैयक्तिकृत आरोग्य शिफारसी प्राप्त करा.';
  @override
  String get labelSleepTracker =>
      'तुमच्या झोपेच्या पद्धतींचा मागोवा घ्या आणि झोपेची गुणवत्ता सुधारा.';
  @override
  String get labelSetReminder =>
      'आरोग्य आणि फिटनेस क्रियाकलापांसाठी स्मरणपत्रे सेट करा.';
  // @override
  // String get labelMenstruationCycle =>
  //     'चांगल्या अंतर्दृष्टीसाठी तुमच्या मासिक पाळीचा मागोवा घ्या आणि व्यवस्थापित करा.';
  @override
  String get labelCSVDownload =>
      'सोप्या विश्लेषणासाठी तुमचा डेटा CSV फॉरमॅटमध्ये डाउनलोड करा.';

  // New Headings
  @override
  String get headingBloodOxygenHeart => 'रक्त | ऑक्सिजन';
  @override
  String get headingTop10Food => 'शीर्ष 10 अन्न';
  @override
  String get headingWaterTrack => 'पाणी ट्रॅकर';
  @override
  String get headingPersonalDetails => 'वैयक्तिक माहिती';
  @override
  String get headingFeedback => 'अभिप्राय';
  @override
  String get headingContactUs => 'आमच्याशी संपर्क साधा';
  @override
  String get headingBMICalculator => 'BMI कॅल्क्युलेटर';
  @override
  String get headingBMRCalculator => 'BMR कॅल्क्युलेटर';
  @override
  String get headingRunningJoggingSteps => 'धावणे / धावणे / पायऱ्या';
  @override
  String get headingHealthyDietChart => 'निरोगी आहार चार्ट';
  @override
  String get headingHealthyRecommendation => 'आरोग्यदायी शिफारस';
  @override
  String get headingSleepTracker => 'स्लीप ट्रॅकर';
  @override
  String get headingSetReminder => 'स्मरणपत्र सेट करा';
  // @override
  // String get headingMenstruationCycle => 'मासिक पाळी चक्र';
  @override
  String get headingCSVDownload => 'CSV डाउनलोड';

  // Water-related phrases
  @override
  String get labelWaterTarget => "पाणी लक्ष्य";
  // @override
  // String get labelTodayTarget => "आज टार्गेट";
  @override
  String get labelWaterGoal => "पाण्याचे ध्येय";
  // @override
  // String get labelWaterIntake => "पाण्याचे सेवन";
  @override
  String get labelWaterProgress => "पाण्याची प्रगती";
  // @override
  // String get labelWeekly => "साप्ताहिक";
  @override
  String get labelDateWise => "तारखेनुसार";
  @override
  String get labelSun => "रवि";
  @override
  String get labelMon => "सोम";
  @override
  String get labelTue => "मंगळ";
  @override
  String get labelWed => "बुध";
  @override
  String get labelThu => "गुरु";
  @override
  String get labelFri => "शुक्र";

  // BMI Calculator
  // @override
  // String get labelBMI => "BMI";
  @override
  String get labelEnterHeight => "उंची प्रविष्ट करा (सेमी)";
  @override
  String get labelEnterWeight => "वजन प्रविष्ट करा (किलो)";
  @override
  String get labelCalculateBMI => "बीएमआयची गणना करा";

  // BMR Calculator
  @override
  String get labelMale => "पुरुष";
  @override
  String get labelFemale => "स्त्री";
  @override
  String get labelEnterAge => "वय प्रविष्ट करा";
  @override
  String get labelCalculateBMR => "बीएमआरची गणना करा";
  @override
  String get labelBMR => "BMR";
  @override
  String get labelCaloriesPerDay => "कॅलरी / दिवस";

  // Step Tracker
  @override
  String get labelStepsTracker => "स्टेप ट्रॅकर";
  @override
  String get labelRunningTracker => "ट्रॅकर चालू आहे";
  @override
  String get labelAddStep => "पायरी जोडा";
  @override
  String get labelSelectDate => "तारीख निवडा";
  @override
  String get labelJoggingTracker => "जॉगिंग ट्रॅकर";
  @override
  String get labelCaloriesBurn => "कॅलरीज जळतात";

  // Sleep Tracker
  @override
  String get labelSleepTarget => "झोपेचे लक्ष्य";
  @override
  String get labelTodaySleep => "आज झोप";
  @override
  String get labelSleepProgress => "झोपेची प्रगती";
  @override
  String get labelTotalSleep => "एकूण झोप";
  @override
  String get labelSleepGoal => "झोपेचे ध्येय";
  @override
  String get labelSetNotification => "सूचना सेट करा";
  @override
  String get labelStartTime => "सुरवातीची वेळ";
  @override
  String get labelEndTime => "समाप्तीचा कालावधी";
  @override
  String get labelSelect => "निवडा";
  @override
  String get labelSat => "शनि";
  // @override
  // String get labelSave => "जतन करा";
  @override
  String get labelStart => "सुरू करा";
  @override
  String get labelEnd => "शेवट";
  @override
  String get labelType => "प्रकार";
  @override
  String get labelIsConnected => "जोडलेले आहे";

  // @override
  // String get labelMensurationCycle => "सायकल मोजमाप";

  @override
  String get labelTrackAndManage =>
      "चांगल्या अंतर्दृष्टीसाठी तुमच्या मासिकपाळी चक्राचा मागोवा घ्या आणि व्यवस्थापित करा";

  @override
  String get labelMensurationStatus => "मापन स्थिती";

  @override
  String get labelDaysLength => "दिवसांची लांबी";

  @override
  String get labelDay => "दिवस";

  @override
  String get labelNextDate => "पुढची तारीख";

  @override
  String get labelLastPeriodStartDate => "शेवटचा कालावधी सुरू होण्याची तारीख";

  @override
  String get labelAverageCycleLength => "सायकलची सरासरी लांबी";

  @override
  String get labelChange => "बदला";

  // Common Messages
  @override
  String get messageSent => "संदेश पाठवला";

  @override
  String get thankYouForContactingUs =>
      "आम्हाला संपर्क केल्याबद्दल आभारी आहोत!";

  @override
  String get alert => "अलर्ट";

  @override
  String get fillInAllFields => "कृपया सर्व फील्ड भरा.";

  @override
  String get thankYouFeedbackSubmitted => "तुमचा अभिप्राय सबमिट केला गेला आहे.";

  @override
  String get resetPassword => "पासवर्ड रीसेट करा";

  @override
  String get dishAdded => "डिश जोडले!";

  @override
  String get dishAndIngredientsAddedSuccessfully =>
      "डिश आणि साहित्य यशस्वीरित्या जोडले.";

  @override
  String get failed => "अयशस्वी";

  @override
  String get error => "त्रुटी";

  @override
  String get enterBloodGlucoseLevel =>
      "mg/dL मध्ये रक्तातील ग्लुकोजची पातळी प्रविष्ट करा";

  @override
  String get enterBloodPressureLevel => "mmHg मध्ये रक्तदाब पातळी प्रविष्ट करा";

  @override
  String get enterHeartLevel =>
      "कृपया हृदय गती प्रति मिनिट (BPM) मध्ये प्रविष्ट करा.";

  @override
  String get cancel => "रद्द करा";

  @override
  String get submit => "प्रस्तुत करणे";

  @override
  String get valueCannotBeGreaterThan100 =>
      "मूल्य 100 पेक्षा जास्त असू शकत नाही.";

  @override
  String get bloodStatusSubmittedSuccessfully =>
      "रक्ताची स्थिती यशस्वीरित्या सबमिट केली.";

  @override
  String get failedToSubmitBlood => "रक्त सबमिट करण्यात अयशस्वी.";

  @override
  String get enterHeartLevel1to100 =>
      "कृपया हृदय गती प्रति मिनिट (BPM) मध्ये प्रविष्ट करा.";

  @override
  String get heartLevelSubmittedSuccessfully =>
      "हृदय पातळी यशस्वीरित्या सबमिट केली.";

  @override
  String get enterOxygenSaturationLevel1to100 =>
      "ऑक्सिजन संपृक्तता पातळी 1% -100% प्रविष्ट करा";

  @override
  String get oxygenLevelSubmittedSuccessfully =>
      "ऑक्सिजन पातळी यशस्वीरित्या सबमिट केली.";

  @override
  String get updateData => "डेटा अपडेट करा";

  @override
  String get selectLastPeriodStartDate =>
      "शेवटचा कालावधी सुरू होण्याची तारीख निवडा";

  @override
  String get update => "अपडेट करा";

  @override
  String get failedToFetchBooks =>
      "पुस्तके आणण्यात अयशस्वी. कृपया पुन्हा प्रयत्न करा.";

  @override
  String get errorOccurred => "एक त्रुटी आली:";

  @override
  String get invalidEndTime => "अवैध समाप्ती वेळ";

  @override
  String get chooseTimeWithin1Hour =>
      "कृपया प्रारंभ वेळेच्या 1 तासाच्या आत वेळ निवडा.";

  @override
  String get notificationSaved => "सूचना जतन केली";

  @override
  String get notificationSetSuccessfully => "सूचना यशस्वीरित्या सेट केली.";

  @override
  String get thereIsSomeError => "काही त्रुटी आहे.";

  @override
  String get watchDisconnected => "घड्याळ डिस्कनेक्ट झाले";

  @override
  String get watchDisconnectedSuccessfully =>
      "घड्याळ यशस्वीरित्या डिस्कनेक्ट केले गेले आहे.";

  @override
  String get addCup => "कप घाला";

  @override
  String get numberOfCups => "कपांची संख्या";

  @override
  String get addCupCapacityInMl => "मिली मध्ये कप क्षमता घाला";

  @override
  String get cupCapacitySubmittedSuccessfully =>
      "कप क्षमता यशस्वीरित्या सबमिट केली.";

  @override
  String get pleaseEnterValidValuesForAllFields =>
      "कृपया सर्व फील्डसाठी वैध मूल्ये प्रविष्ट करा.";

  @override
  String get enterWater => "पाणी प्रविष्ट करा";

  @override
  String get waterGoalLiters => "पाण्याचे ध्येय (लिटर)";

  @override
  String get waterSubmittedSuccessfully =>
      "पाण्याचे उद्दिष्ट यशस्वीरित्या सबमिट केले.";

  @override
  String get addActivityData => "क्रियाकलाप डेटा जोडा";

  @override
  String get enterValue => "मूल्य प्रविष्ट करा";

  @override
  String get addStepsData => "चरण डेटा जोडा";

  @override
  String get numberOfSteps => "पायऱ्यांची संख्या";

  @override
  String get stepsDataSubmittedSuccessfully =>
      "चरण डेटा यशस्वीरित्या सबमिट केला.";

  @override
  String get enterSleepTarget => "झोपेचे लक्ष्य प्रविष्ट करा";

  @override
  String get sleepTargetInHours => "तासांमध्ये झोपेचे लक्ष्य";

  @override
  String get addYourSleepDuration => "तुमचा झोपेचा कालावधी जोडा";

  @override
  String get enterDurationInMinutes => "मिनिटांमध्ये कालावधी प्रविष्ट करा:";

  @override
  String get add => "ॲड";

  @override
  String get ok => "ठीक आहे";

  @override
  String get csvFileSavedTo => "CSV फाइल यामध्ये सेव्ह केली";

  @override
  String get ageMustBeBetween2And100Years => "वय 2 ते 100 वर्षे दरम्यान असावे";

  @override
  String get next => "पुढे";

  @override
  String get register => "नोंदणी करा";

  @override
  String get oopsSomethingWentWrong => "अरेरे! काहीतरी चूक झाली";

  @override
  String get errorFetchingMeals => "जेवण आणताना त्रुटी आली:";

  @override
  String get reviewAddedSuccessfully => "पुनरावलोकन यशस्वीरित्या जोडले!";

  @override
  String get failedToAddReview => "पुनरावलोकन जोडण्यात अयशस्वी:";

  @override
  String get alreadyInCart => "आधीच कार्टमध्ये";

  @override
  String get addedToCart => "कार्टमध्ये जोडले";

  @override
  String get quantityNotBetween1And2 =>
      "प्रमाण 2 पेक्षा जास्त आणि 1 पेक्षा कमी नाही";

  String get createcustomdish => "सानुकूल डिश तयार करा";
  String get quantityingram => "प्रमाण (ग्रॅम)";
  String get labelCaloriestaken => 'ऊर्जा';
  String get mainlabelEarlyMorning => "पहाटे";
  String get mainlabelMidMorning => "मध्य सकाळ";
  String get mainlabelEvening => "संध्याकाळ";
  String get mainlabelBedtime => "निजायची वेळ";
  String get mainlabelTimeSpentOn => "वेगवेगळ्या कामांमध्ये वेळ घालवला";
  String get mainlabelHealthCalculator => "आरोग्य कॅल्क्युलेटर";
  String get mainlabelStepProgress => "पाऊल प्रगती";
  String get mainlabelRealTimeIntakes => "वास्तविक वेळ सेवन";
  String get mainlabelCaloriesBurnProgress => "कॅलरीज बर्न प्रगती";
  String get mainlabelCaloriesBurnBreakdown => "कॅलरीज बर्न ब्रेकडाउन वर";
  String get mainlabelHeartReportsTrends => "हार्ट ट्रेंडचा अहवाल देतो";
  String get mainlabelOxygenStatus => "ऑक्सिजन स्थिती";
  String get mainlabelNoRecord => "मला आठवत नाही";
  String get mainlabelSystolicBloodPressure => "सिस्टोलिक रक्तदाब";
  String get mainlabelMeasuredon => "वर मोजले";
  String get mainlabelEnterBloodPressure => "रक्तदाब प्रविष्ट करा";
  String get mainlabelBloodPressure => "रक्तदाब";
  String get mainlabelDiastolicBloodPressure => "डायस्टोलिक रक्तदाब";
  String get mainlabelBloodGlucose => "रक्तातील ग्लुकोज";
  String get mainlabelHeartStatus => "हृदयाची स्थिती";
  String get mainlabelAllExercise => "सर्व व्यायाम";
  String get mainlabelCleaningOrMopping => "साफ करणे किंवा पुसणे";
  String get mainlabelGardening => "बागकाम";
  String get mainlabelWatchingTV => "टीव्ही पाहतोय";
  String get mainlabelCycling => "सायकलिंग";
  String get mainlabelRunning => "धावत आहे";
  String get mainlabelWalking => "चालणे";
  String get mainlabelShuttle => "शटल";
  String get mainlabelTableTennis => "टेबल टेनिस";
  String get mainlabelTennis => "टेनिस";
  String get mainlabelVolleyBall => "व्हॉली बॉल";
  String get mainlabelDancing => "नाचत";
  String get mainlabelFishing => "मासेमारी";
  String get mainlabelShopping => "खरेदी";
  String get mainlabelTyping => "टायपिंग";
  String get mainlabelSleeping => "झोपलेला";
  String get mainlabelStanding => "उभे";
  String get mainlabelSitting => "बसलेले";
  String get mainlabelClickToStartActivity =>
      "क्रियाकलाप सुरू करण्यासाठी क्लिक करा";
  String get mainlabelBMICalculator => "BMI कॅल्क्युलेटर";
  String get mainlabelBMRCalculator => "BMR कॅल्क्युलेटर";
  String get mainlabelDownloadActivityReportInCsv =>
      "csv मध्ये क्रियाकलाप अहवाल डाउनलोड करा";
  String get mainlabelSelectStartDate => "प्रारंभ तारीख निवडा";
  String get mainlabelSelectEndDate => "समाप्ती तारीख निवडा";
  String get mainlabelDownloadFile => "फाइल डाउनलोड करा";
  String get mainlabelDate => "तारीख";
  String get mainlabelValue => "मूल्य";
  String get mainlabelLink => "दुवा";
  String get mainlabelNoNotificationFound => "कोणतीही सूचना आढळली नाही";
  String get mainlabelTotalNutritionTaken => "= एकूण पोषण घेतले";
  String get mainlabelSearchFood => "पाककृती शोधा";
  String get mainlabelSelectFromPersonalFood => "वैयक्तिक पाककृतींमधून निवडा";
  String get mainlabelRecipeName => "रेसिपीचे नाव";
  String get mainlabelSelectDate => "तारीख निवडा";
  String get mainlabelNutrientOfAllIngredientsRaw =>
      "सर्व घटकांचे पोषक (कच्चे)";
  String get mainlabelNutrientsCompostionOfCookedWeight =>
      "साठी शिजवलेल्या वजनाची पोषक रचना";
  String get mainlabelWantToEditThisRecipyFollowThe =>
      "ही रेसिपी संपादित करू इच्छिता? अनुसरण करा";
  String get mainlabelAddIngredientFrom => "पासून घटक जोडा";
  String get mainlabelAddFromNutrientSpecifcFood =>
      "पोषक विशिष्ट अन्नातून जोडा";
  String get mainlabelAddFromAllFoods => "सर्व पदार्थांमधून घाला";
  String get mainlabelNumberOfServing => "सर्विंग्सची संख्या";
  String get mainlabelWeightInG => "वजन (ग्रॅम)";
  String get mainlabelEditIngredientsWeight => "घटक वजन संपादित करा";
  String get mainlabelIngredient => "घटक";
  String get mainlabelNewWeightInG => "नवीन वजन (ग्रॅम)";
  String get mainlabelCancel => "रद्द करा";
  String get mainlabelUpdate => "अद्यतन";
  String get mainlabelCookedWeightInG => "शिजवलेले वजन (ग्रॅम)";
  String get mainlabelEnterWeight => "वजन प्रविष्ट करा";
  String get mainlabelEditRecipy => "कृती संपादित करा";
  String get mainlabelAlert => "इशारा";
  String get mainlabelToSeeNutritionCompositionPleaseEnterNoOfServing =>
      "पोषण रचना पाहण्यासाठी, कृपया सर्विंगची संख्या प्रविष्ट करा";
  String get mainlabelNutrirntsIn100CookedWeight => "100 (शिजवलेले) वजनात पोषक";
  String get mainlabelSetNutritionTargetInG => "पोषण लक्ष्य ग्रॅममध्ये सेट करा";
  String get mainlabelFoodAnalyse => "अन्वेषण";
  String get mainlabelExploreTop10Foods => "शीर्ष 10 पदार्थ एक्सप्लोर करा";
  String get mainlabelSearchCookedFood => "रेसिपीमध्ये पोषक घटक शोधा";
  String get mainlabelNutritionBasedOnEAR =>
      "EAR वर आधारित पोषक तत्वांची आवश्यकता";
  String get mainlabelDietDiary => "आहार डायरी";
  String get mainlabelRecipes => "पाककृती";
  String get mainlabelSearchByFoodName => "अन्नाच्या नावाने शोधा";
  String get mainlabelAllRecipeOf100G => "सर्व कृती 100 ग्रॅम";
  String get mainlabelNutritionRequirement => "पोषण आवश्यकता";
  String get mainlabelGender => "लिंग";
  String get mainlabelParticulars => "तपशील";
  String get mainlabelBodyWeight => "शरीराचे वजन";
  String get mainlabelDietaryDiaryReports => "पोषक तत्वांचे सेवन";
  String get mainlabelTotalNutritionTakenOn => "एकूण पोषण घेतले";
  String get mainlabelAttachImage => "प्रतिमा संलग्न करा";
  String get mainlabelFixedRecipy => "फिक्स्ड रेसिपी";
  String get mainlabelFoodInDetail => "तपशीलवार अन्न";
  String get TextAppNutrientsInMyFood => "अन्नपदार्थांमध्ये पोषक घटक शोधा";
  String get TextAppMyActivity => "माझी क्रियाकलाप";
  String get TextAppToday => "आज";
  String get TextAppMyNutrientRequirements => "माझ्या पौष्टिक गरजा";
  String get TextAppTotalNutrition => "एकूण पोषण";
  String get TextAppTaken => "घेतले";
  String get TextAppRatings => "रेटिंग";
  String get TextAppSearchComponents => "घटक शोधा";
  String get TextAppTotalNutrientTaken => "आज माझे पोषक सेवन";
  String get TextAppShareApp => "ॲप शेअर करा";
  String get TextAppNoNotificationsFound => "कोणत्याही सूचना आढळल्या नाहीत";
  String get TextAppConnectWatch => "घड्याळ कनेक्ट करा";
  String get TextAppYourBMIIs => "तुमचा बीएमआय आहे";
  String get TextAppBMI => "BMI";
  String get TextAppBMICategories => "BMI श्रेणी";
  String get TextAppUnderweight => "कमी वजन";
  String get TextAppNormal => "सामान्य";
  String get TextAppOverweight => "जास्त वजन";
  String get TextAppObesity => "लठ्ठपणा";
  String get TextAppSelectDate => "तारीख निवडा";
  String get TextAppOxygen => "ऑक्सिजन";
  String get TextAppBlood => "रक्त";
  String get TextAppNoRecord => "नोंद नाही";
  String get TextAppAllExercise => "सर्व व्यायाम";
  String get TextAppCleaningOrMopping => "साफसफाई किंवा मोपिंग";
  String get TextAppGardening => "बागकाम";
  String get TextAppWatchingTV => "टीव्ही पाहत आहे";
  String get TextAppCycling => "सायकलिंग";
  String get TextAppRunning => "धावत आहे";
  String get TextAppWalking => "चालणे";
  String get TextAppShuttle => "शटल";
  String get TextAppTableTennis => "टेबल टेनिस";
  String get TextAppTennis => "टेनिस";
  String get TextAppVolleyBall => "व्हॉली बॉल";
  String get TextAppDancing => "नाचणे";
  String get TextAppFishing => "मासेमारी";
  String get TextAppShopping => "खरेदी";
  String get TextAppTyping => "टायपिंग";
  String get TextAppSleeping => "झोपलेला";
  String get TextAppStanding => "उभे";
  String get TextAppSitting => "बसलेले";
  String get TextAppClickStartToStartActivity =>
      "क्रियाकलाप सुरू करण्यासाठी प्रारंभ क्लिक करा";
  String get TextAppCaloriesBurn => "कॅलरीज जळतात";
  String get TextAppAddDurationManually => "मॅन्युअली कालावधी जोडा";
  String get TextAppStartOrMopping => "प्रारंभ करा किंवा मोपिंग करा";
  String get TextAppMale => "पुरुष";
  String get TextAppFemale => "स्त्री";
  String get TextAppWeightManager => "माझ्या शरीराच्या वजनाचा मागोवा घ्या";
  String get TextAppUpdateWeight => "वजन अद्यतनित करा";
  String get TextAppSetWeightGoal => "वजन लक्ष्य सेट करा";
  String get TextAppCurrentWeight => "सध्याचे वजन";
  String get TextAppWeightProgress => "वजन प्रगती";
  String get TextAppPrevious30Days => "मागील 30 दिवस";
  String get TextAppYourWeightGoalIsSet => "आपले ध्येय आहे";
  String get TextAppMaintain => "राखणे";
  String get TextAppInitialWeightOf => "प्रारंभिक वजन";
  String get TextAppFinalWeightOf => "नवीनतम वजन";
  String get TextAppWeight => "वजन";
  String get TextAppYouAreNotYetAchievingYourWeightGoalKeepGoing =>
      "आपण अद्याप आपले वजन लक्ष्य साध्य करत नाही. चालू ठेवा!";
  String get TextAppYouAreAchievedYourWeightGoalKeepGoing =>
      "आपण आपले वजन लक्ष्य साध्य केले आहे. चालू ठेवा!";
  String get TextAppAndYourWeightChangeIsSet => "आणि तुमचे वजन बदललेले आहे";
  String get TextApp1NutrientsInMyFood => "माझ्या अन्नातील पोषक";
  String get TextAppSearchNutrientsInRawFoods =>
      "कच्च्या अन्नामध्ये पोषक घटक शोधा";
  String get TextAppRawIngredients => "कच्चा पदार्थ";
  String get TextAppSearchRawFoodByName => "नावाने कच्चे अन्न शोधा";
  String get TextApp1MyActivity => "माझा क्रियाकलाप अहवाल";
  String get TextAppCheckOthersDates => "इतर तारखा तपासा";
  String get TextAppYour24HoursChart => "तुमचा २४ तासांचा चार्ट";
  String get TextAppActivity => "क्रियाकलाप";
  String get TextAppOthers => "इतर";
  String get TextAppExerciseDetails => "व्यायाम तपशील";
  String get TextAppActivityType => "क्रियाकलाप प्रकार";
  String get TextAppDuration => "कालावधी";
  String get TextAppMyActivityOfCustomDates =>
      "सानुकूल तारखांची माझी क्रियाकलाप";
  String get TextAppOurCustomerFeedback => "आमचे ग्राहक अभिप्राय";
  String get TextAppOverallRatings => "एकूण रेटिंग";
  String get TextAppEnterCookedWeight => "शिजवलेले वजन प्रविष्ट करा";
  String get TextAppCookedWeightGram => "शिजवलेले वजन (ग्रॅम)";
  String get TextAppNutrientIn100gCooked => "100 ग्रॅम मध्ये पोषक (शिजवलेले)";
  String get TextAppEnterServingSize => "सर्व्हिंग आकार प्रविष्ट करा";
  String get TextAppSearchByRecipeName => "रेसिपीच्या नावाने शोधा";
  String get TextAppMyPersonalRecipe => "माझी वैयक्तिक पाककृती";
  String get TextAppFixedRecipe => "निश्चित कृती";
  String get TextApp2NutrientsInMyFood => "माझ्या अन्नातील पोषक";
  String get TextAppMyDietDiary => "माझी आहार डायरी";
  String get TextApp2MyActivity => "माझा उपक्रम";
  String get TextAppDownloadFile => "फाइल डाउनलोड करा";
  String get TextAppStartMyNewDietDiary => "माझी नवीन आहार डायरी सुरू करा";
  String get TextAppGoogle => "Google";
  String get TextAppFacebook => "फेसबुक";
  String get TextAppLinkedin => "लिंक्डइन";
  String get TextAppTwitter => "ट्विटर";
  String get TextAppContactUs => "आमच्याशी संपर्क साधा";
  String get TextAppReportBug => "दोष नोंदवा";
  String get TextAppAttachImage => "प्रतिमा संलग्न करा";
  String get TextAppResetPassword => "पासवर्ड रीसेट करा";
  String get TextAppNINAppCreditsPage => "NIN ॲप क्रेडिट पृष्ठ";
  String get NINTextOopsSomethingWentWrong => "अरेरे! काहीतरी चूक झाली";
  String get NINTextPleaseEnterAllFields => "कृपया सर्व फील्ड प्रविष्ट करा";
  String get NINTextSubmittedSuccessfully1 => "यशस्वीरित्या सबमिट केले";
  String get NINTextSubmittedSuccessfully2 => "यशस्वीरित्या सबमिट केले";
  String get NINTextFitbitAuthentication => "Fitbit प्रमाणीकरण";
  String get NINTextHours => "तास";
  String get NINTextMinutes => "मिनिटे";
  String get NINTextEnterDurationFor => "साठी कालावधी प्रविष्ट करा";
  String get NINTextTimerRunning => "टायमर चालू आहे";
  String get NINTextPleaseStopTheTimerBeforeSubmitting =>
      "कृपया सबमिट करण्यापूर्वी टाइमर थांबवा";
  String get NINTextTotalDuration => "एकूण कालावधी";
  String get NINTextSec => "सेकंद";
  String get NINTextStartYourActivity => "तुमचा उपक्रम सुरू करा!";
  String get NINTextPause => "विराम द्या";
  String get NINTextReset => "रीसेट करा";
  String get NINTextError => "त्रुटी";
  String get NINTextPleaseEnterCookedWeightAndServingSize =>
      "कृपया शिजवलेले वजन आणि सर्व्हिंग आकार प्रविष्ट करा";
  String get NINTextEditIngredient => "घटक संपादित करा";
  String get NINTextAlert => "अलर्ट";
  String get NINTextEnterWeightFor => "साठी वजन प्रविष्ट करा";
  String get NINTextNewWeightGram => "नवीन वजन (ग्रॅम)";
  String get NINTextEditRecipeName => "पाककृतीचे नाव संपादित करा";
  String get NINTextNewRecipeName => "नवीन रेसिपीचे नाव";
  String get NINTextSubmitted => "सादर केले";
  String get NINTextSuccess => "यश";
  String get NINTextDietaryDiaryReportSavedTo => "आहार डायरी अहवाल जतन";
  String get NINTextErrorSavingFile => "फाइल जतन करताना त्रुटी";
  String get NINTextClose => "बंद";
  String get NINTextIWantTo => "मला करायचे आहे";
  String get NINTextGain => "मिळवणे";
  String get NINTextMaintain => "राखणे";
  String get NINTextLose => "हरले";
  String get NINTextWeightChangeKg => "वजन बदल (किलो)";
  String get NINTextAddNewWeight => "नवीन वजन जोडा";
  String get NINTextEnterWeight => "वजन प्रविष्ट करा";
  String get NINTextOf100Gram => "100 ग्रॅम";
  String get NINTextProximateComposition => "जवळपासची रचना";
  String get NINTextVitamins => "जीवनसत्त्वे";
  String get NINTextMinerals => "खनिजे";
  String get NINTextTotalSaturatedFattyAcids => "एकूण संतृप्त फॅटी ऍसिडस्";
  String get NINTextAllRecipeOf100Grams => "सर्व कृती 100 ग्रॅम";
  String get NINTextOurCustomerFeedback => "आमचे ग्राहक अभिप्राय";
  String get NINTextOverallRatings => "एकूण रेटिंग";
  String get NINTextRateUs => "आम्हाला रेट करा";
  String get NINTextBookDetails => "पुस्तक तपशील";
  String get NINTextOne => "एक";
  String get NINTextWeightOf => "wt च्या";
  String get NINTextSelectStartDate => "प्रारंभ तारीख निवडा";
  String get NINTextSelectEndDate => "समाप्ती तारीख निवडा";
  String get NINTextNoData => "माहिती उपलब्ध नाही";
  String get NINTextWorkLevel => "कामाची पातळी";
  String get NINTextOldPassword => "जुना पासवर्ड";
  String get NINTextNewPassword => "नवीन पासवर्ड";
  String get NINTextUpdateProfile => "प्रोफाइल अपडेट करा";
  String get NINTextChangeImage => "प्रतिमा बदला";
  String get NINTextNoFavouriteFoodFound => "आवडते पदार्थ मिळाले नाहीत";
  String get NINTextCookedQuantity => "शिजवलेले प्रमाण";
  String get NINTextServingQuantity => "सर्व्हिंग प्रमाण";
  String get NINTextNutrientInformation => "पोषक माहिती";
  String get NINTextIngredient => "घटक";
  String get NINTextMealsTakenOn => "जेवण घेतले";
  String get NINTextPercentage => "टक्केवारी";
  String get NINTextEAR => "कान";
  String get NINTextValue => "मूल्य";
  String get NINTextNutrient => "पोषक";
  String get NINTextEnergyKcal => "ऊर्जा (kcal)";
  String get NINTextProteinG => "प्रथिने (ग्रॅ)";
  String get NINTextFatG => "चरबी (ग्रॅ)";
  String get NINTextCarbohydratesG => "कर्बोदके (ग्रॅ)";
  String get NINTextCalciumMg => "कॅल्शियम (मिग्रॅ)";
  String get NINTextFiberG => "फायबर (ग्रॅ)";
  String get NINTextIronMg => "लोह (मिग्रॅ)";
  String get NINTextZincMg => "झिंक (मिग्रॅ)";
  String get NINTextMagnesiumMg => "मॅग्नेशियम (मिग्रॅ)";
  String get NINTextThiamineB1Mg => "थायमिन (B1) (मिग्रॅ)";
  String get NINTextRiboflavinB2Mg => "रिबोफ्लेविन (B2) (मिग्रॅ)";
  String get NINTextNiacinB3Mg => "नियासिन (B3) (मिग्रॅ)";
  String get NINTextFolatesB9Mcg => "फोलेट्स (B9) (mcg)";
  String get NINTextRetinolVitAMcg => "विटामिन ए (एमसीजी)";
  String get VitaminCmg => "व्हिटॅमिन सी (मिग्रॅ)";
  String get Iodinemcg => "आयोडीन (mcg)";
  String get serving => "सेवा देत आहे";
  String get Mynutritionstatus => "माझी पोषण स्थिती";

  String get ninTextMyHealthStatus => 'माझी आरोग्य स्थिती';
  String get ninTextNutrientsInRawFoods => 'कच्च्या अन्नात पोषक';
  String get ninTextNutrientsInRecipes => 'पाककृती मध्ये पोषक';
  String get ninTextIcmrNinMyPlateForTheDay => 'ICMR-NIN दिवसाची माझी प्लेट';
  String get ninTextToday => 'आज';
  String get ninTextTrackMyActivity => 'माझ्या क्रियाकलापाचा मागोवा घ्या';
  String get ninTextMyHeartRate => 'माझ्या हृदयाचे ठोके';
  String get ninTextMyWaterIntake => 'माझे पाणी सेवन';
  String get ninTextSleepTracker => 'स्लीप ट्रॅकर';
  String get ninTextLit => 'लिट';
  String get ninTextRecordMyBloodPressure =>
      'माझा रक्तदाब / रक्त ग्लुकोज / SPO2 रेकॉर्ड करा';
  String get ninTextNutritionEducationContent => 'पोषण शिक्षण सामग्री';
  String get ninTextMyNutrientIntake => 'माझे पोषक सेवन';
  String get ninTextOn => 'वर';
  String get ninTextWithReferenceToEAR => 'EAR च्या संदर्भात';
  String get ninTextAchieveYourHealthGoals =>
      'तुमचे आरोग्य उद्दिष्टे साध्य करा';
  String get ninTextPercentage => 'टक्केवारी';
  String get ninTextMyPreviousDietDiaries => 'माझ्या मागील आहार डायरी';
  String get ninTextRecordReviewSleep => 'झोपेची नोंद / पुनरावलोकन करा';
  String get ninTextHours => 'तास';
  String get ninTextIngredient => 'घटक';
  String get ninTextOthersSpecify => 'इतर निर्दिष्ट करतात';
  String get ninTextAddNewIngredient => 'नवीन घटक घाला';
  String get ninTextFoodName => 'अन्नाचे नाव';
  String get ninTextSource => 'स्त्रोत';
  String get ninTextEnterBrandAndProductName =>
      'ब्रँड आणि उत्पादनाचे नाव प्रविष्ट करा';
  String get ninTextEnterAuthorDetails =>
      'लेखकाचे नाव, वर्ष, जर्नल, पृष्ठ प्रविष्ट करा';
  String get ninTextEnterFctName => 'FCT चे नाव एंटर करा';
  String get ninTextName => 'नाव';
  String get ninTextProductName => 'उत्पादनाचे नांव';
  String get ninTextSelectStartDate => 'प्रारंभ तारीख निवडा';
  String get ninTextSelectEndDate => 'समाप्ती तारीख निवडा';
  String get ninTextNoExercise => 'कोणताही व्यायाम नाही';
  String get ninTextDevelopedWithExpertiseAndInputs =>
      'सेंटर फॉर डेव्हलपमेंट अँड ॲडव्हान्स्ड कॉम्प्युटिंग (सी-डॅक), हैदराबाद लँग्वेज लिंकद्वारे एनआयएन मधील कौशल्य आणि इनपुटसह विकसित';
  String get ninTextMyNutrientIntakeToday => 'आज माझे पोषक सेवन';
  String get ninTextIcmrNationalInstituteOfNutritionAddress =>
      'ICMR - तरनाका मेट्रो स्टेशनच्या बाजूला राष्ट्रीय पोषण संस्था, जमाई-उस्मानिया पीओ, हैदराबाद-500 007, भारत.';

  String get ninTextKcal => 'kcal';
  String get ninTextKcalPerDay => 'kcal/दिवस';
  String get ninTextDelete => 'हटवा';
  String get ninTextDeleteNotification => 'सूचना हटवा';
  String get ninTextConfirmDeleteNotification =>
      'तुमची खात्री आहे की तुम्ही ही सूचना हटवू इच्छिता?';
  String get ninTextTimeFor => 'अहो, ते\'s time for';
  String get ninTextFitbitWatch => 'फिटबिट घड्याळ';
  String get ninTextGoogleFitApp => 'Google Fit ॲप';
  String get ninTextUnderweight => 'कमी वजन';
  String get ninTextNormal => 'सामान्य';
  String get ninTextOverweight => 'जास्त वजन';
  String get ninTextObesity => 'लठ्ठपणा';
  String get ninTextMale => 'पुरुष';
  String get ninTextFemale => 'स्त्री';
  String get ninTextAgeInYears => 'वर्षांमध्ये वय';
  String get ninTextChangeInWeight => 'वजनात बदल';
  String get ninTextSteps => 'पायऱ्या';
  String get ninTextFor => 'च्या साठी';
  String get ninTextMinutes => 'मिनिटे';
  String get ninTextPause => 'विराम द्या';
  String get ninTextReset => 'रीसेट करा';
  String get ninTextStartActivity => 'तुमचा उपक्रम सुरू करा';
  String get ninTextCartIsEmpty => 'तुमची कार्ट रिकामी आहे';
  String get ninTextMyPersonalRecipe => 'माझी वैयक्तिक पाककृती';
  String get ninTextSearchByRecipeName => 'रेसिपीच्या नावाने शोधा';
  String get ninTextHelpCenter => 'मदत केंद्र';
  String get ninTextCommonProblems => 'सामान्य समस्या';
  String get ninTextFAQs => 'वारंवार विचारले जाणारे प्रश्न';
  String get ninTextHowActiveAreYou => 'तुम्ही किती सक्रिय आहात';
  String get ninTextVitaminC => 'व्हिटॅमिन सी (मिग्रॅ)';
  String get ninTextVitaminA => 'व्हिटॅमिन ए (आययू)';
  String get ninTextSodium => 'सोडियम (मिग्रॅ)';
  String get ninTextJournal => 'जर्नल';
  String get ninTextPage => 'पान';
  String get ninTextAdequateIntakeCarbs =>
      '*कार्बोहायड्रेट्ससाठी पुरेसे सेवन (AI) शिफारस केलेले: प्रौढ पुरुष आणि महिलांसाठी 130 ग्रॅम.';
  String get ninTextAdequateIntakeFiber =>
      '**फायबरसाठी AI ची शिफारस: महिलांसाठी २५ ग्रॅम आणि पुरुषांसाठी ३८ ग्रॅम.';
  String get your => 'आपले';
  String get question1 => 'मी माझे वैयक्तिक तपशील संपादित करू शकतो का?';
  String get answer1 =>
      'होय. तुमचा वैयक्तिक डेटा तुमच्या प्रोफाइलमध्ये संपादित केला जाऊ शकतो.';
  String get linkText1 =>
      'तुमचे वैयक्तिक तपशील संपादित करण्यासाठी येथे क्लिक करा';

  String get question2 => 'मी माझे संपर्क तपशील बदलू शकतो का?';
  String get answer2 =>
      'होय. तुमच्या प्रोफाइलमधील ‘पर्सनल डेटा’ या पर्यायावर जाऊन तुमचे संपर्क तपशील बदलले जाऊ शकतात.';
  String get linkText2 =>
      'तुमचे संपर्क तपशील संपादित करण्यासाठी येथे क्लिक करा';

  String get question3 => 'मी माझा वापरकर्ता पासवर्ड बदलू शकतो का?';
  String get answer3 =>
      "होय. तुमच्या प्रोफाइलमधील 'सेटिंग' पर्यायावर जाऊन तुमचा पासवर्ड बदलला जाऊ शकतो.";
  String get linkText3 => 'तुमचा पासवर्ड बदलण्यासाठी येथे क्लिक करा';

  String get question4 => 'मी माझा BMI कसा तपासू शकतो?';
  String get answer4 =>
      "होम पेजवर प्रदर्शित 'हेल्थ कॅल्क्युलेटर' पर्यायामध्ये प्रदान केलेल्या 'BMI कॅल्क्युलेटर'मध्ये तुमची उंची आणि शरीराचे वजन टाकून तुम्ही तुमचा BMI तपासू शकता.";
  String get linkText4 => 'BMI कॅल्क्युलेटर वापरण्यासाठी येथे क्लिक करा';

  String get question5 => 'मी गेल्या महिन्यातील माझे वजन ट्रॅक करू शकतो का?';
  String get answer5 =>
      'होय. मुख्यपृष्ठावर प्रदान केलेल्या ‘वजन व्यवस्थापक’ पर्यायामध्ये तुम्ही मागील महिन्या/वर्षातील तुमच्या शरीराच्या वजनातील बदलांचे तपशील पाहू शकता.';
  String get linkText5 => 'तुमचे वजन ट्रॅक करण्यासाठी येथे क्लिक करा';

  String get question6 =>
      'मी एका विशिष्ट दिवशी माझी एकूण शारीरिक क्रिया कशी तपासू शकतो?';
  String get answer6 =>
      'होम पेजवरील ‘माय ॲक्टिव्हिटी’ पर्यायातून तुम्ही तुमच्या शारीरिक हालचालींचा मागोवा घेऊ शकता.';
  String get linkText6 => 'तुमचा क्रियाकलाप पाहण्यासाठी येथे क्लिक करा';

  String get question7 => 'मी पाणी पिण्यासाठी स्मरणपत्र कसे सेट करू शकतो?';
  String get answer7 =>
      'तुम्ही होम पेजवर दिलेल्या ‘सेट नोटिफिकेशन’ पर्यायामध्ये पाण्याच्या सेवन स्मरणपत्रासाठी वेळ सेट करू शकता.';
  String get linkText7 => 'पाणी सेवन स्मरणपत्र सेट करण्यासाठी येथे क्लिक करा';

  String get question8 =>
      'मी माझ्या स्मार्ट घड्याळासोबत ॲप कसे समाकलित करू शकतो?';
  String get answer8 =>
      'होम पेजवर प्रदान केलेल्या ‘कनेक्ट घड्याळ’ पर्यायावर जाऊन तुम्ही तुमचे स्मार्ट घड्याळ ॲपसोबत समाकलित करू शकता.';
  String get linkText8 =>
      'तुमचे स्मार्ट घड्याळ कनेक्ट करण्यासाठी येथे क्लिक करा';

  String get question9 =>
      'मी एका वेळी किती घालण्यायोग्य गोष्टी ॲपसह समाकलित करू शकतो?';
  String get answer9 =>
      'तुम्ही Fitbit घड्याळ आणि Google Fit ॲपसह एकत्रित करू शकता.';
  String get linkText9 => '';

  String get question10 => 'कोणती स्मार्ट घड्याळे ॲपशी सुसंगत आहेत?';
  String get answer10 => 'Fitbit घड्याळ आणि Google Fit.';
  String get linkText10 => '';

  String get question11 =>
      'माझ्याकडे स्मार्ट घड्याळ नसल्यास मी माझ्या क्रियाकलापाचा मागोवा घेऊ शकतो का?';
  String get answer11 =>
      'होय, तुम्ही तुमच्या क्रियाकलापाचा मागोवा घेऊ शकता. त्यासाठी, तुम्हाला Google Fit ॲप डाउनलोड करावे लागेल, Google खात्याने साइन इन करावे लागेल आणि त्याच Google खात्यासह, तुम्हाला आमच्या वॉच विभागात लॉग इन करावे लागेल.';
  String get linkText11 => '';

  String get question12 => 'मी माझ्या झोपेचा मागोवा कसा घेऊ शकतो?';
  String get answer12 =>
      'होम पेजवर दिलेल्या स्लीप ट्रॅकर पर्यायावर जाऊन तुम्ही साप्ताहिक/मासिक आधारावर तुमच्या झोपेचा मागोवा घेऊ शकता.';
  String get linkText12 => 'तुमच्या झोपेचा मागोवा घेण्यासाठी येथे क्लिक करा';

  String get question13 =>
      'मी ॲपद्वारे कोणतेही NIN प्रकाशन कसे खरेदी करू शकतो?';
  String get answer13 =>
      'तुम्ही होम पेजवर दिलेल्या ‘बुक स्टोअर’ पर्यायावरून NIN प्रकाशन खरेदी करू शकता.';
  String get linkText13 =>
      'पुस्तकांच्या दुकानाला भेट देण्यासाठी येथे क्लिक करा';

  String get question14 => 'मी माझी वैयक्तिक आहार डायरी कशी तयार करू शकतो?';
  String get answer14 =>
      'तुम्ही ‘माय डायट डायरी पर्याय’ वर जाऊन संपूर्ण दिवस खाल्लेल्या अन्नाचा तपशील टाकू शकता.';
  String get linkText14 => 'तुमची आहार डायरी तयार करण्यासाठी येथे क्लिक करा';

  String get question15 =>
      'विशिष्ट पौष्टिकतेने समृद्ध असलेली पाककृती मी कशी शोधू शकतो?';
  String get answer15 =>
      'तुम्ही प्रथम होम पेजवरील ‘माय फूडमधील पोषक’ टॅबमध्ये दिलेला ‘रेसिपीमध्ये पोषक घटक शोधा’ पर्याय निवडू शकता. नंतर वरच्या उजव्या कोपऱ्यातील ड्रॉप-डाउन सूचीमधून आवश्यक पोषक निवडा.';
  String get linkText15 => 'पाककृती शोधण्यासाठी येथे क्लिक करा';

  String get question16 =>
      'मागील महिन्यात जतन केलेल्या एका दिवसासाठी मी माझे पोषक आहार कसे तपासू शकतो?';
  String get answer16 =>
      "'जेवण सूची' पृष्ठावरील 'कॅलेंडर आयकॉन' मधून तारीख निवडून तुम्ही विशिष्ट दिवशी तुमचे पोषक आहार पाहू शकता.";
  String get linkText16 => 'तुमचे पोषक सेवन तपासण्यासाठी येथे क्लिक करा';

  String get question17 =>
      'माझ्या पाककृतींमध्ये वापरल्या जाणाऱ्या कच्च्या घटकांमधील पोषक घटक मी कसे शोधू शकतो?';
  String get answer17 =>
      'मुख्यपृष्ठावरील ‘माय अन्नातील पोषक’ टॅबमध्ये दिलेला ‘कच्च्या खाद्यपदार्थांमध्ये पोषक घटक शोधा’ पर्याय निवडून तुम्ही विशिष्ट घटकातील पोषक घटक जाणून घेऊ शकता.';
  String get linkText17 =>
      'कच्च्या खाद्यपदार्थांमध्ये पोषक घटक शोधण्यासाठी येथे क्लिक करा';

  String get question18 => 'मला रेसिपीची पोषक रचना कशी कळेल?';
  String get answer18 =>
      'होम पेजवरील ‘माय फूडमधील पोषक’ टॅबमध्ये दिलेला ‘रेसिपीमध्ये पोषक घटक शोधा’ पर्याय निवडून तुम्ही विशिष्ट घटकातील पोषक घटक जाणून घेऊ शकता.';
  String get linkText18 => 'पोषक घटकांची रचना जाणून घेण्यासाठी येथे क्लिक करा';

  String get question19 =>
      'ॲपमध्ये उपलब्ध नसलेली नवीन पाककृती मी समाविष्ट करू शकतो का?';
  String get answer19 =>
      'होय. तुम्ही विशिष्ट फिक्स्ड रेसिपीच्या तळाशी दिलेल्या लिंकचा वापर करून सध्याची रेसिपी बदलू शकता किंवा आहार डायरीच्या पानावर प्रत्येक जेवणासाठी दिलेल्या ‘कस्टम डिश तयार करा’ पर्यायावर क्लिक करून पूर्णपणे नवीन रेसिपी तयार करू शकता.';
  String get linkText19 => 'सानुकूल कृती तयार करण्यासाठी येथे क्लिक करा';

  String get question20 =>
      'विशिष्ट आरोग्य स्थितीसाठी मला आहारविषयक शिफारसी मिळू शकतात का?';
  String get answer20 =>
      'होय. तुम्ही मुख्यपृष्ठावरील ‘शोध घटक’ पर्यायावरून आरोग्य शिफारसी किंवा आहार चार्ट मार्गदर्शक तत्त्वे मिळवू शकता.';
  String get linkText20 => 'आहारविषयक शिफारसी मिळविण्यासाठी येथे क्लिक करा';

  String get question21 => 'मी इंग्रजीशिवाय इतर भाषेत ॲप वापरू शकतो का?';
  String get answer21 =>
      'होय. तुमच्या प्रोफाइलमध्ये दिलेल्या ‘सेटिंग’ पर्यायातून तुम्ही इच्छित भाषा निवडू शकता.';
  String get linkText21 => 'भाषा बदलण्यासाठी येथे क्लिक करा';

  String get ninTextBmiHwading => 'बॉडी मास इंडेक्स (BMI):';
  String get ninTextBmiDiscription =>
      'BMI ची व्याख्या एखाद्या व्यक्तीचे वजन किलोग्रॅममध्ये भागिले व्यक्तीच्या उंचीच्या वर्गाने मीटरमध्ये (kg/m2) केली जाते. बीएमआय श्रेणी शरीरातील अति चरबीचा रोग आणि मृत्यूवर होणा-या परिणामावर आधारित आहे आणि ते ॲडिपोसीटीशी वाजवीपणे संबंधित आहेत. बीएमआय हा रोगाचा धोका सूचक म्हणून विकसित करण्यात आला होता; जसजसा BMI वाढतो, तसाच काही रोगांचा धोकाही वाढतो. जादा वजन आणि लठ्ठपणाशी संबंधित काही सामान्य परिस्थितींमध्ये हे समाविष्ट आहे: अकाली मृत्यू, हृदय व रक्तवाहिन्यासंबंधी रोग, उच्च रक्तदाब, ऑस्टियोआर्थरायटिस, काही कर्करोग आणि मधुमेह.';
  String get ninTextbminutritionsta => 'BMI पोषण स्थिती';
  String get ninTextNutritionstat => 'पौष्टिक स्थिती';
  String get ninTextBelow => 'खाली';
  String get ninTextPreobesity => 'पूर्व लठ्ठपणा';

  String get ninTextbesity => 'लठ्ठपणा वर्ग I';
  String get ninTextbesity2 => 'लठ्ठपणा वर्ग II';
  String get ninTextbesity3 => 'लठ्ठपणा वर्ग II';
  String get ninTextBMRfull => 'बेसल मेटाबॉलिक रेट (BMR)';
  String get ninTextBMRDiscription =>
      'बेसल मेटाबॉलिक रेट (BMR) हा दर म्हणजे एखादी व्यक्ती विश्रांती घेत असताना ऊर्जा खर्च करते';
  String get ninTextPreviousdays => 'मागील 30 दिवस';
  String get ninTextason => 'वर म्हणून';
  String get ninTextYearly => 'वार्षिक';
  String get ninTextabove => 'वर';
  String get ninTextAchieveyourhealthgoal => 'आपले आरोग्य ध्येय साध्य करा';
  String get heavyDescription =>
      'या श्रेणीमध्ये दररोज एक तासापेक्षा जास्त काळ धावणे, सायकल चालवणे किंवा जड उचलणे यासारख्या नियमित आणि तीव्र शारीरिक हालचालींचा समावेश असलेल्या व्यवसायांचा समावेश होतो. उदाहरणांमध्ये लोहार, खाणकाम करणारे आणि बांधकाम कामगार यांचा समावेश होतो.';
  String get moderateDescription =>
      'या श्रेणीतील व्यक्ती दररोज सुमारे 30 मिनिटे ते एक तास चालणे किंवा हलके जॉगिंग यासारख्या शारीरिक हालचालींमध्ये व्यस्त असतात. अंगमेहनती, कारागीर आणि काही प्रकारचे कुशल कामगार यांसारखे व्यवसाय या श्रेणीत येतात.';
  String get sedentaryDescription =>
      'या श्रेणीमध्ये दिवसभर शारीरिक हालचाल नसलेले व्यवसाय समाविष्ट आहेत. या नोकऱ्यांमधील लोक त्यांचा बहुतांश वेळ बसण्यात किंवा पडून राहण्यात घालवतात. उदाहरणांमध्ये कार्यालयीन कर्मचारी, शिक्षक आणि प्रशासकीय भूमिकेत असणारे यांचा समावेश होतो.';
  String get Foodprotein => "प्रथिने";
  String get Foodfat => "चरबी";
  String get Foodenergy => "ऊर्जा";
  String get FoodtotalB2 => "एकूण B2";
  String get Foodvitamins => "जीवनसत्त्वे";
  String get FoodtotalFat => "एकूण चरबी";
  String get FoodproximateComposition => "जवळपासची रचना";
  String get FoodnutrientsIn100g => "100 ग्रॅम मध्ये पोषक";
  String get FoodtotalCarotenoids => "एकूण कॅरोटीनोइड्स";
  String get FoodtotalAscorbicAcid => "एकूण एस्कॉर्बिक ऍसिड";
  String get FoodtotalB9 => "एकूण B9";
  String get FoodtotalB6 => "एकूण B6";
  String get Foodcalcium => "कॅल्शियम";
  String get Foodsodium => "सोडियम";
  String get Foodpotassium => "पोटॅशियम";
  String get Foodzinc => "जस्त";
  String get Foodiron => "लोखंड";
  String get Foodminerals => "खनिजे";
  String get FoodtotalSaturatedFattyAcids => "एकूण संतृप्त फॅटी ऍसिडस्";
  String get FoodfattyAcids => "चरबीयुक्त आम्ल";
  String get FoodtotalDietaryFiber => "एकूण आहारातील फायबर";
  String get Foodmanganese => "मँगनीज";
  String get Foodcopper => "तांबे";
  String get Foodselenium => "सेलेनियम";
  String get Foodmagnesium => "मॅग्नेशियम";
  String get Foodphosphorus => "फॉस्फरस";
  String get Foodcholesterol => "कोलेस्टेरॉल";
  String get Foodcarbohydrate => "कार्बोहायड्रेट";
  String get FoodvitaminB6 => "व्हिटॅमिन बी 6 (मिग्रॅ)";

  String get Punjabi => "पंजाबी";
  String get Gujarati => "गुजराती";
  String get Odia => "ओडिया";
  String get Kannada => "कन्नड";
  String get Marathi => "मराठी";
  String get Tamil => "तमिळ";
  String get Bengali => "बंगाली";
  String get Telugu => "तेलगु";
  String get English => "इंग्रजी";
  String get Hindi => "हिंदी";
  String get firstname => "पहिलं नाव";
  String get lastname => "आडनाव";
  String get labelSodium => "सोडियम";
  String get labelVitaminC => "विटामिन C";
  String get FinanameEnergy => "ऊर्जा";
  String get FinanameCarbohydrate => "कार्बोहायड्रेट";
  String get FinanameFat => "साई";
  String get FinanameSodium => "सोडियम";
  String get FinanameDietaryFibre => "आहारी फायबर";
  String get FinanameCalcium => "कॅल्शियम";
  String get FinanameIron => "लोह";
  String get FinanameMagnesium => "मॅग्नेशियम";
  String get EssentialNutritionalGuidelines =>
      "भारतीयांच्या आहाराच्या गरजांसाठी अनुकूलित अत्यावश्यक पोषण मार्गदर्शक तत्त्वे.";
  String get NutrientRequirementsRDA2020 =>
      "भारतीयांसाठी पोषकतत्त्वांची आवश्यकता आणि शिफारस केलेले आहार भत्ते (RDA 2020).";
  String get RecommendationsBalancedDiets =>
      "भारतात संतुलित आहार आणि निरोगी खाण्याच्या सवयींना प्रोत्साहन देणाऱ्या शिफारसी.";
  String get DietaryGuidelinesForIndians =>
      "भारतीयांसाठी आहार मार्गदर्शक तत्त्वे.";
  String get Nutritionstat => "पोषण सांख्यिकी";
  String get referenceMen65kg => "संदर्भ पुरुष (65 किलो)";
  String get referenceWomen55kg => "संदर्भ महिला (55 किलो)";
  String get valueForMen => "1506";
  String get valueForWomen => "1184";

  String get FinanameZinc => "झिंक";
  String get FinanameProtein => "प्रोटीन";
  String get FinanameThiamine => "थायमिन";
  String get FinanameRiboflavin => "रायबोफ्लेविन";
  String get FinanameNiacin => "नियासिन";
  String get FinanameVitaminB => "विटामिन B";
  String get FinanameFolate => "फोलेट";
  String get FinanameVitaminC => "विटामिन C";
  String get FinanameVitaminA => "विटामिन A";
  String get FinanameVitaminb6 => "विटामिन B6";
  String get confirmDeleteAllNotifications => "सर्व सूचना नष्ट करायच्या?";
  String get fillAllFields => "सर्व फील्ड भरा";
  String get successfullyAddedIngredient => "घटक सफळतेने जोडला";
  String get confirmDeletion => "काढून टाकण्याची पुष्टी करा";
  String get confirmDeleteIngredient =>
      "तुम्हाला सुनिश्चित आहे की तुम्ही हा घटक काढून टाकायचं?";
  String get fileDownloaded =>
      "फाईल यशस्वीरित्या डाउनलोड केली आणि फाईलचे स्थान";
  String get referenceMenWomenDescription =>
      "संदर्भ पुरुष आणि महिला 19-39 वयोगटातील सामान्य बीएमआय आणि मध्यम सक्रिय असलेल्या निरोगी प्रौढ म्हणून (ICMR-NIN). पहा";
  String get personalizedDietDiaryDescription =>
      "वैयक्तिकृत आहार डायरी आपले वर्तमान पासून मागील महिन्यापर्यंत पोषक सेवन ट्रॅक करते";

  String get confirmDeleteFood =>
      "तुम्हाला सुनिश्चित आहे की तुम्ही अन्न काढून टाकायचं?";
  String get estimatedAverageRequirement =>
      'अनुमानित औसत आवश्यकता (EAR): स्वस्थ व्यक्तींच्या 50% ला आवश्यकता संपूर्ण करण्याच्या दैनंदिन औसत स्तर';
  String get editQuantity => "मात्रा संपादित करा";
  String get confirmDelete =>
      "तुम्हाला हे खात्री आहे की तुम्ही हे हटवू इच्छिता?";
  String get exerciseDeleted => "व्यायाम यशस्वीरित्या हटवला गेला.";
  String get confirmDeleteExercise =>
      "तुम्हाला सुनिश्चित आहे की तुम्ही हा व्यायाम काढून टाकायचा आहे?";
}
