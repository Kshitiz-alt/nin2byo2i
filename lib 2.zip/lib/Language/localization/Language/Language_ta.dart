// LanguageTa.dart
import 'languages.dart';

class LanguageTa extends Languages {
  @override
  String get appName => "NIN2.0";
  String get recordMyDiet => "எனது உணவை பதிவு செய்யவும்";
  String get moisture => "உலர்ச்சி";

  @override
  String get labelWelcome => "வரவேற்பு";
  String get activities => "செயற்பாடுகள்";
  String get searchActivityHere => "இங்கு செயல்பாட்டைத் தேடுங்கள்";
  String get orSelectActivityFromBelow =>
      "அல்லது கீழே உள்ள செயல்பாட்டைப் பின்பற்றவும்";
  String get tryLater => "பின்னர் முயற்சி செய்";
  String get indianFoodCompositionTitle =>
      "இந்திய உணவுப் பொருளியல் அட்டவணைகள் (2017)";

  String get indianFoodCompositionDescription =>
      "இந்திய உணவுப் பொருளியல் அட்டவணைகள் (2017): இந்திய உணவுகளுக்கான விரிவான ஊட்டச்சத்து தரவுகள்.";

  @override
  String get labelSelectLanguage => "மொழியை தேர்ந்தெடுங்கள்";
  String get inputActivityDataPrompt =>
      "உங்கள் ஆற்றல் செலவு மற்றும் சமநிலையை காண, தயவுசெய்து 24 மணி நேர செயல்பாட்டு தரவுகளை உள்ளிடவும்.";
  String get myEnergyBalanceYesterday => "எனது ஆற்றல் சமநிலை (நேற்று)";
  String get caloriesBurnFromWatch =>
      "நாட்காட்டியிலிருந்து எரிக்கப்பட்ட கிலோபொருள்";

  @override
  String get labelInfo => "இது பல மொழி டெமோ பயன்பாடு ஆகும்";

  @override
  // TODO: implement labelChangeLanguage
  String get labelChangeLanguage => "மொழியை மாற்றவும்";
  @override
  String get labelWelcomeBack => "மீண்டும் வருக,";

  @override
  String get labelUnderweight => "நீங்கள் எடை குறைவாக இருக்கிறீர்கள்";

  @override
  String get labelNormalWeight => "நீங்கள் சாதாரண எடை கொண்டவர்";

  @override
  String get labelOverweight => "நீங்கள் அதிக எடையுடன் இருக்கிறீர்கள்";

  @override
  String get labelObese => "நீங்கள் பருமனாக இருக்கிறீர்கள்";

  @override
  String get labelViewMore => "மேலும் பார்க்க";

  @override
  String get labelTodaySteps => "இன்றைய படிகள்";

  @override
  String get labelCheck => "காசோலை";

  @override
  String get labelHealthData =>
      "எனது இரத்த அழுத்தம் / இரத்த குளுக்கோஸ் / SPO2 ஐ பதிவு செய்யவும்";

  @override
  String get labelActivityStatus => "செயல்பாட்டு நிலை";

  @override
  String get labelHeartRate => "இதய துடிப்பு";

  @override
  String get labelHeartRateValue => "78 பிபிஎம்";

  @override
  String get labelMinutesAgo => "நிமிடங்களுக்கு முன்பு";

  @override
  String get labelWaterIntake => "என் நீர் உட்கொள்ளல்";

  @override
  String get labelLiters => "லிட்டர்கள்";

  @override
  String get labelZeroLiters => "0 லிட்டர்";

  @override
  String get labelRealTimeGoal => "உண்மையான நேரம், இலக்கு";

  @override
  String get labelCalories => "கலோரிகள் எரிந்தன";

  @override
  String get labelCaloriesEarned => "சம்பாதித்த கலோரிகள்";

  @override
  String get labelFoodPlan => "உணவு திட்டம்";

  @override
  String get labelWorkoutProgress => "உடற்பயிற்சி முன்னேற்றம்";

  @override
  String get labelWeekly => "வாரந்தோறும்";

  @override
  String get labelMonthly => "மாதாந்திர";

  @override
  String get labelLatestWorkout => "சமீபத்திய உடற்பயிற்சி";

  @override
  String get labelSeeMore => "மேலும் பார்க்க";
  String get labelBreakfast => "காலை உணவு";
  String get labelLunch => "மதிய உணவு";
  String get labelDinner => "இரவு உணவு";
  String get labelSnacks => "சிற்றுண்டி";
  String get labelTaken => "எடுக்கப்பட்டது";
  String get labelTarget => "இலக்கு";

  //profile

  String get labelProfile => "சுயவிவரம்";
  String get labelEdit => "தொகு";
  String get labelUser => "பயனர்";
  String get labelProgram => "ஒரு கொழுப்பு திட்டத்தை இழக்கவும்";
  String get labelHeight => "உயரம்";
  String get labelWeight => "எடை";
  String get labelAge => "வயது";
  String get labelAccount => "கணக்கு";
  String get labelPersonalData => "தனிப்பட்ட தகவல்";
  String get labelAchievement => "சாதனை";
  String get labelActivityHistory => "செயல்பாட்டு வரலாறு";
//String get labelWorkoutProgress => "உடற்பயிற்சி முன்னேற்றம்";
  String get labelNotification => "அறிவிப்பு";
  String get labelPopupNotification => "பாப்-அப் அறிவிப்பு";
  String get labelMensurationCycle => "சுழற்சி அளவீடு";
  String get labelOther => "மற்றவை";
  String get labelContactUs => "எங்களை தொடர்பு கொள்ள";
  String get labelPrivacyPolicy => "தனியுரிமைக் கொள்கை";
  String get labelSetting => "அமைத்தல்";
  String get labelFeedback => "பின்னூட்டம்";
  String get labelConfirmLogout => "வெளியேறுவதை உறுதிப்படுத்தவும்";
  String get labelConfirmLogoutMessage =>
      "நிச்சயமாக வெளியேற விரும்புகிறீர்களா?";
  String get labelLogout => "வெளியேறு";
  //select tab
  String get labelOptions => "விருப்பங்கள்";
  String get labelFoodTable => "உணவைச் சேர்க்கவும்";
  String get labelTop10Food => "முதல் 10 உணவுகள்";
  String get labelActivityTrack => "செயல்பாடு கண்காணிப்பான்";
  String get labelsteptracker => "படி கண்காணிப்பாளர்";

  String get labelTodayTarget => "நீர் இலக்கு";
  String get labelJoggingTrack => "மெதுவோட்ட பாதை";
  String get labelMensurationTrack => "மாதவிடாய் தடம்";
//String get labelFoodTable => "உணவு அட்டவணை";
  String get labelPassword => "கடவுச்சொல்லை மாற்று";
  String get labelDarkMode => "இருண்ட பயன்முறையை முயற்சிக்கவும்";
  String get labelconectWatch => "கடிகாரத்தை இணைக்கவும்";
  @override
  String get labelSleep => "தூங்கு";
  @override
  String get labelBookStore => "புத்தகக் கடை";
  @override
  String get labelSearchBooks => "புத்தகங்களைத் தேடுங்கள்";
  @override
  String get labelPrice => "விலை";
  @override
  String get labelAddToCart => "பெட்டகத்தில் சேர்";
  @override
  String get labelAuthor => "நூலாசிரியர்";
  @override
  String get labelYear => "ஆண்டு";
  @override
  String get labelQuantityAvailable => "கிடைக்கும் அளவு";
  @override
  String get labelCart => "பெட்டகத்தில் சேர்";
  @override
  String get labelMyOrders => "என் கட்டளைகள்";
  @override
  String get labelAllOrders => "அனைத்து ஆர்டர்கள்";
  @override
  String get labelOrderDetail => "ஆர்டர் விவரம்";
  @override
  String get labelOrderId => "ஆர்டர் ஐடி";
  @override
  String get labelOrdersInMyOrders => "எனது ஆர்டர்களில் ஆர்டர்கள்";
  @override
  String get labelItemsInMyOrders => "எனது ஆர்டர்களில் உள்ள பொருட்கள்";
  @override
  String get labelTotal => "மொத்தம்";
  @override
  String get labelTotalPrice => "மொத்த விலை";
  @override
  String get labelCheckout => "சரிபார்";

  // Meal List
  @override
  String get labelMealList => "என் உணவுமுறை";
  @override
  String get labelAnalyze => "பகுப்பாய்வு செய்யுங்கள்";
  @override
  String get labelAddDish => "டிஷ் சேர்க்கவும்";
  @override
  String get labelTop10Foods => "முதல் 10 உணவுகள்";
  @override
  String get labelRecentMeal => "சமீபத்திய உணவு";
  @override
  String get labelAnalyzeIngredientsTaken =>
      "உணவு உட்கொள்ளலை பகுப்பாய்வு செய்யுங்கள்";

  // Nutrition Summary
  @override
  String get labelCarbs => "கார்போஹைட்ரேட்";
  // @override
  // String get labelCalories => "கலோரிகள்";
  @override
  String get labelFibers => "மொத்த நார்ச்சத்து";
  @override
  String get labelFats => "கொழுப்பு";
  @override
  String get labelProteins => "புரத";
  @override
  String get labelCalcium => "கால்சியம்";

  @override
  String get labelNiacinB3 => "நியாசின் (B3)";

  @override
  String get labelThiamineB1 => "தியாமின் (B1)";

  @override
  String get labelIron => "இரும்பு";

  @override
  String get labelZinc => "துத்தநாகம்";

  @override
  String get labelFolatesB9 => "ஃபோலேட் (B9)";

  @override
  String get labelRiboflavinB2 => "ரிபோஃப்ளேவின் (B2)";

  @override
  String get labelRetinolVitA => "ரெட்டினோல் (வைட்டமின் ஏ)";

  @override
  String get labelMagnesium => "வெளிமம்";

  @override
  String get labelTodaysNutritionSummary => "இன்றைய ஊட்டச்சத்து சுருக்கம்";
  @override
  String get labelChangeGoal => "இலக்கை மாற்றவும்";
  @override
  String get labelIngredientsTaken => "எடுக்கப்பட்ட பொருட்கள்";
  @override
  String get labelIngredientsLeft => "தேவையான பொருட்கள்";

  // Food Table
  // @override
  // String get labelFoodTable => "உணவு அட்டவணை";
  // @override
  // String get labelBreakfast => "காலை உணவு";
  // @override
  // String get labelLunch => "மதிய உணவு";
  // @override
  // String get labelDinner => "இரவு உணவு";
  // @override
  // String get labelSnacks => "சிற்றுண்டி";
  @override
  String get labelTop10FoodsSleep => "முதல் 10 உணவுகள்";
  @override
  String get labelFavouriteDishes => "பிடித்த உணவுகள்";

  // User Profile
  @override
  String get labelHelp => "உதவி";
  // @override
  // String get labelLogout => "வெளியேறு";
  // @override
  // String get labelWeight => "எடை";
  @override
  String get labelEmail => "மின்னஞ்சல்";
  // @override
  // String get labelHeight => "உயரம்";
  @override
  String get labelLinkedInProfileLink => "LinkedIn சுயவிவர இணைப்பு";
  @override
  String get labelGoogleProfileLink => "Google சுயவிவர இணைப்பு";
  @override
  String get labelFacebookProfileLink => "Facebook சுயவிவர இணைப்பு";
  @override
  String get labelTwitterProfileLink => "Twitter சுயவிவர இணைப்பு";
  @override
  String get labelName => "பெயர்";
  @override
  String get labelPhoneNumber => "தொலைபேசி எண்.";
  @override
  String get labelDateOfBirth => "டி.ஓ.பி";
  @override
  String get labelBMI => "பிஎம்ஐ";
  // @override
  // String get labelAge => "வயது";

  // Contact Us
  @override
  String get labelMessage => "செய்தி";
  @override
  String get labelSubmit => "சமர்ப்பிக்கவும்";
  @override
  String get labelCompanyContacts => "நிறுவனத்தின் தொடர்புகள்";
  @override
  String get labelAddress => "முகவரி";
  @override
  String get labelDirectorsEmail => "இயக்குனரின் மின்னஞ்சல்";
  @override
  String get labelFax => "தொலைநகல்";

  // Settings
  @override
  String get labelResetPassword => "கடவுச்சொல்லை மீட்டமைக்க";
  // @override
  // String get labelFeedback => "பின்னூட்டம்";
  @override
  String get labelPleaseProvideFeedback =>
      "தயவுசெய்து உங்கள் கருத்தை வழங்கவும்";
  @override
  String get labelEnterYourFeedbackHere => "உங்கள் கருத்தை இங்கே உள்ளிடவும்";
  @override
  String get labelSubmitFeedback => "கருத்தைச் சமர்ப்பிக்கவும்";

  // Credits
  // @override
  // String get labelContactUs => "எங்களை தொடர்பு கொள்ள";
  @override
  String get labelDevelopmentTeam => "வளர்ச்சி குழு";
  @override
  String get labelAcknowledgments => "அங்கீகாரங்கள்";
  @override
  String get labelPartnerships => "கூட்டாண்மைகள்";

  // Mobile
  @override
  String get labelSearchComponents => "தேடல் கூறுகள்";
  @override
  String get labelSearchComponentsHere => "கூறுகளை இங்கே தேடுங்கள்";
  @override
  String get lablelDishName => 'டிஷ் பெயர்';
  @override
  String get labelCredits => 'கடன்கள்';
  @override
  String get labelShareAppButton => "பகிர்";
  @override
  String get labelShareApp =>
      "பார்கோடு ஸ்கேனர் பயன்பாட்டின் மூலம் QR குறியீட்டை ஸ்கேன் செய்து, பயன்பாட்டைப் பதிவிறக்கவும்";
  // New translations
  @override
  String get labelConnectedWatch => "இணைக்கப்பட்ட கடிகாரம்";
  @override
  String get labelDisconnect => "துண்டிக்கவும்";
  @override
  String get labelFitbit => "ஃபிட்பிட்";
  @override
  String get labelGoogleFit => "கூகுள் ஃபிட்";
  @override
  String get labelAppleWatch => "ஆப்பிள் வாட்ச்";
  @override
  String get labelSamsungSmartWatch => "சாம்சங் ஸ்மார்ட் வாட்ச்";
  @override
  String get labelBookDetails => "புத்தக விவரங்கள்";
  @override
  String get labelDeliveryDate => "டெலிவரி தேதி";
  @override
  String get labelOrderDate => "ஆர்டர் தேதி";
  @override
  String get labelAnalyseIngredientsTaken =>
      "உணவு உட்கொள்ளலை பகுப்பாய்வு செய்யுங்கள்";
  @override
  String get labelAddDishIngredients => "டிஷ் பொருட்கள் சேர்க்கவும்";
  @override
  String get labelIngredientName => "மூலப்பொருள் பெயர்";
  @override
  String get labelEnterIngredientName => "ஒரு மூலப்பொருளின் பெயரை உள்ளிடவும்";
  @override
  String get labelIngredientQuantity => "மூலப்பொருள் அளவு";
  @override
  String get labelEnterIngredientQuantity => "மூலப்பொருளின் அளவை உள்ளிடவும்";
  @override
  String get labelAdd => "கூட்டு";
  @override
  String get labelSave => "சேமிக்கவும்";
  @override
  String get labelwatch => "பார்க்க";

  //
  @override
  String get labelBloodOxygenHeart =>
      'முக்கிய அறிகுறிகளை அளவிடவும் மற்றும் ஒட்டுமொத்த ஆரோக்கியத்தை கண்காணிக்கவும்.';
  @override
  String get labelTop10FoodS =>
      'ஆரோக்கியமான வாழ்க்கை முறையை பராமரிக்க பரிந்துரைக்கப்பட்ட உணவுகளைக் கண்டறியவும்.';
  @override
  String get labelWaterTrack =>
      'தினசரி உடற்பயிற்சி நீரேற்றம் இலக்குகளை அமைத்து அடையுங்கள்.';
  @override
  String get labelPersonalDetails =>
      'தனிப்பட்ட தகவலைப் பாதுகாப்பாக நிர்வகிக்கவும் மற்றும் புதுப்பிக்கவும்.';
  @override
  String get labelFeedbackS =>
      'உங்கள் எண்ணங்களையும் ஆலோசனைகளையும் எங்களுடன் பகிர்ந்து கொள்ளுங்கள்.';
  @override
  String get labelContactUsS =>
      'வாடிக்கையாளர் ஆதரவை அடைந்து எங்களைத் தொடர்புகொள்ளவும்.';
  @override
  String get labelBMICalculator =>
      'சுகாதார நுண்ணறிவுக்காக உங்கள் உடல் நிறை குறியீட்டைக் கணக்கிடுங்கள்.';
  @override
  String get labelBMRCalculator =>
      'உடற்பயிற்சி திட்டமிடலுக்கான உங்கள் அடிப்படை வளர்சிதை மாற்ற விகிதத்தைக் கணக்கிடுங்கள்.';
  @override
  String get labelRunningJoggingSteps =>
      'ஆரோக்கியமான வாழ்க்கை முறைக்கு உங்கள் ஓட்டம் மற்றும் ஜாகிங் படிகளைக் கண்காணிக்கவும்.';
  @override
  String get labelHealthyDietChart =>
      'ஆரோக்கியமான உணவுக் கண்ணோட்டத்திற்கான விரிவான விளக்கப்படத்தை அணுகவும்.';
  @override
  String get labelHealthyRecommendation =>
      'தனிப்பட்ட சுகாதார பரிந்துரைகளைப் பெறுங்கள்.';
  @override
  String get labelSleepTracker =>
      'உங்கள் தூக்க முறைகளைக் கண்காணித்து, தூக்கத்தின் தரத்தை மேம்படுத்தவும்.';
  @override
  String get labelSetReminder =>
      'உடல்நலம் மற்றும் உடற்பயிற்சி நடவடிக்கைகளுக்கு நினைவூட்டல்களை அமைக்கவும்.';
  // @override
  // String get labelMenstruationCycle =>
  //     'சிறந்த நுண்ணறிவுகளுக்கு உங்கள் மாதவிடாய் சுழற்சியைக் கண்காணித்து நிர்வகிக்கவும்.';
  @override
  String get labelCSVDownload =>
      'எளிதான பகுப்பாய்விற்கு உங்கள் தரவை CSV வடிவத்தில் பதிவிறக்கவும்.';

  // New Headings
  @override
  String get headingBloodOxygenHeart => 'இரத்தம் | ஆக்ஸிஜன்';
  @override
  String get headingTop10Food => 'முதல் 10 உணவுகள்';
  @override
  String get headingWaterTrack => 'நீர் கண்காணிப்பு';
  @override
  String get headingPersonalDetails => 'சொந்த விவரங்கள்';
  @override
  String get headingFeedback => 'பின்னூட்டம்';
  @override
  String get headingContactUs => 'எங்களை தொடர்பு கொள்ள';
  @override
  String get headingBMICalculator => 'பிஎம்ஐ கால்குலேட்டர்';
  @override
  String get headingBMRCalculator => 'பிஎம்ஆர் கால்குலேட்டர்';
  @override
  String get headingRunningJoggingSteps => 'ஓடுதல் / ஜாகிங் / படிகள்';
  @override
  String get headingHealthyDietChart => 'ஆரோக்கியமான உணவு அட்டவணை';
  @override
  String get headingHealthyRecommendation => 'ஆரோக்கியமான பரிந்துரை';
  @override
  String get headingSleepTracker => 'ஸ்லீப் டிராக்கர்';
  @override
  String get headingSetReminder => 'நினைவூட்டலை அமைக்கவும்';
  // @override
  // String get headingMenstruationCycle => 'மாதவிடாய் சுழற்சி';
  @override
  String get headingCSVDownload => 'CSV பதிவிறக்கம்';

  // Water-related phrases
  @override
  String get labelWaterTarget => "நீர் இலக்கு";
  // @override
  // String get labelTodayTarget => "இன்றைய இலக்கு";
  @override
  String get labelWaterGoal => "நீர் இலக்கு";
  // @override
  // String get labelWaterIntake => "நீர் உட்கொள்ளல்";
  @override
  String get labelWaterProgress => "நீர் முன்னேற்றம்";
  // @override
  // String get labelWeekly => "வாரந்தோறும்";
  @override
  String get labelDateWise => "தேதி வாரியாக";
  @override
  String get labelSun => "சூரியன்";
  @override
  String get labelMon => "திங்கள்";
  @override
  String get labelTue => "செவ்வாய்";
  @override
  String get labelWed => "திருமணம் செய்";
  @override
  String get labelThu => "வியாழன்";
  @override
  String get labelFri => "வெள்ளி";

  // BMI Calculator
  // @override
  // String get labelBMI => "பிஎம்ஐ";
  @override
  String get labelEnterHeight => "உயரத்தை உள்ளிடவும் (செ.மீ.)";
  @override
  String get labelEnterWeight => "எடையை உள்ளிடவும் (கிலோ)";
  @override
  String get labelCalculateBMI => "பிஎம்ஐ கணக்கிடவும்";

  // BMR Calculator
  @override
  String get labelMale => "ஆண்";
  @override
  String get labelFemale => "பெண்";
  @override
  String get labelEnterAge => "வயதை உள்ளிடவும்";
  @override
  String get labelCalculateBMR => "BMR ஐக் கணக்கிடுங்கள்";
  @override
  String get labelBMR => "பி.எம்.ஆர்";
  @override
  String get labelCaloriesPerDay => "கலோரிகள் / நாள்";

  // Step Tracker
  @override
  String get labelStepsTracker => "படி கண்காணிப்பாளர்";
  @override
  String get labelRunningTracker => "இயங்கும் டிராக்கர்";
  @override
  String get labelAddStep => "படி சேர்க்கவும்";
  @override
  String get labelSelectDate => "தேதியைத் தேர்ந்தெடுக்கவும்";
  @override
  String get labelJoggingTracker => "ஜாகிங் டிராக்கர்";
  @override
  String get labelCaloriesBurn => "கலோரிகள் எரிந்தன";

  // Sleep Tracker
  @override
  String get labelSleepTarget => "தூக்க இலக்கு";
  @override
  String get labelTodaySleep => "இன்று தூக்கம்";
  @override
  String get labelSleepProgress => "தூக்கம் முன்னேற்றம்";
  @override
  String get labelTotalSleep => "மொத்த தூக்கம்";
  @override
  String get labelSleepGoal => "தூக்க இலக்கு";
  @override
  String get labelSetNotification => "அறிவிப்பை அமைக்கவும்";
  @override
  String get labelStartTime => "ஆரம்பிக்கும் நேரம்";
  @override
  String get labelEndTime => "முடிவு நேரம்";
  @override
  String get labelSelect => "தேர்ந்தெடு";
  @override
  String get labelSat => "சனி";
  // @override
  // String get labelSave => "சேமிக்கவும்";
  @override
  String get labelStart => "தொடங்கு";
  @override
  String get labelEnd => "முடிவு";
  @override
  String get labelType => "வகை";
  @override
  String get labelIsConnected => "இணைக்கப்பட்டுள்ளது";

  // @override
  // String get labelMensurationCycle => "சுழற்சி அளவீடு";

  @override
  String get labelTrackAndManage =>
      "சிறந்த நுண்ணறிவுகளுக்கு உங்கள் மாதவிடாய் சுழற்சியைக் கண்காணித்து நிர்வகிக்கவும்";

  @override
  String get labelMensurationStatus => "அளவீட்டு நிலை";

  @override
  String get labelDaysLength => "நாட்கள் நீளம்";

  @override
  String get labelDay => "நாள்";

  @override
  String get labelNextDate => "அடுத்த தேதி";

  @override
  String get labelLastPeriodStartDate => "கடைசி காலம் தொடங்கும் தேதி";

  @override
  String get labelAverageCycleLength => "சராசரி சுழற்சி நீளம்";

  @override
  String get labelChange => "மாற்றவும்";

  // Common Messages
  @override
  String get messageSent => "செய்தி அனுப்பப்பட்டது";

  @override
  String get thankYouForContactingUs => "எங்களை தொடர்பு கொண்டதற்கு நன்றி!";

  @override
  String get alert => "எச்சரிக்கை";

  @override
  String get fillInAllFields => "அனைத்து துறைகளையும் நிரப்பவும்.";

  @override
  String get thankYouFeedbackSubmitted => "உங்கள் கருத்து சமர்ப்பிக்கப்பட்டது.";

  @override
  String get resetPassword => "கடவுச்சொல்லை மீட்டமைக்க";

  @override
  String get dishAdded => "டிஷ் சேர்க்கப்பட்டது!";

  @override
  String get dishAndIngredientsAddedSuccessfully =>
      "டிஷ் மற்றும் பொருட்கள் வெற்றிகரமாக சேர்க்கப்பட்டது.";

  @override
  String get failed => "தோல்வி";

  @override
  String get error => "பிழை";

  @override
  String get enterBloodGlucoseLevel =>
      "இரத்த குளுக்கோஸ் அளவை mg / dL இல் உள்ளிடவும்";

  @override
  String get enterBloodPressureLevel => "இரத்த அழுத்த அளவை mmHg இல் உள்ளிடவும்";

  @override
  String get enterHeartLevel =>
      "தயவு செய்து இதயத் துடிப்பை நிமிடத்திற்கு துடிக்கிறது (BPM).";

  @override
  String get cancel => "ரத்து செய்";

  @override
  String get submit => "சமர்ப்பிக்கவும்";

  @override
  String get valueCannotBeGreaterThan100 =>
      "மதிப்பு 100 ஐ விட அதிகமாக இருக்கக்கூடாது.";

  @override
  String get bloodStatusSubmittedSuccessfully =>
      "இரத்த நிலை வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது.";

  @override
  String get failedToSubmitBlood => "இரத்தத்தை சமர்ப்பிக்க முடியவில்லை.";

  @override
  String get enterHeartLevel1to100 =>
      "தயவு செய்து இதயத் துடிப்பை நிமிடத்திற்கு துடிக்கிறது (BPM).";

  @override
  String get heartLevelSubmittedSuccessfully =>
      "இதய நிலை வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது.";

  @override
  String get enterOxygenSaturationLevel1to100 =>
      "ஆக்ஸிஜன் செறிவு நிலை 1% -100% உள்ளிடவும்";

  @override
  String get oxygenLevelSubmittedSuccessfully =>
      "ஆக்ஸிஜன் அளவு வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது.";

  @override
  String get updateData => "தரவைப் புதுப்பிக்கவும்";

  @override
  String get selectLastPeriodStartDate =>
      "கடைசி காலம் தொடங்கும் தேதியைத் தேர்ந்தெடுக்கவும்";

  @override
  String get update => "புதுப்பிக்கவும்";

  @override
  String get failedToFetchBooks =>
      "புத்தகங்களைப் பெறுவதில் தோல்வி. தயவு செய்து மீண்டும் முயற்சிக்கவும்.";

  @override
  String get errorOccurred => "பிழை ஏற்பட்டது:";

  @override
  String get invalidEndTime => "தவறான முடிவு நேரம்";

  @override
  String get chooseTimeWithin1Hour =>
      "தொடக்க நேரத்திலிருந்து 1 மணி நேரத்திற்குள் நேரத்தைத் தேர்ந்தெடுக்கவும்.";

  @override
  String get notificationSaved => "அறிவிப்பு சேமிக்கப்பட்டது";

  @override
  String get notificationSetSuccessfully =>
      "அறிவிப்பு வெற்றிகரமாக அமைக்கப்பட்டது.";

  @override
  String get thereIsSomeError => "சில பிழை உள்ளது.";

  @override
  String get watchDisconnected => "வாட்ச் துண்டிக்கப்பட்டது";

  @override
  String get watchDisconnectedSuccessfully =>
      "வாட்ச் வெற்றிகரமாக துண்டிக்கப்பட்டது.";

  @override
  String get addCup => "கோப்பை சேர்க்கவும்";

  @override
  String get numberOfCups => "கோப்பைகளின் எண்ணிக்கை";

  @override
  String get addCupCapacityInMl => "கப் கொள்ளளவு மிலியில் சேர்க்கவும்";

  @override
  String get cupCapacitySubmittedSuccessfully =>
      "கோப்பை திறன் வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது.";

  @override
  String get pleaseEnterValidValuesForAllFields =>
      "எல்லா புலங்களுக்கும் சரியான மதிப்புகளை உள்ளிடவும்.";

  @override
  String get enterWater => "தண்ணீரை உள்ளிடவும்";

  @override
  String get waterGoalLiters => "நீர் இலக்கு (லிட்டர்)";

  @override
  String get waterSubmittedSuccessfully =>
      "நீர் இலக்கு வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது.";

  @override
  String get addActivityData => "செயல்பாட்டுத் தரவைச் சேர்க்கவும்";

  @override
  String get enterValue => "மதிப்பை உள்ளிடவும்";

  @override
  String get addStepsData => "படிகள் தரவைச் சேர்க்கவும்";

  @override
  String get numberOfSteps => "படிகளின் எண்ணிக்கை";

  @override
  String get stepsDataSubmittedSuccessfully =>
      "படிகள் தரவு வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது.";

  @override
  String get enterSleepTarget => "தூக்க இலக்கை உள்ளிடவும்";

  @override
  String get sleepTargetInHours => "மணிநேரங்களில் தூக்க இலக்கு";

  @override
  String get addYourSleepDuration => "உங்கள் தூக்க கால அளவைச் சேர்க்கவும்";

  @override
  String get enterDurationInMinutes => "நிமிடங்களில் கால அளவை உள்ளிடவும்:";

  @override
  String get add => "கூட்டு";

  @override
  String get ok => "சரி";

  @override
  String get csvFileSavedTo => "CSV கோப்பு சேமிக்கப்பட்டது";

  @override
  String get ageMustBeBetween2And100Years =>
      "வயது 2 முதல் 100 வயதுக்குள் இருக்க வேண்டும்";

  @override
  String get next => "அடுத்தது";

  @override
  String get register => "பதிவு";

  @override
  String get oopsSomethingWentWrong => "அச்சச்சோ! ஏதோ தவறு நடந்துவிட்டது";

  @override
  String get errorFetchingMeals => "உணவைப் பெறும்போது பிழை ஏற்பட்டது:";

  @override
  String get reviewAddedSuccessfully =>
      "மதிப்பாய்வு வெற்றிகரமாக சேர்க்கப்பட்டது!";

  @override
  String get failedToAddReview => "மதிப்பாய்வைச் சேர்க்க முடியவில்லை:";

  @override
  String get alreadyInCart => "ஏற்கனவே வண்டியில்";

  @override
  String get addedToCart => "வண்டியில் சேர்க்கப்பட்டது";

  @override
  String get quantityNotBetween1And2 =>
      "அளவு 2 க்கு மேல் இல்லை மற்றும் 1 க்கு குறைவாக இல்லை";

  String get createcustomdish => "தனிப்பயன் உணவை உருவாக்கவும்";
  String get quantityingram => "அளவு (கிராம்)";
  String get labelCaloriestaken => 'ஆற்றல்';
  String get mainlabelEarlyMorning => "அதிகாலை";
  String get mainlabelMidMorning => "நண்பகல்";
  String get mainlabelEvening => "சாயங்காலம்";
  String get mainlabelBedtime => "உறங்கும் நேரம்";
  String get mainlabelTimeSpentOn => "வெவ்வேறு நடவடிக்கைகளில் செலவிடும் நேரம்";
  String get mainlabelHealthCalculator => "சுகாதார கால்குலேட்டர்";
  String get mainlabelStepProgress => "படி முன்னேற்றம்";
  String get mainlabelRealTimeIntakes => "உண்மையான நேர உட்கொள்ளல்கள்";
  String get mainlabelCaloriesBurnProgress => "கலோரிகள் எரிந்த முன்னேற்றம்";
  String get mainlabelCaloriesBurnBreakdown => "கலோரிகள் எரிந்த முறிவு";
  String get mainlabelHeartReportsTrends => "இதய அறிக்கைகள் போக்குகள்";
  String get mainlabelOxygenStatus => "ஆக்ஸிஜன் நிலை";
  String get mainlabelNoRecord => "எனக்கு ஞாபகம் இல்லை";
  String get mainlabelSystolicBloodPressure => "சிஸ்டாலிக் இரத்த அழுத்தம்";
  String get mainlabelMeasuredon => "அன்று அளவிடப்படுகிறது";
  String get mainlabelEnterBloodPressure => "இரத்த அழுத்தத்தை உள்ளிடவும்";
  String get mainlabelBloodPressure => "இரத்த அழுத்தம்";
  String get mainlabelDiastolicBloodPressure => "டயஸ்டாலிக் இரத்த அழுத்தம்";
  String get mainlabelBloodGlucose => "இரத்த குளுக்கோஸ்";
  String get mainlabelHeartStatus => "இதய நிலை";
  String get mainlabelAllExercise => "அனைத்து உடற்பயிற்சி";
  String get mainlabelCleaningOrMopping => "சுத்தம் செய்தல் அல்லது துடைத்தல்";
  String get mainlabelGardening => "தோட்டம்";
  String get mainlabelWatchingTV => "டிவி பார்ப்பது";
  String get mainlabelCycling => "சைக்கிள் ஓட்டுதல்";
  String get mainlabelRunning => "ஓடுதல்";
  String get mainlabelWalking => "நடைபயிற்சி";
  String get mainlabelShuttle => "விண்கலம்";
  String get mainlabelTableTennis => "டேபிள் டென்னிஸ்";
  String get mainlabelTennis => "டென்னிஸ்";
  String get mainlabelVolleyBall => "கைப்பந்து";
  String get mainlabelDancing => "நடனம்";
  String get mainlabelFishing => "மீன்பிடித்தல்";
  String get mainlabelShopping => "கடையில் பொருட்கள் வாங்குதல்";
  String get mainlabelTyping => "தட்டச்சு";
  String get mainlabelSleeping => "தூங்குகிறது";
  String get mainlabelStanding => "நிற்கும்";
  String get mainlabelSitting => "உட்கார்ந்து";
  String get mainlabelClickToStartActivity =>
      "செயல்பாட்டைத் தொடங்க கிளிக் செய்யவும்";
  String get mainlabelBMICalculator => "பிஎம்ஐ கால்குலேட்டர்";
  String get mainlabelBMRCalculator => "பிஎம்ஆர் கால்குலேட்டர்";
  String get mainlabelDownloadActivityReportInCsv =>
      "csv இல் செயல்பாட்டு அறிக்கையைப் பதிவிறக்கவும்";
  String get mainlabelSelectStartDate => "தொடக்க தேதியைத் தேர்ந்தெடுக்கவும்";
  String get mainlabelSelectEndDate => "முடிவுத் தேதியைத் தேர்ந்தெடுக்கவும்";
  String get mainlabelDownloadFile => "பதிவிறக்க கோப்பு";
  String get mainlabelDate => "தேதி";
  String get mainlabelValue => "மதிப்பு";
  String get mainlabelLink => "இணைப்பு";
  String get mainlabelNoNotificationFound => "எந்த அறிவிப்பும் இல்லை";
  String get mainlabelTotalNutritionTaken => "= எடுக்கப்பட்ட மொத்த ஊட்டச்சத்து";
  String get mainlabelSearchFood => "சமையல் குறிப்புகளைத் தேடுங்கள்";
  String get mainlabelSelectFromPersonalFood =>
      "தனிப்பட்ட சமையல் குறிப்புகளிலிருந்து தேர்ந்தெடுக்கவும்";
  String get mainlabelRecipeName => "செய்முறை பெயர்";
  String get mainlabelSelectDate => "தேதியைத் தேர்ந்தெடுக்கவும்";
  String get mainlabelNutrientOfAllIngredientsRaw =>
      "அனைத்து பொருட்களின் ஊட்டச்சத்து (பச்சையாக)";
  String get mainlabelNutrientsCompostionOfCookedWeight =>
      "சமைத்த எடையின் ஊட்டச்சத்து கலவை";
  String get mainlabelWantToEditThisRecipyFollowThe =>
      "இந்த செய்முறையைத் திருத்த வேண்டுமா? பின்பற்றவும்";
  String get mainlabelAddIngredientFrom => "இருந்து மூலப்பொருள் சேர்க்கவும்";
  String get mainlabelAddFromNutrientSpecifcFood =>
      "ஊட்டச்சத்து குறிப்பிட்ட உணவில் இருந்து சேர்க்கவும்";
  String get mainlabelAddFromAllFoods =>
      "அனைத்து உணவுகளிலிருந்தும் சேர்க்கவும்";
  String get mainlabelNumberOfServing => "சேவைகளின் எண்ணிக்கை";
  String get mainlabelWeightInG => "எடை (கிராம்)";
  String get mainlabelEditIngredientsWeight =>
      "பொருட்களின் எடையைத் திருத்தவும்";
  String get mainlabelIngredient => "மூலப்பொருள்";
  String get mainlabelNewWeightInG => "புதிய எடை (கிராம்)";
  String get mainlabelCancel => "ரத்து செய்";
  String get mainlabelUpdate => "மேம்படுத்தல்";
  String get mainlabelCookedWeightInG => "சமைத்த எடை (கிராம்)";
  String get mainlabelEnterWeight => "எடையை உள்ளிடவும்";
  String get mainlabelEditRecipy => "செய்முறையைத் திருத்தவும்";
  String get mainlabelAlert => "எச்சரிக்கை";
  String get mainlabelToSeeNutritionCompositionPleaseEnterNoOfServing =>
      "ஊட்டச்சத்து கலவையைப் பார்க்க, சேவைகளின் எண்ணிக்கையை உள்ளிடவும்";
  String get mainlabelNutrirntsIn100CookedWeight =>
      "100 (சமைத்த) எடையில் ஊட்டச்சத்துக்கள்";
  String get mainlabelSetNutritionTargetInG =>
      "ஊட்டச்சத்து இலக்கை கிராமில் நிர்ணயம் செய்யுங்கள்";
  String get mainlabelFoodAnalyse => "ஆராயுங்கள்";
  String get mainlabelExploreTop10Foods => "முதல் 10 உணவுகளை ஆராயுங்கள்";
  String get mainlabelSearchCookedFood =>
      "சமையல் குறிப்புகளில் ஊட்டச்சத்துக்களைத் தேடுங்கள்";
  String get mainlabelNutritionBasedOnEAR =>
      "EAR அடிப்படையிலான ஊட்டச்சத்து தேவை";
  String get mainlabelDietDiary => "உணவு நாட்குறிப்பு";
  String get mainlabelRecipes => "சமையல் வகைகள்";
  String get mainlabelSearchByFoodName => "உணவின் பெயரால் தேடுங்கள்";
  String get mainlabelAllRecipeOf100G => "அனைத்து செய்முறையும் 100 கிராம்";
  String get mainlabelNutritionRequirement => "ஊட்டச்சத்து தேவை";
  String get mainlabelGender => "பாலினம்";
  String get mainlabelParticulars => "விவரங்கள்";
  String get mainlabelBodyWeight => "உடல் எடை";
  String get mainlabelDietaryDiaryReports => "ஊட்டச்சத்து உட்கொள்ளல்";
  String get mainlabelTotalNutritionTakenOn => "எடுக்கப்பட்ட மொத்த ஊட்டச்சத்து";
  String get mainlabelAttachImage => "படத்தை இணைக்கவும்";
  String get mainlabelFixedRecipy => "நிலையான செய்முறை";
  String get mainlabelFoodInDetail => "உணவு விவரம்";
  String get TextAppNutrientsInMyFood =>
      "உணவுகளில் உள்ள ஊட்டச்சத்துக்களைத் தேடுங்கள்";
  String get TextAppMyActivity => "எனது செயல்பாடு";
  String get TextAppToday => "இன்று";
  String get TextAppMyNutrientRequirements => "எனது ஊட்டச்சத்து தேவைகள்";
  String get TextAppTotalNutrition => "மொத்த ஊட்டச்சத்து";
  String get TextAppTaken => "எடுக்கப்பட்டது";
  String get TextAppRatings => "மதிப்பீடுகள்";
  String get TextAppSearchComponents => "தேடல் கூறுகள்";
  String get TextAppTotalNutrientTaken => "இன்று எனது ஊட்டச்சத்து உட்கொள்ளல்";
  String get TextAppShareApp => "ஆப்ஸைப் பகிரவும்";
  String get TextAppNoNotificationsFound => "அறிவிப்புகள் எதுவும் இல்லை";
  String get TextAppConnectWatch => "கடிகாரத்தை இணைக்கவும்";
  String get TextAppYourBMIIs => "உங்கள் பிஎம்ஐ";
  String get TextAppBMI => "பிஎம்ஐ";
  String get TextAppBMICategories => "பிஎம்ஐ வகைகள்";
  String get TextAppUnderweight => "எடை குறைவு";
  String get TextAppNormal => "இயல்பானது";
  String get TextAppOverweight => "அதிக எடை";
  String get TextAppObesity => "உடல் பருமன்";
  String get TextAppSelectDate => "தேதியைத் தேர்ந்தெடுக்கவும்";
  String get TextAppOxygen => "ஆக்ஸிஜன்";
  String get TextAppBlood => "இரத்தம்";
  String get TextAppNoRecord => "விவரம் இல்லை";
  String get TextAppAllExercise => "அனைத்து உடற்பயிற்சி";
  String get TextAppCleaningOrMopping => "சுத்தம் செய்தல் அல்லது துடைத்தல்";
  String get TextAppGardening => "தோட்டம்";
  String get TextAppWatchingTV => "டிவி பார்ப்பது";
  String get TextAppCycling => "சைக்கிள் ஓட்டுதல்";
  String get TextAppRunning => "ஓடுதல்";
  String get TextAppWalking => "நடைபயிற்சி";
  String get TextAppShuttle => "விண்கலம்";
  String get TextAppTableTennis => "டேபிள் டென்னிஸ்";
  String get TextAppTennis => "டென்னிஸ்";
  String get TextAppVolleyBall => "வாலி பால்";
  String get TextAppDancing => "நடனம்";
  String get TextAppFishing => "மீன்பிடித்தல்";
  String get TextAppShopping => "கடையில் பொருட்கள் வாங்குதல்";
  String get TextAppTyping => "தட்டச்சு";
  String get TextAppSleeping => "தூங்குகிறது";
  String get TextAppStanding => "நிற்கும்";
  String get TextAppSitting => "உட்கார்ந்து";
  String get TextAppClickStartToStartActivity =>
      "செயல்பாட்டைத் தொடங்க, தொடங்கு என்பதைக் கிளிக் செய்யவும்";
  String get TextAppCaloriesBurn => "கலோரிகள் எரிந்தன";
  String get TextAppAddDurationManually => "கால அளவை கைமுறையாகச் சேர்க்கவும்";
  String get TextAppStartOrMopping => "தொடங்கவும் அல்லது துடைக்கவும்";
  String get TextAppMale => "ஆண்";
  String get TextAppFemale => "பெண்";
  String get TextAppWeightManager => "என் உடல் எடையைக் கண்காணிக்கவும்";
  String get TextAppUpdateWeight => "எடையைப் புதுப்பிக்கவும்";
  String get TextAppSetWeightGoal => "எடை இலக்கை அமைக்கவும்";
  String get TextAppCurrentWeight => "தற்போதைய எடை";
  String get TextAppWeightProgress => "எடை முன்னேற்றம்";
  String get TextAppPrevious30Days => "முந்தைய 30 நாட்கள்";
  String get TextAppYourWeightGoalIsSet => "உங்கள் இலக்கு";
  String get TextAppMaintain => "பராமரிக்கவும்";
  String get TextAppInitialWeightOf => "ஆரம்ப எடை";
  String get TextAppFinalWeightOf => "சமீபத்திய எடை";
  String get TextAppWeight => "எடை";
  String get TextAppYouAreNotYetAchievingYourWeightGoalKeepGoing =>
      "உங்கள் எடை இலக்கை நீங்கள் இன்னும் அடையவில்லை. தொடருங்கள்!";
  String get TextAppYouAreAchievedYourWeightGoalKeepGoing =>
      "உங்கள் எடை இலக்கை அடைந்துவிட்டீர்கள். தொடருங்கள்!";
  String get TextAppAndYourWeightChangeIsSet =>
      "மற்றும் உங்கள் எடை மாற்றம் அமைக்கப்பட்டுள்ளது";
  String get TextApp1NutrientsInMyFood => "என் உணவில் உள்ள ஊட்டச்சத்துக்கள்";
  String get TextAppSearchNutrientsInRawFoods =>
      "மூல உணவுகளில் ஊட்டச்சத்துக்களைத் தேடுங்கள்";
  String get TextAppRawIngredients => "மூல பொருட்கள்";
  String get TextAppSearchRawFoodByName => "பெயரால் மூல உணவைத் தேடுங்கள்";
  String get TextApp1MyActivity => "எனது செயல்பாட்டு அறிக்கை";
  String get TextAppCheckOthersDates => "மற்ற தேதிகளைச் சரிபார்க்கவும்";
  String get TextAppYour24HoursChart => "உங்கள் 24 மணிநேர விளக்கப்படம்";
  String get TextAppActivity => "செயல்பாடு";
  String get TextAppOthers => "மற்றவைகள்";
  String get TextAppExerciseDetails => "உடற்பயிற்சி விவரங்கள்";
  String get TextAppActivityType => "செயல்பாட்டு வகை";
  String get TextAppDuration => "கால அளவு";
  String get TextAppMyActivityOfCustomDates =>
      "தனிப்பயன் தேதிகளின் எனது செயல்பாடு";
  String get TextAppOurCustomerFeedback => "எங்கள் வாடிக்கையாளர் கருத்து";
  String get TextAppOverallRatings => "ஒட்டுமொத்த மதிப்பீடுகள்";
  String get TextAppEnterCookedWeight => "சமைத்த எடையை உள்ளிடவும்";
  String get TextAppCookedWeightGram => "சமைத்த எடை (கிராம்)";
  String get TextAppNutrientIn100gCooked => "100 கிராம் (சமைத்த) ஊட்டச்சத்து";
  String get TextAppEnterServingSize => "பரிமாறும் அளவை உள்ளிடவும்";
  String get TextAppSearchByRecipeName => "செய்முறை பெயர் மூலம் தேடவும்";
  String get TextAppMyPersonalRecipe => "எனது தனிப்பட்ட செய்முறை";
  String get TextAppFixedRecipe => "நிலையான செய்முறை";
  String get TextApp2NutrientsInMyFood => "என் உணவில் உள்ள சத்துக்கள்";
  String get TextAppMyDietDiary => "என் டயட் டைரி";
  String get TextApp2MyActivity => "எனது செயல்பாடு";
  String get TextAppDownloadFile => "பதிவிறக்க கோப்பு";
  String get TextAppStartMyNewDietDiary =>
      "எனது புதிய டயட் டைரியைத் தொடங்குங்கள்";
  String get TextAppGoogle => "கூகிள்";
  String get TextAppFacebook => "முகநூல்";
  String get TextAppLinkedin => "Linkedin";
  String get TextAppTwitter => "ட்விட்டர்";
  String get TextAppContactUs => "எங்களை தொடர்பு கொள்ள";
  String get TextAppReportBug => "பிழையைப் புகாரளிக்கவும்";
  String get TextAppAttachImage => "படத்தை இணைக்கவும்";
  String get TextAppResetPassword => "கடவுச்சொல்லை மீட்டமைக்க";
  String get TextAppNINAppCreditsPage => "NIN ஆப்ஸ் கிரெடிட்ஸ் பக்கம்";
  String get NINTextOopsSomethingWentWrong =>
      "அச்சச்சோ! ஏதோ தவறு நடந்துவிட்டது";
  String get NINTextPleaseEnterAllFields => "அனைத்து புலங்களையும் உள்ளிடவும்";
  String get NINTextSubmittedSuccessfully1 => "வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது";
  String get NINTextSubmittedSuccessfully2 => "வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது";
  String get NINTextFitbitAuthentication => "ஃபிட்பிட் அங்கீகாரம்";
  String get NINTextHours => "மணி";
  String get NINTextMinutes => "நிமிடங்கள்";
  String get NINTextEnterDurationFor => "இதற்கான கால அளவை உள்ளிடவும்";
  String get NINTextTimerRunning => "டைமர் இயங்குகிறது";
  String get NINTextPleaseStopTheTimerBeforeSubmitting =>
      "சமர்ப்பிக்கும் முன் டைமரை நிறுத்தவும்";
  String get NINTextTotalDuration => "மொத்த கால அளவு";
  String get NINTextSec => "நொடி";
  String get NINTextStartYourActivity => "உங்கள் செயல்பாட்டைத் தொடங்குங்கள்!";
  String get NINTextPause => "இடைநிறுத்தம்";
  String get NINTextReset => "மீட்டமை";
  String get NINTextError => "பிழை";
  String get NINTextPleaseEnterCookedWeightAndServingSize =>
      "சமைத்த எடை மற்றும் பரிமாறும் அளவை உள்ளிடவும்";
  String get NINTextEditIngredient => "மூலப்பொருளைத் திருத்தவும்";
  String get NINTextAlert => "எச்சரிக்கை";
  String get NINTextEnterWeightFor => "எடையை உள்ளிடவும்";
  String get NINTextNewWeightGram => "புதிய எடை (கிராம்)";
  String get NINTextEditRecipeName => "செய்முறை பெயரைத் திருத்தவும்";
  String get NINTextNewRecipeName => "புதிய செய்முறை பெயர்";
  String get NINTextSubmitted => "சமர்ப்பிக்கப்பட்டது";
  String get NINTextSuccess => "வெற்றி";
  String get NINTextDietaryDiaryReportSavedTo =>
      "உணவியல் நாட்குறிப்பு அறிக்கை சேமிக்கப்பட்டது";
  String get NINTextErrorSavingFile => "கோப்பை சேமிப்பதில் பிழை";
  String get NINTextClose => "நெருக்கமான";
  String get NINTextIWantTo => "எனக்கு வேண்டும்";
  String get NINTextGain => "ஆதாயம்";
  String get NINTextMaintain => "பராமரிக்கவும்";
  String get NINTextLose => "இழக்க";
  String get NINTextWeightChangeKg => "எடை மாற்றம் (கிலோ)";
  String get NINTextAddNewWeight => "புதிய எடையைச் சேர்க்கவும்";
  String get NINTextEnterWeight => "எடையை உள்ளிடவும்";
  String get NINTextOf100Gram => "100 கிராம்";
  String get NINTextProximateComposition => "நெருங்கிய கலவை";
  String get NINTextVitamins => "வைட்டமின்கள்";
  String get NINTextMinerals => "கனிமங்கள்";
  String get NINTextTotalSaturatedFattyAcids =>
      "மொத்த நிறைவுற்ற கொழுப்பு அமிலங்கள்";
  String get NINTextAllRecipeOf100Grams => "அனைத்து செய்முறையும் 100 கிராம்";
  String get NINTextOurCustomerFeedback => "எங்கள் வாடிக்கையாளர் கருத்து";
  String get NINTextOverallRatings => "ஒட்டுமொத்த மதிப்பீடுகள்";
  String get NINTextRateUs => "எங்களை மதிப்பிடு";
  String get NINTextBookDetails => "புத்தக விவரங்கள்";
  String get NINTextOne => "ஒன்று";
  String get NINTextWeightOf => "wt. இன்";
  String get NINTextSelectStartDate => "தொடக்க தேதியைத் தேர்ந்தெடுக்கவும்";
  String get NINTextSelectEndDate => "முடிவுத் தேதியைத் தேர்ந்தெடுக்கவும்";
  String get NINTextNoData => "தகவல் இல்லை";
  String get NINTextWorkLevel => "வேலை நிலை";
  String get NINTextOldPassword => "பழைய கடவுச்சொல்";
  String get NINTextNewPassword => "புதிய கடவுச்சொல்";
  String get NINTextUpdateProfile => "சுயவிவரத்தைப் புதுப்பிக்கவும்";
  String get NINTextChangeImage => "படத்தை மாற்றவும்";
  String get NINTextNoFavouriteFoodFound =>
      "பிடித்த உணவு எதுவும் கிடைக்கவில்லை";
  String get NINTextCookedQuantity => "சமைத்த அளவு";
  String get NINTextServingQuantity => "பரிமாறும் அளவு";
  String get NINTextNutrientInformation => "ஊட்டச்சத்து தகவல்";
  String get NINTextIngredient => "மூலப்பொருள்";
  String get NINTextMealsTakenOn => "எடுத்த சாப்பாடு";
  String get NINTextPercentage => "சதவிதம்";
  String get NINTextEAR => "காது";
  String get NINTextValue => "மதிப்பு";
  String get NINTextNutrient => "ஊட்டச்சத்து";
  String get NINTextEnergyKcal => "ஆற்றல் (கிலோ கலோரி)";
  String get NINTextProteinG => "புரதம் (கிராம்)";
  String get NINTextFatG => "கொழுப்பு (கிராம்)";
  String get NINTextCarbohydratesG => "கார்போஹைட்ரேட் (கிராம்)";
  String get NINTextCalciumMg => "கால்சியம் (மிகி)";
  String get NINTextFiberG => "ஃபைபர் (கிராம்)";
  String get NINTextIronMg => "இரும்பு (மிகி)";
  String get NINTextZincMg => "துத்தநாகம் (மிகி)";
  String get NINTextMagnesiumMg => "மெக்னீசியம் (மிகி)";
  String get NINTextThiamineB1Mg => "தியாமின் (பி1) (மிகி)";
  String get NINTextRiboflavinB2Mg => "ரிபோஃப்ளேவின் (பி2) (மிகி)";
  String get NINTextNiacinB3Mg => "நியாசின் (B3) (மிகி)";
  String get NINTextFolatesB9Mcg => "ஃபோலேட்ஸ் (B9) (mcg)";
  String get NINTextRetinolVitAMcg => "வைட்டமின் ஏ (எம்சிஜி)";
  String get VitaminCmg => "வைட்டமின் சி (மிகி)";
  String get Iodinemcg => "அயோடின் (mcg)";
  String get serving => "சேவை";
  String get Mynutritionstatus => "எனது ஊட்டச்சத்து நிலை";

  String get ninTextMyHealthStatus => 'எனது உடல்நிலை';
  String get ninTextNutrientsInRawFoods =>
      'மூல உணவுகளில் உள்ள ஊட்டச்சத்துக்கள்';
  String get ninTextNutrientsInRecipes =>
      'சமையல் குறிப்புகளில் உள்ள ஊட்டச்சத்துக்கள்';
  String get ninTextIcmrNinMyPlateForTheDay => 'ICMR-NIN அன்றைக்கு என் தட்டு';
  String get ninTextToday => 'இன்று';
  String get ninTextTrackMyActivity => 'எனது செயல்பாட்டைக் கண்காணிக்கவும்';
  String get ninTextMyHeartRate => 'என் இதயத்துடிப்பு';
  String get ninTextMyWaterIntake => 'என் நீர் உட்கொள்ளல்';
  String get ninTextSleepTracker => 'ஸ்லீப் டிராக்கர்';
  String get ninTextLit => 'லிட்';
  String get ninTextRecordMyBloodPressure =>
      'எனது இரத்த அழுத்தம் / இரத்த குளுக்கோஸ் / SPO2 ஐ பதிவு செய்யுங்கள்';
  String get ninTextNutritionEducationContent => 'ஊட்டச்சத்து கல்வி உள்ளடக்கம்';
  String get ninTextMyNutrientIntake => 'எனது ஊட்டச்சத்து உட்கொள்ளல்';
  String get ninTextOn => 'அன்று';
  String get ninTextWithReferenceToEAR => 'EAR பற்றிய குறிப்புடன்';
  String get ninTextAchieveYourHealthGoals =>
      'உங்கள் ஆரோக்கிய இலக்குகளை அடையுங்கள்';
  String get ninTextPercentage => 'சதவிதம்';
  String get ninTextMyPreviousDietDiaries => 'எனது முந்தைய டயட் டைரிகள்';
  String get ninTextRecordReviewSleep =>
      'தூக்கத்தை பதிவு செய்யவும் / மதிப்பாய்வு செய்யவும்';
  String get ninTextHours => 'மணி';
  String get ninTextIngredient => 'மூலப்பொருள்';
  String get ninTextOthersSpecify => 'மற்றவர்கள் குறிப்பிடுகின்றனர்';
  String get ninTextAddNewIngredient => 'புதிய மூலப்பொருள் சேர்க்கவும்';
  String get ninTextFoodName => 'உணவின் பெயர்';
  String get ninTextSource => 'ஆதாரம்';
  String get ninTextEnterBrandAndProductName =>
      'பிராண்ட் மற்றும் தயாரிப்பு பெயரை உள்ளிடவும்';
  String get ninTextEnterAuthorDetails =>
      'ஆசிரியரின் பெயர், ஆண்டு, இதழ், பக்கம் ஆகியவற்றை உள்ளிடவும்';
  String get ninTextEnterFctName => 'FCT இன் பெயரை உள்ளிடவும்';
  String get ninTextName => 'பெயர்';
  String get ninTextProductName => 'பொருளின் பெயர்';
  String get ninTextSelectStartDate => 'தொடக்க தேதியைத் தேர்ந்தெடுக்கவும்';
  String get ninTextSelectEndDate => 'முடிவுத் தேதியைத் தேர்ந்தெடுக்கவும்';
  String get ninTextNoExercise => 'உடற்பயிற்சி இல்லை';
  String get ninTextDevelopedWithExpertiseAndInputs =>
      'வளர்ச்சி மற்றும் மேம்பட்ட கம்ப்யூட்டிங் மையம் (C-DAC) மூலம் NIN இலிருந்து நிபுணத்துவம் மற்றும் உள்ளீடுகளுடன் உருவாக்கப்பட்டது, ஹைதராபாத் மொழி இணைப்பு';
  String get ninTextMyNutrientIntakeToday =>
      'இன்று எனது ஊட்டச்சத்து உட்கொள்ளல்';
  String get ninTextIcmrNationalInstituteOfNutritionAddress =>
      'ICMR - தர்னாகா மெட்ரோ நிலையம் அருகே தேசிய ஊட்டச்சத்து நிறுவனம், ஜமாய்-உஸ்மானியா PO, ஹைதராபாத்-500 007, இந்தியா.';

  String get ninTextKcal => 'கிலோகலோரி';
  String get ninTextKcalPerDay => 'கிலோகலோரி/நாள்';
  String get ninTextDelete => 'அழி';
  String get ninTextDeleteNotification => 'அறிவிப்பை நீக்கு';
  String get ninTextConfirmDeleteNotification =>
      'இந்த அறிவிப்பை நிச்சயமாக நீக்க விரும்புகிறீர்களா?';
  String get ninTextTimeFor => 'ஏய், அது\'s time for';
  String get ninTextFitbitWatch => 'ஃபிட்பிட் வாட்ச்';
  String get ninTextGoogleFitApp => 'Google ஃபிட் பயன்பாடு';
  String get ninTextUnderweight => 'எடை குறைவு';
  String get ninTextNormal => 'இயல்பானது';
  String get ninTextOverweight => 'அதிக எடை';
  String get ninTextObesity => 'உடல் பருமன்';
  String get ninTextMale => 'ஆண்';
  String get ninTextFemale => 'பெண்';
  String get ninTextAgeInYears => 'ஆண்டுகளில் வயது';
  String get ninTextChangeInWeight => 'எடை மாற்றம்';
  String get ninTextSteps => 'படிகள்';
  String get ninTextFor => 'க்கான';
  String get ninTextMinutes => 'நிமிடங்கள்';
  String get ninTextPause => 'இடைநிறுத்தம்';
  String get ninTextReset => 'மீட்டமை';
  String get ninTextStartActivity => 'உங்கள் செயல்பாட்டைத் தொடங்குங்கள்';
  String get ninTextCartIsEmpty => 'உங்கள் வண்டி காலியாக உள்ளது';
  String get ninTextMyPersonalRecipe => 'எனது தனிப்பட்ட செய்முறை';
  String get ninTextSearchByRecipeName => 'செய்முறை பெயர் மூலம் தேடவும்';
  String get ninTextHelpCenter => 'உதவி மையம்';
  String get ninTextCommonProblems => 'பொதுவான பிரச்சனைகள்';
  String get ninTextFAQs => 'அடிக்கடி கேட்கப்படும் கேள்விகள்';
  String get ninTextHowActiveAreYou =>
      'நீங்கள் எவ்வளவு சுறுசுறுப்பாக இருக்கிறீர்கள்';
  String get ninTextVitaminC => 'வைட்டமின் சி (மிகி)';
  String get ninTextVitaminA => 'வைட்டமின் ஏ (IU)';
  String get ninTextSodium => 'சோடியம் (மிகி)';
  String get ninTextJournal => 'இதழ்';
  String get ninTextPage => 'பக்கம்';
  String get ninTextAdequateIntakeCarbs =>
      'கார்போஹைட்ரேட்டுகளுக்கு போதுமான அளவு உட்கொள்ளல் (AI) பரிந்துரைக்கப்படுகிறது: வயது வந்த ஆண்கள் மற்றும் பெண்களுக்கு 130 கிராம்.';
  String get ninTextAdequateIntakeFiber =>
      '** நார்ச்சத்துக்காக AI பரிந்துரைக்கப்படுகிறது: பெண்களுக்கு 25 கிராம் மற்றும் ஆண்களுக்கு 38 கிராம்.';
  String get your => 'உங்கள்';
  String get question1 => 'எனது தனிப்பட்ட விவரங்களைத் திருத்த முடியுமா?';
  String get answer1 =>
      'ஆம். உங்கள் சுயவிவரத்தில் உங்கள் தனிப்பட்ட தரவு திருத்தப்படலாம்.';
  String get linkText1 =>
      'உங்கள் தனிப்பட்ட விவரங்களைத் திருத்த இங்கே கிளிக் செய்யவும்';

  String get question2 => 'எனது தொடர்பு விவரங்களை மாற்ற முடியுமா?';
  String get answer2 =>
      "ஆம். உங்கள் சுயவிவரத்தில் உள்ள 'தனிப்பட்ட தரவு' விருப்பத்திற்குச் செல்வதன் மூலம் உங்கள் தொடர்பு விவரங்களை மாற்றலாம்.";
  String get linkText2 =>
      'உங்கள் தொடர்பு விவரங்களைத் திருத்த இங்கே கிளிக் செய்யவும்';

  String get question3 => 'எனது பயனர் கடவுச்சொல்லை மாற்ற முடியுமா?';
  String get answer3 =>
      "ஆம். உங்கள் சுயவிவரத்தில் உள்ள 'அமைப்பு' விருப்பத்திற்குச் செல்வதன் மூலம் உங்கள் கடவுச்சொல்லை மாற்றலாம்.";
  String get linkText3 => 'உங்கள் கடவுச்சொல்லை மாற்ற இங்கே கிளிக் செய்யவும்';

  String get question4 => 'எனது பிஎம்ஐ எவ்வாறு சரிபார்க்கலாம்?';
  String get answer4 =>
      "முகப்புப் பக்கத்தில் காட்டப்படும் 'ஹெல்த் கால்குலேட்டர்' விருப்பத்தில் கொடுக்கப்பட்டுள்ள 'பிஎம்ஐ கால்குலேட்டரில்' உங்கள் உயரம் மற்றும் உடல் எடையை உள்ளிட்டு உங்கள் பிஎம்ஐ சரிபார்க்கலாம்.";
  String get linkText4 =>
      'பிஎம்ஐ கால்குலேட்டரைப் பயன்படுத்த இங்கே கிளிக் செய்யவும்';

  String get question5 =>
      'கடந்த ஒரு மாதத்திற்கான எனது எடையைக் கண்காணிக்க முடியுமா?';
  String get answer5 =>
      'ஆம். முகப்புப் பக்கத்தில் கொடுக்கப்பட்டுள்ள ‘வெயிட் மேனேஜர்’ ஆப்ஷனில் கடந்த மாதம்/ஆண்டுக்கான உங்கள் உடல் எடையில் ஏற்பட்ட மாற்றங்களின் விவரங்களைப் பார்க்கலாம்.';
  String get linkText5 => 'உங்கள் எடையைக் கண்காணிக்க இங்கே கிளிக் செய்யவும்';

  String get question6 =>
      'ஒரு குறிப்பிட்ட நாளில் எனது ஒட்டுமொத்த உடல் செயல்பாடுகளை எவ்வாறு சரிபார்க்கலாம்?';
  String get answer6 =>
      "முகப்புப் பக்கத்தில் உள்ள 'எனது செயல்பாடு' விருப்பத்திலிருந்து உங்கள் உடல் செயல்பாடுகளைக் கண்காணிக்கலாம்.";
  String get linkText6 => 'உங்கள் செயல்பாட்டைப் பார்க்க இங்கே கிளிக் செய்யவும்';

  String get question7 => 'தண்ணீர் உட்கொள்ளும் நினைவூட்டலை எவ்வாறு அமைப்பது?';
  String get answer7 =>
      'முகப்புப் பக்கத்தில் கொடுக்கப்பட்டுள்ள ‘செட் நோட்டிஃபிகேஷன்’ விருப்பத்தில் தண்ணீர் உட்கொள்ளும் நினைவூட்டலுக்கான நேரத்தை அமைக்கலாம்.';
  String get linkText7 =>
      'தண்ணீர் உட்கொள்ளும் நினைவூட்டலை அமைக்க இங்கே கிளிக் செய்யவும்';

  String get question8 =>
      'எனது ஸ்மார்ட் வாட்சுடன் பயன்பாட்டை எவ்வாறு ஒருங்கிணைப்பது?';
  String get answer8 =>
      'முகப்புப் பக்கத்தில் வழங்கப்பட்டுள்ள ‘கனெக்ட் வாட்ச்’ ஆப்ஷனுக்குச் சென்று உங்கள் ஸ்மார்ட் வாட்சை ஆப்ஸுடன் ஒருங்கிணைக்கலாம்.';
  String get linkText8 =>
      'உங்கள் ஸ்மார்ட் வாட்சை இணைக்க இங்கே கிளிக் செய்யவும்';

  String get question9 =>
      'ஒரே நேரத்தில் எத்தனை அணியக்கூடியவற்றை ஆப்ஸுடன் ஒருங்கிணைக்க முடியும்?';
  String get answer9 =>
      'நீங்கள் ஃபிட்பிட் வாட்ச் மற்றும் கூகுள் ஃபிட்டை ஆப்ஸுடன் ஒருங்கிணைக்கலாம்.';
  String get linkText9 => '';

  String get question10 => 'எந்த ஸ்மார்ட் வாட்ச்கள் ஆப்ஸுடன் இணக்கமாக உள்ளன?';
  String get answer10 => 'ஃபிட்பிட் வாட்ச் மற்றும் கூகுள் ஃபிட்.';
  String get linkText10 => '';

  String get question11 =>
      'என்னிடம் ஸ்மார்ட் வாட்ச் இல்லையென்றால் எனது செயல்பாட்டைக் கண்காணிக்க முடியுமா?';
  String get answer11 =>
      'ஆம், உங்கள் செயல்பாட்டைக் கண்காணிக்கலாம். அதற்கு, கூகுள் ஃபிட் செயலியைப் பதிவிறக்கம் செய்து, கூகுள் அக்கவுண்ட் மூலம் உள்நுழைய வேண்டும், அதே கூகுள் கணக்கின் மூலம் எங்கள் வாட்ச் பிரிவில் உள்நுழைய வேண்டும்.';
  String get linkText11 => '';

  String get question12 => 'எனது தூக்கத்தை நான் எவ்வாறு கண்காணிக்க முடியும்?';
  String get answer12 =>
      'முகப்புப் பக்கத்தில் கொடுக்கப்பட்டுள்ள ஸ்லீப் டிராக்கர் விருப்பத்திற்குச் சென்று உங்கள் தூக்கத்தை வாராந்திர/மாதாந்திர அடிப்படையில் கண்காணிக்கலாம்.';
  String get linkText12 =>
      'உங்கள் தூக்கத்தைக் கண்காணிக்க இங்கே கிளிக் செய்யவும்';

  String get question13 =>
      'பயன்பாட்டின் மூலம் எந்த NIN வெளியீட்டையும் எப்படி வாங்குவது?';
  String get answer13 =>
      "முகப்புப் பக்கத்தில் கொடுக்கப்பட்டுள்ள 'புத்தகக் கடை' விருப்பத்திலிருந்து நீங்கள் NIN வெளியீடுகளை வாங்கலாம்.";
  String get linkText13 => 'புத்தகக் கடைக்குச் செல்ல இங்கே கிளிக் செய்யவும்';

  String get question14 =>
      'எனது தனிப்பட்ட உணவு நாட்குறிப்பை எவ்வாறு உருவாக்குவது?';
  String get answer14 =>
      "'மை டயட் டைரி ஆப்ஷன்' என்பதற்குச் சென்று நாள் முழுவதும் உட்கொள்ளும் உணவின் விவரங்களை உள்ளிடலாம்.";
  String get linkText14 =>
      'உங்கள் உணவு நாட்குறிப்பை உருவாக்க இங்கே கிளிக் செய்யவும்';

  String get question15 =>
      'ஒரு குறிப்பிட்ட ஊட்டச்சத்து நிறைந்த ஒரு செய்முறையை நான் எவ்வாறு தேடுவது?';
  String get answer15 =>
      "முகப்புப் பக்கத்தில் உள்ள 'எனது உணவில் உள்ள ஊட்டச்சத்துக்கள்' தாவலில் கொடுக்கப்பட்டுள்ள 'செய்முறைகளில் ஊட்டச்சத்துக்களை தேடு' விருப்பத்தை நீங்கள் முதலில் தேர்ந்தெடுக்கலாம். மேல் வலது மூலையில் உள்ள கீழ்தோன்றும் பட்டியலில் இருந்து தேவையான ஊட்டச்சத்தை தேர்ந்தெடுக்கவும்.";
  String get linkText15 => 'சமையல் குறிப்புகளைத் தேட இங்கே கிளிக் செய்யவும்';

  String get question16 =>
      'முந்தைய மாதம் சேமிக்கப்பட்ட ஒரு நாளுக்கான எனது ஊட்டச்சத்து உட்கொள்ளலை எவ்வாறு சரிபார்க்கலாம்?';
  String get answer16 =>
      "'உணவு பட்டியல்' பக்கத்தில் உள்ள 'காலண்டர் ஐகானில்' இருந்து ஒரு தேதியைத் தேர்ந்தெடுப்பதன் மூலம் ஒரு குறிப்பிட்ட நாளில் உங்கள் ஊட்டச்சத்து உட்கொள்ளலைப் பார்க்கலாம்.";
  String get linkText16 =>
      'உங்கள் ஊட்டச்சத்து உட்கொள்ளலை சரிபார்க்க இங்கே கிளிக் செய்யவும்';

  String get question17 =>
      'எனது சமையல் குறிப்புகளில் பயன்படுத்தப்படும் மூலப் பொருட்களில் உள்ள சத்துக்களை நான் எவ்வாறு கண்டறிவது?';
  String get answer17 =>
      'முகப்புப் பக்கத்தில் உள்ள ‘எனது உணவில் உள்ள ஊட்டச்சத்துக்கள்’ என்ற தாவலில் கொடுக்கப்பட்டுள்ள ‘பச்சை உணவுகளில் ஊட்டச்சத்துக்களை தேடு’ என்ற விருப்பத்தைத் தேர்ந்தெடுப்பதன் மூலம் குறிப்பிட்ட மூலப்பொருளில் உள்ள ஊட்டச்சத்துக்களை நீங்கள் அறிந்து கொள்ளலாம்.';
  String get linkText17 =>
      'மூல உணவுகளில் உள்ள ஊட்டச்சத்துக்களைத் தேட இங்கே கிளிக் செய்யவும்';

  String get question18 =>
      'ஒரு செய்முறையின் ஊட்டச்சத்து கலவையை நான் எப்படி அறிவது?';
  String get answer18 =>
      'முகப்புப் பக்கத்தில் உள்ள ‘எனது உணவில் உள்ள ஊட்டச்சத்துக்கள்’ என்ற டேப்பில் கொடுக்கப்பட்டுள்ள ‘சேர்ச் சத்துகளை சமையல் குறிப்புகளில் தேடு’ என்ற விருப்பத்தைத் தேர்ந்தெடுப்பதன் மூலம் குறிப்பிட்ட மூலப்பொருளில் உள்ள சத்துக்களை அறிந்து கொள்ளலாம்.';
  String get linkText18 => 'ஊட்டச்சத்து கலவையை அறிய இங்கே கிளிக் செய்யவும்';

  String get question19 =>
      'பயன்பாட்டில் இல்லாத புதிய செய்முறையைச் சேர்க்க முடியுமா?';
  String get answer19 =>
      "ஆம். குறிப்பிட்ட நிலையான செய்முறையின் கீழே கொடுக்கப்பட்டுள்ள இணைப்பைப் பயன்படுத்தி ஏற்கனவே உள்ள செய்முறையை மாற்றலாம் அல்லது டயட் டைரி பக்கத்தில் உள்ள ஒவ்வொரு உணவிற்கும் வழங்கப்படும் 'கஸ்டம்ஸ் டிஷ்' விருப்பத்தை கிளிக் செய்வதன் மூலம் முற்றிலும் புதிய செய்முறையை உருவாக்கலாம்.";
  String get linkText19 =>
      'தனிப்பயன் செய்முறையை உருவாக்க இங்கே கிளிக் செய்யவும்';

  String get question20 =>
      'ஒரு குறிப்பிட்ட உடல்நிலைக்கான உணவுப் பரிந்துரைகளைப் பெற முடியுமா?';
  String get answer20 =>
      "ஆம். முகப்புப் பக்கத்தில் உள்ள 'தேடல் கூறு' விருப்பத்திலிருந்து நீங்கள் சுகாதார பரிந்துரைகள் அல்லது உணவு விளக்கப்பட வழிகாட்டுதல்களைப் பெறலாம்.";
  String get linkText20 => 'உணவுப் பரிந்துரைகளைப் பெற இங்கே கிளிக் செய்யவும்';

  String get question21 =>
      'நான் ஆங்கிலத்தைத் தவிர வேறு மொழியில் பயன்பாட்டைப் பயன்படுத்தலாமா?';
  String get answer21 =>
      "ஆம். உங்கள் சுயவிவரத்தில் வழங்கப்பட்டுள்ள 'அமைப்பு' விருப்பத்திலிருந்து விரும்பிய மொழியைத் தேர்ந்தெடுக்கலாம்.";
  String get linkText21 => 'மொழியை மாற்ற இங்கே கிளிக் செய்யவும்';

  String get ninTextBmiHwading => 'உடல் நிறை குறியீட்டெண் (பிஎம்ஐ):';
  String get ninTextBmiDiscription =>
      'பிஎம்ஐ என்பது ஒரு நபரின் எடையை கிலோகிராமில் உள்ள நபரின் உயரத்தின் சதுரத்தால் மீட்டரில் (கிலோ/மீ2) வகுக்கப்படுகிறது. பிஎம்ஐ வரம்புகள் அதிகப்படியான உடல் கொழுப்பு நோய் மற்றும் இறப்பில் ஏற்படுத்தும் விளைவை அடிப்படையாகக் கொண்டவை மற்றும் அவை கொழுப்புத்தன்மையுடன் நியாயமான முறையில் தொடர்புடையவை. பிஎம்ஐ நோயின் ஆபத்து குறிகாட்டியாக உருவாக்கப்பட்டது; BMI அதிகரிக்கும் போது, ​​சில நோய்களுக்கான ஆபத்தும் அதிகரிக்கிறது. அதிக எடை மற்றும் உடல் பருமன் தொடர்பான சில பொதுவான நிலைமைகள் பின்வருமாறு: அகால மரணம், இருதய நோய்கள், உயர் இரத்த அழுத்தம், கீல்வாதம், சில புற்றுநோய்கள் மற்றும் நீரிழிவு நோய்.';
  String get ninTextbminutritionsta => 'பிஎம்ஐ ஊட்டச்சத்து நிலை';
  String get ninTextNutritionstat => 'ஊட்டச்சத்து நிலை';
  String get ninTextBelow => 'கீழே';
  String get ninTextPreobesity => 'முன் உடல் பருமன்';

  String get ninTextbesity => 'உடல் பருமன் வகுப்பு I';
  String get ninTextbesity2 => 'உடல் பருமன் வகுப்பு II';
  String get ninTextbesity3 => 'உடல் பருமன் வகுப்பு II';
  String get ninTextBMRfull => 'அடிப்படை வளர்சிதை மாற்ற விகிதம் (BMR)';
  String get ninTextBMRDiscription =>
      'அடிப்படை வளர்சிதை மாற்ற விகிதம் (BMR) என்பது ஒரு நபர் ஓய்வில் இருக்கும்போது ஆற்றலைச் செலவழிக்கும் விகிதமாகும்.';
  String get ninTextPreviousdays => 'முந்தைய 30 நாட்கள்';
  String get ninTextason => 'ஒரு மகன்';
  String get ninTextYearly => 'ஆண்டுதோறும்';
  String get ninTextabove => 'மேலே';
  String get ninTextAchieveyourhealthgoal =>
      'உங்கள் ஆரோக்கிய இலக்கை அடையுங்கள்';
  String get heavyDescription =>
      'ஒவ்வொரு நாளும் ஒரு மணி நேரத்திற்கும் மேலாக ஓடுதல், சைக்கிள் ஓட்டுதல் அல்லது அதிக எடை தூக்குதல் போன்ற வழக்கமான மற்றும் தீவிரமான உடல் செயல்பாடுகளை உள்ளடக்கிய தொழில்கள் இந்தப் பிரிவில் அடங்கும். உதாரணங்களில் கொல்லர்கள், சுரங்கத் தொழிலாளர்கள் மற்றும் கட்டுமானத் தொழிலாளர்கள் உள்ளனர்.';
  String get moderateDescription =>
      'இந்தப் பிரிவில் உள்ள நபர்கள் தினமும் சுமார் 30 நிமிடங்கள் முதல் ஒரு மணி நேரம் வரை நடைபயிற்சி அல்லது லேசான ஜாகிங் போன்ற உடல் செயல்பாடுகளில் ஈடுபடுவார்கள். கைவினைஞர்கள், கைவினைஞர்கள் மற்றும் சில வகையான திறமையான தொழிலாளர்கள் போன்ற தொழில்கள் இந்த வகைக்குள் அடங்கும்.';
  String get sedentaryDescription =>
      'இந்தப் பிரிவில் நாள் முழுவதும் உடல் இயக்கம் சிறிதும் இல்லாத தொழில்களும் அடங்கும். இந்த வேலைகளில் இருப்பவர்கள் தங்கள் பெரும்பாலான நேரத்தை உட்கார்ந்து அல்லது படுத்துக் கொள்வதில் செலவிடுகிறார்கள். எடுத்துக்காட்டுகளில் அலுவலகப் பணியாளர்கள், ஆசிரியர்கள் மற்றும் நிர்வாகப் பாத்திரங்களில் உள்ளவர்கள் அடங்குவர்.';
  String get Foodprotein => "புரத";
  String get Foodfat => "கொழுப்பு";
  String get Foodenergy => "ஆற்றல்";
  String get FoodtotalB2 => "மொத்த B2";
  String get Foodvitamins => "வைட்டமின்கள்";
  String get FoodtotalFat => "மொத்த கொழுப்பு";
  String get FoodproximateComposition => "நெருங்கிய கலவை";
  String get FoodnutrientsIn100g => "100 கிராம் உள்ள சத்துக்கள்";
  String get FoodtotalCarotenoids => "மொத்த கரோட்டினாய்டுகள்";
  String get FoodtotalAscorbicAcid => "மொத்த அஸ்கார்பிக் அமிலம்";
  String get FoodtotalB9 => "மொத்த B9";
  String get FoodtotalB6 => "மொத்த B6";
  String get Foodcalcium => "கால்சியம்";
  String get Foodsodium => "சோடியம்";
  String get Foodpotassium => "பொட்டாசியம்";
  String get Foodzinc => "துத்தநாகம்";
  String get Foodiron => "இரும்பு";
  String get Foodminerals => "கனிமங்கள்";
  String get FoodtotalSaturatedFattyAcids =>
      "மொத்த நிறைவுற்ற கொழுப்பு அமிலங்கள்";
  String get FoodfattyAcids => "கொழுப்பு அமிலங்கள்";
  String get FoodtotalDietaryFiber => "மொத்த உணவு நார்ச்சத்து";
  String get Foodmanganese => "மாங்கனீசு";
  String get Foodcopper => "செம்பு";
  String get Foodselenium => "செலினியம்";
  String get Foodmagnesium => "வெளிமம்";
  String get Foodphosphorus => "பாஸ்பரஸ்";
  String get Foodcholesterol => "கொலஸ்ட்ரால்";
  String get Foodcarbohydrate => "கார்போஹைட்ரேட்";
  String get FoodvitaminB6 => "வைட்டமின் B6 (மிகி)";

  String get Punjabi => "பஞ்சாபி";
  String get Gujarati => "குஜராத்தி";
  String get Odia => "ஒடியா";
  String get Kannada => "கன்னட";
  String get Marathi => "மராத்தி";
  String get Tamil => "தமிழ்";
  String get Bengali => "பங்காளி";
  String get Telugu => "தெலுங்கு";
  String get English => "ஆங்கிலம்";
  String get Hindi => "ஹிந்தி";
  String get firstname => "முதல் பெயர்";
  String get lastname => "கடைசி பெயர்";
  String get labelSodium => "சோடியம்";
  String get labelVitaminC => "வைட்டமின் C";
  String get FinanameEnergy => "ஆற்றல்";
  String get FinanameCarbohydrate => "கார்போஹைட்ரேட்";
  String get FinanameFat => "எலும்பு";
  String get FinanameSodium => "சோடியம்";
  String get FinanameDietaryFibre => "உணவு நார்கள்";
  String get FinanameCalcium => "கால்சியம்";
  String get FinanameIron => "இரும்பு";
  String get FinanameMagnesium => "மேக்னீசியம்";
  String get FinanameZinc => "ஜிங்";
  String get FinanameProtein => "சத்து";
  String get FinanameThiamine => "தயாமின்";
  String get FinanameRiboflavin => "ரிபோஃபிளேவின்";
  String get FinanameNiacin => "நியாசின்";
  String get FinanameVitaminB => "வைட்டமின் B";
  String get FinanameFolate => "பதக்கு";
  String get FinanameVitaminC => "வைட்டமின் C";
  String get FinanameVitaminA => "வைட்டமின் A";
  String get FinanameVitaminb6 => "வைட்டமின் B6";
  String get EssentialNutritionalGuidelines =>
      "இந்தியர்களின் உணவு தேவைகளுக்குத் தகுந்த முக்கிய ஊட்டச்சத்து வழிகாட்டுதல்கள்.";
  String get NutrientRequirementsRDA2020 =>
      "இந்தியர்களுக்கான ஊட்டச்சத்து தேவைகள் மற்றும் பரிந்துரைக்கப்பட்ட உணவு கொடுப்பனவு (RDA 2020).";
  String get RecommendationsBalancedDiets =>
      "இந்தியாவில் சமநிலை உணவு மற்றும் ஆரோக்கியமான உணவுப் பழக்கங்களை ஊக்குவிக்க பரிந்துரைகள்.";
  String get DietaryGuidelinesForIndians =>
      "இந்தியர்களுக்கான உணவு வழிகாட்டுதல்கள்.";
  String get Nutritionstat => "ஊட்டச்சத்து புள்ளிவிவரங்கள்";
  String get referenceMen65kg => "குறிப்பு ஆண்கள் (65 கிலோ)";
  String get referenceWomen55kg => "குறிப்பு பெண்கள் (55 கிலோ)";
  String get valueForMen => "1506";
  String get valueForWomen => "1184";
  String get referenceMenWomenDescription =>
      "உ_reference_ ஆண்களும் பெண்களும் 19-39 வயதுடையவர்களாகவும், வழக்கமான BMI கொண்டவர்களாகவும், மிதமாகச் செயல்படும் ஆரோக்கியமானவர்களாகவும் உள்ளனர் (ICMR-NIN). பார்க்க";
  String get personalizedDietDiaryDescription =>
      "பயனர்பயன்படுத்தும் உணவு டையரி தற்போதையதிலிருந்து கடந்த மாதம் வரை உங்கள் ஊட்டச்சத்து உள்வாங்கலை கண்காணிக்கிறது";

  String get confirmDeleteAllNotifications =>
      "அனைத்து அறிவிகளையும் நீக்க வேண்டுமா?";
  String get fillAllFields => "அனைத்து புலங்களையும் நிரப்பவும்";
  String get successfullyAddedIngredient =>
      "உணவு பாகங்களை வெற்றிகரமாக சேர்க்கப்பட்டன";
  String get confirmDeletion => "நீக்குதலை உறுதிப்படுத்து";
  String get confirmDeleteIngredient => "இந்த உணவு பொருளை நீக்க வேண்டுமா?";
  String get fileDownloaded =>
      "கோப்பு வெற்றிகரமாக பதிவிறக்கப்பட்டுள்ளது மற்றும் கோப்பின் இருப்பினை";
  String get confirmDeleteFood => "நீங்கள் உணவை நீக்க வேண்டுமா?";
  String get estimatedAverageRequirement =>
      'அதிகாரப்பூர்வ சேதம் (EAR): ஆரோக்கிய மக்களின் 50% க்கும் தேவைகளை போலி பெற எளிதாகும் நாள்தோறும் அளவு';
  String get editQuantity => "அளவைத் திருத்து";
  String get confirmDelete => "நீக்க வேண்டுமா?";
  String get exerciseDeleted => "வாய்ப்பு வெற்றிகரமாக நீக்கப்பட்டது.";
  String get confirmDeleteExercise => "இந்த உடல் பயிற்சியை நீக்க வேண்டுமா?";
  String get totalEnergyConsumption => "மொத்த கனவு பயன்படுத்தல்";
  String get totalEnergyExpenditure => "மொத்த கனவு செலவு";
  String get energybalance => "காரிய இருப்பு";
  String get indicatorhealth =>
      "('+' ஆற்றல் அதிகமாக காட்டுகின்றது; '-' ஆற்றல் குறைவாக காட்டுகின்றது)";
}
