// import 'package:flutter/material.dart';
// import 'package:nin2byo2i/Common/appfontsize.dart';

// class CartPage extends StatefulWidget {
//   CartPage({super.key});

//   @override
//   State<StatefulWidget> createState() => _CodiaPage();
// }

// class _CodiaPage extends State<CartPage> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         color: Colors.white,
//         child: Container(
//           width: 221.5,
//           height: 463,
//           decoration: BoxDecoration(
//             color: const Color(0xffffffff),
//             borderRadius: BorderRadius.circular(30),
//           ),
//           child: Stack(
//             children: [
//               Positioned(
//                 left: 19,
//                 width: 183.5,
//                 top: 401.5,
//                 height: 36,
//                 child: Container(
//                   width: 183.5,
//                   height: 36,
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(25),
//                   ),
//                   child: Stack(
//                     children: [
//                       Positioned(
//                         left: 0,
//                         width: 183.5,
//                         top: 0,
//                         height: 36,
//                         child: Container(
//                           width: 183.5,
//                           height: 36,
//                           decoration: BoxDecoration(
//                             borderRadius: BorderRadius.circular(25),
//                             boxShadow: const [
//                               BoxShadow(
//                                   color: const Color(0x33ff8c4c),
//                                   offset: Offset(0, 4.5),
//                                   blurRadius: 7),
//                             ],
//                           ),
//                         ),
//                       ),
//                       Positioned(
//                         left: 66,
//                         width: 52.5,
//                         top: 11.5,
//                         child: Text(
//                           'CHECKOUT',
//                           textAlign: TextAlign.left,
//                           style: TextStyle(
//                               decoration: TextDecoration.none,
//                               fontSize: 9,
//                               color: const Color(0xffffffff),
//                               fontFamily: 'Poppins-Bold',
//                               fontWeight: FontWeight.normal),
//                           maxLines: 9999,
//                           overflow: TextOverflow.ellipsis,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//               Positioned(
//                 left: 22.5,
//                 width: 15,
//                 top: 23.5,
//                 height: 15,
//                 child: Image.asset(
//                   'images/imageView1_2436.png',
//                   width: 15,
//                   height: 15,
//                 ),
//               ),
//               Positioned(
//                 left: 98.5,
//                 width: 25,
//                 top: 23.5,
//                 height: 14.5,
//                 child: Text(
//                   'Cart',
//                   textAlign: TextAlign.left,
//                   style: TextStyle(
//                       decoration: TextDecoration.none,
//                       fontSize: AppFontSizes.smallDefault,
//                       color: const Color(0xff060606),
//                       fontFamily: 'Inter-Bold',
//                       fontWeight: FontWeight.normal),
//                   maxLines: 9999,
//                   overflow: TextOverflow.ellipsis,
//                 ),
//               ),
//               Positioned(
//                 left: 171,
//                 width: 16,
//                 top: 23.5,
//                 height: 14.5,
//                 child: Image.asset(
//                   'images/imageView2_812443.png',
//                   width: 16,
//                   height: 14.5,
//                   fit: BoxFit.cover,
//                 ),
//               ),
//               Positioned(
//                 left: 30.5,
//                 width: 79.5,
//                 top: 266,
//                 child: Text(
//                   'Total Price :  ₹737.34',
//                   textAlign: TextAlign.left,
//                   style: TextStyle(
//                       decoration: TextDecoration.none,
//                       fontSize: 7.5,
//                       color: const Color(0xaaff1515),
//                       fontFamily: 'Poppins-Bold',
//                       fontWeight: FontWeight.normal),
//                   maxLines: 9999,
//                   overflow: TextOverflow.ellipsis,
//                 ),
//               ),
//               Positioned(
//                 left: 141,
//                 width: 54,
//                 top: 264,
//                 height: 13.5,
//                 child: Container(
//                   width: 54,
//                   height: 13.5,
//                   decoration: BoxDecoration(
//                     color: const Color(0xaa15b8ff),
//                     borderRadius: BorderRadius.circular(2),
//                   ),
//                   child: Padding(
//                     padding: const EdgeInsets.only(
//                         left: 16, top: 8, right: 16, bottom: 8),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         Column(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           children: [
//                             SizedBox(
//                               width: 51.5,
//                               height: 9.5,
//                               child: Text(
//                                 'Checkout',
//                                 textAlign: TextAlign.center,
//                                 style: TextStyle(
//                                     decoration: TextDecoration.none,
//                                     fontSize: 5,
//                                     color: const Color(0xffffffff),
//                                     fontFamily: 'Poppins-Bold',
//                                     fontWeight: FontWeight.normal),
//                                 maxLines: 9999,
//                                 overflow: TextOverflow.ellipsis,
//                               ),
//                             ),
//                           ],
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//               Positioned(
//                 left: 165.5,
//                 top: 226,
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   mainAxisSize: MainAxisSize.min,
//                   crossAxisAlignment: CrossAxisAlignment.end,
//                   children: [
//                     SizedBox(
//                       width: 23,
//                       height: 8,
//                       child: Text(
//                         '₹245.78',
//                         textAlign: TextAlign.left,
//                         style: TextStyle(
//                             decoration: TextDecoration.none,
//                             fontSize: 5.5,
//                             color: const Color(0xffb2bbc9),
//                             fontFamily: 'Poppins-Regular',
//                             fontWeight: FontWeight.normal),
//                         maxLines: 9999,
//                         overflow: TextOverflow.ellipsis,
//                       ),
//                     ),
//                     SizedBox(
//                       width: 28.5,
//                       height: 10,
//                       child: Text(
//                         '₹245.78',
//                         textAlign: TextAlign.left,
//                         style: TextStyle(
//                             decoration: TextDecoration.none,
//                             fontSize: 7,
//                             color: const Color(0xff000000),
//                             fontFamily: 'Poppins-SemiBold',
//                             fontWeight: FontWeight.normal),
//                         maxLines: 9999,
//                         overflow: TextOverflow.ellipsis,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               Positioned(
//                 left: 18.5,
//                 width: 185,
//                 top: 47,
//                 height: 217,
//                 child: Stack(
//                   children: [
//                     Positioned(
//                       left: 10,
//                       top: 9.5,
//                       child: Text(
//                         'Cart Review',
//                         textAlign: TextAlign.left,
//                         style: TextStyle(
//                             decoration: TextDecoration.none,
//                             fontSize: AppFontSizes.mediumDefault,
//                             color: const Color(0xff000000),
//                             fontFamily: 'OpenSans-Bold',
//                             fontWeight: FontWeight.normal),
//                         maxLines: 9999,
//                         overflow: TextOverflow.ellipsis,
//                       ),
//                     ),
//                     Positioned(
//                       left: 10,
//                       top: 21.5,
//                       child: Text(
//                         '3 items in Cart',
//                         textAlign: TextAlign.left,
//                         style: TextStyle(
//                             decoration: TextDecoration.none,
//                             fontSize: 6,
//                             color: const Color(0xff000000),
//                             fontFamily: 'OpenSans-Regular',
//                             fontWeight: FontWeight.normal),
//                         maxLines: 9999,
//                         overflow: TextOverflow.ellipsis,
//                       ),
//                     ),
//                     Positioned(
//                       left: 10,
//                       width: 165,
//                       top: 39.5,
//                       child: Column(
//                         mainAxisAlignment: MainAxisAlignment.start,
//                         mainAxisSize: MainAxisSize.min,
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Row(
//                             children: [
//                               Expanded(
//                                 child: Row(
//                                   mainAxisAlignment: MainAxisAlignment.start,
//                                   mainAxisSize: MainAxisSize.min,
//                                   children: [
//                                     Expanded(
//                                       child: Row(
//                                         children: [
//                                           Expanded(
//                                             child: Container(
//                                               child: Row(
//                                                 mainAxisAlignment:
//                                                     MainAxisAlignment.start,
//                                                 mainAxisSize: MainAxisSize.max,
//                                                 crossAxisAlignment:
//                                                     CrossAxisAlignment.start,
//                                                 children: [
//                                                   Column(
//                                                     mainAxisAlignment:
//                                                         MainAxisAlignment.start,
//                                                     mainAxisSize:
//                                                         MainAxisSize.min,
//                                                     children: [
//                                                       Row(
//                                                         mainAxisAlignment:
//                                                             MainAxisAlignment
//                                                                 .start,
//                                                         mainAxisSize:
//                                                             MainAxisSize.min,
//                                                         crossAxisAlignment:
//                                                             CrossAxisAlignment
//                                                                 .start,
//                                                         children: [
//                                                           Column(
//                                                             mainAxisAlignment:
//                                                                 MainAxisAlignment
//                                                                     .start,
//                                                             children: [
//                                                               Image.asset(
//                                                                 'images/imageView7_6491.png',
//                                                                 width: 40,
//                                                                 height: 40,
//                                                               ),
//                                                             ],
//                                                           ),
//                                                           const SizedBox(
//                                                               width: 14),
//                                                           Column(
//                                                             mainAxisAlignment:
//                                                                 MainAxisAlignment
//                                                                     .start,
//                                                             mainAxisSize:
//                                                                 MainAxisSize
//                                                                     .min,
//                                                             children: [
//                                                               Column(
//                                                                 mainAxisAlignment:
//                                                                     MainAxisAlignment
//                                                                         .start,
//                                                                 mainAxisSize:
//                                                                     MainAxisSize
//                                                                         .min,
//                                                                 crossAxisAlignment:
//                                                                     CrossAxisAlignment
//                                                                         .start,
//                                                                 children: [
//                                                                   SizedBox(
//                                                                     width: 78.5,
//                                                                     child: Text(
//                                                                       'Nutrient Requirements and Recommended Dietary Allowances for Indians',
//                                                                       textAlign:
//                                                                           TextAlign
//                                                                               .left,
//                                                                       style: TextStyle(
//                                                                           decoration: TextDecoration
//                                                                               .none,
//                                                                           fontSize:
//                                                                               5,
//                                                                           color: const Color(
//                                                                               0xff000000),
//                                                                           fontFamily:
//                                                                               'Poppins-Regular',
//                                                                           fontWeight:
//                                                                               FontWeight.normal),
//                                                                       maxLines:
//                                                                           9999,
//                                                                       overflow:
//                                                                           TextOverflow
//                                                                               .ellipsis,
//                                                                     ),
//                                                                   ),
//                                                                   const SizedBox(
//                                                                       height:
//                                                                           10),
//                                                                   Container(
//                                                                     width: 44.5,
//                                                                     height:
//                                                                         14.5,
//                                                                     decoration:
//                                                                         BoxDecoration(
//                                                                       boxShadow: const [
//                                                                         BoxShadow(
//                                                                             color: const Color(
//                                                                                 0x14858585),
//                                                                             offset: Offset(0,
//                                                                                 1),
//                                                                             blurRadius:
//                                                                                 20),
//                                                                       ],
//                                                                     ),
//                                                                     child:
//                                                                         Stack(
//                                                                       children: [
//                                                                         Positioned(
//                                                                           left:
//                                                                               0,
//                                                                           width:
//                                                                               14.47,
//                                                                           top:
//                                                                               0,
//                                                                           height:
//                                                                               14.5,
//                                                                           child:
//                                                                               Container(
//                                                                             width:
//                                                                                 14.47,
//                                                                             height:
//                                                                                 14.5,
//                                                                             decoration:
//                                                                                 BoxDecoration(
//                                                                               border: Border.all(color: const Color(0xffb2bbc9), width: 1),
//                                                                               borderRadius: BorderRadius.circular(1.5),
//                                                                               boxShadow: const [
//                                                                                 BoxShadow(color: const Color(0x14858585), offset: Offset(0, 1), blurRadius: 20),
//                                                                               ],
//                                                                             ),
//                                                                           ),
//                                                                         ),
//                                                                         Positioned(
//                                                                           left:
//                                                                               0,
//                                                                           width:
//                                                                               44.5,
//                                                                           top:
//                                                                               3.5,
//                                                                           height:
//                                                                               7.5,
//                                                                           child:
//                                                                               Text(
//                                                                             '2',
//                                                                             textAlign:
//                                                                                 TextAlign.center,
//                                                                             style: TextStyle(
//                                                                                 decoration: TextDecoration.none,
//                                                                                 fontSize: 6,
//                                                                                 color: const Color(0xff4f4f4f),
//                                                                                 fontFamily: 'OpenSans-Regular',
//                                                                                 fontWeight: FontWeight.normal),
//                                                                             maxLines:
//                                                                                 9999,
//                                                                             overflow:
//                                                                                 TextOverflow.ellipsis,
//                                                                           ),
//                                                                         ),
//                                                                         Positioned(
//                                                                           left:
//                                                                               30.03,
//                                                                           width:
//                                                                               14.47,
//                                                                           top:
//                                                                               0,
//                                                                           height:
//                                                                               14.5,
//                                                                           child:
//                                                                               Container(
//                                                                             width:
//                                                                                 14.47,
//                                                                             height:
//                                                                                 14.5,
//                                                                             decoration:
//                                                                                 BoxDecoration(
//                                                                               border: Border.all(color: const Color(0xffb2bbc9), width: 1),
//                                                                               borderRadius: BorderRadius.circular(1.5),
//                                                                             ),
//                                                                           ),
//                                                                         ),
//                                                                         Positioned(
//                                                                           left:
//                                                                               35.09,
//                                                                           width:
//                                                                               4.39,
//                                                                           top:
//                                                                               5.07,
//                                                                           height:
//                                                                               4.4,
//                                                                           child:
//                                                                               Image.asset(
//                                                                             'images/imageView8_1899.png',
//                                                                             width:
//                                                                                 4.39,
//                                                                             height:
//                                                                                 4.4,
//                                                                           ),
//                                                                         ),
//                                                                         Positioned(
//                                                                           left:
//                                                                               5.07,
//                                                                           width:
//                                                                               4.34,
//                                                                           top:
//                                                                               7.25,
//                                                                           height:
//                                                                               0.5,
//                                                                           child:
//                                                                               Image.asset(
//                                                                             'images/imageView9_1902.png',
//                                                                             width:
//                                                                                 4.34,
//                                                                             height:
//                                                                                 0.5,
//                                                                           ),
//                                                                         ),
//                                                                       ],
//                                                                     ),
//                                                                   ),
//                                                                 ],
//                                                               ),
//                                                             ],
//                                                           ),
//                                                         ],
//                                                       ),
//                                                     ],
//                                                   ),
//                                                   const SizedBox(width: 24),
//                                                   Expanded(
//                                                     child: Column(
//                                                       mainAxisAlignment:
//                                                           MainAxisAlignment
//                                                               .start,
//                                                       mainAxisSize:
//                                                           MainAxisSize.max,
//                                                       children: [
//                                                         Expanded(
//                                                           child: Container(
//                                                             width:
//                                                                 double.infinity,
//                                                             height: 40,
//                                                             child: Column(
//                                                               mainAxisAlignment:
//                                                                   MainAxisAlignment
//                                                                       .start,
//                                                               crossAxisAlignment:
//                                                                   CrossAxisAlignment
//                                                                       .end,
//                                                               children: [
//                                                                 Text(
//                                                                   '✕',
//                                                                   textAlign:
//                                                                       TextAlign
//                                                                           .center,
//                                                                   style: TextStyle(
//                                                                       decoration:
//                                                                           TextDecoration
//                                                                               .none,
//                                                                       fontSize:
//                                                                           6,
//                                                                       color: const Color(
//                                                                           0xff000000),
//                                                                       fontFamily:
//                                                                           'Montserrat-Medium',
//                                                                       fontWeight:
//                                                                           FontWeight
//                                                                               .normal),
//                                                                   maxLines:
//                                                                       9999,
//                                                                   overflow:
//                                                                       TextOverflow
//                                                                           .ellipsis,
//                                                                 ),
//                                                                 const SizedBox(
//                                                                     height: 24),
//                                                                 Row(
//                                                                   mainAxisAlignment:
//                                                                       MainAxisAlignment
//                                                                           .end,
//                                                                   mainAxisSize:
//                                                                       MainAxisSize
//                                                                           .min,
//                                                                   children: [
//                                                                     Column(
//                                                                       mainAxisAlignment:
//                                                                           MainAxisAlignment
//                                                                               .center,
//                                                                       mainAxisSize:
//                                                                           MainAxisSize
//                                                                               .min,
//                                                                       crossAxisAlignment:
//                                                                           CrossAxisAlignment
//                                                                               .end,
//                                                                       children: [
//                                                                         SizedBox(
//                                                                           width:
//                                                                               23,
//                                                                           height:
//                                                                               8,
//                                                                           child:
//                                                                               Text(
//                                                                             '₹245.78',
//                                                                             textAlign:
//                                                                                 TextAlign.left,
//                                                                             style: TextStyle(
//                                                                                 decoration: TextDecoration.none,
//                                                                                 fontSize: 5.5,
//                                                                                 color: const Color(0xffb2bbc9),
//                                                                                 fontFamily: 'Poppins-Regular',
//                                                                                 fontWeight: FontWeight.normal),
//                                                                             maxLines:
//                                                                                 9999,
//                                                                             overflow:
//                                                                                 TextOverflow.ellipsis,
//                                                                           ),
//                                                                         ),
//                                                                         SizedBox(
//                                                                           width:
//                                                                               28.5,
//                                                                           height:
//                                                                               10,
//                                                                           child:
//                                                                               Text(
//                                                                             '₹245.78',
//                                                                             textAlign:
//                                                                                 TextAlign.left,
//                                                                             style: TextStyle(
//                                                                                 decoration: TextDecoration.none,
//                                                                                 fontSize: 7,
//                                                                                 color: const Color(0xff000000),
//                                                                                 fontFamily: 'Poppins-SemiBold',
//                                                                                 fontWeight: FontWeight.normal),
//                                                                             maxLines:
//                                                                                 9999,
//                                                                             overflow:
//                                                                                 TextOverflow.ellipsis,
//                                                                           ),
//                                                                         ),
//                                                                       ],
//                                                                     ),
//                                                                   ],
//                                                                 ),
//                                                               ],
//                                                             ),
//                                                           ),
//                                                         ),
//                                                       ],
//                                                     ),
//                                                   ),
//                                                 ],
//                                               ),
//                                             ),
//                                           ),
//                                         ],
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             ],
//                           ),
//                           const SizedBox(height: 20),
//                           Row(
//                             children: [
//                               Expanded(
//                                 child: Container(
//                                   child: Image.asset(
//                                     'images/imageView_1891.png',
//                                     height: 0.5,
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ],
//                       ),
//                     ),
//                     Positioned(
//                       left: 10,
//                       width: 165,
//                       top: 97.5,
//                       child: Column(
//                         mainAxisAlignment: MainAxisAlignment.start,
//                         mainAxisSize: MainAxisSize.min,
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Row(
//                             children: [
//                               Expanded(
//                                 child: Row(
//                                   mainAxisAlignment: MainAxisAlignment.start,
//                                   mainAxisSize: MainAxisSize.min,
//                                   children: [
//                                     Expanded(
//                                       child: Row(
//                                         children: [
//                                           Expanded(
//                                             child: Container(
//                                               child: Row(
//                                                 mainAxisAlignment:
//                                                     MainAxisAlignment.start,
//                                                 mainAxisSize: MainAxisSize.max,
//                                                 crossAxisAlignment:
//                                                     CrossAxisAlignment.start,
//                                                 children: [
//                                                   Column(
//                                                     mainAxisAlignment:
//                                                         MainAxisAlignment.start,
//                                                     mainAxisSize:
//                                                         MainAxisSize.min,
//                                                     children: [
//                                                       Row(
//                                                         mainAxisAlignment:
//                                                             MainAxisAlignment
//                                                                 .start,
//                                                         mainAxisSize:
//                                                             MainAxisSize.min,
//                                                         crossAxisAlignment:
//                                                             CrossAxisAlignment
//                                                                 .start,
//                                                         children: [
//                                                           Column(
//                                                             mainAxisAlignment:
//                                                                 MainAxisAlignment
//                                                                     .start,
//                                                             children: [
//                                                               Image.asset(
//                                                                 'images/imageView11_6491.png',
//                                                                 width: 40,
//                                                                 height: 40,
//                                                               ),
//                                                             ],
//                                                           ),
//                                                           const SizedBox(
//                                                               width: 14),
//                                                           Column(
//                                                             mainAxisAlignment:
//                                                                 MainAxisAlignment
//                                                                     .start,
//                                                             mainAxisSize:
//                                                                 MainAxisSize
//                                                                     .min,
//                                                             children: [
//                                                               Column(
//                                                                 mainAxisAlignment:
//                                                                     MainAxisAlignment
//                                                                         .start,
//                                                                 mainAxisSize:
//                                                                     MainAxisSize
//                                                                         .min,
//                                                                 crossAxisAlignment:
//                                                                     CrossAxisAlignment
//                                                                         .start,
//                                                                 children: [
//                                                                   SizedBox(
//                                                                     width: 78.5,
//                                                                     child: Text(
//                                                                       'Nutrient Requirements and Recommended Dietary Allowances for Indians',
//                                                                       textAlign:
//                                                                           TextAlign
//                                                                               .left,
//                                                                       style: TextStyle(
//                                                                           decoration: TextDecoration
//                                                                               .none,
//                                                                           fontSize:
//                                                                               5,
//                                                                           color: const Color(
//                                                                               0xff000000),
//                                                                           fontFamily:
//                                                                               'Poppins-Regular',
//                                                                           fontWeight:
//                                                                               FontWeight.normal),
//                                                                       maxLines:
//                                                                           9999,
//                                                                       overflow:
//                                                                           TextOverflow
//                                                                               .ellipsis,
//                                                                     ),
//                                                                   ),
//                                                                   const SizedBox(
//                                                                       height:
//                                                                           10),
//                                                                   Container(
//                                                                     width: 44.5,
//                                                                     height:
//                                                                         14.5,
//                                                                     decoration:
//                                                                         BoxDecoration(
//                                                                       boxShadow: const [
//                                                                         BoxShadow(
//                                                                             color: const Color(
//                                                                                 0x14858585),
//                                                                             offset: Offset(0,
//                                                                                 1),
//                                                                             blurRadius:
//                                                                                 20),
//                                                                       ],
//                                                                     ),
//                                                                     child:
//                                                                         Stack(
//                                                                       children: [
//                                                                         Positioned(
//                                                                           left:
//                                                                               0,
//                                                                           width:
//                                                                               14.47,
//                                                                           top:
//                                                                               0,
//                                                                           height:
//                                                                               14.5,
//                                                                           child:
//                                                                               Container(
//                                                                             width:
//                                                                                 14.47,
//                                                                             height:
//                                                                                 14.5,
//                                                                             decoration:
//                                                                                 BoxDecoration(
//                                                                               border: Border.all(color: const Color(0xffb2bbc9), width: 1),
//                                                                               borderRadius: BorderRadius.circular(1.5),
//                                                                               boxShadow: const [
//                                                                                 BoxShadow(color: const Color(0x14858585), offset: Offset(0, 1), blurRadius: 20),
//                                                                               ],
//                                                                             ),
//                                                                           ),
//                                                                         ),
//                                                                         Positioned(
//                                                                           left:
//                                                                               0,
//                                                                           width:
//                                                                               44.5,
//                                                                           top:
//                                                                               3.5,
//                                                                           height:
//                                                                               7.5,
//                                                                           child:
//                                                                               Text(
//                                                                             '2',
//                                                                             textAlign:
//                                                                                 TextAlign.center,
//                                                                             style: TextStyle(
//                                                                                 decoration: TextDecoration.none,
//                                                                                 fontSize: 6,
//                                                                                 color: const Color(0xff4f4f4f),
//                                                                                 fontFamily: 'OpenSans-Regular',
//                                                                                 fontWeight: FontWeight.normal),
//                                                                             maxLines:
//                                                                                 9999,
//                                                                             overflow:
//                                                                                 TextOverflow.ellipsis,
//                                                                           ),
//                                                                         ),
//                                                                         Positioned(
//                                                                           left:
//                                                                               30.03,
//                                                                           width:
//                                                                               14.47,
//                                                                           top:
//                                                                               0,
//                                                                           height:
//                                                                               14.5,
//                                                                           child:
//                                                                               Container(
//                                                                             width:
//                                                                                 14.47,
//                                                                             height:
//                                                                                 14.5,
//                                                                             decoration:
//                                                                                 BoxDecoration(
//                                                                               border: Border.all(color: const Color(0xffb2bbc9), width: 1),
//                                                                               borderRadius: BorderRadius.circular(1.5),
//                                                                             ),
//                                                                           ),
//                                                                         ),
//                                                                         Positioned(
//                                                                           left:
//                                                                               35.09,
//                                                                           width:
//                                                                               4.39,
//                                                                           top:
//                                                                               5.07,
//                                                                           height:
//                                                                               4.4,
//                                                                           child:
//                                                                               Image.asset(
//                                                                             'images/imageView12_1899.png',
//                                                                             width:
//                                                                                 4.39,
//                                                                             height:
//                                                                                 4.4,
//                                                                           ),
//                                                                         ),
//                                                                         Positioned(
//                                                                           left:
//                                                                               5.07,
//                                                                           width:
//                                                                               4.34,
//                                                                           top:
//                                                                               7.25,
//                                                                           height:
//                                                                               0.5,
//                                                                           child:
//                                                                               Image.asset(
//                                                                             'images/imageView13_1902.png',
//                                                                             width:
//                                                                                 4.34,
//                                                                             height:
//                                                                                 0.5,
//                                                                           ),
//                                                                         ),
//                                                                       ],
//                                                                     ),
//                                                                   ),
//                                                                 ],
//                                                               ),
//                                                             ],
//                                                           ),
//                                                         ],
//                                                       ),
//                                                     ],
//                                                   ),
//                                                   const SizedBox(width: 24),
//                                                   Expanded(
//                                                     child: Column(
//                                                       mainAxisAlignment:
//                                                           MainAxisAlignment
//                                                               .start,
//                                                       mainAxisSize:
//                                                           MainAxisSize.max,
//                                                       children: [
//                                                         Expanded(
//                                                           child: Container(
//                                                             width:
//                                                                 double.infinity,
//                                                             height: 40,
//                                                             child: Column(
//                                                               mainAxisAlignment:
//                                                                   MainAxisAlignment
//                                                                       .start,
//                                                               crossAxisAlignment:
//                                                                   CrossAxisAlignment
//                                                                       .end,
//                                                               children: [
//                                                                 Text(
//                                                                   '✕',
//                                                                   textAlign:
//                                                                       TextAlign
//                                                                           .center,
//                                                                   style: TextStyle(
//                                                                       decoration:
//                                                                           TextDecoration
//                                                                               .none,
//                                                                       fontSize:
//                                                                           6,
//                                                                       color: const Color(
//                                                                           0xff000000),
//                                                                       fontFamily:
//                                                                           'Montserrat-Medium',
//                                                                       fontWeight:
//                                                                           FontWeight
//                                                                               .normal),
//                                                                   maxLines:
//                                                                       9999,
//                                                                   overflow:
//                                                                       TextOverflow
//                                                                           .ellipsis,
//                                                                 ),
//                                                               ],
//                                                             ),
//                                                           ),
//                                                         ),
//                                                       ],
//                                                     ),
//                                                   ),
//                                                 ],
//                                               ),
//                                             ),
//                                           ),
//                                         ],
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             ],
//                           ),
//                           const SizedBox(height: 20),
//                           Row(
//                             children: [
//                               Expanded(
//                                 child: Container(
//                                   child: Image.asset(
//                                     'images/imageView10_1891.png',
//                                     height: 0.5,
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ],
//                       ),
//                     ),
//                     Positioned(
//                       left: 10,
//                       width: 165,
//                       top: 155.5,
//                       child: Column(
//                         mainAxisAlignment: MainAxisAlignment.start,
//                         mainAxisSize: MainAxisSize.min,
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Row(
//                             children: [
//                               Expanded(
//                                 child: Row(
//                                   mainAxisAlignment: MainAxisAlignment.start,
//                                   mainAxisSize: MainAxisSize.min,
//                                   children: [
//                                     Expanded(
//                                       child: Row(
//                                         children: [
//                                           Expanded(
//                                             child: Container(
//                                               child: Row(
//                                                 mainAxisAlignment:
//                                                     MainAxisAlignment.start,
//                                                 mainAxisSize: MainAxisSize.max,
//                                                 crossAxisAlignment:
//                                                     CrossAxisAlignment.start,
//                                                 children: [
//                                                   Column(
//                                                     mainAxisAlignment:
//                                                         MainAxisAlignment.start,
//                                                     mainAxisSize:
//                                                         MainAxisSize.min,
//                                                     children: [
//                                                       Row(
//                                                         mainAxisAlignment:
//                                                             MainAxisAlignment
//                                                                 .start,
//                                                         mainAxisSize:
//                                                             MainAxisSize.min,
//                                                         crossAxisAlignment:
//                                                             CrossAxisAlignment
//                                                                 .start,
//                                                         children: [
//                                                           Column(
//                                                             mainAxisAlignment:
//                                                                 MainAxisAlignment
//                                                                     .start,
//                                                             children: [
//                                                               Image.asset(
//                                                                 'images/imageView15_6491.png',
//                                                                 width: 40,
//                                                                 height: 40,
//                                                               ),
//                                                             ],
//                                                           ),
//                                                           const SizedBox(
//                                                               width: 14),
//                                                           Column(
//                                                             mainAxisAlignment:
//                                                                 MainAxisAlignment
//                                                                     .start,
//                                                             mainAxisSize:
//                                                                 MainAxisSize
//                                                                     .min,
//                                                             children: [
//                                                               Column(
//                                                                 mainAxisAlignment:
//                                                                     MainAxisAlignment
//                                                                         .start,
//                                                                 mainAxisSize:
//                                                                     MainAxisSize
//                                                                         .min,
//                                                                 crossAxisAlignment:
//                                                                     CrossAxisAlignment
//                                                                         .start,
//                                                                 children: [
//                                                                   SizedBox(
//                                                                     width: 78.5,
//                                                                     child: Text(
//                                                                       'Nutrient Requirements and Recommended Dietary Allowances for Indians',
//                                                                       textAlign:
//                                                                           TextAlign
//                                                                               .left,
//                                                                       style: TextStyle(
//                                                                           decoration: TextDecoration
//                                                                               .none,
//                                                                           fontSize:
//                                                                               5,
//                                                                           color: const Color(
//                                                                               0xff000000),
//                                                                           fontFamily:
//                                                                               'Poppins-Regular',
//                                                                           fontWeight:
//                                                                               FontWeight.normal),
//                                                                       maxLines:
//                                                                           9999,
//                                                                       overflow:
//                                                                           TextOverflow
//                                                                               .ellipsis,
//                                                                     ),
//                                                                   ),
//                                                                   const SizedBox(
//                                                                       height:
//                                                                           10),
//                                                                   Container(
//                                                                     width: 44.5,
//                                                                     height:
//                                                                         14.5,
//                                                                     decoration:
//                                                                         BoxDecoration(
//                                                                       boxShadow: const [
//                                                                         BoxShadow(
//                                                                             color: const Color(
//                                                                                 0x14858585),
//                                                                             offset: Offset(0,
//                                                                                 1),
//                                                                             blurRadius:
//                                                                                 20),
//                                                                       ],
//                                                                     ),
//                                                                     child:
//                                                                         Stack(
//                                                                       children: [
//                                                                         Positioned(
//                                                                           left:
//                                                                               0,
//                                                                           width:
//                                                                               14.47,
//                                                                           top:
//                                                                               0,
//                                                                           height:
//                                                                               14.5,
//                                                                           child:
//                                                                               Container(
//                                                                             width:
//                                                                                 14.47,
//                                                                             height:
//                                                                                 14.5,
//                                                                             decoration:
//                                                                                 BoxDecoration(
//                                                                               border: Border.all(color: const Color(0xffb2bbc9), width: 1),
//                                                                               borderRadius: BorderRadius.circular(1.5),
//                                                                               boxShadow: const [
//                                                                                 BoxShadow(color: const Color(0x14858585), offset: Offset(0, 1), blurRadius: 20),
//                                                                               ],
//                                                                             ),
//                                                                           ),
//                                                                         ),
//                                                                         Positioned(
//                                                                           left:
//                                                                               0,
//                                                                           width:
//                                                                               44.5,
//                                                                           top:
//                                                                               3.5,
//                                                                           height:
//                                                                               7.5,
//                                                                           child:
//                                                                               Text(
//                                                                             '2',
//                                                                             textAlign:
//                                                                                 TextAlign.center,
//                                                                             style: TextStyle(
//                                                                                 decoration: TextDecoration.none,
//                                                                                 fontSize: 6,
//                                                                                 color: const Color(0xff4f4f4f),
//                                                                                 fontFamily: 'OpenSans-Regular',
//                                                                                 fontWeight: FontWeight.normal),
//                                                                             maxLines:
//                                                                                 9999,
//                                                                             overflow:
//                                                                                 TextOverflow.ellipsis,
//                                                                           ),
//                                                                         ),
//                                                                         Positioned(
//                                                                           left:
//                                                                               30.03,
//                                                                           width:
//                                                                               14.47,
//                                                                           top:
//                                                                               0,
//                                                                           height:
//                                                                               14.5,
//                                                                           child:
//                                                                               Container(
//                                                                             width:
//                                                                                 14.47,
//                                                                             height:
//                                                                                 14.5,
//                                                                             decoration:
//                                                                                 BoxDecoration(
//                                                                               border: Border.all(color: const Color(0xffb2bbc9), width: 1),
//                                                                               borderRadius: BorderRadius.circular(1.5),
//                                                                             ),
//                                                                           ),
//                                                                         ),
//                                                                         Positioned(
//                                                                           left:
//                                                                               35.09,
//                                                                           width:
//                                                                               4.39,
//                                                                           top:
//                                                                               5.07,
//                                                                           height:
//                                                                               4.4,
//                                                                           child:
//                                                                               Image.asset(
//                                                                             'images/imageView16_1899.png',
//                                                                             width:
//                                                                                 4.39,
//                                                                             height:
//                                                                                 4.4,
//                                                                           ),
//                                                                         ),
//                                                                         Positioned(
//                                                                           left:
//                                                                               5.07,
//                                                                           width:
//                                                                               4.34,
//                                                                           top:
//                                                                               7.25,
//                                                                           height:
//                                                                               0.5,
//                                                                           child:
//                                                                               Image.asset(
//                                                                             'images/imageView17_1902.png',
//                                                                             width:
//                                                                                 4.34,
//                                                                             height:
//                                                                                 0.5,
//                                                                           ),
//                                                                         ),
//                                                                       ],
//                                                                     ),
//                                                                   ),
//                                                                 ],
//                                                               ),
//                                                             ],
//                                                           ),
//                                                         ],
//                                                       ),
//                                                     ],
//                                                   ),
//                                                   const SizedBox(width: 24),
//                                                   Expanded(
//                                                     child: Column(
//                                                       mainAxisAlignment:
//                                                           MainAxisAlignment
//                                                               .start,
//                                                       mainAxisSize:
//                                                           MainAxisSize.max,
//                                                       children: [
//                                                         Expanded(
//                                                           child: Container(
//                                                             width:
//                                                                 double.infinity,
//                                                             height: 40,
//                                                             child: Column(
//                                                               mainAxisAlignment:
//                                                                   MainAxisAlignment
//                                                                       .start,
//                                                               crossAxisAlignment:
//                                                                   CrossAxisAlignment
//                                                                       .end,
//                                                               children: [
//                                                                 Text(
//                                                                   '✕',
//                                                                   textAlign:
//                                                                       TextAlign
//                                                                           .center,
//                                                                   style: TextStyle(
//                                                                       decoration:
//                                                                           TextDecoration
//                                                                               .none,
//                                                                       fontSize:
//                                                                           6,
//                                                                       color: const Color(
//                                                                           0xff000000),
//                                                                       fontFamily:
//                                                                           'Montserrat-Medium',
//                                                                       fontWeight:
//                                                                           FontWeight
//                                                                               .normal),
//                                                                   maxLines:
//                                                                       9999,
//                                                                   overflow:
//                                                                       TextOverflow
//                                                                           .ellipsis,
//                                                                 ),
//                                                               ],
//                                                             ),
//                                                           ),
//                                                         ),
//                                                       ],
//                                                     ),
//                                                   ),
//                                                 ],
//                                               ),
//                                             ),
//                                           ),
//                                         ],
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             ],
//                           ),
//                           const SizedBox(height: 20),
//                           Row(
//                             children: [
//                               Expanded(
//                                 child: Container(
//                                   child: Image.asset(
//                                     'images/imageView14_1891.png',
//                                     height: 0.5,
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ],
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               Positioned(
//                 left: 165,
//                 top: 169,
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   mainAxisSize: MainAxisSize.min,
//                   crossAxisAlignment: CrossAxisAlignment.end,
//                   children: [
//                     SizedBox(
//                       width: 23,
//                       height: 8,
//                       child: Text(
//                         '₹245.78',
//                         textAlign: TextAlign.left,
//                         style: TextStyle(
//                             decoration: TextDecoration.none,
//                             fontSize: 5.5,
//                             color: const Color(0xffb2bbc9),
//                             fontFamily: 'Poppins-Regular',
//                             fontWeight: FontWeight.normal),
//                         maxLines: 9999,
//                         overflow: TextOverflow.ellipsis,
//                       ),
//                     ),
//                     SizedBox(
//                       width: 28.5,
//                       height: 10,
//                       child: Text(
//                         '₹245.78',
//                         textAlign: TextAlign.left,
//                         style: TextStyle(
//                             decoration: TextDecoration.none,
//                             fontSize: 7,
//                             color: const Color(0xff000000),
//                             fontFamily: 'Poppins-SemiBold',
//                             fontWeight: FontWeight.normal),
//                         maxLines: 9999,
//                         overflow: TextOverflow.ellipsis,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               Positioned(
//                 left: 75.5,
//                 width: 78.5,
//                 top: 86.5,
//                 child: Text(
//                   'Nutrient Requirements and Recommended Dietary Allowances for Indians',
//                   textAlign: TextAlign.left,
//                   style: TextStyle(
//                       decoration: TextDecoration.none,
//                       fontSize: 5,
//                       color: const Color(0xff000000),
//                       fontFamily: 'Poppins-Regular',
//                       fontWeight: FontWeight.normal),
//                   maxLines: 9999,
//                   overflow: TextOverflow.ellipsis,
//                 ),
//               ),
//               Positioned(
//                 left: 75.5,
//                 width: 78.5,
//                 top: 86.5,
//                 child: Text(
//                   'Nutrient Requirements and Recommended Dietary Allowances for Indians',
//                   textAlign: TextAlign.left,
//                   style: TextStyle(
//                       decoration: TextDecoration.none,
//                       fontSize: 5,
//                       color: const Color(0xff000000),
//                       fontFamily: 'Poppins-Regular',
//                       fontWeight: FontWeight.normal),
//                   maxLines: 9999,
//                   overflow: TextOverflow.ellipsis,
//                 ),
//               ),
//               Positioned(
//                 left: 28.5,
//                 width: 40,
//                 top: 86.5,
//                 height: 40,
//                 child: Image.asset(
//                   'images/imageView3_812456.png',
//                   width: 40,
//                   height: 40,
//                   fit: BoxFit.cover,
//                 ),
//               ),
//               Positioned(
//                 left: 28.5,
//                 width: 40,
//                 top: 145.5,
//                 height: 39,
//                 child: Image.asset(
//                   'images/imageView4_812457.png',
//                   width: 40,
//                   height: 39,
//                   fit: BoxFit.cover,
//                 ),
//               ),
//               Positioned(
//                 left: 28.5,
//                 width: 40,
//                 top: 202.5,
//                 height: 40,
//                 child: Image.asset(
//                   'images/imageView5_812458.png',
//                   width: 40,
//                   height: 40,
//                   fit: BoxFit.cover,
//                 ),
//               ),
//               Positioned(
//                 left: 28.5,
//                 width: 165,
//                 top: 288,
//                 height: 0.5,
//                 child: Image.asset(
//                   'images/imageView6_2459.png',
//                   width: 165,
//                   height: 0.5,
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
