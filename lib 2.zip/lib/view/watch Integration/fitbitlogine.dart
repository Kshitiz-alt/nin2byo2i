import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:nin2byo2i/Common/ThemeColor.dart';
import 'package:nin2byo2i/Common/colo_extension.dart';
import 'package:nin2byo2i/Controller/user_profile_controller.dart';
import 'package:nin2byo2i/Language/localization/Language/languages.dart';
import 'package:nin2byo2i/Repository/TokenManagerforWatch.dart';
import 'package:nin2byo2i/Repository/auth_repo.dart';
import 'package:nin2byo2i/view/watch%20Integration/fitbitresp%5Bonse.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:nin2byo2i/Common/appfontsize.dart';

//fitbit login page
class FitbitAuthPage extends StatefulWidget {
  @override
  _FitbitAuthPageState createState() => _FitbitAuthPageState();
}

class _FitbitAuthPageState extends State<FitbitAuthPage> {
  WebViewController? _webViewController;
  String _code = '';
  final UserProfileController _controller = UserProfileController();
  final String clientId = '23RGPC';
  final String redirectUri = 'https://www.nin.res.in/';
  final String authorizationEndpoint =
      'https://www.fitbit.com/oauth2/authorize';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: Text('Fitbit Authentication'),
      // ),
      appBar: AppBar(
        backgroundColor: ThemeManager.themeColor,
        centerTitle: true,
        elevation: 0,
        leading: InkWell(
          onTap: () {
            Navigator.pop(context);
          },
          child: Container(
            margin: const EdgeInsets.all(8),
            height: 40,
            width: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
                color: ThemeManager.themelightColor,
                borderRadius: BorderRadius.circular(10)),
            child: Image.asset(
              "assets/img/black_btn.png", // Replace with your health app logo asset path
              width: 15,
              height: 15,
              color: ThemeManager.themeText,
              fit: BoxFit.contain,
            ),
          ),
        ),
        title: Text(
          Languages.of(context)!.NINTextFitbitAuthentication,
          style: TextStyle(
              color: ThemeManager.themeText,
              fontSize: AppFontSizes.mediumDefault,
              fontWeight: FontWeight.w700),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: WebView(
              initialUrl:
                  '$authorizationEndpoint?client_id=$clientId&response_type=code&code_challenge=nD69oDMMhxF_E9KHtVpPdUgCCQHZfyl_Yw8_C6bHUdY&code_challenge_method=S256&scope=activity%20heartrate%20location%20nutrition%20oxygen_saturation%20profile%20respiratory_rate%20settings%20sleep%20social%20temperature%20weight',
              javascriptMode: JavascriptMode.unrestricted,
              onWebViewCreated: (WebViewController webViewController) {
                _webViewController = webViewController;
              },
              onPageStarted: (String url) {
                // You can add loading indicators or perform actions based on URL changes.
              },
              onPageFinished: (String url) {
                String accessToken;
                String userId;
                // Check if the URL contains the 'code' parameter
                if (url.contains('code=')) {
                  // Extract the code from the URL
                  Uri uri = Uri.parse(url);
                  _code = uri.queryParameters['code'] ?? '';
                  final String apiUrl = 'https://api.fitbit.com/oauth2/token';

                  final String clientId = '23RGPC';

                  // final String code = 'e3e7d820637917fc50eef0b237399c895c41c518';
                  final String codeVerifier =
                      'Q7laS4s0ercASoZu1xLKJUMUB6-XhLUdN2V0epAT5at6CtBK1BB4aTfiaIYfEhc4xMxtQQDsHNYc61wRcwckog';
                  final String grantType = 'authorization_code';
                  // Do something with the code

                  void _postData() async {
                    try {
                      var response = await http.post(
                        Uri.parse(
                            'https://api.fitbit.com/oauth2/token?client_id=$clientId&code=$_code&code_verifier=$codeVerifier&grant_type=authorization_code'),
                        headers: {
                          'Authorization':
                              'Basic MjNSR1BDOmEwMjY1OTE1YjRkZmM5YTcyM2VmOGI1NmMxNTIyMzgw',
                          'Content-Type': 'application/x-www-form-urlencoded',
                        },
                      );

                      if (response.statusCode == 200) {
                        // Successful API call, handle the response
                        // Parse the JSON response
                        Map<String, dynamic> responseData =
                            json.decode(response.body);
                        print("token is herere  kklkm $responseData");
                        // Extract and store the token and user ID
                        accessToken = responseData['access_token'];
                        String ReferToken = responseData['refresh_token'];
                        userId = responseData['user_id'];
                        await TokenManager.saveToken(accessToken);
                        await TokenManager.saveId(userId);
                        await TokenManager.saveRefreshToken(ReferToken);
                        await TokenManager.saveWatchType('Fitbit');
                        await CookieManager().clearCookies();
                        _controller.PostProfileVariableTypeData("Fitbit");
                        // await AuthRepo.storeTokenfit(accessToken);
                        // await AuthRepo.storeidfit(userId);
                        // String? token = await AuthRepo.getTokenfit();
                        // String? idfit = await AuthRepo.getidfit();
                        print('token in id is $ReferToken');
                        // await AuthRepo.storeidfit(userId);
                        // _saveData() async {
                        //   SharedPreferences prefs =
                        //       await SharedPreferences.getInstance();
                        //   prefs.setString('tokenfit', accessToken);
                        //   prefs.setString(
                        //       'userIdfit', userId); // replace with your user ID
                        // }

                        // _saveData();

                        // _loadData() async {
                        //   SharedPreferences prefs =
                        //       await SharedPreferences.getInstance();
                        //   setState(() {
                        //     print(
                        //         'usr is fit${prefs.getInt('userIdfit') ?? 0}');
                        //     print(
                        //         'token is fit${prefs.getString('tokenfit') ?? ""}');
                        //     print(
                        //         'usr is fit${prefs.getInt('userIdfit') ?? 0}');
                        //     // tokenfit = prefs.getString('tokenfit') ?? "";
                        //     // userIdfit = prefs.getInt('userIdfit') ?? 0;
                        //   });
                        // }

                        // _loadData();

                        // Now you can use 'accessToken' and 'userId' as needed
                        print('Access Token: $accessToken');
                        print('User ID: $userId');
                        print('API call successful');
                        print('Response: ${response.body}');
                        final String apiUrl1 =
                            'https://api.fitbit.com/1/user/$userId/profile.json';
                        // final String authToken =
                        //     'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIyM1JHUEMiLCJzdWIiOiJCU1RSWUoiLCJpc3MiOiJGaXRiaXQiLCJ0eXAiOiJhY2Nlc3NfdG9rZW4iLCJzY29wZXMiOiJyc29jIHJzZXQgcm94eSBybnV0IHJwcm8gcnNsZSByYWN0IHJsb2MgcnJlcyByd2VpIHJociBydGVtIiwiZXhwIjoxNzAxMDk3OTY1LCJpYXQiOjE3MDEwNjkxNjV9.Gd18mk5OaoSynxMioTsB1PU6DE7Pa5yVvxNjBTPHjv8';

                        Future<Map<String, dynamic>> fetchData() async {
                          final response =
                              await http.get(Uri.parse(apiUrl1), headers: {
                            'Authorization': 'Bearer $accessToken',
                          });

                          if (response.statusCode == 200) {
                            print('response fat ${response.body}');

                            Map<String, dynamic> responseData1 =
                                json.decode(response.body);
                            Navigator.pop(context);
                            // Navigator.push(
                            //   context,
                            //   MaterialPageRoute(
                            //     builder: (context) => DisplayDataPage(
                            //         responseData: responseData1),
                            //   ),
                            // );
                            return json.decode(response.body);
                          } else {
                            print('response fat ${response.body}');
                            throw Exception('Failed to load data');
                          }
                        }

                        fetchData();
                      } else {
                        // Handle error
                        print('Error: ${response.statusCode}');
                        print('Response: ${response.body}');
                      }
                    } catch (error) {
                      // Handle exceptions
                      print('Error: $error');
                    }
                  }

                  _postData();

                  print('Code: $_code');
                }
              },
            ),
          ),
          SizedBox(height: 20),
          Text(' wait until we will get Code: $_code'),
        ],
      ),
    );
  }
}
