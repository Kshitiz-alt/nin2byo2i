// import 'package:flutter/material.dart';
// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:nin2byo2i/Controller/user_profile_controller.dart';

// class SearchTop10FoodsHere extends StatefulWidget {
//   @override
//   _SearchTop10FoodsHereState createState() => _SearchTop10FoodsHereState();
// }

// class _SearchTop10FoodsHereState extends State<SearchTop10FoodsHere> {
//   List<Map<String, dynamic>> foodData = [];
//   List<Map<String, dynamic>> filteredFoodData = [];

//   @override
//   void initState() {
//     super.initState();
//     fetchData();
//   }

//   final UserProfileController _controller = UserProfileController();
//   Future<void> fetchData() async {
//     try {
//       List<Map<String, dynamic>> data =
//           await _controller.fetchallIngredientsDataFromApi(
//         'total_fat', // Change parameter and type as needed
//         'all', // Change parameter and type as needed
//       );
//       setState(() {
//         print("fdgbfhgfhgg $data");
//         foodData = data;
//         filteredFoodData = data;
//       });
//     } catch (e) {
//       print('Error fetching data: $e');
//     }
//   }

//   void filterFoods(String query) {
//     setState(() {
//       filteredFoodData = foodData
//           .where((food) =>
//               food['food'].toLowerCase().contains(query.toLowerCase()))
//           .toList();
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Food List'),
//         actions: [
//           Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: SizedBox(
//               width: MediaQuery.of(context).size.width * 0.7,
//               child: TextField(
//                 onChanged: (value) => filterFoods(value),
//                 decoration: InputDecoration(
//                   hintText: 'Search',
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//       body: ListView.builder(
//         itemCount: filteredFoodData.length,
//         itemBuilder: (context, index) {
//           final food = filteredFoodData[index];
//           return ListTile(
//             title: Text(food['food']),
//             subtitle: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text('Category: ${food['category']}'),
//                 Text('Protein: ${food['protein']}'),
//                 Text('Energy: ${food['energy']}'),
//                 Text('Fat: ${food['nutritionName']}'),
//               ],
//             ),
//           );
//         },
//       ),
//     );
//   }
// }
