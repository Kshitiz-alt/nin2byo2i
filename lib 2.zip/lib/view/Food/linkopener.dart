import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Links Page'),
        ),
        body: LinksPage(),
      ),
    );
  }
}

class LinksPage extends StatelessWidget {
  // URLs for the three links
  final List<String> urls = [
    'https://example.com/link1',
    'https://example.com/link2',
    'https://example.com/link3',
  ];

  // Function to open the URL in Chrome
  void _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url, forceSafariVC: false, forceWebView: false);
    } else {
      throw 'Could not launch $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Link 1
          ElevatedButton(
            onPressed: () {
              _launchURL(urls[0]);
            },
            child: Text('Open Link 1'),
          ),
          SizedBox(height: 20),
          // Link 2
          ElevatedButton(
            onPressed: () {
              _launchURL(urls[1]);
            },
            child: Text('Open Link 2'),
          ),
          SizedBox(height: 20),
          // Link 3
          ElevatedButton(
            onPressed: () {
              _launchURL(urls[2]);
            },
            child: Text('Open Link 3'),
          ),
        ],
      ),
    );
  }
}
