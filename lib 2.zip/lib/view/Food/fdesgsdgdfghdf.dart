// import 'package:flutter/material.dart';
// import 'dart:convert';
// import 'package:nin2byo2i/Common/ThemeColor.dart';
// import 'package:nin2byo2i/Controller/user_profile_controller.dart';
// import 'package:nin2byo2i/Language/localization/Language/languages.dart';
// import 'package:nin2byo2i/Repository/auth_repo.dart';
// import 'package:nin2byo2i/constants/server.dart';

// class AddFromTop10food extends StatefulWidget {
//   @override
//   _AddFromTop10foodState createState() => _AddFromTop10foodState();
// }

// class _AddFromTop10foodState extends State<AddFromTop10food> {
//   bool checkisAscending = false;
//   bool checkisExpanded = false;
//   String selectedSortOptionforTop10food = "carbohydrate";
//   String selectedTypeforTop10food = "All";
//   List<Map<String, dynamic>> Top10foodList = [];

//   List<Map<String, dynamic>> ingredientList = [
//     {'ingredientName': 'RICE', 'raw': 'milled', 'ingredientQuantity': 200.0},
//     {'ingredientName': 'Jowar', 'ingredientQuantity': 55.0}
//   ];

//   @override
//   void initState() {
//     super.initState();
//     fetchDataFromApi(selectedSortOptionforTop10food, selectedTypeforTop10food);
//   }

//   final UserProfileController controller = UserProfileController();
//   Future<void> fetchDataFromApi(String parameter, String type) async {
//     try {
//       List<Map<String, dynamic>> data =
//           await controller.fetchFstDataFromApi(parameter, type);
//       setState(() {
//         Top10foodList = data;
//         _sortFoodList();
//       });
//     } catch (e) {
//       print('Failed to fetch data: $e');
//       // Handle error
//     }
//   }

//   // Method to sort foodList based on the selected sorting option
//   void _sortFoodList() {
//     Top10foodList.sort((a, b) {
//       if (checkisAscending) {
//         return a['nutritionName'].compareTo(b['nutritionName']);
//       } else {
//         return b['nutritionName'].compareTo(a['nutritionName']);
//       }
//     });
//   }

//   void _showWeightDialog(String foodName) {
//     TextEditingController weightController = TextEditingController();
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title:
//               Text('${Languages.of(context)!.NINTextEnterWeightFor} $foodName'),
//           content: TextFormField(
//             controller: weightController,
//             keyboardType: TextInputType.numberWithOptions(decimal: true),
//             decoration: InputDecoration(
//                 labelText: Languages.of(context)!.mainlabelCookedWeightInG),
//           ),
//           actions: <Widget>[
//             TextButton(
//               onPressed: () {
//                 Navigator.of(context).pop(); // Close the dialog
//               },
//               child: Text(Languages.of(context)!.cancel),
//             ),
//             TextButton(
//               onPressed: () {
//                 // Add the ingredient to the list
//                 setState(() {
//                   ingredientList.add({
//                     'ingredientName': foodName,
//                     'ingredientQuantity': double.parse(weightController.text),
//                   });
//                 });
//                 print("gfffffffffd $ingredientList");
//                 Navigator.of(context).pop(); // Close the dialog
//               },
//               child: Text(Languages.of(context)!.labelSubmit),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: Scaffold(
//         appBar: AppBar(
//           title: Text('Top 10 Foods'),
//         ),
//         body: Column(
//           children: [
//             Padding(
//               padding: const EdgeInsets.all(12.0),
//               child: Container(
//                 decoration: BoxDecoration(
//                   borderRadius: BorderRadius.circular(15.0),
//                   color: ThemeManager.themelightColor.withOpacity(0.5),
//                 ),
//                 child: Column(
//                   children: [
//                     ListTile(
//                       title: Row(
//                         children: [
//                           SizedBox(
//                             width: 300,
//                             child: Text(
//                               'Add Ingredients from top 10 food',
//                               style: TextStyle(color: ThemeManager.themeText),
//                             ),
//                           ),
//                           Spacer(),
//                           Icon(
//                             checkisExpanded
//                                 ? Icons.expand_less
//                                 : Icons.expand_more,
//                             color: ThemeManager.themeText,
//                           ),
//                         ],
//                       ),
//                       onTap: () {
//                         setState(() {
//                           checkisExpanded = !checkisExpanded;
//                         });
//                       },
//                     ),
//                     if (checkisExpanded)
//                       Padding(
//                         padding: const EdgeInsets.all(8.0),
//                         child: Column(
//                           mainAxisSize: MainAxisSize.min,
//                           children: [
//                             Container(
//                               margin: const EdgeInsets.only(bottom: 16.0),
//                               child: DropdownButton<String>(
//                                 value: selectedTypeforTop10food,
//                                 items: <String>[
//                                   'Non-Vegetarian',
//                                   'Vegetarian',
//                                   'All'
//                                 ].map((String value) {
//                                   return DropdownMenuItem<String>(
//                                     value: value,
//                                     child: Text(value),
//                                   );
//                                 }).toList(),
//                                 onChanged: (String? newValue) {
//                                   setState(() {
//                                     selectedTypeforTop10food = newValue!;
//                                     fetchDataFromApi(
//                                         selectedSortOptionforTop10food,
//                                         selectedTypeforTop10food);
//                                   });
//                                 },
//                               ),
//                             ),
//                             Row(
//                               children: [
//                                 DropdownButton<String>(
//                                   value: selectedSortOptionforTop10food,
//                                   items: <String>[
//                                     'selenium',
//                                     'copper',
//                                     'manganese',
//                                     'zinc',
//                                     'magnesium',
//                                     'phosphorus',
//                                     'potassium',
//                                     'iron',
//                                     'total_Fat',
//                                     'carbohydrate',
//                                     'Protein',
//                                     'Total_Dietary_Fibre',
//                                     'cholesterol',
//                                     "sodium",
//                                     'calcium'
//                                   ].map((String value) {
//                                     return DropdownMenuItem<String>(
//                                       value: value.toLowerCase(),
//                                       child: Text(value),
//                                     );
//                                   }).toList(),
//                                   onChanged: (String? newValue) {
//                                     setState(() {
//                                       selectedSortOptionforTop10food =
//                                           newValue!;
//                                       fetchDataFromApi(
//                                           selectedSortOptionforTop10food,
//                                           selectedTypeforTop10food);
//                                     });
//                                   },
//                                 ),
//                                 DropdownButton<String>(
//                                   value: checkisAscending
//                                       ? 'Ascending'
//                                       : 'Descending',
//                                   items: <String>['Ascending', 'Descending']
//                                       .map((String value) {
//                                     return DropdownMenuItem<String>(
//                                       value: value,
//                                       child: Text(value),
//                                     );
//                                   }).toList(),
//                                   onChanged: (String? newValue) {
//                                     setState(() {
//                                       checkisAscending =
//                                           newValue == 'Ascending';
//                                       fetchDataFromApi(
//                                           selectedSortOptionforTop10food,
//                                           selectedTypeforTop10food);
//                                     });
//                                   },
//                                 ),
//                               ],
//                             ),
//                           ],
//                         ),
//                       ),
//                     if (checkisExpanded)
//                       Container(
//                         height: 300, // Set the desired height here
//                         child: SingleChildScrollView(
//                           child: SizedBox(
//                             height:
//                                 300, // Should match the height of the container
//                             child: ListView.builder(
//                               itemCount: Top10foodList.length,
//                               itemBuilder: (context, index) {
//                                 final foodItem = Top10foodList[index];
//                                 return ListTile(
//                                   title: Text(foodItem['food']),
//                                   subtitle:
//                                       Text('${foodItem['nutritionName']}'),
//                                   trailing: ElevatedButton(
//                                     onPressed: () {
//                                       _showWeightDialog(foodItem['food']);
//                                     },
//                                     child: Text('Add'),
//                                   ),
//                                 );
//                               },
//                             ),
//                           ),
//                         ),
//                       )
//                   ],
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
