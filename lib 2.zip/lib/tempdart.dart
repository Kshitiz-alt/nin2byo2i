import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

class CloudinaryApiService {
  final String cloudName;
  final String uploadPreset;

  CloudinaryApiService({required this.cloudName, required this.uploadPreset});

  Future<String?> uploadImage(File imageFile) async {
    final url = Uri.parse(
        'https://api.cloudinary.com/v1_1/$cloudName/image/upload'); // Cloudinary upload endpoint

    // Create the request
    var request = http.MultipartRequest('POST', url)
      ..fields['upload_preset'] = uploadPreset
      ..files.add(await http.MultipartFile.fromPath('file', imageFile.path));

    // Send the request
    var response = await request.send();

    if (response.statusCode == 200) {
      // If successful, extract the image URL from the response
      final responseData = await response.stream.toBytes();
      final responseString = String.fromCharCodes(responseData);
      final jsonMap = jsonDecode(responseString);
      return jsonMap[
          'secure_url']; // Assuming 'secure_url' contains the image URL
    } else {
      // If upload fails, return null
      return null;
    }
  }
}

class CloudinaryImageUploader extends StatefulWidget {
  @override
  _CloudinaryImageUploaderState createState() =>
      _CloudinaryImageUploaderState();
}

class _CloudinaryImageUploaderState extends State<CloudinaryImageUploader> {
  File? _imageFile;
  String? _imageUrl;
  final String cloudName =
      '<your_cloud_name>'; // Replace with your Cloudinary cloud name
  final String uploadPreset =
      '<your_upload_preset>'; // Replace with your Cloudinary unsigned upload preset

  final CloudinaryApiService _apiService = CloudinaryApiService(
      cloudName: '<your_cloud_name>', uploadPreset: '<your_upload_preset>');

  Future<void> _uploadImage() async {
    if (_imageFile == null) return;

    String? imageUrl = await _apiService.uploadImage(_imageFile!);
    if (imageUrl != null) {
      setState(() {
        _imageUrl = imageUrl;
      });
    } else {
      // If upload fails, show an error message
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Error'),
          content: Text('Failed to upload image'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cloudinary Image Uploader'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            if (_imageFile != null)
              Image.file(
                _imageFile!,
                width: 200,
                height: 200,
                fit: BoxFit.cover,
              ),
            ElevatedButton(
              onPressed: () async {
                final pickedFile =
                    await ImagePicker().pickImage(source: ImageSource.gallery);
                if (pickedFile != null) {
                  setState(() {
                    _imageFile = File(pickedFile.path);
                  });
                }
              },
              child: Text('Select Image'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                if (_imageFile != null) {
                  _uploadImage();
                } else {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text('Error'),
                      content: Text('Please select an image first'),
                      actions: <Widget>[
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text('OK'),
                        ),
                      ],
                    ),
                  );
                }
              },
              child: Text('Upload Image'),
            ),
            if (_imageUrl != null)
              SizedBox(
                height: 20,
                child: Text('Uploaded Image URL: $_imageUrl'),
              ),
          ],
        ),
      ),
    );
  }
}
