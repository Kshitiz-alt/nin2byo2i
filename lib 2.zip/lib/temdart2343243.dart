import 'package:flutter/material.dart';
import 'package:nin2byo2i/Controller/user_profile_controller.dart';

class WorkLevelPage extends StatefulWidget {
  @override
  _WorkLevelPageState createState() => _WorkLevelPageState();
}

class _WorkLevelPageState extends State<WorkLevelPage> {
  final UserProfileController _controller = UserProfileController();
  String? _selectedWorkLevel;

  Future<void> _saveWorkLevel() async {
    if (_selectedWorkLevel != null) {
      try {
        await _controller.saveOrUpdateWorkLevel(_selectedWorkLevel!);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Work level updated successfully'),
          ),
        );
        // You can navigate to another page or do other actions upon success
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update work level: $e'),
          ),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please select a work level'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Work Level Page'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            DropdownButtonFormField<String>(
              value: _selectedWorkLevel,
              onChanged: (value) {
                setState(() {
                  _selectedWorkLevel = value;
                });
              },
              items: ["Heavy", "Moderate", "Sedentary"]
                  .map((workLevel) => DropdownMenuItem(
                        value: workLevel,
                        child: Text(workLevel),
                      ))
                  .toList(),
              decoration: InputDecoration(
                labelText: 'Select Work Level',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _saveWorkLevel,
              child: Text('Save Work Level'),
            ),
          ],
        ),
      ),
    );
  }
}
