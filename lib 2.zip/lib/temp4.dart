import 'package:flutter/material.dart';
import 'package:nin2byo2i/Controller/user_profile_controller.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';

class IngredientListPage extends StatefulWidget {
  @override
  _IngredientListPageState createState() => _IngredientListPageState();
}

class _IngredientListPageState extends State<IngredientListPage> {
  Future<List<Map<String, String>>>? _ingredientsList;
  List<Map<String, dynamic>> _submittedIngredients = [];
  TextEditingController ingredientNameController = TextEditingController();
  TextEditingController weightController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadIngredients();
  }

  Future<void> _loadIngredients() async {
    setState(() {
      _ingredientsList = UserProfileController().IngredientsListtemp();
    });
  }

  String foodcodeforIndividualIngredients = '';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ingredients List'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TypeAheadFormField(
              textFieldConfiguration: TextFieldConfiguration(
                controller: ingredientNameController,
                decoration: InputDecoration(
                  labelText: 'Search',
                ),
              ),
              suggestionsCallback: (pattern) {
                return _ingredientsList!.then((ingredients) => ingredients
                    .where((ingredient) => ingredient['foodName']!
                        .toLowerCase()
                        .contains(pattern.toLowerCase()))
                    .toList());
              },
              itemBuilder: (context, suggestion) {
                return ListTile(
                  title: Text(suggestion['foodName'] ?? ''),
                );
              },
              onSuggestionSelected: (suggestion) {
                ingredientNameController.text = suggestion['foodName'] ?? '';
                setState(() {
                  // Set the food code when an ingredient is selected
                  foodcodeforIndividualIngredients =
                      suggestion['foodCode'] ?? '';
                  print("gdfgfdhhfg $foodcodeforIndividualIngredients");
                });
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: weightController,
              decoration: InputDecoration(
                labelText: 'Weight',
              ),
              keyboardType: TextInputType.number,
            ),
          ),
          ElevatedButton(
            onPressed: () {
              // Retrieve the ingredient name and weight
              String ingredientName = ingredientNameController.text;
              String weight = weightController.text;

              // Check if both name and weight are not empty
              if (ingredientName.isNotEmpty && weight.isNotEmpty) {
                // Add the name, food code, and weight to the _submittedIngredients list
                setState(() {
                  _submittedIngredients.add({
                    'ingredientName': ingredientName,
                    'foodCode': foodcodeforIndividualIngredients,
                    'ingredientQuantity': weight,
                  });
                });
//{ingredientName: RICE, raw, milled, ingredientQuantity: 200.0, foodCode: A015}
                // Clear the text fields
                ingredientNameController.clear();
                weightController.clear();
              } else {
                // Show a snackbar or any other UI feedback for empty fields
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content:
                        Text('Please enter both ingredient name and weight.'),
                  ),
                );
              }
            },
            child: Text('Add'),
          ),
        ],
      ),
    );
  }
}
